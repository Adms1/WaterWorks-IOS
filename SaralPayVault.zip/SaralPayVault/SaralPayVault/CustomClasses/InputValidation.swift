//
//  InputValidation.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import Foundation

@objc protocol SuccessFailedDelegate
{
    @objc optional func MobileDuplicateDelegate()
    @objc optional func SuccessFailedStatus()
}

enum VersionError: Error {
    case invalidResponse, invalidBundleInfo
}

extension Notification.Name {
    
    static let remove      = Notification.Name(
        rawValue: "remove")
}

extension UIImage
{
    func compressImage() -> NSData {
        // Reducing file size to a 10th
        
        var actualHeight : CGFloat = self.size.height
        var actualWidth : CGFloat = self.size.width
        let maxHeight : CGFloat = 120.0
        let maxWidth : CGFloat = 100.0
        var imgRatio : CGFloat = actualWidth/actualHeight
        let maxRatio : CGFloat = maxWidth/maxHeight
        var compressionQuality : CGFloat = 0.5
        
        if (actualHeight > maxHeight || actualWidth > maxWidth){
            if(imgRatio < maxRatio){
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight
                actualWidth = imgRatio * actualWidth
                actualHeight = maxHeight;
            }
            else if(imgRatio > maxRatio){
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = maxWidth
            }
            else{
                actualHeight = maxHeight
                actualWidth = maxWidth
                compressionQuality = 1
            }
        }
        
        let rect = CGRect(x:0.0, y:0.0, width:actualWidth, height:actualHeight)
        UIGraphicsBeginImageContext(rect.size)
        self.draw(in: rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        let imageData = UIImageJPEGRepresentation(img!, compressionQuality)
        UIGraphicsEndImageContext()
        
        return imageData! as NSData
    }
}

extension UIViewController {
    func performSegue(_ identifier:String){
        
        self.performSegue(withIdentifier: identifier, sender: self)
    }
    
    func setValues(_ dict:NSDictionary, _ isPush:Bool)
    {
        var date:String!
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        dateFormatter.dateFormat = "dd-MM-yyyy @ h:mm a"
        
        date = dateFormatter.string(from: NSDate() as Date)
        
        let cdvc:ClientDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ClientDetailsViewController") as! ClientDetailsViewController
        cdvc.navigationItem.hidesBackButton = true
        CompanyDetails = ((dict.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as! NSDictionary)
        narration = "This charge is for \(((dict.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "TypeofBussiness") as! String) at \(((dict.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "CompanyName") as! String) on \(date!)"
        UserDefaults.standard.set(((dict.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "CompanyName") as! String, forKey: "CompanyName")
        UserDefaults.standard.set(((dict.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "CustomerID") as! NSNumber, forKey: "CustomerID")
        if isPush {
            self.navigationController?.isNavigationBarHidden = false
            self.navigationController?.pushViewController(cdvc, animated: true)
        }
    }
}

extension Date {
    
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}

extension String {
    var isValidEmail: Bool {
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", options: .caseInsensitive)
            return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count)) != nil
        } catch {
            return false
        }
    }
    
    func toDate( dateFormat format  : String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if let date = dateFormatter.date(from: self)
        {
            return date
        }
        return Date()
    }
}

extension NSDictionary {
    func safeObject(forKey key: String) -> Any {
        let ret: NSObject? = (self[key] as? String as NSObject?)
        if ret == nil {
            return ""
        }
        if (ret is NSNull) {
            return ""
        }
        if (ret is [Any]) || (ret is [Any]) || (ret is [AnyHashable: Any]) || (ret is [AnyHashable: Any]) {
            return ret!
        }
        let strData: String = "\(ret!)"
        return strData
    }
}

var resultValue:NSDictionary!
var delegate:SuccessFailedDelegate?
var supercontroller:UIViewController!

var bundleName               = Bundle.main.infoDictionary?["CFBundleName"] as! String

class InputValidation: NSObject {
    
    enum UIUserInterfaceIdiom : Int
    {
        case Unspecified
        case Phone
        case Pad
    }
    
    struct ScreenSize
    {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
        static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    }
    
    //-----------------------------WEB API----------------------------//
    struct WEB_API
    {
        static var BaseUrl              = "http://www.saralpayonline.com/WebService.asmx/"
        //static var BaseUrl              = "http://developer.saralpayonline.com/WebService.asmx/"
        static var PaymentUrl           = "GeneratePaymentRequest"
        static var UpdatePaymentUrl     = "UpdatePaymentRequest"
        static var TraknPayUrl          = "https://biz.traknpay.in/v1/paymentrequest"
        
        // TODO: - SaralPayVault
        static var ClientLoginUrl       = "ClientLogin"
        static var RegisterUrl          = "CreateClient"
        static var MobilenoUrl          = "ClientDuplicateMobile"
        static var QRScnningUrl         = "GetCustomerDataByQRCodeorMobileno"
        static var CreateAgentUrl       = "CreateCustomerByAgent"
        
        // TODO: - SaralPay
        static var CustomerLoginUrl                     = "CustomerLogin"
        static var CMobilenoUrl                         = "CustomerDuplicateMobile"
        static var CustomerShowpopupUrl                 = "Customer_Showpopup"
        static var GetCustomerAllDetailUrl              = "GetCustomerAllDetail"
        static var Get_KYC_CustomerSuccess_PaymentUrl   = "Get_KYC_CustomerSuccess_Payment"
        static var UpdateCustomerUrl                    = "UpdateCustomer"
        static var ForgotPasswordUrl                    = "GenerateOTPByRegisteredNumber"
        static var CheckOTPUrl                          = "CheckOTPStatus"
        static var PinChangeUrl                         = "UpdateCustomerPin"
        static var GetBusinessTypeUrl                   = "GetBusinessType"
        static var GetStateDetailUrl                    = "GetStateDetail"
        static var CreateCustomerUrl                    = "CreateCustomer"
        static var UpgradeCustomerStatusUrl             = "UpgradeCustomerStatus"
        static var GetMyPaymentDetailUrl                = "GetMyPaymentDetail"
        static var SendSMSToCustomerUrl                 = "SendSMSToCustomer"
        static var VerifyPageUrl                        = "http://saralpayonline.com/terms.aspx"
    }
    
    //----------------------------SUCCESS MSG---------------------------//
    struct MSG
    {
        // ----- Updation Message -----
        
        static let appUpdateTitle:String               = "Update Available"
        static let appUpdateMsg:String                 = "A new version of {} is available. Please update to version () now."
        
        static var Login_MSG            = "Login Successfully"
        static var Register_MSG         = "Registered Successfully"
        static var Mobileno_MSG         = "You have already register with same Mobile no."
        static var Password_MSG         = "Password Changed Successfully"
        static var Upgrade_MSG          = "Congratulations, You have been upgraded to Premium Membership"
        static var KYC_MSG              = "Your KYC Documents have been Uploaded successfully"
        static var SEND_RECEIPT_MSG     = "Receipt Sent Via SMS"
        static var RESENT_MSG           = "Code has been resent to your registered number."
        
        //----------------------------FAILURE MSG---------------------------//
        static var NoRecord_MSG         = "No Records are found"
        static var Client_MSG           = "No Client Available"
        static var Verify_MSG           = "Please Accept the Terms of Service before Proceeding"
        static var NoRegistered_MSG     = "This mobile number is not registered with us. Please enter a registered mobile number."
    }
    
    //-----------------------------FMDB----------------------------//
    struct FMDB
    {
        static var kDATA_STORAGE_PATH   = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        static var kDB_NAME             = "SaralPayVault translation.sqlite"
        static var kDB_PATH             = NSURL(fileURLWithPath: kDATA_STORAGE_PATH).appendingPathComponent(kDB_NAME)?.absoluteString
        static var kSHARED_INSTANCE     = SharedDataManager.sharedDb()
        static var kDATABASE            = kSHARED_INSTANCE?.database
    }
    
    //-----------------------------Constants----------------------------//
    struct Constants
    {
        static var Headertitle      = bundleName.contains("Vault") ? "SARAL PAY CLIENT VAULT" : "SARAL PAY ONLINE"
        static var Email            = "support@saralpayonline.com"
        static var QRError          = "QR Code doesn't match"
        static var Phoneno          = "+917575809733"
        static var  alertTitle      = "Logout"
        static var  alertMessage    = "Are you sure you want to logout?"
        static var  inValidDate     = "Invalid Date"
        
        static var  documentSuccessTitle   = ["Aadhar Card Front Page / PAN Card uploaded successfully", "Aadhar Card Back Page / PAN Card uploaded successfully", "Cheque Book Front Page uploaded successfully"]
        static var  documentTitle          = ["Front Page of Aadhar or PAN Card", "Back Page of Aadhar or PAN Card", "Current Account Cheque Book First Page"]
        static var  documentImages:[UIImage]  = [UIImage.init(named: "placeholder")!, UIImage.init(named: "placeholder")!, UIImage.init(named: "placeholder")!]
    }
    
    //----------------------------CALLING API----------------------------//
    
    class func ApiCalling(web_url:String,param:Any,success_msg:String,failure_msg:String,superview:UIView)
    {
        MBProgressHUD.showAdded(to: superview, animated: true)
        
        //        let HTTPMethod = "GET"
        //        let headers = [
        //            "cache-control": "no-cache",
        //            "postman-token": "f18b76f0-1515-1155-7106-82e7187525c1"
        //        ]
        //
        //        let request = NSMutableURLRequest(url: NSURL(string: web_url)! as URL,
        //                                          cachePolicy: .useProtocolCachePolicy,
        //                                          timeoutInterval: 60.0)
        //
        //        request.httpMethod = HTTPMethod
        //        request.allHTTPHeaderFields = headers
        //        request.httpBody = try! JSONSerialization.data(withJSONObject: param, options: [])
        //
        //        let session = URLSession.shared
        //        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
        //            if (error != nil) {
        //                print(error!)
        //            } else {
        //                let httpResponse = response as? HTTPURLResponse
        //                print(httpResponse!)
        //            }
        //        })
        //
        //        dataTask.resume()
        
        let manager = AFHTTPRequestOperationManager()
        manager.post(web_url, parameters: param, success: { (operation:AFHTTPRequestOperation?, response:Any?) in
            
            print(response.debugDescription)
            
            let result:String = (response as! NSDictionary).safeObject(forKey: "Success") as! String
            
            if(complareTwoString(str1: result, str2: "True"))
            {
                InputValidation.Toast(msg: success_msg)
                if(((response as! NSDictionary).value(forKey: bundleName.contains("Vault") ? "ClientDetail" : "CustomerDetail")) != nil)
                {
                    if(!bundleName.contains("Vault")){
                        if(((response as! NSDictionary).value(forKey: "CustomerDetail")! as AnyObject).objectAt(0).value(forKey: "CustomerID") != nil)
                        {
                            UserDefaults.standard.set(((response as! NSDictionary).value(forKey: "CustomerDetail")! as AnyObject).objectAt(0).value(forKey: "CustomerID"), forKey: "ClientID")
                        }
                    }
                    else {
                        if(((response as! NSDictionary).value(forKey: "ClientDetail")! as AnyObject).objectAt(0).value(forKey: "ClientID") != nil)
                        {
                            UserDefaults.standard.set(((response as! NSDictionary).value(forKey: "ClientDetail")! as AnyObject).objectAt(0).value(forKey: "ClientID"), forKey: "ClientID")
                        }
                    }
                }
            }
            else
            {
                InputValidation.Toast(msg: failure_msg)
            }
            
            callDelegate(dic: response as! NSDictionary, view: superview)
            
        }) { (operation:AFHTTPRequestOperation?, error:Error?) in
            if  error != nil {
                callDelegate(dic: [:], view: superview)
            }
        }
    }
    
    //-------------------------CALLING DELEGATE-------------------------//
    
    class func callDelegate(dic:NSDictionary,view:UIView)
    {
        MBProgressHUD.hide(for: view, animated: true)
        
        resultValue = dic
        if (resultValue.value(forKey: "Phone") != nil || resultValue.value(forKey: "Phone1") != nil)
        {
            delegate?.MobileDuplicateDelegate!()
        }
        else
        {
            delegate?.SuccessFailedStatus!()
        }
    }
    
    //--------------------CALLING MOBILE VALIDATION---------------------//
    
    class func MobilenoValidation(mno:String)->Bool
    {
        var validation_msg:String = ""
        if mno.count == 0
        {
            validation_msg = "Enter a 10 digit phone number"
        }
        else if mno.count < 10
        {
            validation_msg = "Phone no. should be atleast 10 digit."
        }
        if validation_msg.count != 0 {
            Toast(msg: validation_msg)
            return true
        }
        return false
    }
    
    //--------------------CALLING LOGIN VALIDATION---------------------//
    
    class func loginValidation(pno:String,pwd:String)->Bool
    {
        var validation_msg:String = ""
        if !MobilenoValidation(mno: pno)
        {
            if pwd.count == 0
            {
                validation_msg = "Enter a 4 digit pin"
            }
            else if pwd.count < 4
            {
                validation_msg = "Password/Pin should be 4 digits"
            }
            if validation_msg.count != 0 {
                Toast(msg: validation_msg)
                return true
            }
            return false
        }
        return true
    }
    
    //--------------------CALLING PASSWORD VALIDATION---------------------//
    
    class func passwordValidation(pwd:String,cpwd:String)->Bool
    {
        var validation_msg:String = ""
        if pwd.count == 0
        {
            validation_msg = "Enter a 4 digit pin"
        }
        else if pwd.count < 4
        {
            validation_msg = "Pin/Password should be 4 digits"
        }
        else if cpwd.count == 0 || pwd != cpwd
        {
            validation_msg = "Enter Comfirm Password same as Password"
        }
        if validation_msg.count != 0 {
            Toast(msg: validation_msg)
            return true
        }
        return false
    }
    
    
    //-----------------CALLING REGISTRATION VALIDATION------------------//
    
    class func registerValidation(pno:String,eid:String,pwd:String,fname:String,lname:String)->Bool
    {
        var validation_msg:String = ""
        if !MobilenoValidation(mno: pno)
        {
            if eid.count == 0
            {
                validation_msg = "Email Address"
            }
            else if !eid.isValidEmail
            {
                validation_msg = "Valid Email Address"
            }
            else if pwd.count == 0
            {
                validation_msg = "Enter a 4 digit pin"
            }
            else if pwd.count < 4
            {
                validation_msg = "Pin/Password should be 4 digits"
            }
            else if fname.count == 0
            {
                validation_msg = "First Name"
            }
            else if lname.count == 0
            {
                validation_msg = "Last Name"
            }
            if validation_msg.count != 0 {
                validation_msg = "Enter \(validation_msg)"
                Toast(msg: validation_msg)
                return true
            }
            return false
        }
        return true
    }
    
    //--------------CALLING SARAL PAY REGISTRATION VALIDATION----------------//
    
    class func SaralPayRegisterValidation(pno:String,bname:String,btype:String,state:String,city:String,cname:String,pwd:String)->Bool
    {
        var validation_msg:String = ""
        if bname.count == 0
        {
            validation_msg = "Business Name"
        }
        else if btype == "Select Business Type"
        {
            validation_msg = btype
        }
        else if state == "Select State"
        {
            validation_msg = state
        }
        else if city.count == 0
        {
            validation_msg = "City"
        }
        else if cname.count == 0
        {
            validation_msg = "Contact Name"
        }
        else if MobilenoValidation(mno: pno)
        {
            return true
        }
        else if pwd.count == 0
        {
            validation_msg = "Password/Pin"
        }
        else if pwd.count < 4
        {
            validation_msg = "Pin/Password should be 4 digits"
        }
        if validation_msg.count != 0 {
            validation_msg = "Enter \(validation_msg)"
            Toast(msg: validation_msg)
            return true
        }
        return false
    }
    
    //--------------------CALLING CLIENT VALIDATION---------------------//
    
    class func ClientDetailValidation(amount:String,narration:String)->(Bool,NSNumber)
    {
        var finalAmount:NSNumber = 0
        if amount.count != 0 {
            let NumberStr: String = amount
            let Formatter: NumberFormatter = NumberFormatter()
            Formatter.locale = NSLocale(localeIdentifier: "EN") as Locale!
            finalAmount = Formatter.number(from: NumberStr)!
        }
        
        var validation_msg:String = ""
        if amount.count == 0
        {
            validation_msg = "Amount"
        }
        else if(floor(Double(finalAmount)) < 2)
        {
            validation_msg = "Amount can't be less than Rs. 2.00"
        }
        else if narration.count == 0
        {
            validation_msg = "Narration"
        }
        if validation_msg.count != 0 {
            validation_msg = "Enter \(validation_msg)"
            Toast(msg: validation_msg)
            return (true,0)
        }
        return (false,finalAmount)
    }
    
    //--------------------CALLING OTP VALIDATION---------------------//
    
    class func OTPValidation(txtOTP:String, compareText:String)->Bool
    {
        var validation_msg:String = ""
        if txtOTP.count == 0
        {
            validation_msg = "Enter a Sent OTP"
        }
        else if txtOTP != compareText
        {
            validation_msg = "Invalid OTP"
        }
        if validation_msg.count != 0 {
            Toast(msg: validation_msg)
            return true
        }
        return false
    }
    
    //--------------------TOAST---------------------//
    
    class func Toast(msg:String)
    {
        KSToastView.ks_showToast(msg, duration: 3.0)
    }
    
    class func complareTwoString(str1:String,str2:String)->Bool
    {
        if (str1 == "") {
            return false
        }
        if (str2 == "") {
            return false
        }
        if(str1.caseInsensitiveCompare(str2) == ComparisonResult.orderedSame){
            return true
        }
        return false
    }
    
    /*class func GetTranslate(row_id: String) -> String {
     var translation = ""
     if !row_id.isEmpty
     {
     let strgetQuery = "select * from language where rowid = \(row_id)"
     
     let resultSet:FMResultSet = Constants.Appconstants.kDATABASE.executeQuery("\(strgetQuery)", withArgumentsInArray: nil)
     if(UserDefaults.standardUserDefaults().valueForKey("language") != nil)
     {
     Constants.Appconstants.Userlanguage = NSUserDefaults.standardUserDefaults().valueForKey("language") as! String
     }
     while resultSet.next() {
     if (Constants.Appconstants.Userlanguage == "English") {
     translation = resultSet.stringForColumn("col_3")
     }
     else if (Constants.Appconstants.Userlanguage == "Hindi") {
     translation = resultSet.stringForColumn("col_4")
     }
     }
     }
     return translation
     }*/
}

func add(asChildViewController viewController: UIViewController, _ selfVC:UIViewController) {
    
    selfVC.addChildViewController(viewController)
    selfVC.view.addSubview(viewController.view)
    viewController.view.frame = selfVC.view.bounds
    viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    viewController.didMove(toParentViewController: selfVC)
}













/*class func CustomNavigationBar(controller:UIViewController)
 {
 supercontroller = controller
 controller.title = InputValidation.Headertitle
 controller.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white,NSFontAttributeName: UIFont.boldSystemFont(ofSize: 18)]
 controller.navigationController?.navigationBar.barTintColor = UIColor.init(colorLiteralRed: 239.0/255.0, green: 27.0/255.0, blue: 39.0/255.0, alpha: 1.0)
 
 let btn_menu = UIButton(type: .custom)
 btn_menu.setImage(UIImage(named: "menubar"), for: .normal)
 btn_menu.frame = CGRect(x: 0, y: 0, width: (controller.view.frame.size.width*30)/450, height: (controller.view.frame.size.width*30)/414)
 btn_menu.addTarget(self, action: #selector(InputValidation.showMenu), for: .touchUpInside)
 let litem = UIBarButtonItem(customView: btn_menu)
 controller.navigationItem.setLeftBarButtonItems([litem], animated: true)
 
 let btn_logout = UIButton(type: .custom)
 btn_logout.setImage(UIImage(named: "logout"), for: .normal)
 btn_logout.frame = CGRect(x: 0, y: 0, width: (controller.view.frame.size.width*30)/450, height: (controller.view.frame.size.width*30)/414)
 btn_logout.addTarget(self, action: #selector(InputValidation.logOut), for: .touchUpInside)
 let ritem = UIBarButtonItem(customView: btn_logout)
 controller.navigationItem.setRightBarButtonItems([ritem], animated: true)
 }
 
 //MARK: Calling Function
 
 func showMenu()
 {
 menuPopover.dismiss()
 menuPopover = MLKMenuPopover(frame: CGRect(x:8,y:0,width:150,height:135), menuItems: menuItems)
 menuPopover.menuPopoverDelegate = self
 menuPopover.show(in: supercontroller.view)
 }
 
 func logOut()
 {
 supercontroller.navigationController?.popToRootViewController(animated: false)
 }
 
 func menuPopover(_ menuPopover: MLKMenuPopover!, didSelectMenuItemAt selectedIndex: Int)
 {
 menuPopover.dismiss()
 switch selectedIndex {
 case 0:
 let qsvc:QRScannerViewController = supercontroller.storyboard?.instantiateViewController(withIdentifier: "QRScannerViewController") as! QRScannerViewController
 qsvc.navigationItem.hidesBackButton = true
 supercontroller.navigationController?.pushViewController(qsvc, animated: true)
 break
 
 case 1:
 let hvc:HelpViewController = supercontroller.storyboard?.instantiateViewController(withIdentifier: "HelpViewController") as! HelpViewController
 hvc.navigationItem.hidesBackButton = true
 supercontroller.navigationController?.pushViewController(hvc, animated: true)
 break
 
 case 2:
 
 break
 default:
 break
 }
 }*/




