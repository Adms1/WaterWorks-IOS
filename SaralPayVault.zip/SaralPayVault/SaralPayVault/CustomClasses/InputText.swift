//
//  InputText.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

extension UIToolbar {
    
    func ToolbarPiker(mySelect : Selector) -> UIToolbar {
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([ spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        return toolBar
    }
    
}

class InputText: UITextField,UITextFieldDelegate {
    
    var activeTextField: UITextField?
    
    override func awakeFromNib() {
        self.delegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        if(self.textAlignment == NSTextAlignment.left)
        {
            let paddingView = UIView(frame:CGRect(x:0, y:0, width:15, height:15))
            self.leftView = paddingView;
            self.leftViewMode = UITextFieldViewMode.always
        }
        
        //        if(self.keyboardType == UIKeyboardType.numberPad)
        //        {
        //            let toolBar = UIToolbar().ToolbarPiker(mySelect: #selector(dismissPicker))
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputText.dismissPicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let leftButton = UIBarButtonItem(image: UIImage(named: "left"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputText.nextPrevious(sender:)))
        leftButton.tag = -1
        let rightButton = UIBarButtonItem(image: UIImage(named: "right"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(InputText.nextPrevious(sender:)))
        rightButton.tag = -2
        
        toolBar.setItems([leftButton, rightButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        self.inputAccessoryView = toolBar
        //        }
    }
    
    func nextPrevious(sender:UIBarButtonItem)
    {
        if let nextField = self.superview?.viewWithTag(self.tag + (sender.tag != -1 ? (self.tag/10 == 0 ? 1 : 10) : (self.tag/10 == 0 ? -1 : -10))) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            // Not found, so remove keyboard.
            let contentInsets = UIEdgeInsets.zero
            if(self.tag == 100 || self.tag == 2)
            {
                (self.superview as! UIScrollView).contentInset = contentInsets
                (self.superview as! UIScrollView).scrollIndicatorInsets = contentInsets
                (self.superview as! UIScrollView).contentOffset = CGPoint.zero
            }
            self.resignFirstResponder()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if self.placeholder == "OTP" {
            let border = CALayer()
            let width = CGFloat(2.0)
            border.borderColor = UIColor.init(colorLiteralRed: 255.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: 1.0).cgColor
            border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: self.frame.size.height)
            border.borderWidth = width
            self.layer.addSublayer(border)
            self.layer.masksToBounds = true
        }
    }
    
    func dismissPicker() {
        let contentInsets = UIEdgeInsets.zero
        (self.superview as? UIScrollView)?.contentInset = contentInsets
        (self.superview as? UIScrollView)?.scrollIndicatorInsets = contentInsets
        (self.superview as? UIScrollView)?.contentOffset = CGPoint.zero
        self.superview?.endEditing(true)
    }
    
    func keyboardWillShow(_ notification: NSNotification) {
        
        //        var userInfo = notification.userInfo!
        //        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        //        if self.superview != nil && (self.superview?.isKind(of: UIScrollView.classForCoder()))! {
        //            keyboardFrame = (self.superview?.convert(keyboardFrame, to: nil))!
        //
        //            var contentInset:UIEdgeInsets = ((self.superview as? UIScrollView)?.contentInset)!
        //            contentInset.bottom = keyboardFrame.size.height + 30
        //            (self.superview as? UIScrollView)?.contentInset = contentInset
        //        }
        
        var info = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height+10, 0.0)
        (self.superview as? UIScrollView)?.contentInset = contentInsets
        (self.superview as? UIScrollView)?.scrollIndicatorInsets = contentInsets
        var aRect : CGRect = self.superview!.frame
        aRect.size.height -= keyboardSize!.height
        if let activeField = self.activeTextField
        {
            if (!aRect.contains(activeField.frame.origin))
            {
                (self.superview as? UIScrollView)?.scrollRectToVisible(activeField.frame, animated: true)
            }
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        self.dismissPicker()
    }
    
    //MARK: UITextfield Delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextField = nil
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if range.location > 9 && (textField.placeholder?.contains("Phone"))! {
            return false
        }
        else if range.location > 9 && (textField.placeholder?.contains("Mobile"))! {
            return false
        }
        else if range.location > 3 && (textField.placeholder?.contains("Pin"))! {
            return false
        }
        else if (textField.placeholder?.contains("Amount"))! {
            
            let nsString = textField.text as NSString?
            let newString:String = (nsString?.replacingCharacters(in: range, with: string))!
            let sep:[String] = newString.components(separatedBy: ".")
            if(sep.count >= 2){
                let sepStr:String = "\(sep[1])"
                if(!(sepStr.count > 2)){
                    if(sepStr.count == 2 && string == "."){
                        return false
                    }
                    return true
                }else{
                    return false
                }
            }
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let nextField = self.superview?.viewWithTag(self.tag + (self.tag/10 == 0 ? 1 : 10)) as? UITextField {
            nextField.becomeFirstResponder()
        } else {
            // Not found, so remove keyboard.
            self.dismissPicker()
        }
        return true
    }
}
