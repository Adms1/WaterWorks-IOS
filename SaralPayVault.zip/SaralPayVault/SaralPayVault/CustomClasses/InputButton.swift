//
//  InputButton.swift
//  SaralPayVault
//
//  Created by Ankit on 23/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class InputButton: UIButton {
    
    @IBInspectable open var radius:CGFloat = 0.0 {
        didSet {
            self.layer.cornerRadius = radius
        }
    }
    
    override func awakeFromNib() {
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: InputValidation.DeviceType.IS_IPAD ? 25:16)
        
        if self.tag != -1 || self.tag != -2 {
            self.layer.shadowColor = UIColor.black.cgColor
            self.layer.shadowOpacity = 0.2
            self.layer.shadowRadius  = 2.0
            self.layer.shadowOffset  = CGSize(width:0,height:2.0)
        }
        
        if(self.tag == -1 && !bundleName.contains("Vault")){
            
            let attributes : [String: Any] = [
                NSForegroundColorAttributeName : self.titleLabel?.textColor!,
                NSUnderlineStyleAttributeName : NSUnderlineStyle.styleSingle.rawValue]
            
            let attributeString = NSMutableAttributedString(string: "Forgot Password?", attributes: attributes)
            self.setAttributedTitle(attributeString, for: .normal)
            self.contentHorizontalAlignment = .left
        }
    }
}
