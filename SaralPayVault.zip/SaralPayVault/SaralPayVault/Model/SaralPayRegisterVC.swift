//
//  RegisterViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class SaralPayRegisterVC: CustomHeaderBar,SuccessFailedDelegate {
    
    @IBOutlet weak var txtBusinessName:InputText!
    @IBOutlet weak var txtBusinessType:InputText!
    @IBOutlet weak var txtState:InputText!
    @IBOutlet weak var txtCity:InputText!
    @IBOutlet weak var txtContactname:InputText!
    @IBOutlet weak var txtPhone:InputText!
    @IBOutlet weak var txtPassword:InputText!
    
    var dicBusinessType:[String:String] = [:]
    var arrStates:[String] = []
    
    var strBusinessTypeID:String!
    var strState:String!
    
    //MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        delegate = self
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.GetBusinessTypeUrl)", param: [:], success_msg: "", failure_msg:"", superview: self.view)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        for view in self.view.subviews[1].subviews
        {
            if view.isKind(of: InputText.classForCoder()) {
                if(view.tag > 2){
                    (view as! InputText).text = ""
                }else{
                    view.isHidden = false
                    if(view.tag == 1){
                        (view as! InputText).text = "Select Business Type"
                    }else{
                        (view as! InputText).text = "Select State"
                    }
                }
            }else if view.isKind(of: UIDropDown.classForCoder()) {
                view.removeFromSuperview()
            }
        }
    }
    
    func MobileDuplicateDelegate()
    {
        if (resultValue.value(forKey: "Phone1") as! NSArray).count == 0
        {
            let params = ["C_FirstName": txtContactname.text!,
                          "C_LastName": "",
                          "C_Address1": "",
                          "C_Address2": "",
                          "C_Address3": "",
                          "CityName": txtCity.text!,
                          "StateName": txtState.text!,
                          "C_Pincode": "",
                          "C_EmailAddress": "",
                          "C_Phone1": txtPhone.text!,
                          "C_Phone2": "",
                          "C_ID1cardtype": "",
                          "C_ID1number": "",
                          "C_AadharCardFront": "",
                          "C_AadharCardBack": "",
                          "C_ID2cardtype": "",
                          "C_ID2cardnumber": "",
                          "C_ChequeBookFront": "",
                          "C_CompanyName": txtBusinessName.text!,
                          "C_BussinessType": self.strBusinessTypeID,
                          "C_Bankname": "",
                          "C_BranchName": "",
                          "C_BankaccountNo": "",
                          "C_BankIFCcode": "",
                          "C_CreateDate": Date().toString(dateFormat: "dd/MM/yyyy"),
                          "C_ApproxDate": Date().toString(dateFormat: "dd/MM/yyyy"),
                          "C_Status": "pending",
                          "C_TransactionCode": "",
                          "C_Passcode": txtPassword.text!,
                          "ManagerID": "0",
                          "ExecutiveID": "0",
                          ]
            
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.CreateCustomerUrl)", param: params, success_msg: "", failure_msg:"", superview: self.view)
        }
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            if (resultValue.value(forKey: "FinalArray") != nil)
            {
                let array = resultValue.value(forKey: "FinalArray") as! NSArray
                for value in array {
                    let dic:NSDictionary = value as! NSDictionary
                    self.dicBusinessType["\(dic["BusinessType"]!)"] = "\(dic["BusinessTypeID"]!)"
                }
                InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.GetStateDetailUrl)", param: [:], success_msg: "", failure_msg:"", superview: self.view)
            }
            else if (resultValue.value(forKey: "StateData") != nil)
            {
                let array = resultValue.value(forKey: "StateData") as! NSArray
                for value in array {
                    let dic:NSDictionary = value as! NSDictionary
                    self.arrStates.append(dic["StateName"] as! String)
                }
                
                self.view.layoutIfNeeded()
                self.addDropDown(self.view.subviews[1].viewWithTag(1) as! InputText)
                self.addDropDown(self.view.subviews[1].viewWithTag(2) as! InputText)
            }
            else
            {
                dicVerify = resultValue
                self.performSegue("Verify")
            }
        }
    }
    
    //MARK: Button Action
    
    @IBAction func btnProceedPressed(sender:UIButton)
    {
        for txt in self.view.subviews[1].subviews
        {
            if txt.isKind(of: InputText.classForCoder()) {
                txt.resignFirstResponder()
            }
        }
        
        if !InputValidation.SaralPayRegisterValidation(pno: txtPhone.text!, bname: txtBusinessName.text!, btype: txtBusinessType.text!, state: txtState.text!, city: txtCity.text!, cname: txtContactname.text!, pwd: txtPassword.text!)
        {
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.CMobilenoUrl)", param: ["MobileNo":txtPhone.text], success_msg: InputValidation.MSG.Mobileno_MSG, failure_msg:"",  superview: self.view)
        }
    }
    
    func addDropDown(_ txtFld:InputText)
    {
        txtFld.isHidden = true
        let dropDown:UIDropDown = UIDropDown(frame: (txtFld.frame))
        dropDown.options = txtFld.tag == 1 ? Array(dicBusinessType.keys).sorted(by: <) : arrStates
        dropDown.placeholder = txtFld.text
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            txtFld.text = option
            if(txtFld.tag == 1) {
                self.strBusinessTypeID = self.dicBusinessType[option]
            }else{
                self.strState = option
            }
        }
        txtFld.superview?.addSubview(dropDown)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
