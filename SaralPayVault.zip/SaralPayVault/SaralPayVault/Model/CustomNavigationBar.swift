//
//  CustomNavigationBar.swift
//  SaralPayVault
//
//  Created by Ankit on 22/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class NavigationController: UINavigationController
{
    override func awakeFromNib() {
        self.navigationBar.barTintColor = UIColor.init(colorLiteralRed: 255.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: 1.0)
        self.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white,NSFontAttributeName: UIFont.boldSystemFont(ofSize: 18)]
        self.navigationBar.tintColor = .white
    }
}

class CustomNavigationBar: UIViewController,MLKMenuPopoverDelegate {
    
    var menuPopover:MLKMenuPopover!
    var menuItems_vault = ["QR Scan","Help & Support","Log Out"]
    var menuItems = ["Home", "My KYC", "My Report", "Help & Support","Log Out"]
    
    var flag:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(self is MyReportVC) {
            self.navigationController?.isNavigationBarHidden = true
            let value = UIInterfaceOrientation.landscapeLeft.rawValue
            UIDevice.current.setValue(value, forKey: "orientation")
            
            let headerView = self.view.subviews[0]
            let btnMenu:UIButton = headerView.subviews[0].viewWithTag(1) as! UIButton
            btnMenu.addTarget(self, action: #selector(showMenu), for: .touchUpInside)
            
            let btnLogout:UIButton = headerView.subviews[0].viewWithTag(2) as! UIButton
            btnLogout.addTarget(self, action: #selector(logOut), for: .touchUpInside)
            
        }else{
            self.navigationController?.isNavigationBarHidden = false
            let value = UIInterfaceOrientation.portrait.rawValue
            UIDevice.current.setValue(value, forKey: "orientation")
            CustomNavigationBar()
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    func CustomNavigationBar()
    {
        self.title = InputValidation.Constants.Headertitle
        
        let btn_menu = UIBarButtonItem.init(image: UIImage(named: "menubar"), landscapeImagePhone: nil, style: .plain, target: self, action: #selector(showMenu))
        btn_menu.imageInsets = UIEdgeInsetsMake(3, -5, -6, 0)
        self.navigationItem.leftBarButtonItem = btn_menu
        
        let btn_logout = UIBarButtonItem.init(image: UIImage(named: "logout"), landscapeImagePhone: nil, style: .plain, target: self, action: #selector(logOut))
        btn_logout.imageInsets = UIEdgeInsetsMake(3, 0, -6, -5)
        self.navigationItem.rightBarButtonItem = btn_logout
    }
    
    @objc func showMenu()
    {
        if(flag)
        {
            menuPopover.dismiss()
        }
        else
        {
            if(self is HelpViewController){
                menuItems_vault.remove(at: 1)
            }
            
            if(bundleName.contains("Vault")){
                menuPopover = MLKMenuPopover(frame: CGRect(x:((self.view.frame.size.width*30)/450)/2,y:50,width:150,height:self is HelpViewController ? 90:135), menuItems: menuItems_vault)
            }else{
                var strIdentifier:String!
                
                switch(self)
                {
                case is ClientDetailsViewController:
                    strIdentifier = "Home"
                case is MyKYCVC:
                    strIdentifier = "My KYC"
                case is MyReportVC:
                    strIdentifier = "My Report"
                case is HelpViewController:
                    strIdentifier = "Help & Support"
                default:
                    break
                }
                
                if(strIdentifier != nil){
                    let idx:Int? = menuItems.index(of: strIdentifier)
                    if(idx != nil){
                        menuItems.remove(at: idx!)
                    }
                }
                menuPopover = MLKMenuPopover(frame: CGRect(x: self is MyReportVC ? 15 : Int(((self.view.frame.size.width*30)/450)/2)+3,y:50,width:150,height:(menuItems.count * 45)), menuItems: menuItems)
            }
            menuPopover.menuPopoverDelegate = self
            menuPopover.show(in: self.view)
        }
        flag = !flag
    }
    
    @objc func logOut()
    {
        selectedTag = 0
        NotificationCenter.default.post(name: .remove, object: nil)
        var alertController:JLAlertViewController!
        alertController = JLAlertViewController.alertController(InputValidation.Constants.alertTitle, message: InputValidation.Constants.alertMessage, cancelButtonText: "CANCEL", regularButtonText: "YES")
        
        alertController.didDismissBlock = { alertViewController, buttonTapped in
            
            if buttonTapped.rawValue == 1 {
                self.navigationController?.popToRootViewController(animated: false)
            }
            print("TAPPED: \(buttonTapped.rawValue)")
            
        }
        alertController.show()
    }
    
    func menuPopover(_ menuPopover: MLKMenuPopover!, didSelectMenuItemAt selectedIndex: Int)
    {
        for i in 0...2{
            InputValidation.Constants.documentImages[i] = UIImage.init(named: "placeholder")!
        }
        
        flag = false
        menuPopover.dismiss()
        switch selectedIndex {
        case 0:
            if(bundleName.contains("Vault")){
                self.performSegue(menuItems_vault[selectedIndex])
            }else{
                self.performSegue(menuItems[selectedIndex])
            }
            
        case 1:
            if(bundleName.contains("Vault"))
            {
                if(self is HelpViewController) {
                    logOut()
                }else{
                    self.performSegue(menuItems_vault[selectedIndex])
                }
            }
            else{
                self.performSegue(menuItems[selectedIndex])
            }
            
        case 2:
            if(bundleName.contains("Vault")){
                logOut()
            }else{
                self.performSegue(menuItems[selectedIndex])
            }
            
        case 3,4:
            logOut()
            
        default:
            break
        }
    }
    
    @objc func showActionSheet(_ tapGesture:UITapGestureRecognizer?) {
        
        if tapGesture != nil {
            selectedTag = (tapGesture?.view?.tag)!
        }
        
        let actionSheet = UIAlertController(title: "Add Photo!", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Take Photo", style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Choose From Library", style: UIAlertActionStyle.default, handler: { (alert:UIAlertAction!) -> Void in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    func camera()
    {
        let myPickerController = UIImagePickerController()
        myPickerController.delegate = self;
        myPickerController.sourceType = UIImagePickerControllerSourceType.camera
        myPickerController.allowsEditing = true
        self.present(myPickerController, animated: true, completion: nil)
    }
    
    func photoLibrary()
    {
        let myPickerController = UIImagePickerController()
        myPickerController.delegate = self;
        myPickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
        myPickerController.allowsEditing = true
        self.present(myPickerController, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CustomNavigationBar: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let kycVC:MyKYCVC = self.storyboard?.instantiateViewController(withIdentifier: "MyKYCVC") as! MyKYCVC
        InputValidation.Constants.documentImages[selectedTag-1] = info[UIImagePickerControllerEditedImage] as! UIImage
        self.dismiss(animated: true, completion: nil)
        self.navigationController?.pushViewController(kycVC, animated: false)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}

class CustomHeaderBar: UIViewController {
    
    override func viewDidLoad() {
        self.navigationController?.isNavigationBarHidden = false
        CustomNavigationBar()
    }
    
    //MARK: Calling Function
    
    func CustomNavigationBar()
    {
        self.title = InputValidation.Constants.Headertitle
        
        let btn_back = UIBarButtonItem.init(image: UIImage(named: "back_button"), landscapeImagePhone: nil, style: .plain, target: self, action: #selector(popOut))
        btn_back.imageInsets = UIEdgeInsetsMake(3, -5, -6, 0)
        self.navigationItem.leftBarButtonItem = btn_back
    }
    
    @objc func popOut()
    {
        self.navigationController?.popViewController(animated: true)
    }
}
