//
//  ChangePasswordVC.swift
//  SaralPay
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ChangePasswordVC: CustomHeaderBar, SuccessFailedDelegate {
    
    @IBOutlet weak var txtPassword:InputText!
    @IBOutlet weak var txtComfirmPassword:InputText!
    
    //MARK: Button Action
    
    @IBAction func btnChangePasswordPressed(sender:UIButton)
    {
        if sender.tag == 1 {
            self.popOut()
            return
        }
        
        delegate = self
        if InputValidation.passwordValidation(pwd: txtPassword.text!, cpwd: txtComfirmPassword.text!)
        {
            return
        }
        
        let params = ["CustomerID": UserDefaults.standard.value(forKey: "CustomerID") as! NSNumber,
                      "NewPin": txtPassword.text!] as [String : Any]
        
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.PinChangeUrl)", param: params, success_msg: InputValidation.MSG.Password_MSG, failure_msg:"",  superview: self.view)
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            //InputValidation.Toast(msg: InputValidation.MSG.Password_MSG)
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
