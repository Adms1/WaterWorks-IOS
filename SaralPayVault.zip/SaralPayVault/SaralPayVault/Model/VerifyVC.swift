//
//  VerifyVC.swift
//  SaralPay
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

var dicVerify:NSDictionary!
class VerifyVC: CustomHeaderBar {
    
    @IBOutlet weak var webview: UIWebView!

    //MARK: View Life Cycle

    override func viewWillAppear(_ animated: Bool)
    {
        let url = URL(string: InputValidation.WEB_API.VerifyPageUrl)
        webview.loadRequest(URLRequest(url: url!))
        
        for checkBox in (self.view.subviews.flatMap{$0 as? VKCheckbox})
        {
            checkBox.line             = .normal
            checkBox.bgColorSelected  = UIColor.init(colorLiteralRed: 255.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: 1.0)
            checkBox.color            = .white
            checkBox.borderWidth      = 1.0
            checkBox.setOn(false, animated: true)
            
            checkBox.checkboxValueChangedBlock = {
                isOn in
                checkBox.setOn(isOn, animated: true)
            }
        }
        
        for lbl in (self.view.subviews.flatMap{$0 as? UILabel})
        {
            let tap:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapOnCheckBox(_:)))
            lbl.addGestureRecognizer(tap)
        }
    }
    
    func tapOnCheckBox(_ gesture:UIGestureRecognizer)
    {
        let tag = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : gesture.view?.tag
        let checkBox:VKCheckbox = self.view.viewWithTag(tag!) as! VKCheckbox
        checkBox.setOn(!checkBox.isOn(), animated: true)
    }
    
    @IBAction func btnProceedPressed(sender:UIButton)
    {
        for checkBox in (self.view.subviews.flatMap{$0 as? VKCheckbox})
        {
            if(!checkBox.isOn()){
                InputValidation.Toast(msg: InputValidation.MSG.Verify_MSG)
                return
            }
        }
        self.performSegue("ThankYou")
        InputValidation.Toast(msg: InputValidation.MSG.Register_MSG)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK: WEBVIEW DELEGATE

extension VerifyVC: UIWebViewDelegate
{
    func webViewDidStartLoad(_ webView: UIWebView)
    {
        (view.viewWithTag(-1) as! UIActivityIndicatorView).startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        (view.viewWithTag(-1) as! UIActivityIndicatorView).stopAnimating()
        (view.viewWithTag(-1) as! UIActivityIndicatorView).hidesWhenStopped = true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error)
    {
        (view.viewWithTag(-1) as! UIActivityIndicatorView).stopAnimating()
        (view.viewWithTag(-1) as! UIActivityIndicatorView).hidesWhenStopped = true
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if navigationType == UIWebViewNavigationType.linkClicked {
            UIApplication.shared.openURL(request.url!)
            return false
        }
        return true
    }
}
