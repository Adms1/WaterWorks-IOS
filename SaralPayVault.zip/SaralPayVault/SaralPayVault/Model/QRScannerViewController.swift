//
//  QRScannerViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 21/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var str_pwd:String!
class QRScannerViewController: UIViewController,SuccessFailedDelegate{
    
    @IBOutlet weak var txtPhone:InputText!
    @IBOutlet weak var lbl:UILabel!
    
    var str_typeOfbusiness:String!
    var date:String!
    var dateFormatter = DateFormatter()
    var flag:Bool = false
    
    //MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        CustomNavigationBar()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        txtPhone.text = ""
    }
    
    //MARK: Calling Function
    
    func CustomNavigationBar()
    {
        self.title = InputValidation.Constants.Headertitle
        
        let btn_logout = UIButton(type: .custom)
        btn_logout.setImage(UIImage(named: "logout"), for: .normal)
        btn_logout.frame = CGRect(x: 0, y: 0, width: (self.view.frame.size.width*30)/450, height: (self.view.frame.size.width*30)/414)
        btn_logout.addTarget(self, action: #selector(QRScannerViewController.logOut), for: .touchUpInside)
        let item = UIBarButtonItem(customView: btn_logout)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    func logOut()
    {
        var alertController:JLAlertViewController!
        alertController = JLAlertViewController.alertController(InputValidation.Constants.alertTitle, message: InputValidation.Constants.alertMessage, cancelButtonText: "CANCEL", regularButtonText: "YES")
        
        alertController.didDismissBlock = { alertViewController, buttonTapped in
            
            if buttonTapped.rawValue == 1 {
                self.navigationController?.popToRootViewController(animated: false)
            }
        }
        alertController.show()
    }
    
    func goToQRScannerView(sby:String,sinput:String)
    {
        let svc:ScannerViewController = self.storyboard?.instantiateViewController(withIdentifier: "ScannerViewController") as! ScannerViewController
        svc.searchby = sby
        svc.searchinput = sinput
        svc.navigationItem.hidesBackButton = true
        self.navigationController?.pushViewController(svc, animated: true)
    }
    
    //MARK: Button Action
    
    @IBAction func btnQRPressed(sender:UIButton)
    {
        if sender.tag == 1
        {
            if InputValidation.MobilenoValidation(mno: txtPhone.text!)
            {
                return
            }
            delegate = self
            let params = ["SearchInput":txtPhone.text!,"SearchBy":"M"]
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.QRScnningUrl)", param:params, success_msg: "", failure_msg:InputValidation.MSG.Client_MSG,superview: self.view)
        }
        else{
            goToQRScannerView(sby: "Q",sinput: "")
        }
    }
    
    func SuccessFailedStatus()
    {
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        dateFormatter.dateFormat = "dd-MM-yyyy @ h:mm a"
        dateFormatter.amSymbol = "AM"
        dateFormatter.pmSymbol = "PM"
        
        date = dateFormatter.string(from: NSDate() as Date)
        
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            let cdvc:ClientDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ClientDetailsViewController") as! ClientDetailsViewController
            cdvc.navigationItem.hidesBackButton = true
            if flag
            {
                let params = ["SearchInput":txtPhone.text!,"SearchBy":"M"]
                InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.QRScnningUrl)", param:params, success_msg: "", failure_msg:InputValidation.MSG.Client_MSG,superview: self.view)
                flag = false
            }
            else {
                self.setValues(resultValue, true)
            }
        }
        else
        {
            dateFormatter.dateFormat = "dd/MM/yyyy"
            date = dateFormatter.string(from: NSDate() as Date)
            flag = true
            
            var alertController:JLAlertViewController!
            alertController = JLAlertViewController.alertController("Confirmation", message: "Are you sure you want to register this no. \(txtPhone.text!)?", cancelButtonText: "CANCEL", regularButtonText: "YES")
            
            alertController.didDismissBlock = { alertViewController, buttonTapped in
                
                if buttonTapped.rawValue == 1 {
                    let params = ["C_CreateDate":self.date,
                                  "C_EmailAddress":"",
                                  "C_AadharCardBack":"",
                                  "C_ApproxDate":self.date,
                                  "C_Phone1":self.txtPhone.text!,
                                  "C_Address3":"",
                                  "C_FirstName":"New_Merchant",
                                  "QRCodeID":"0",
                                  "C_LastName":"New_Merchant",
                                  "ManagerID":"0",
                                  "C_Phone2":"",
                                  "C_Status":"pending",
                                  "C_Address1":"",
                                  "C_Passcode":"1234",
                                  "C_CompanyName":"New_Merchant",
                                  "C_AadharCardFront":"",
                                  "C_ID1cardtype":"",
                                  "C_Address2":"",
                                  "ExecutiveID":"0",
                                  "C_ID2cardnumber":"0",
                                  "C_Bankname":"",
                                  "C_ChequeBookFront":"",
                                  "C_Pincode":"",
                                  "C_ID2cardtype":"",
                                  "C_BranchName":"",
                                  "StateName":"Gujarat",
                                  "C_BussinessType":"1",
                                  "CityName":"Ahmedabad",
                                  "C_BankaccountNo":"",
                                  "C_ID1number":"",
                                  "C_TransactionCode":"",
                                  "C_BankIFCcode":"",
                                  ] as [String : Any]
                    
                    InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.CreateAgentUrl)", param:params, success_msg: "", failure_msg:InputValidation.MSG.Client_MSG,superview: self.view)
                }
            }
            alertController.show()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
