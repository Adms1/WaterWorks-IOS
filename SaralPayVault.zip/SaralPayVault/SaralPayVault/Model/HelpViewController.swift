
//
//  HelpViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 21/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import MessageUI

class HelpViewController: CustomNavigationBar,UITextViewDelegate, MFMailComposeViewControllerDelegate {
    
    @IBOutlet weak var txtEmail_Phoneno:UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtEmail_Phoneno.text = "Email : \(InputValidation.Constants.Email)\n\nPhone : \(InputValidation.Constants.Phoneno)"
        
        let attributedString = NSMutableAttributedString(string: "Email : \(InputValidation.Constants.Email)\n\nPhone : \(InputValidation.Constants.Phoneno)")
        let linkRange1 = (attributedString.string as NSString).range(of: InputValidation.Constants.Email)
        let linkRange2 = (attributedString.string as NSString).range(of: InputValidation.Constants.Phoneno)
        attributedString.addAttribute(NSLinkAttributeName, value: InputValidation.Constants.Email, range: linkRange1)
        attributedString.addAttribute(NSLinkAttributeName, value: InputValidation.Constants.Phoneno, range: linkRange2)
        let linkAttributes: [String : Any] = [
            NSForegroundColorAttributeName: UIColor.init(colorLiteralRed: 53.0/255.0, green: 153.0/255.0, blue: 174.0/255.0, alpha: 1.0),
            NSUnderlineColorAttributeName: UIColor.init(colorLiteralRed: 53.0/255.0, green: 153.0/255.0, blue: 174.0/255.0, alpha: 1.0),
            NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue]
        
        txtEmail_Phoneno.linkTextAttributes = linkAttributes
        txtEmail_Phoneno.attributedText = attributedString
        txtEmail_Phoneno.font = UIFont.boldSystemFont(ofSize: 16)
        txtEmail_Phoneno.delegate = self
    }
    
    //MARK: Calling Function
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange) -> Bool
    {
        print(URL)
        if(URL.absoluteString.contains("+"))
        {
            if let url = NSURL(string: "tel://\(URL.absoluteString)"), UIApplication.shared.canOpenURL(url as URL) {
                UIApplication.shared.openURL(url as URL)
            }
        }
        else
        {
            sendEmail(eid: URL.absoluteString)
        }
        return true
    }
    
    func sendEmail(eid:String)
    {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients([eid])
            //            mail.setMessageBody("<p>!</p>", isHTML: true)
            
            present(mail, animated: true)
        } else {
            // show failure alert
            showSendMailErrorAlert()
        }
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
