//
//  MyReportVC.swift
//  SaralPayVault
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

class MyReportVC: CustomNavigationBar,SuccessFailedDelegate {
    
    @IBOutlet var tblPaymentData:UITableView!
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    
    var btnDate:UIButton!
    var arrPaymentDetails:[[String]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        //UIApplication.shared.setStatusBarHidden(false, with: .none)
        //        for view in self.view.subviews {
        //            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
        //                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        //            }
        //        }
        //        self.callPaymentDetailsApi()
    }
    
    func callPaymentDetailsApi()
    {
        delegate = self
        let params = ["CustomerID": (CompanyDetails.value(forKey: "CustomerID") as! NSNumber).stringValue,
                      "FromDate": (btnStartDate.titleLabel?.text)!,
                      "ToDate": (btnEndDate.titleLabel?.text)!]
        
        print(params)
        
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.GetMyPaymentDetailUrl)", param: params, success_msg: "", failure_msg:InputValidation.MSG.NoRecord_MSG,  superview: self.view)
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            if (resultValue.value(forKey: "FinalArray") != nil)
            {
                let array = resultValue.value(forKey: "FinalArray") as! NSArray
                
                arrPaymentDetails = []
                for value in array {
                    let dic:NSDictionary = value as! NSDictionary
                    
                    var arrDetails:[String] = []
                    arrDetails.append(dic["PaymentDate"] as! String)
                    arrDetails.append(dic["Trans_PaymentID"] as! String)
                    arrDetails.append(dic["Trans_Amount"] as! String)
                    arrDetails.append(dic["PaymentStatus"] as! String)
                    
                    arrPaymentDetails.append(arrDetails)
                }
                self.tblPaymentData.reloadData()
            }
        }
    }
    
    @IBAction func btnChooseDateAction(_ sender:UIButton)
    {
        btnDate = sender
        
        var strDate:Date = Date()
        if(!(btnDate.titleLabel?.text?.contains("Date"))!){
            strDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        }
        
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = strDate
        selector.optionCurrentDateRange.setStartDate(strDate)
        selector.optionCurrentDateRange.setEndDate(strDate)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnShowAction(_ sender:UIButton)
    {
        if(((btnStartDate.titleLabel?.text)?.contains("Date"))!){
            InputValidation.Toast(msg: "Please Select Start Date")
            return
            
        }else if(((btnEndDate.titleLabel?.text)?.contains("Date"))!){
            InputValidation.Toast(msg: "Please Select End Date")
            return
        }
        self.callPaymentDetailsApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MyReportVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell:TableCell = tableView.dequeueReusableCell(withIdentifier: "HeaderCell") as! TableCell
        return arrPaymentDetails.count > 0 ? cell.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrPaymentDetails.count > 0 ? 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPaymentDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableCell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableCell
        cell.displayPaymentData(arrPaymentDetails[indexPath.row])
        return cell
    }
}

extension MyReportVC:WWCalendarTimeSelectorProtocol
{
    // MARK: Calender Delegate
    
    func WWCalendarTimeSelectorShouldSelectDate(_ selector: WWCalendarTimeSelector, date: Date) -> Bool {
        if date.timeIntervalSinceNow.sign == .minus || date.toString(dateFormat: "dd/MM/yyyy") == Date().toString(dateFormat: "dd/MM/yyyy") {
            //myDate is earlier than Now (date and time)
            return true
        } else {
            //myDate is equal or after than Now (date and time)
            return false
        }
    }
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        if(btnStartDate == btnDate)
        {
            if(!((btnEndDate.titleLabel?.text)?.contains("Date"))!){
                if(dateFormatter.date(from: (btnEndDate.titleLabel?.text)!)?.compare(date) == .orderedAscending)
                {
                    InputValidation.Toast(msg: InputValidation.Constants.inValidDate)
                    return
                }
            }
        }
        else
        {
            if(!((btnStartDate.titleLabel?.text)?.contains("Date"))!){
                if(dateFormatter.date(from: (btnStartDate.titleLabel?.text)!)?.compare(date) == .orderedDescending)
                {
                    InputValidation.Toast(msg: InputValidation.Constants.inValidDate)
                    return
                }
            }
        }
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}

class TableCell:UITableViewCell{
    
    func displayPaymentData(_ array:[String])
    {
        var i = 0
        for lbl in (self.contentView.subviews.flatMap{$0 as? UILabel}) {
            
            lbl.text = array[i]
            i += 1
        }
    }
}
