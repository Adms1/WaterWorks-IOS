//
//  SubmitOTPVC.swift
//  SaralPay
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

protocol SubmitOTPVCDelegate {
    func resendOTP()
    func confirmOTP()
}

class SubmitOTPVC: UIViewController, SuccessFailedDelegate {
    
    @IBOutlet weak var txtOTP:InputText!
    var submitDelegate:SubmitOTPVCDelegate!
    var dicOTP:NSDictionary!
    
    //MARK: View Life Cycle
    
    override func viewWillAppear(_ animated: Bool) {
        txtOTP.text = nil
    }
    
    func callConfirmApi()
    {
        delegate = self
        let strCustomerID = dicOTP.value(forKey: "CustomerID") as! String
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.CheckOTPUrl)", param: ["CutomerID":strCustomerID], success_msg: "", failure_msg:"",  superview: self.view)
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            submitDelegate.confirmOTP()
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
        }
    }
    
    @IBAction func btnClicked(_ sender:UIButton)
    {
        switch sender.tag {
        case 1:
            submitDelegate.resendOTP()
            
        case 2:
            let strOTP = dicOTP.value(forKey: "OTP") as! String
            if(!InputValidation.OTPValidation(txtOTP: txtOTP.text!, compareText: strOTP))
            {
                self.callConfirmApi()
            }
        default:
            break
        }
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

