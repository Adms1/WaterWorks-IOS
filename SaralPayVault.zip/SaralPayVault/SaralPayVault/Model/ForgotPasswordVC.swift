//
//  ForgotPasswordVC.swift
//  SaralPayVault
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ForgotPasswordVC: CustomHeaderBar, SuccessFailedDelegate {
    
    @IBOutlet weak var txtPhone:InputText!
    var flag:Bool = false
    
    //MARK: Button Action
    
    override func viewWillDisappear(_ animated: Bool) {
        txtPhone.text = nil
    }
    
    @IBAction func btnSendOTPPressed(sender:UIButton?)
    {
        self.view.endEditing(true)
        delegate = self
        if InputValidation.MobilenoValidation(mno: txtPhone.text!)
        {
            return
        }
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.ForgotPasswordUrl)", param: ["Mobile":txtPhone.text], success_msg: "", failure_msg:InputValidation.MSG.NoRegistered_MSG,  superview: self.view)
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            if flag {
                InputValidation.Toast(msg: InputValidation.MSG.RESENT_MSG)
            }
            add(asChildViewController: self.submitOTPVC, self)
        }
    }
    
    lazy var submitOTPVC: SubmitOTPVC = {
        
        var viewController:SubmitOTPVC = self.storyboard?.instantiateViewController(withIdentifier: "SubmitOTPVC") as! SubmitOTPVC
        viewController.submitDelegate = self
        viewController.dicOTP = resultValue
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ForgotPasswordVC: SubmitOTPVCDelegate
{
    func resendOTP() {
        flag = true
        self.btnSendOTPPressed(sender: nil)
    }
    
    func confirmOTP() {
        self.performSegue("Change Password")
    }
}
