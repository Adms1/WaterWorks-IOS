//
//  ViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import CoreLocation

var currentLocation: CLLocation!
var dictCustomerDetails:NSDictionary!

class ViewController: UIViewController ,SuccessFailedDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var txtPhone:InputText!
    @IBOutlet weak var txtPassword:InputText!
    public var locationManager = CLLocationManager()
    
    //MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        self.navigationController?.isNavigationBarHidden = true
        
        //        locationManager.requestWhenInUseAuthorization()
        //        
        //        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.denied)
        //        {
        //            print("DENIED")
        //            UIApplication.shared.openURL(URL.init(string: UIApplicationOpenSettingsURLString)!)
        //        }
        //        
        //        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
        //            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways){
        //            currentLocation = locationManager.location
        //            
        //        }
        
        if(bundleName.contains("Vault")){
            if(UserDefaults.standard.value(forKey: "VaultPhone") != nil){
                txtPhone.text = UserDefaults.standard.value(forKey: "VaultPhone") as! String?
            }
        }else{
            if(UserDefaults.standard.value(forKey: "PayPhone") != nil){
                txtPhone.text = UserDefaults.standard.value(forKey: "PayPhone") as! String?
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        for txt in self.view.subviews[1].subviews
        {
            if txt.isKind(of: InputText.classForCoder()) {
                (txt as! InputText).text = ""
            }
        }
    }
    
    //MARK: Calling Function
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True" {
            if(bundleName.contains("Vault")){
                UserDefaults.standard.set(txtPhone.text, forKey: "VaultPhone")
                str_pwd = txtPassword.text
                self.performSegue("QRScan")
            }
            else {
                if (resultValue.value(forKey: "CustomerDetail") != nil)
                {
                    let dict = (resultValue.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as! NSDictionary
                    
                    if (dict.value(forKey: "PopupStatus") != nil)
                    {
                        if(dict.value(forKey: "PopupStatus") as! String == "0"){
                            selectedTag = -1
                            self.setValues(dictCustomerDetails, true)
                        }
                        else if(dict.value(forKey: "PopupStatus") as! String == "1"){
                        }
                        else{
                            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.GetCustomerAllDetailUrl)", param: ["CutomerID": (((dictCustomerDetails.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "CustomerID") as! NSNumber).stringValue], success_msg: "", failure_msg: "", superview: self.view)
                        }
                    }
                    else
                    {
                        UserDefaults.standard.set(txtPhone.text, forKey: "PayPhone")
                        dictCustomerDetails = [:]
                        dictCustomerDetails = resultValue
                        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.CustomerShowpopupUrl)", param: ["CustomerID": (dict.value(forKey: "CustomerID") as! NSNumber).stringValue], success_msg: "", failure_msg: "", superview: self.view)
                    }
                }
                else
                {
                    if (resultValue.value(forKey: "ExecutiveData") != nil)
                    {
                        let dict = (resultValue.value(forKey: "ExecutiveData")! as! NSArray).object(at: 0) as! NSDictionary
                        dicCustomerAllDetails = [:]
                        dicCustomerAllDetails = dict
                        
                        arrDocumentCount = []
                        if(dict["C_AadharCardFront"] as! String != ""){
                            arrDocumentCount.append(1)
                        }else{
                            selectedTag = 1
                        }
                        
                        if(dict["C_AadharCardBack"] as! String != ""){
                            arrDocumentCount.append(2)
                        }else{
                            selectedTag = 2
                        }
                        
                        if(dict["C_ChequeBookFront"] as! String != ""){
                            arrDocumentCount.append(3)
                        }else{
                            selectedTag = 3
                        }
                        add(asChildViewController: self.verifyPopUpVC, self)
                    }
                }
            }
        }
    }
    
    lazy var verifyPopUpVC: VerifyPopUpVC = {
        
        var viewController:VerifyPopUpVC = self.storyboard?.instantiateViewController(withIdentifier: "VerifyPopUpVC") as! VerifyPopUpVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    //MARK: Button Action
    
    @IBAction func btnLoginPressed(sender:InputButton)
    {
        delegate = self
        
        for txt in self.view.subviews[1].subviews
        {
            if txt.isKind(of: InputText.classForCoder()) {
                txt.resignFirstResponder()
            }
        }
        
        if !InputValidation.loginValidation(pno: txtPhone.text!, pwd: txtPassword.text!)
        {
            let params = ["MobileNo":txtPhone.text,"Passcode":txtPassword.text]
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(bundleName.contains("Vault") ? InputValidation.WEB_API.ClientLoginUrl : InputValidation.WEB_API.CustomerLoginUrl)", param: params, success_msg: InputValidation.MSG.Login_MSG, failure_msg:InputValidation.MSG.Client_MSG, superview: self.view)
        }
    }
    
    @IBAction func btnForgotPasswordPressed(sender:InputButton)
    {
        if(sender.titleLabel?.text != "Saral Vault"){
            self.performSegue("Forgot Password")
        }
    }
    
    @IBAction func btnRegisterPressed(sender:InputButton)
    {
        if(bundleName.contains("Vault")){
            self.performSegue("Register")
        }else{
            self.performSegue("SaralPayRegister")
        }
    }
    
    @IBAction func btnLinkPressed(sender:InputButton)
    {
        guard let url = URL(string: "http://www.admsonline.com") else {
            return //be safe
        }
        
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

