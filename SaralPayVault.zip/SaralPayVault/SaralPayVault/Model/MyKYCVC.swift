//
//  MyKYCVC.swift
//  SaralPay
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

var selectedTag:NSInteger = 0
var dicCustomerAllDetails:NSDictionary!

class MyKYCVC: CustomNavigationBar, SuccessFailedDelegate {
    
    @IBOutlet var tblDocument:UITableView!
    var selectedDocument:UIImage!
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        self.view.subviews[0].isHidden = selectedTag == -1 ? true : false
    }
    
    @IBAction func btnProceedPressed(sender:UIButton)
    {
        delegate = self
        var strAadharFront:String = ""
        var strAadharBack:String = ""
        var strChequeBookFront:String = ""
        
        if(dicCustomerAllDetails.value(forKey: "C_AadharCardFront") as! String == "")
        {
            if(InputValidation.Constants.documentImages[0] != UIImage.init(named: "placeholder")!)
            {
                let imageData = InputValidation.Constants.documentImages[0].compressImage()
                strAadharFront = imageData.base64EncodedString(options: .lineLength64Characters)
            }
        }
        
        if(dicCustomerAllDetails.value(forKey: "C_AadharCardBack") as! String == "")
        {
            if(InputValidation.Constants.documentImages[1] != UIImage.init(named: "placeholder")!)
            {
                let imageData = InputValidation.Constants.documentImages[1].compressImage()
                strAadharBack = imageData.base64EncodedString(options: .lineLength64Characters)
            }
        }
        
        if(dicCustomerAllDetails.value(forKey: "C_ChequeBookFront") as! String == "")
        {
            if(InputValidation.Constants.documentImages[2] != UIImage.init(named: "placeholder")!)
            {
                let imageData = InputValidation.Constants.documentImages[2].compressImage()
                strChequeBookFront = imageData.base64EncodedString(options: .lineLength64Characters)
            }
        }
        
        let params = ["CustomerID": UserDefaults.standard.value(forKey: "CustomerID") as! NSNumber,
                      "C_FirstName": dicCustomerAllDetails.value(forKey: "C_FirstName") as! String,
                      "C_LastName": dicCustomerAllDetails.value(forKey: "C_LastName") as! String,
                      "C_Address1": dicCustomerAllDetails.value(forKey: "C_Address1") as! String,
                      "C_Address2": dicCustomerAllDetails.value(forKey: "C_Address2") as! String,
                      "C_Address3": dicCustomerAllDetails.value(forKey: "C_Address2") as! String,
                      "CityName": dicCustomerAllDetails.value(forKey: "Fk_CityID") as! String,
                      "StateName": dicCustomerAllDetails.value(forKey: "FK_StateID") as! String,
                      "C_Pincode": dicCustomerAllDetails.value(forKey: "C_Pincode") as! String,
                      "C_EmailAddress": dicCustomerAllDetails.value(forKey: "C_EmailAddress") as! String,
                      "C_Phone1": dicCustomerAllDetails.value(forKey: "C_Phone1") as! String,
                      "C_Phone2": dicCustomerAllDetails.value(forKey: "C_Phone2") as! String,
                      "C_ID1cardtype": dicCustomerAllDetails.value(forKey: "C_ID1cardtype") as! String,
                      "C_ID1number": dicCustomerAllDetails.value(forKey: "C_ID1number") as! String,
                      "C_AadharCardFront": strAadharFront,
                      "C_AadharCardBack": strAadharBack,
                      "C_ID2cardtype": dicCustomerAllDetails.value(forKey: "C_ID2cardtype") as! String,
                      "C_ID2cardnumber": dicCustomerAllDetails.value(forKey: "C_ID2cardnumber") as! String,
                      "C_ChequeBookFront": strChequeBookFront,
                      "C_CompanyName": dicCustomerAllDetails.value(forKey: "C_CompanyName") as! String,
                      "C_BussinessType": dicCustomerAllDetails.value(forKey: "C_BussinessType") as! String,
                      "C_Bankname": dicCustomerAllDetails.value(forKey: "C_Bankname") as! String,
                      "C_BranchName": dicCustomerAllDetails.value(forKey: "C_BranchName") as! String,
                      "C_BankaccountNo": dicCustomerAllDetails.value(forKey: "C_BankaccountNo") as! String,
                      "C_BankIFCcode": dicCustomerAllDetails.value(forKey: "C_BankIFCcode") as! String,
                      "C_CreateDate": Date().toString(dateFormat: "dd/MM/yyyy"),
                      "C_ApproxDate": Date().toString(dateFormat: "dd/MM/yyyy"),
                      "C_Status": dicCustomerAllDetails.value(forKey: "C_Status") as! String,
                      "C_TransactionCode": dicCustomerAllDetails.value(forKey: "C_TransactionCode") as! String,
                      "C_Passcode": dicCustomerAllDetails.value(forKey: "C_Passcode") as! String,
                      "ManagerID": dicCustomerAllDetails.value(forKey: "FK_ManagerID") as! String,
                      "ExecutiveID": dicCustomerAllDetails.value(forKey: "FK_ExecutiveID") as! String,
                      ] as [String : Any]
        
        print(params)
        
        InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.UpdateCustomerUrl)", param: params, success_msg: InputValidation.MSG.KYC_MSG, failure_msg:"", superview: self.view)
        
        /*let manager = AFHTTPRequestOperationManager()
         manager.requestSerializer.timeoutInterval = 180000
         manager.responseSerializer = AFHTTPResponseSerializer()
         
         manager.post("\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.UpdateCustomerUrl)", parameters: params, constructingBodyWith: { (data: AFMultipartFormData!) in
         
         if(dicCustomerAllDetails.value(forKey: "C_AadharCardFront") as! String == "")
         {
         if(InputValidation.Constants.documentImages[0] != UIImage.init(named: "placeholder")!)
         {
         data.appendPart(withFileData: (UIImagePNGRepresentation(InputValidation.Constants.documentImages[0])! as NSData) as Data!, name: "C_AadharCardFront", fileName: "C_AadharCardFront.jpg", mimeType: "image/jpg")
         }
         }
         
         if(dicCustomerAllDetails.value(forKey: "C_AadharCardBack") as! String == "")
         {
         if(InputValidation.Constants.documentImages[1] != UIImage.init(named: "placeholder")!)
         {
         data.appendPart(withFileData: (UIImagePNGRepresentation(InputValidation.Constants.documentImages[1])! as NSData) as Data!, name: "C_AadharCardBack", fileName: "C_AadharCardBack.jpg", mimeType: "image/jpg")
         }
         }
         
         if(dicCustomerAllDetails.value(forKey: "C_ChequeBookFront") as! String == "")
         {
         if(InputValidation.Constants.documentImages[2] != UIImage.init(named: "placeholder")!)
         {
         data.appendPart(withFileData: (UIImagePNGRepresentation(InputValidation.Constants.documentImages[2])! as NSData) as Data!, name: "C_ChequeBookFront", fileName: "C_ChequeBookFront.jpg", mimeType: "image/jpg")
         }
         }
         
         }, success: { (operation:AFHTTPRequestOperation?, response:Any?) in
         
         MBProgressHUD.hide(for: self.view, animated: true)
         InputValidation.Toast(msg: InputValidation.MSG.KYC_MSG)
         self.setValues(dictCustomerDetails, true)
         
         }, failure: { (operation:AFHTTPRequestOperation?, error:Error?) in
         MBProgressHUD.hide(for: self.view, animated: true)
         })*/
    }
    
    func SuccessFailedStatus()
    {
        if (resultValue.value(forKey: "ExecutiveData") != nil)
        {
            let dict = (resultValue.value(forKey: "ExecutiveData")! as! NSArray).object(at: 0) as! NSDictionary
            dicCustomerAllDetails = dict
            
            arrDocumentCount = []
            selectedTag = -1
            
            if(dict["C_AadharCardFront"] as! String != ""){
                arrDocumentCount.append(1)
            }else{
                selectedTag = 1
            }
            
            if(dict["C_AadharCardBack"] as! String != ""){
                arrDocumentCount.append(2)
            }else{
                selectedTag = 2
            }
            
            if(dict["C_ChequeBookFront"] as! String != ""){
                arrDocumentCount.append(3)
            }else{
                selectedTag = 3
            }
            self.setValues(dictCustomerDetails, true)
        }
        else
        {
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.GetCustomerAllDetailUrl)", param: ["CutomerID": (((dictCustomerDetails.value(forKey: "CustomerDetail")! as! NSArray).object(at: 0) as AnyObject).value(forKey: "CustomerID") as! NSNumber).stringValue], success_msg: "", failure_msg: "", superview: self.view)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MyKYCVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return selectedTag == -1 ? 50 : self.tblDocument.frame.size.height/3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedTag == -1 ? InputValidation.Constants.documentSuccessTitle.count : 3-arrDocumentCount.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "VerifyCell"
        if selectedTag == -1 {
            strIdentifier = "VerifySuccessCell"
        }
        let cell:TableCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! TableCell
        
        let lblTitle:UILabel = cell.contentView.subviews[0] as! UILabel
        
        if selectedTag == -1 {
            lblTitle.text = InputValidation.Constants.documentSuccessTitle[indexPath.row]
        }else {
            let imageView:UIImageView = cell.contentView.subviews[1] as! UIImageView
            imageView.tag = indexPath.row + 1
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(showActionSheet(_:)))
            imageView.addGestureRecognizer(tapGesture)
            
            var idx:NSInteger = 0
            switch arrDocumentCount.count {
            case 0:
                idx = indexPath.row
            case 1:
                if(arrDocumentCount.contains(1)){
                    idx = indexPath.row == 0 ? 1 : 2
                }else if(arrDocumentCount.contains(2)){
                    idx = indexPath.row == 0 ? 0 : 2
                }else{
                    idx = indexPath.row
                }
            default:
                idx = selectedTag - 1
            }
            
            lblTitle.text = InputValidation.Constants.documentTitle[idx]
            imageView.contentMode = InputValidation.Constants.documentImages[idx] == UIImage.init(named: "placeholder")! ? .scaleAspectFit : .scaleToFill
            imageView.image = InputValidation.Constants.documentImages[idx]
        }
        return cell
    }
}
