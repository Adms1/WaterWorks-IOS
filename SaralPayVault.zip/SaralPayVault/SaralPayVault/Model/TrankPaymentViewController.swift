//
//  TrankPaymentViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 22/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

/*let hashStr:String = "531553f8d6b906aa3342948a3c535ca301de9d5d|-|-|\(amount!)|535ee616-a161-4e16-88ed-a338582e841a|Ahmedabad|IND|INR|\(narration!)|ClientId59@saralpayonline.com|TEST|\((CompanyDetails.value(forKey: "CustomerName")! as! String))|\(Order_ID!)|7575809733|https://biz.traknpay.in/tnp/return_page_android.php|y|Gujarat|380015"
 
 /let webstr:String = String(format: "%@?address_line_1=-&address_line_2=-&amount=%@&api_key=535ee616-a161-4e16-88ed-a338582e841a&city=Ahmedabad&country=IND&currency=INR&description=%@&email=ClientId59@saralpayonline.com&mode=TEST&name=%@&order_id=%@&phone=7575809733&return_url=https://biz.traknpay.in/tnp/return_page_android.php&show_saved_cards=y&state=Gujarat&zip_code=380015&hash=%@",InputValidation.WEB_API.TraknPayUrl,amount!,narration!,(CompanyDetails.value(forKey: "CustomerName") as! String),Order_ID!,SHA_512_str).addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!*/


import UIKit
import WebKit
import JavaScriptCore

class TrankPaymentViewController: CustomNavigationBar , UIWebViewDelegate {
    
    @IBOutlet weak var webview: UIWebView!
    var amount: String!
    
    var Salt             = "531553f8d6b906aa3342948a3c535ca301de9d5d"
    var Api_key          = "535ee616-a161-4e16-88ed-a338582e841a"
    var AmountRs         = ""
    var City             = "Ahmedabad"
    var Country          = "IND"
    var Currency         = "INR"
    var Description      = ""
    var Email            = "@saralpayonline.com"
    var Mode             = "LIVE"
    var Name             = ""
    var Order_id         = ""
    var Phone            = "7575809733"
    var Return_url       = "https://biz.traknpay.in/tnp/return_page_android.php"
    var Show_saved_cards = "n"
    var State            = "Gujarat"
    var ZipCode          = "380015"
    var Address_line_1   = "-"
    var Address_line_2   = "-"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        AmountRs  = amount!
        Description = narration!
        Name = (CompanyDetails.value(forKey: "CustomerName")! as! String)
        Order_id = Order_ID!
        Email = "\(bundleName.contains("Vault") ? "ClientId" : "CustomerId")\(UserDefaults.standard.value(forKey: "ClientID") as! NSNumber)\(Email)"
        
        let headers = [
            "cache-control": "no-cache",
            "postman-token": "570b0683-97e0-edad-1258-bde786158280"
        ]
        
        let hashdata = [Salt,Address_line_1,Address_line_2,AmountRs,Api_key,City,Country,Currency,Description,Email,Mode,Name,Order_id,Phone,Return_url,Show_saved_cards,State,ZipCode].joined(separator: "|")
        
        let SHA_512_str:String = SHA_512.createSHA512(hashdata).uppercased()
        
        let postkey = ["salt","address_line_1","address_line_2","amount","api_key","city","country","currency","description","email","mode","name","order_id","phone","return_url","show_saved_cards","state","zip_code"]
        
        var postdata:String = "hash=\(SHA_512_str)"
        for (index, element) in (hashdata.components(separatedBy: "|") as NSArray).enumerated()
        {
            if index != 0
            {
                postdata = "\(postdata)&\(postkey[index])=\(element)"
            }
        }
        
        let request = NSMutableURLRequest(url: NSURL(string: InputValidation.WEB_API.TraknPayUrl)! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 10.0)
        request.httpBody = postdata.data(using: .utf8)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = headers
        
        webview.delegate = self
        webview.loadRequest(request as URLRequest)
        
    }
    
    //MARK: WEBVIEW DELEGATE
    
    func webViewDidStartLoad(_ webView: UIWebView)
    {
        (view.viewWithTag(1) as! UIActivityIndicatorView).startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        (view.viewWithTag(1) as! UIActivityIndicatorView).stopAnimating()
        (view.viewWithTag(1) as! UIActivityIndicatorView).hidesWhenStopped = true
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error)
    {
        (view.viewWithTag(1) as! UIActivityIndicatorView).stopAnimating()
        (view.viewWithTag(1) as! UIActivityIndicatorView).hidesWhenStopped = true
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if (request.url?.absoluteString  == "https://biz.traknpay.in/tnp/return_page_android.php") {
            
            webview.addJavascriptInterface(JSInterface(), forKey: "Android");
        }
        return true
    }
}
