//
//  ThankYouVC.swift
//  SaralPay
//
//  Created by ADMS on 04/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ThankYouVC: UIViewController,SuccessFailedDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        for view in self.view.subviews[2].subviews {
            if(view.tag == -1){
                view.layer.cornerRadius = 6
                view.clipsToBounds = true
            }
        }
    }
    
    @IBAction func btnClick(_ sender:UIButton)
    {
        delegate = self
        if sender.tag == 1 {
            self.SuccessFailedStatus()
            
        }else{
            let params = ["CustomerID": dicVerify.value(forKey: "CustomerID") as! String,
                          "C_UpgradeStatus": "1",
                          "C_UpgradeDate": Date().toString(dateFormat: "dd/MM/yyyy")]
            
            print(params)
            
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.UpgradeCustomerStatusUrl)", param: params, success_msg: InputValidation.MSG.Upgrade_MSG, failure_msg:"",  superview: self.view)
        }
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
