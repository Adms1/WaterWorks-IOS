//
//  ClientDetailsViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 21/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import CoreLocation

var Order_ID:String!
var CompanyDetails:NSDictionary!
var narration:String!

class ClientDetailsViewController: CustomNavigationBar,SuccessFailedDelegate {
    
    @IBOutlet weak var txtAmount:UITextField!
    @IBOutlet weak var txtNarration:UITextView!
    @IBOutlet weak var btnCompanyName:UIButton!
    var amount:NSNumber = 0
    
    //MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = false
        btnCompanyName.setTitle("PAYMENT PORTAL FOR \((CompanyDetails.value(forKey: "CompanyName") as! String).uppercased())", for: .normal)
        btnCompanyName.titleLabel?.textAlignment = NSTextAlignment.center
        txtNarration.text = narration
    }
    
    //MARK: Calling Function
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            Order_ID = (resultValue.value(forKey: "TransactionID")) as! String
            let tpvc:TrankPaymentViewController = self.storyboard?.instantiateViewController(withIdentifier: "TrankPaymentViewController") as! TrankPaymentViewController
            tpvc.amount = self.amount.stringValue
            tpvc.navigationItem.hidesBackButton = true
            self.navigationController?.pushViewController(tpvc, animated: true)
        }
    }
    
    //MARK: Button Action
    
    @IBAction func btnChargeClicked(sender:InputButton)
    {
        delegate = self
        if sender.tag == 0
        {
            let result = InputValidation.ClientDetailValidation(amount: txtAmount.text!, narration: txtNarration.text!)
            if(!result.0)
            {
                amount = result.1
                let UDID: String = UIDevice.current.identifierForVendor!.uuidString
                //                var lat = "23.0129"
                //                var long = "72.5041"
                //
                //                if currentLocation != nil {
                //                    lat = "\(currentLocation.coordinate.latitude)"
                //                    long = "\(currentLocation.coordinate.longitude)"
                //                }
                //
                let params = ["CustomerID":(CompanyDetails.value(forKey: "CustomerID") as! NSNumber).stringValue,"Name":(CompanyDetails.value(forKey: "CustomerName") as! String),"Email":"saralpayonline@gmail.com","Mobile":(CompanyDetails.value(forKey: "CustomerMobile") as! String),"Amount":amount.stringValue,"Description":txtNarration.text!,"Trans_Type":"2","Latitude":"","Longitude":"","IMEINumber":UDID]
                
                InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.PaymentUrl)", param: params, success_msg: "", failure_msg:InputValidation.MSG.Client_MSG, superview: self.view)
            }
        }
        else
        {
            //CANCEL
            txtAmount.text = ""
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ClientDetailsViewController: UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        textView.textColor = .black
        textView.textAlignment = .left
        if(textView.text == "Narration"){
            textView.text = nil
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Narration"
            textView.textColor = UIColor.init(red: (170.0/255.0), green: (170.0/255.0), blue: (170.0/255.0), alpha: 1.0)
            textView.textAlignment = .center
        }
    }
}
