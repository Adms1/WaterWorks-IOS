//
//  VerifyPopUpVC.swift
//  SaralPay
//
//  Created by ADMS on 05/04/18.
//  Copyright © 2018 Waterworks Aquatics. All rights reserved.
//

import UIKit

var arrDocumentCount:[Int] = []
class VerifyPopUpVC: CustomNavigationBar {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(removePopUp(_:)), name: .remove, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        for i in 1...3 {
            let btn = self.view.subviews[0].subviews[0].viewWithTag(i) as! UIButton
            let aspectRatioConstraint = NSLayoutConstraint.init(item: btn, attribute: .width, relatedBy: .equal, toItem: btn, attribute: .height, multiplier: 125/18, constant: arrDocumentCount.contains(i) ? (btn.frame.size.width) : 0)
            btn.removeConstraint((btn.constraints.last)!)
            btn.addConstraint(aspectRatioConstraint)
            btn.isHidden = arrDocumentCount.contains(i) ? true : false
        }
    }
    
    @IBAction func btnClicked(_ sender:UIButton)
    {
        if(dictCustomerDetails.count != 0){
            self.setValues(dictCustomerDetails, sender.tag == 0 ? true : false)
        }
        
        if sender.tag != 0 {
            selectedTag = sender.tag
            self.showActionSheet(nil)
        }
    }
    
    func removePopUp(_ notification:NSNotification)
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
