//
//  RegisterViewController.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class RegisterViewController: CustomHeaderBar,SuccessFailedDelegate {
    
    @IBOutlet weak var txtPhone:InputText!
    @IBOutlet weak var txtEmail:InputText!
    @IBOutlet weak var txtPassword:InputText!
    @IBOutlet weak var txtFname:InputText!
    @IBOutlet weak var txtLname:InputText!
    
    //MARK: View Life Cycle
    
    override func viewWillDisappear(_ animated: Bool) {
        for txt in self.view.subviews[1].subviews
        {
            if txt.isKind(of: InputText.classForCoder()) {
                (txt as! InputText).text = ""
            }
        }
    }
    
    func MobileDuplicateDelegate()
    {
        if (resultValue.value(forKey: "Phone") as! NSArray).count == 0
        {
            let params = ["PhoneNo":txtPhone.text,"password":txtPassword.text,"FirstName":txtFname.text,"LastName":txtLname.text,"EmailID":txtEmail.text]
            
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.RegisterUrl)", param: params, success_msg: "", failure_msg:"", superview: self.view)
        }
    }
    
    func SuccessFailedStatus()
    {
        if resultValue.value(forKey: "Success") as! String == "True"
        {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    //MARK: Button Action
    
    @IBAction func btnProceedPressed(sender:UIButton)
    {
        delegate = self
        
        for txt in self.view.subviews[1].subviews
        {
            if txt.isKind(of: InputText.classForCoder()) {
                txt.resignFirstResponder()
            }
        }
        
        if !InputValidation.registerValidation(pno: txtPhone.text!, eid: txtEmail.text!, pwd: txtPassword.text!, fname: txtFname.text!, lname: txtLname.text!)
        {
            InputValidation.ApiCalling(web_url: "\(InputValidation.WEB_API.BaseUrl)\(InputValidation.WEB_API.MobilenoUrl)", param: ["MobileNo":txtPhone.text], success_msg: InputValidation.MSG.Mobileno_MSG, failure_msg:"",  superview: self.view)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
