//
//  AppDelegate.swift
//  SaralPayVault
//
//  Created by Ankit on 20/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var navigationController:NavigationController!
    var storyboard:UIStoryboard!
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        storyboard = UIStoryboard(name: "Main", bundle: nil)
        //let vc:ViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        //navigationController = NavigationController
        navigationController = storyboard.instantiateViewController(withIdentifier: "navigation") as! NavigationController
        self.window?.rootViewController = navigationController
        self.window?.makeKeyAndVisible()
        
        //        UIBarButtonItem.appearance().setBackButtonBackgroundImage(nil, for: .normal, barMetrics: .default)
        //        UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white,NSFontAttributeName: UIFont.boldSystemFont(ofSize: 18)]
        //        UINavigationBar.appearance().barTintColor = UIColor.init(colorLiteralRed: 255.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: 1.0)
        
        UITextField.appearance().font = UIFont.systemFont(ofSize: InputValidation.DeviceType.IS_IPAD ? 25:17)
        
        return true
    }

    func isUpdateAvailable() throws -> (Bool,String,String) {
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let proName = info["CFBundleDisplayName"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        let data = try Data(contentsOf: url)
        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            return (version != currentVersion, proName, version)
        }
        throw VersionError.invalidResponse
    }
    
    func setupForUpdate(_ strAppName:String, _ strAppVersion:String)
    {
        let alert = UIAlertController(title: InputValidation.MSG.appUpdateTitle, message: InputValidation.MSG.appUpdateMsg.replacingOccurrences(of: "{}", with: strAppName).replacingOccurrences(of: "()", with: strAppVersion), preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Later", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            exit(0)
        })
        let noButton = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            let url:URL = URL(string: "itms://itunes.apple.com/us/app/apple-store/id1369838903?mt=8")!
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        self.window?.windowLevel = UIWindowLevelAlert + 1
        self.window?.makeKeyAndVisible()
        self.window?.rootViewController?.present(alert, animated: true, completion: { })
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        DispatchQueue.global().async {
            do {
                let update = try self.isUpdateAvailable().0
                if(update){
                    self.setupForUpdate(try self.isUpdateAvailable().1, try self.isUpdateAvailable().2)
                }
            } catch {
                print(error)
            }
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}

