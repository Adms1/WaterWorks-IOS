//
//  JLAlertViewController.Swift
//  JLAlertViewController
//
//  Created by Jason Loewy on 5/17/16.
//  Copyright © 2016 Jason Loewy. All rights reserved.
//

import UIKit
import Foundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


@objc enum JLAlertButtonType:Int {
    
    case cancel
    case regular
}

@objc enum JLAlertInputStyle:Int {
    case none
    case plainText
    case secureText
    case decimal
    
    /// Responsible for telling the caller if the current type is of input type or not
    func isInputType()->Bool {
        return (self == .plainText || self == .secureText || self == .decimal)
    }
}

class JLAlertViewController: UIViewController {
    
    
    /// Responsible for telling the caller that this alert view was dismissed by a button tap - this closure  gets called after all view dismissal has finished
    var didDismissBlock:((JLAlertViewController,JLAlertButtonType)->Void)?;
    
    var inputStyle:JLAlertInputStyle = .none
    
    fileprivate var titleText:String = ""
    fileprivate var messageText:String = ""
    fileprivate var cancelButtonText:String?
    fileprivate var regularButtonText:String?
    
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var messageLabel: UILabel?
 
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var regularButton: UIButton!
    
    // Styling Variables
    fileprivate let enabledButtonColor  = UIColor(red: 40.0/255.0, green: 40.0/255.0, blue: 40.0/255.0, alpha: 1.0)
    fileprivate let disabledButtonColor = UIColor(red: 140.0/255.0, green: 140.0/255.0, blue: 140.0/255.0, alpha: 1.0)
    
    // MARK: - Initialization Methods
    
    /// Create a new plain style alertController
    static func alertController(_ title:String, message:String, cancelButtonText:String?, regularButtonText:String?)->JLAlertViewController
    {
        let alertController = JLAlertViewController(nibName: "JLAlertViewController", bundle: nil)
        alertController.configure(title, message: message, cancelButtonText: cancelButtonText, regularButtonText: regularButtonText, inputStyle: .none, placeholderText: nil)
        
        return alertController
    }
    
    /// Create a new plain text input style alertController
    static func inputAlertController(_ title:String, placeholder:String?, cancelButtonText:String?, regularButtonText:String?)->JLAlertViewController
    {
        let alertController = JLAlertViewController(nibName: "JLInputAlertViewController", bundle: nil)
        alertController.configure(title, message: "", cancelButtonText: cancelButtonText, regularButtonText: regularButtonText, inputStyle: .plainText, placeholderText: placeholder)
        
        return alertController
    }
    
    /// Create a new plain text input style alertController with decimal keyboard input
    static func decimalAlertController(_ title:String, placeholder:String?, cancelButtonText:String?, regularButtonText:String?)->JLAlertViewController
    {
        let alertController = JLAlertViewController(nibName: "JLInputAlertViewController", bundle: nil)
        alertController.configure(title, message: "", cancelButtonText: cancelButtonText, regularButtonText: regularButtonText, inputStyle: .decimal, placeholderText: placeholder)
        
        return alertController
    }
    
    /// Create a new secure text input style alertControler
    static func secureInputAlertController(_ title:String, placeholder:String?, cancelButtonText:String?, regularButtonText:String?)->JLAlertViewController
    {
        let alertController = JLAlertViewController(nibName: "JLInputAlertViewController", bundle: nil)
        alertController.configure(title, message: "", cancelButtonText: cancelButtonText, regularButtonText: regularButtonText, inputStyle: .secureText, placeholderText: placeholder)
        
        return alertController
    }
    
    fileprivate func configure(_ title:String, message:String, cancelButtonText:String?, regularButtonText:String?, inputStyle:JLAlertInputStyle, placeholderText:String?)
    {
        self.titleText            = title
        self.messageText          = message
        self.cancelButtonText     = cancelButtonText
        self.regularButtonText    = regularButtonText
        self.inputStyle           = inputStyle
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - View Controller Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Display the background properly based off of if visual effect is avaialble or not
        if #available(iOS 8.0, *) {
            
            let visualEffectView   = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
            visualEffectView.alpha = 0.625
            visualEffectView.frame = self.view.bounds
            visualEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            visualEffectView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(JLAlertViewController.backgroundViewTapped(_:))))
            self.view.insertSubview(visualEffectView, at: 0)
        } else {
            // Fallback on earlier versions
            view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        }
        
        
        alertView.layer.cornerRadius  = 2.0
        alertView.layer.shadowOffset  = CGSize(width: 0.0, height: 0.0)
        alertView.layer.shadowColor   = UIColor(white: 0.0, alpha: 1.0).cgColor
        alertView.layer.shadowOpacity = 0.3
        alertView.layer.shadowRadius  = 3.0
        
        titleLabel.text   = titleText
        
        
        // Style the layout based off of the input style
        if inputStyle == .none {
            messageLabel?.text   = messageText
            messageLabel?.isHidden = false
            
        }
  
        
        // Handle the cancel button setup
        if let cancelText = cancelButtonText {
            cancelButton.setTitle(cancelText, for: UIControlState())
        }
        else {
            cancelButton.isHidden  = true
        }
        
        // Handle the regular button setup
        if let regularText = regularButtonText {
            
            regularButton.setTitle(regularText, for: UIControlState())
            if inputStyle.isInputType() {
                regularButton.setTitleColor(disabledButtonColor, for: UIControlState())
                regularButton.isEnabled = false
            }
            else {
                regularButton.setTitleColor(cancelButton.titleColor(for: .normal), for: UIControlState())
            }
        }
        else {
            regularButton.isHidden  = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if inputStyle.isInputType() {
            NotificationCenter.default.addObserver(self, selector: #selector(JLAlertViewController.keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(JLAlertViewController.keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if inputStyle.isInputType() {
            NotificationCenter.default.removeObserver(self)
        }
    }
    
    /// Repsonsible for reacting to the user tapping the visualeffect background
    func backgroundViewTapped(_ sender:AnyObject)
    {
        view.endEditing(true)
    }
    
    // MARK: - Hide/Display Methods
    
    /// Responsible for displaying the alert controller over the topmost active view controller
    func show()
    {
        if let appDelegate = UIApplication.shared.delegate, let window = appDelegate.window, let rootViewController = window?.rootViewController {
            
            var topViewController = rootViewController
            while topViewController.presentedViewController != nil {
                topViewController = topViewController.presentedViewController!
            }
            
            // Add the alert view controller to the top most UIViewController of the application
            topViewController.addChildViewController(self)
            topViewController.view.addSubview(view)
            viewWillAppear(true)
            didMove(toParentViewController: topViewController)
            view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            view.alpha = 0.0
            view.frame = topViewController.view.bounds
            
            alertView.alpha     = 0.0
            UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseOut, animations: { () -> Void in
                self.view.alpha = 1.0
                }, completion: nil)
            
            alertView.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
            alertView.center    = CGPoint(x: (self.view.bounds.size.width/2.0), y: (self.view.bounds.size.height/2.0)-10)
            UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut, animations: { () -> Void in
                self.alertView.alpha = 1.0
                self.alertView.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                self.alertView.center    = CGPoint(x: (self.view.bounds.size.width/2.0), y: (self.view.bounds.size.height/2.0))
                }, completion: nil)
        }
    }
    
    /**
     Responsible for hiding the currently displayed JLAlertViewControlller
     
     - parameter buttonTapped: [optional] The JLAlertButtonType that was just tapped to start dismissing this alert controller
     */
    func hide(_ buttonTapped:JLAlertButtonType?)
    {
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.25, delay: 0.0, options: .curveEaseIn, animations: { () -> Void in
            self.alertView.alpha = 0.0
            self.alertView.transform = CGAffineTransform(scaleX: 1.01, y: 1.01)
            self.alertView.center    = CGPoint(x: (self.view.bounds.size.width/2.0), y: (self.view.bounds.size.height/2.0)-5)
            }, completion: nil)
        
        UIView.animate(withDuration: 0.3, delay: 0.05, options: UIViewAnimationOptions(), animations: { () -> Void in
            self.view.alpha = 0.0
            
        }) { (completed) -> Void in
            
            self.view.removeFromSuperview()
            self.removeFromParentViewController()
            if let buttonType = buttonTapped, let dismissBlock = self.didDismissBlock {
                dismissBlock(self, buttonType)
            }
        }
    }
    
    // MARK: - Keyboard Relocation Methods
    
    /**
     Repsonsible for updating and animating the new constraint update
     
     - parameter constraintIdentifier: The string identifier of the constraint that you are working on
     - parameter value:                The value that it should be set to
     */
    fileprivate func updateConstraint(_ constraintIdentifier:String, value:CGFloat, constraintView:UIView) {
        
        UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseOut, animations: {
            for (_, constraint) in constraintView.constraints.enumerated()
            {
                if constraint.identifier == constraintIdentifier
                {
                    constraint.constant = CGFloat(value)
                    break;
                }
            }
            self.view.layoutIfNeeded()
            }, completion:  nil)
    }
    
    /// Responsible for reacting to the keyboard being displayed
    func keyboardWillShow(_ notification:Notification)
    {
        let keyboardHeight = (notification.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height;
        self.updateConstraint("alertview-center-y", value: -(keyboardHeight/2.0), constraintView: self.view)
    }
    
    /// Responsible for reacting ot the keyboard being hidden
    func keyboardWillHide(_ notification:Notification)
    {
        self.updateConstraint("alertview-center-y", value: 0, constraintView: self.view)
    }
   
    
    // MARK: - Button Interaction Methods
    
    @IBAction func cancelButtonTapped(_ sender: AnyObject) { hide(.cancel) }
    
    @IBAction func regularButtonTapped(_ sender: AnyObject) { hide(.regular) }
}
