
//
//  SHA-512.h
//  SaralPayVault
//
//  Created by Ankit on 23/02/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHA_512 : NSObject
+(NSString *)createSHA512:(NSString *)string;
@end
