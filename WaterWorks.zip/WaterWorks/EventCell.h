//
//  EventCell.h
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventCell : UITableViewCell
@property(nonatomic,retain)IBOutlet UILabel *lblEventName;
@property(nonatomic,retain)IBOutlet UILabel *lblAge;
@property(nonatomic,retain)IBOutlet UIButton *btnSelect;
@property(nonatomic,retain)IBOutlet UILabel *lblRegister;
@end
