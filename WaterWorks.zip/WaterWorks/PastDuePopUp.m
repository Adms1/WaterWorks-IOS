//
//  PastDuePopUp.m
//  WaterWorks
//
//  Created by Ankit on 03/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PastDuePopUp.h"

@interface PastDuePopUp ()

@end

@implementation PastDuePopUp

- (void)viewDidLoad {
    [super viewDidLoad];
    [lblMsg setText:_strMsg];
    
    btnOk.layer.shadowColor = [[UIColor grayColor] CGColor];
    btnOk.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    btnOk.layer.shadowOpacity = 1.0f;
    btnOk.layer.shadowRadius = 1.0f;
}
-(IBAction)btnOk:(id)sender
{
    [self.pd_delegate RemovePopup:self];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
