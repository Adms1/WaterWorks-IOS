//
//  SwimTeamViewController.h
//  WaterWorks
//
//  Created by Ankit on 27/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SwimTeamViewController : UIViewController
{
    IBOutlet UITextView *txtTitle;
    IBOutlet UILabel *lblInstruction;
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UIButton *btnHome , *btnStartDate;
    IBOutlet UIView *viewDays;
    IBOutlet NSLayoutConstraint *dayHeight ,*lblHeight;
    IBOutlet UITextField *txtfldPrice;
    IBOutlet UIView *v1,*v2,*v3,*v4,*v5,*v6;
}
@property(nonatomic,retain)NSString * programId;
@end
