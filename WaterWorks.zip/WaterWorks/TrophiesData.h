//
//  TrophiesData.h
//  WaterWorks
//
//  Created by Ankit on 03/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TrophiesData : NSObject
@property(nonatomic,retain)NSNumber *participation;
@property(nonatomic,retain)NSNumber *timeimprovement;
@property(nonatomic,retain)NSNumber *totalribbons;
@end
