//
//  SwimTeamViewController.m
//  WaterWorks
//
//  Created by Ankit on 27/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SwimTeamViewController.h"
#import "AppDelegate.h"
#import "NIDropDown.h"
#import "CommonClass.h"
#import "MonthPopup.h"
#import "MDDatePickerDialog.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"

@interface SwimTeamViewController ()<NIDropDownDelegate,MonthPopupDelegate,MDDatePickerDialogDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSArray *arrLocation, *arrGroup, *arrMonth, *arrSelectedMonth, *arrTotalDays, *arrDays, *arrSortedDays;
    NSString *str_siteId, *str_childId, *str_groupId, *str_totalDays, *str_month, *str_date, *str_cardnum;
    NSMutableArray *arrChild, *arrSelectedDaysIds;
}
@property(nonatomic) NSDateFormatter *dateFormatter;
@property(nonatomic) MDDatePickerDialog *datePicker;
@end

@implementation SwimTeamViewController
int counter = 0;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dateFormatter = [[NSDateFormatter alloc]init];
    btnStartDate.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    btnStartDate.layer.borderWidth = 0.5f;
    
    lblInstruction.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    lblInstruction.layer.borderWidth = 0.5f;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    for (UIView *v in scroll_main.subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 0)
        {
            ((UIButton *)v).imageEdgeInsets = UIEdgeInsetsMake(0, ((UIButton *)v).frame.size.width - 25, 0, 0);
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksYouthSwimNight :self :btnHome :nil :YES :self];
    
    [self MakePurchase_SwmTm_CardCheck];
    [self MakePurchase_PageLoad_SiteByFamily];
    [self GetProgramInstruction];
    [self MakePurchase_SwimTeamChild];
}

-(void)MakePurchase_SwmTm_CardCheck
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwmTm_CardCheck_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            str_cardnum = [[[responseObject valueForKey:@"MonthList"]valueForKey:@"CardNum"]objectAtIndex:0];
        }
        else
        {
            [CommonClass showToastMsg:AddCardNum];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)GetProgramInstruction
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:programInstruction_Url parameters:@{@"programid":_programId} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            txtTitle.text = [[[responseObject valueForKey:@"Instruction"]valueForKey:@"Instruction"] objectAtIndex:0];
            [txtTitle setTextContainerInset:UIEdgeInsetsMake(0, 0, 0, 0)];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_PageLoad_SiteByFamily
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_PageLoad_SiteByFamily_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrLocation = [responseObject valueForKey:@"PhoneList"];
        }
        
        if (arrLocation.count == 1)
        {
            [((UIButton *)scroll_main.subviews[9])setTitle:[[arrLocation objectAtIndex:0] valueForKey:@"sitename"] forState:0];
            
            str_siteId = [[arrLocation valueForKey:@"siteid"] objectAtIndex:0];
            [self Get_ProgramsPriceInfo:str_siteId];
            [self MakePurchase_SwmTm_BindGroup:str_siteId];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)Get_ProgramsPriceInfo:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"programid":_programId,
                             @"siteid":strSiteId,
                             };
    
    [manager POST:Get_ProgramsPriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            lblInstruction.text = [[[responseObject valueForKey:@"Instruction"]valueForKey:@"Instruction"] objectAtIndex:0];
        }else{
            lblInstruction.text = @"";
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_SwimTeamChild
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwimTeamChild_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrChild = [responseObject valueForKey:@"PhoneList"];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_SwmTm_BindGroup:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"SiteID":strSiteId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwmTm_BindGroup_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrGroup = [responseObject valueForKey:@"MonthList"];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_SwmTm_BindMonthAll
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"showall":@"0",
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwmTm_BindMonthAll_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrMonth = [responseObject valueForKey:@"MonthList"];
        }
        
        if ([arrMonth count] > 1) {
            MonthPopup *mp  = [[MonthPopup alloc]initWithNibName:@"MonthPopup" bundle:nil];
            mp.view.frame = CGRectMake(20, 0, self.view.frame.size.width - 40, self.view.frame.size.height);
            mp.m_delegate = self;
            mp.arrMonthList = arrMonth;
            mp.arrSelectMonth = arrSelectedMonth;
            [self presentPopupViewController:mp animationType:MJPopupViewAnimationFade];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_SwmTm_BindNoOfDay:(NSString *)strGroupId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"GroupID":strGroupId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwmTm_BindNoOfDay_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrTotalDays = [responseObject valueForKey:@"MonthList"];
        }
        
        if(arrTotalDays.count > 0)
            str_totalDays = [[arrTotalDays valueForKey:@"NoOfDayID"]objectAtIndex:0];
        
        if (str_month != nil)
        {
            [self MakePurchase_SwmTm_BindFillDay];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)MakePurchase_SwmTm_BindFillDay
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"GroupID":str_groupId,
                             @"selMonths":str_month,
                             @"NoOfDay":str_totalDays,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MakePurchase_SwmTm_BindFillDay_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrDays = [responseObject valueForKey:@"MonthList"];
        }
        
        lblHeight.constant = 30.0f;
        [self addDynamicDays];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)addDynamicDays
{
    arrSelectedDaysIds = [[NSMutableArray alloc]init];
    counter = 0;
    
    [viewDays.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    viewDays.layer.borderColor = [[UIColor blackColor]CGColor];
    viewDays.layer.borderWidth = 0.5f;
    dayHeight.constant = (arrDays.count * 25)+10;
    
    NSArray *days   = [arrDays valueForKey:@"DayName"];
    NSArray *dayIds = [arrDays valueForKey:@"DayID"];
    
    arrSortedDays = [days sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSNumber* index1 = dayIds[[days indexOfObjectIdenticalTo:obj1]];
        NSNumber* index2 = dayIds[[days indexOfObjectIdenticalTo:obj2]];
        
        NSComparisonResult result = [index1 compare:index2];
        return result;
    }];
    
    for (int i = 0; i < arrDays.count; i++)
    {
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(5, (i*25)+5, 100, 25)];
        lbl.textColor = [UIColor blackColor];
        lbl.font = FONT_OpenSans(14);
        lbl.textAlignment = NSTextAlignmentLeft;
        [lbl setText:[arrSortedDays objectAtIndex:i]];
        [viewDays addSubview:lbl];
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(viewDays.frame.size.width - 30, (i*25)+5, 30, 30)];
        [btn setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:0];
        [btn setImage:[UIImage imageNamed:@"CheckLesson"] forState:UIControlStateSelected];
        btn.tag = i;
        [btn setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [btn addTarget:self action:@selector(btn:) forControlEvents:UIControlEventTouchUpInside];
        [viewDays addSubview:btn];
    }
}

-(void)AddToCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"SiteID":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID],
                             @"ddlStudent1":str_childId,
                             @"chkDaysAry":[arrSelectedDaysIds componentsJoinedByString:@","],
                             @"Price1":txtfldPrice.text,
                             @"NoOfDay":str_totalDays,
                             @"chkMonthListAry":str_month,
                             @"CardNum":str_cardnum != nil ? str_cardnum : @"",
                             @"rdbClassToday2":@"off",
                             @"StartDate":str_date,
                             @"GroupID":str_groupId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:MakePurchase_SwmTm_InsertSwimTeamData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)btn:(UIButton *)sender
{
    v6.layer.borderColor = [[UIColor clearColor]CGColor];
    sender.selected = !sender.selected;
    NSInteger idx = [[arrDays valueForKey:@"DayName"]indexOfObject:[NSString stringWithFormat:@"%@",[arrSortedDays objectAtIndex:sender.tag]]];
    
    if (sender.selected) {
        if (counter == [[[str_totalDays componentsSeparatedByString:@"|"] firstObject] integerValue]) {
            sender.selected = !sender.selected;
            [CommonClass showToastMsg:LimitExceeded];
            return;
        }
        [arrSelectedDaysIds addObject:[[arrDays objectAtIndex:idx] valueForKey:@"DayID"]];
        counter++;
    }
    else{
        counter--;
        [arrSelectedDaysIds removeObject:[[arrDays objectAtIndex:idx] valueForKey:@"DayID"]];
    }
}

-(void)Click:(NSMutableArray *)MonthArray :(NSMutableArray *)arrMonthId{
    
    if (MonthArray.count > 0) {
        
        [((UIButton *)[scroll_main viewWithTag:6])setTitle:@"1" forState:0];
        [((UIButton *)[scroll_main viewWithTag:6])setTitleColor:[UIColor blackColor] forState:0];
        txtfldPrice.text = [[str_totalDays componentsSeparatedByString:@"|"]lastObject];
        
        arrSelectedMonth = MonthArray;
        [((UIButton *)[scroll_main viewWithTag:4])setTitleColor:[UIColor blackColor] forState:0];
        [((UIButton *)[scroll_main viewWithTag:4])setTitle:[MonthArray componentsJoinedByString:@","] forState:0];
        
        str_month = [arrMonthId componentsJoinedByString:@","];
        if (str_groupId != nil && str_totalDays != nil)
        {
            [self MakePurchase_SwmTm_BindFillDay];
        }
    }
    else
    {
        arrSelectedMonth = [NSMutableArray new];
        [((UIButton *)[scroll_main viewWithTag:4])setTitleColor:[UIColor darkGrayColor] forState:0];
        [((UIButton *)[scroll_main viewWithTag:4])setTitle:@"Please select Month" forState:0];
        str_month = nil;
    }
    
    //[lblMonth setText:[array componentsJoinedByString:@","]];
    
    /*NSMutableParagraphStyle *style =  [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
     style.alignment = NSTextAlignmentJustified;
     style.firstLineHeadIndent = 10.0f;
     style.headIndent = 10.0f;
     style.tailIndent = -10.0f;
     
     NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:lblMonth.text attributes:@{ NSParagraphStyleAttributeName : style}];
     lblMonth.attributedText = attrText;*/
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)btnSelectDate:(UIButton *)sender {
    
    v5.layer.borderColor = [[UIColor clearColor]CGColor];
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    
    if (arrSelectedMonth.count > 0) {
        NSString *dateString = [[[arrSelectedMonth objectAtIndex:0] stringByReplacingOccurrencesOfString:@"'" withString:@" "]stringByAppendingString:@" 01"];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MMM yyyy dd"];
        
        /*
         */
        
        NSDateFormatter *mf = [[NSDateFormatter alloc] init];
        [mf setDateFormat:@"MMM"];
        NSString *strCurrentMonth = [mf stringFromDate:[NSDate date]];
        NSString *strSelectedMonth = [[dateString componentsSeparatedByString:@" "] firstObject];
        
        /*
         */
        
        NSDate *date = [dateFormatter dateFromString:dateString];
        _datePicker.selectedDate = date == nil ? [NSDate date] : [strCurrentMonth isEqualToString:strSelectedMonth] ?[NSDate date] : date;
    }else{
        _datePicker.selectedDate = [NSDate date];
    }
    //_datePicker.minimumDate = [NSDate date];
    _datePicker.tag = sender.tag;
    [_datePicker show];
}

- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    _dateFormatter.dateFormat = @"MM/dd/yyyy";
    str_date = [_dateFormatter stringFromDate:date];
    [btnStartDate setTitle:str_date forState:0];
    [btnStartDate setTitleColor:[UIColor blackColor] forState:0];
}

-(IBAction)btnClicked:(UIButton *)sender
{
    NSArray *array;
    switch (sender.tag) {
        case 1:
            v1.layer.borderColor = [[UIColor clearColor]CGColor];
            array = arrLocation.count > 1 ? [arrLocation valueForKey:@"sitename"] : nil;
            break;
            
        case 2:
            v2.layer.borderColor = [[UIColor clearColor]CGColor];
            
            arrChild = arrChild.mutableCopy;
            if (![[arrChild valueForKey:@"Student"]containsObject:@"Please select child"])
            {
                [arrChild insertObject:@{
                                         @"Student":@"Please select child",
                                         @"StudentID":@"0"
                                         } atIndex:0];
            }
            array = [arrChild valueForKey:@"Student"];
            break;
            
        case 3:
            v3.layer.borderColor = [[UIColor clearColor]CGColor];
            array = [arrGroup valueForKey:@"GroupName"];
            break;
            
        case 6:
            array = [arrTotalDays valueForKey:@"NoOfDayName"];
            break;
            
        default:
            break;
    }
    
    if (sender.tag != 4)
    {
        if(dropDown == nil && array.count > 0) {
            CGFloat f = 250;
            dropDown = [[NIDropDown alloc]showDropDown:sender :&f :array :nil :@"down"];
            dropDown.delegate = self;
            dropDown.tag = 1000;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel];
        }
    }
    else
    {
        v4.layer.borderColor = [[UIColor clearColor]CGColor];
        [self MakePurchase_SwmTm_BindMonthAll];
    }
}
- (void)select:(UIButton *)sender :(NSInteger) idx
{
    if (sender.tag == 1)
    {
        str_siteId = [[arrLocation valueForKey:@"siteid"] objectAtIndex:idx];
        [self Get_ProgramsPriceInfo:str_siteId];
        [self MakePurchase_SwmTm_BindGroup:str_siteId];
    }
    else if (sender.tag == 2)
    {
        if (idx > 0) {
            str_childId = [[arrChild valueForKey:@"StudentID"] objectAtIndex:idx];
        }
    }
    else if(sender.tag == 3)
    {
        if (idx > 0) {
            str_groupId = [[arrGroup valueForKey:@"GroupID"] objectAtIndex:idx];
            [self MakePurchase_SwmTm_BindNoOfDay:str_groupId];
        }
    }
    else if (sender.tag == 6)
    {
        str_totalDays = [[arrTotalDays valueForKey:@"NoOfDayID"] objectAtIndex:idx];
        txtfldPrice.text = [[str_totalDays componentsSeparatedByString:@"|"]lastObject];
        if (str_groupId != nil && str_totalDays != nil && str_month != nil)
        {
            [self MakePurchase_SwmTm_BindFillDay];
        }
    }
    [sender setTitleColor:[UIColor blackColor] forState:0];
}
- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

- (IBAction)btnAddClicked:(UIButton *)sender
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
    {
        if ([self Validation]) {
            [self AddToCart];
        }
    }else{
        
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success)
            {
                if ([self Validation]) {
                    [self AddToCart];
                }
            }
        }];
    }
}

-(BOOL)Validation
{
    if (str_siteId == nil)
    {
        v1.layer.borderColor = [[UIColor redColor]CGColor];
        v1.layer.borderWidth = 1.0f;
        return [self toastMsg:SiteSelection];
    }
    else if (str_childId == nil)
    {
        v2.layer.borderColor = [[UIColor redColor]CGColor];
        v2.layer.borderWidth = 1.0f;
        return [self toastMsg:ChildSelection];
    }
    else if (str_groupId == nil)
    {
        v3.layer.borderColor = [[UIColor redColor]CGColor];
        v3.layer.borderWidth = 1.0f;
        return [self toastMsg:GroupSelection];
    }
    else if (str_month == nil)
    {
        v4.layer.borderColor = [[UIColor redColor]CGColor];
        v4.layer.borderWidth = 1.0f;
        return [self toastMsg:MonthSelection];
    }
    else if (str_date == nil)
    {
        v5.layer.borderColor = [[UIColor redColor]CGColor];
        v5.layer.borderWidth = 1.0f;
        return [self toastMsg:StartDateSelection];
    }
    else if (counter != [[[str_totalDays componentsSeparatedByString:@"|"]firstObject] integerValue] || str_totalDays == nil)
    {
        v6.layer.borderColor = [[UIColor redColor]CGColor];
        v6.layer.borderWidth = 1.0f;
        return [self toastMsg:[NSString stringWithFormat:@"You must select at least %ld days",[[[str_totalDays componentsSeparatedByString:@"|"]firstObject] integerValue]]];
    }
    return YES;
}
-(BOOL)toastMsg:(NSString *)str_Msg
{
    [CommonClass showToastMsg:str_Msg];
    return NO;
}
-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
