


//
//  ChangePassword.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ChangePassword.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"

@interface ChangePassword ()<CommonDelegate>

@end

@implementation ChangePassword

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if([v isKindOfClass:[UITextField class]])
        {
            v.layer.borderWidth = 1.0f;
            v.layer.borderColor = RegisterTextColor.CGColor;
        }
        else if([v isKindOfClass:[UILabel class]])
        {
            NSMutableAttributedString *text =
            [[NSMutableAttributedString alloc]
             initWithAttributedString: ((UILabel *)v).attributedText];
            NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 1] options:NSCaseInsensitiveSearch];
            [text addAttribute:NSForegroundColorAttributeName
                         value:[UIColor redColor]
                         range:range];
            [((UILabel *)v) setAttributedText:text];
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksChangePassword :self :btnHome :nil :YES :self];
}

-(void)ChangePassword
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"OldPassword":txtCpwd.text,
                             @"NewPassword":txtNpwd.text
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MyAcnt_ChangePassword_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [CommonClass showToastMsg:PasswordUpdate];
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:@"The password you entered didn’t match our records" delegate:self];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(BOOL)PasswordValidatation
{
    NSString *strCpwd  = [CommonClass trimString:txtCpwd.text];
    NSString *strNpwd = [CommonClass trimString:txtNpwd.text];
    NSString *strCNpwd = [CommonClass trimString:txtCNpwd.text];
    
    if ([strCpwd length] == 0) {
        [txtCpwd becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Current Password" delegate:self];
        return NO;
    }
    else if ([strNpwd length] == 0) {
        [txtNpwd becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter New Password" delegate:self];
        return NO;
    }
    
    else if ([strCNpwd length] == 0) {
        [txtCNpwd becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Confirm Password" delegate:self];
        return NO;
    }
    else if (![txtNpwd.text isEqualToString:txtCNpwd.text]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Confirm Password Same as New Password" delegate:self];
        return NO;
    }
    return  YES;
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}
- (IBAction)onClickUpdatePasswordBtn:(id)sender
{
    if ([self PasswordValidatation])
    {
        [self ChangePassword];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
