//
//  ViewPaymentHistory.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewPaymentHistory : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UITableView *tblPaymentHistory;
    IBOutlet UIButton *btnHome,*btnStartDate,*btnEndDate,*btnLocation,*btnPTypes;
    IBOutlet NSLayoutConstraint *tblHeight;
    IBOutlet UILabel *lblMsg;
}
@end
