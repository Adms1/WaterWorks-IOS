//
//  SLViewController.m
//  WaterWorks
//
//  Created by Ankit on 27/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ScheduleMakeupViewController.h"
#import "SLDViewController.h"
#import "StudentListCell.h"
#import "AFNetworking.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "NSDate+MDExtension.h"
#import "MDDatePickerDialog.h"
#import "SchedulePopup.h"
#import "Transition.h"
#import "NIDropDown.h"

@interface ScheduleMakeupViewController ()<ScheduleDelegate,SchedulePopupDelegate,UIPopoverPresentationControllerDelegate,NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSMutableArray *arrStudentId, *arrStudentList, *arrStudentLessonType;
    NSMutableArray *temp_array, *arrSites;
    
    NSMutableDictionary *dicSelectedStudent, *dicComboStudent;
    int MakeupCount;
    NSMutableDictionary *dicFilterResult,*dicTempFilterResult;
    __block NSMutableArray *arrFilterInstructor;
    __block NSString *temkey;
}
@end

@implementation ScheduleMakeupViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblSlist.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    temp_array = [[NSMutableArray alloc]init];
    [temp_array addObject:[NSNumber numberWithInt:5]];
    [temp_array addObject:[NSNumber numberWithInt:6]];
    
    [self Schl_Get_MakeupCountByFamily];
    [self Schl_Page_Load];
    
    tblHeight.constant = v1Height.constant = v2Height.constant = v3Height.constant = lViewHeight.constant = MakeupCount = 0.0;
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
    
    [[NSUserDefaults standardUserDefaults]setValue:@"MakeUp" forKey:SCHEDULE];
}

//-(void)viewWillDisappear:(BOOL)animated
//{
//    [temp_array removeObject:[NSNumber numberWithInt:4]];
//}

#pragma mark - API Calling

-(void)Schl_Get_MakeupCountByFamily
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_MakeupCountByFamily_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN],@"familyid":[userDefault valueForKey:FAMILYID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            if (![[responseObject objectForKey:@"Mup_cnt"] isEqual:@0])
            {
                [webView setHidden:YES];
                
                MakeupCount = [[responseObject objectForKey:@"Mup_cnt"]intValue];
                
                CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :1 :MakeupCount];
                [self.view insertSubview:ct atIndex:0];
                
                [[NSUserDefaults standardUserDefaults]setInteger:MakeupCount forKey:MAKEUPCOUNT];
                
                [self getSiteByFamily];
            }
            else
            {
                [scroll.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
                [webView setHidden:NO];
                
                CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :1 :MakeupCount];
                [self.view insertSubview:ct atIndex:0];
                
                [[NSUserDefaults standardUserDefaults]setInteger:0 forKey:MAKEUPCOUNT];
                
                [SHARED_APPDELEGATE hideLoadingView];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
    }];
}

-(void)ScheMakeup_recountProcessByFamily
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [manager POST:ScheMakeup_recountProcessByFamily_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
    }];
}

-(void)getSiteByFamily
{
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        
        if (flag) {
            
            arrSites = [[NSMutableArray alloc]init];
            NSArray *arr = [responseObject objectForKey:@"SiteList"];
            [arrSites addObjectsFromArray:arr];
            
            if (arr.count == 1)
            {
                [lv setHidden:YES];
                lViewHeight.constant = 0.0;
                [temp_array addObject:[NSNumber numberWithInt:2]];
                [self Schl_Get_ActiveSiteStartEndDate:[[arr valueForKey:@"siteid"]objectAtIndex:0]];
            }
            else
            {
                [lv setHidden:NO];
                lViewHeight.constant = 80.0;
            }
            
            [self getStudentListByFamily:[[arr valueForKey:@"siteid"]objectAtIndex:0]];
            
            [[NSUserDefaults standardUserDefaults]setValue:[[arr valueForKey:@"siteid"]objectAtIndex:0] forKey:SITEID];
            [[NSUserDefaults standardUserDefaults]setValue:[[arr valueForKey:@"sitename"]objectAtIndex:0] forKey:SITENAME];
            [[NSUserDefaults standardUserDefaults]setBool:[[[arrSites valueForKey:@"Lafitness"]objectAtIndex:0] boolValue] forKey:LAFITNESS];
        }
    }];
}

-(void)Schl_Page_Load
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Page_Load_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN],@"ScheduleType":@"1"} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            [webView loadHTMLString:[[[responseObject valueForKey:@"LessonList"] valueForKey:@"UnusedMsg"] objectAtIndex:0]baseURL:nil];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)Schl_Get_ActiveSiteStartEndDate:(NSString *)siteID
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_ActiveSiteStartEndDate_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN],@"SiteID":siteID} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            SHARED_APPDELEGATE.startDate = [[[responseObject valueForKey:@"InstructorList"]valueForKey:@"StartDate"]objectAtIndex:0];
            NSDate *endDate = [[NSCalendar currentCalendar] dateByAddingUnit:NSCalendarUnitDay
                                                                       value:6
                                                                      toDate:[NSDate date]
                                                                     options:0];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"MM/dd/yyyy";
            //            SHARED_APPDELEGATE.endDate = [[[responseObject valueForKey:@"InstructorList"]valueForKey:@"EndDate"]objectAtIndex:0];;
            SHARED_APPDELEGATE.endDate = [dateFormatter stringFromDate:endDate];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentListByFamily:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    
    arrStudentList = [[NSMutableArray alloc]init];
    arrStudentId = [[NSMutableArray alloc]init];
    dicSelectedStudent = [[NSMutableDictionary alloc]init];
    //arrFilterInstructor = [[NSMutableArray alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:StudentList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr =[responseObject objectForKey:@"StudentList"];
            [arrStudentList addObjectsFromArray:arr];
            
            for (int i = 0; i < arrStudentList.count; i++)
            {
                [arrStudentId addObject:[[arrStudentList objectAtIndex:i]valueForKey:@"StudentID"]];
            }
            
            [self getStudentLessonType:strSiteId];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentLessonType:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"siteid":strSiteId,
                             @"studentarray":[arrStudentId componentsJoinedByString:@","],
                             @"mup":@"1",
                             @"familyid":[userDefault objectForKey:FAMILYID],
                             };
    
    arrStudentLessonType = [[NSMutableArray alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:StudentLessonList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSInteger count = arrStudentList.count;
            int x = 0;
            for (int i = 0; i < count; i++)
            {
                NSArray *arr =[responseObject objectForKey:[NSString stringWithFormat:@"LessonLst_%d",i+1]];
                if (arr.count > 0)
                {
                    [arrStudentLessonType addObject:arr];
                }
                else
                {
                    [arrStudentList removeObjectAtIndex:i-x];
                    x++;
                }
            }
            
            [tblSlist reloadData];
            tblHeight.constant = tblSlist.contentSize.height;
            
            [scroll layoutIfNeeded];
            [scroll setContentSize:CGSizeMake(self.view.frame.size.width,btnNext.frame.size.height + tblHeight.constant + 120 + v1Height.constant + v2Height.constant + v3Height.constant + lViewHeight.constant)];
            
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Button Actions

-(IBAction)btnSelectSameClassClicked:(UIButton *)sender
{
    NSArray *arr = @[v1,v2];
    for (UIView *view in arr)
    {
        for (UIView *v in view.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
            }
        }
    }
    
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
    
    if (sender.tag == 0)
    {
        SHARED_APPDELEGATE.sameClass = YES;
        [UIView animateWithDuration:0.5f animations:^{
            v2Height.constant = 0.0f;
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            [v2 setHidden:YES];
        }];
        
        [self addDynamicInstructorButton];
    }
    else
    {
        SHARED_APPDELEGATE.sameClass = NO;
        [UIView animateWithDuration:0.5f animations:^{
            v2Height.constant = 90.0f;
            v3Height.constant = 0.0f;
            
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            [v2 setHidden:NO];
            [v3 setHidden:YES];
        }];
    }
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width,btnNext.frame.size.height + tblHeight.constant + 120 + v1Height.constant + v2Height.constant + v3Height.constant + lViewHeight.constant)];
    [scroll scrollRectToVisible:CGRectOffset(btnNext.frame, 0, 30) animated:YES];
}

-(IBAction)btnSelectSameScheduleClicked:(UIButton *)sender
{
    [scroll viewWithTag:6].layer.borderColor = [[UIColor clearColor]CGColor];
    
    for (UIView *v in v2.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
        }
    }
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
    
    if (sender.tag == 0)
    {
        SHARED_APPDELEGATE.sameInstructor = YES;
        [self addDynamicInstructorButton];
    }
    else
    {
        SHARED_APPDELEGATE.sameInstructor = NO;
        [UIView animateWithDuration:0.5f animations:^{
            v3Height.constant = 0.0f;
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            [v3 setHidden:YES];
        }];
    }
    
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width,btnNext.frame.size.height + tblHeight.constant + 120 + v1Height.constant + v2Height.constant + v3Height.constant + lViewHeight.constant)];
    [scroll scrollRectToVisible:CGRectOffset(btnNext.frame, 0, 30) animated:YES];
}

-(void)addDynamicInstructorButton
{
    [scroll viewWithTag:4].layer.borderColor = [[UIColor clearColor]CGColor];
    [temp_array addObject:[NSNumber numberWithInt:4]];
    
    for (UIView *v in v3.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [v removeFromSuperview];
        }
    }
    
    __block int i = 0,j = 0;
    __block BOOL isSelect = NO;
    __block NSString *strFirstLessonType = [[[[dicComboStudent allValues] objectAtIndex:0] componentsSeparatedByString:@"|"]lastObject];
    
    [dicComboStudent enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        
        NSString *strLessonType = [[((NSString *)obj) componentsSeparatedByString:@"|"] lastObject];
        
        UIButton *btn;
        if ([strLessonType isEqualToString:strFirstLessonType])
        {
            btn = [[UIButton alloc]initWithFrame:CGRectMake(6, (45 + (i * 35)), (v3.frame.size.width - 12)/2-6, 35)];
            btn.tag = i;
            i++;
            strFirstLessonType = strLessonType;
        }
        else
        {
            btn = [[UIButton alloc]initWithFrame:CGRectMake((v3.frame.size.width - 12)/2-6, (45 + (j * 35)), (v3.frame.size.width - 12)/2, 35)];
            btn.tag = j;
            j++;
        }
        
        [btn setTitle:[[key componentsSeparatedByString:@" "] firstObject] forState:0];
        btn.backgroundColor = [UIColor clearColor];
        btn.titleLabel.font = FONT_OpenSans(14);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"CheckInstructor"] forState:UIControlStateSelected];
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
        btn.accessibilityValue = [[obj componentsSeparatedByString:@"|"]firstObject];
        
        NSString *strMakeupCount = [[strLessonType componentsSeparatedByString:@"["] lastObject];
        if([dicComboStudent allKeys].count == 2 && [strMakeupCount integerValue] > 1)
        {
            btn.selected = isSelect = YES;
        }
        else
        {
            btn.selected = NO;
        }
        
        [btn addTarget:self action:@selector(selectUnselectInstructor:) forControlEvents:UIControlEventTouchUpInside];
        [v3 addSubview:btn];
    }];
    
    [UIView animateWithDuration:0.5f animations:^{
        [v3 setHidden:NO];
        v3Height.constant = ((i>j ? i : j) * 35) + 45;
        [scroll scrollRectToVisible:btnNext.frame animated:YES];
        [self.view layoutIfNeeded];
        
    }completion:nil];
    
    arrFilterInstructor = [[NSMutableArray alloc]init];
    if([dicComboStudent allKeys].count >= 2 && !isSelect)
    {
        dicFilterResult = [[NSMutableDictionary alloc]init];
    }
    else
    {
        [arrFilterInstructor addObjectsFromArray:[dicComboStudent allValues]];
        if ([dicComboStudent allKeys].count == 2)
        {
            [dicFilterResult enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
                
                if (![[NSSet setWithArray:arrFilterInstructor] isEqual:[NSSet setWithArray:obj]]) {
                    [dicFilterResult removeObjectForKey:key];
                }
            }];
        }
    }
}

-(void)selectUnselectInstructor:(UIButton *)sender
{
    [scroll viewWithTag:4].layer.borderColor = [[UIColor clearColor]CGColor];
    [temp_array addObject:[NSNumber numberWithInt:4]];
    
    BOOL flag = sender.selected = !sender.selected;
    
    [dicTempFilterResult enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        
        NSArray *array = ((NSArray *)obj);
        
        NSArray *results = [array filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"SELF contains[c] %@",sender.accessibilityValue]];
        
        if (results.count > 0)
        {
            if (![temkey isEqualToString:key] && temkey != nil) {
                arrFilterInstructor = [[NSMutableArray alloc]init];
                if ([dicFilterResult valueForKey:key] != nil) {
                    [arrFilterInstructor addObjectsFromArray:[dicFilterResult valueForKey:key]];
                }
            }
            
            if(!flag)
            {
                [arrFilterInstructor removeObject:((NSString *)results.firstObject)];
            }
            else
            {
                NSString *strMakeupCount = [[key componentsSeparatedByString:@"["] lastObject];
                
                if (((NSArray *)[dicFilterResult valueForKey:key]).count == [[strMakeupCount substringToIndex:[strMakeupCount length]-1] intValue])
                {
                    sender.selected = !flag;
                    [CommonClass showToastMsg:[NSString stringWithFormat:@"%@ : %d",MakeupAvailabilityMsg,[[strMakeupCount substringToIndex:[strMakeupCount length]-1] intValue]]];
                    return;
                }
                else
                {
                    if (((NSArray *)[dicFilterResult valueForKey:key]).count == [self Combo_Limit:[CommonClass clearString:key]])
                    {
                        sender.selected = !flag;
                        [CommonClass showToastMsg:ComboLimit];
                        return;
                    }
                    [arrFilterInstructor addObject:((NSString *)results.firstObject)];
                }
            }
            
            if (arrFilterInstructor.count == 0) {
                [dicFilterResult removeObjectForKey:key];
            }
            else
            {
                [dicFilterResult setObject:arrFilterInstructor forKey:key];
            }
            temkey = key;
        }
    }];
    
    NSLog(@"Result.......%@",dicFilterResult);
}

-(int)Combo_Limit:(NSString *)str
{
    if ([str isEqualToString:@"Semi-Private"]) {
        return 2;
        
    }else if ([str isEqualToString:@"Group"]){
        return 4;
        
    }else if ([str isEqualToString:@"Stroke Clinic Int"] || [str isEqualToString:@"Stroke Clinic Adv"] || [str isEqualToString:@"Stroke Clinic"]){
        return 12;
        
    }else if ([str isEqualToString:@"P&M Beg"] || [str isEqualToString:@"P&M Int"] || [str isEqualToString:@"P&M B/I"] || [str isEqualToString:@"Stroke Clinic Beg"] || [str isEqualToString:@"Adult Stroke Clinic Beg"] || [str isEqualToString:@"Adult Stroke Clinic Int"]){
        return 6;
        
    }else if ([str isEqualToString:@"P&M Adv"]){
        return 3;
        
    }else{
        return 1;
    }
}

-(IBAction)btnNextStepClicked:(UIButton *)sender
{
    if ((lViewHeight.constant > 0 && [btnLocation.titleLabel.text isEqualToString:provideLocation]) || [dicSelectedStudent allKeys].count == 0 || (v3Height.constant > 0 && arrFilterInstructor.count == 0))
    {
        SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
        sp.s_delegate = self;
        if (lViewHeight.constant > 0 && [btnLocation.titleLabel.text isEqualToString:provideLocation])
        {
            [temp_array removeObject:[NSNumber numberWithInt:2]];
            //sp.msg = provideLocation;
        }
        else if ([dicSelectedStudent allKeys].count == 0)
        {
            [temp_array removeObject:[NSNumber numberWithInt:3]];
            //sp.msg = provideOneStudent;
        }
        else if (v3Height.constant > 0 && arrFilterInstructor.count == 0)
        {
            [temp_array removeObject:[NSNumber numberWithInt:4]];
            //sp.msg = provideOneStudentWSI;
        }
        
        /*
         */
        [self showRedAlert];
        sp.msg = ProvideInfoValidationMsg;
        [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height - 20)];
        [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
    }
    else
    {
        if (SHARED_APPDELEGATE.sameClass || SHARED_APPDELEGATE.sameInstructor)
        {
            if (arrFilterInstructor.count != [dicSelectedStudent allValues].count)
            {
                //                [KSToastView ks_showToast:@"Popup" duration:1.0];
                SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
                sp.s_delegate = self;
                sp.msg = ProvideComboMsg;
                sp.title_msg = @"Alert";
                sp.btn_msg = @"OK, got it";
                [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 20, sp.view.frame.size.height + 70)];
                [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
            }
            else
            {
                [self goNext];
            }
        }
        else
        {
            [self goNext];
        }
    }
}

-(void)goNext
{
    __block BOOL isCombo = YES;
    SLDViewController *sldvc = [[SLDViewController alloc] initWithNibName:@"SLDViewController" bundle:nil];
    NSMutableDictionary *tempDicFilterResult = [[NSMutableDictionary alloc]init];
    [tempDicFilterResult addEntriesFromDictionary:dicFilterResult];
    
    if (SHARED_APPDELEGATE.sameClass || SHARED_APPDELEGATE.sameInstructor)
    {
        [tempDicFilterResult removeObjectForKey:@"Private"];
        [tempDicFilterResult removeObjectForKey:@"Adult"];
        
        if ([tempDicFilterResult allKeys].count > 1)
        {
            [[tempDicFilterResult allValues] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (((NSArray *)obj).count == 1)
                {
                    [tempDicFilterResult removeObjectForKey:[[tempDicFilterResult allKeys] objectAtIndex:idx]];
                }
            }];
        }
        else
        {
            [[tempDicFilterResult allValues] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (((NSArray *)obj).count == 1)
                {
                    isCombo = NO;
                }
            }];
        }
    }
    sldvc.dicFilterResult = !SHARED_APPDELEGATE.sameClass && !SHARED_APPDELEGATE.sameInstructor ? dicTempFilterResult : tempDicFilterResult;
    if(!isCombo)
    {
        SHARED_APPDELEGATE.sameClass = SHARED_APPDELEGATE.sameInstructor = NO;
    }
    [self.navigationController pushViewController:sldvc animated:YES];
}

/*
 */

-(void)showRedAlert
{
    int x = -1;
    for (int i = 0; i < 5; i++)
    {
        if (![temp_array containsObject:[NSNumber numberWithInt:i+2]])
        {
            if (x == -1) {
                [scroll scrollRectToVisible:[scroll viewWithTag:i+2].frame animated:YES];
                x = 0;
            }
            [scroll viewWithTag:i+2].layer.borderColor = [[UIColor redColor]CGColor];
            [scroll viewWithTag:i+2].layer.borderWidth = 1.0f;
        }
    }
}

-(void)Continue:(SchedulePopup *)popup
{
    if (popup.view.tag == 100) {
        [self goNext];
    }
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickLocationBtn:(UIButton *)sender
{
    [scroll viewWithTag:2].layer.borderColor = [[UIColor clearColor]CGColor];
    [temp_array addObject:[NSNumber numberWithInt:2]];
    
    [CommonClass setLocation:arrSites :btnLocation :sender :self];
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    [[NSUserDefaults standardUserDefaults]setBool:[[[arrSites valueForKey:@"Lafitness"]objectAtIndex:idx] boolValue] forKey:LAFITNESS];
    
    [UIView animateWithDuration:0.5f animations:^{
        v1Height.constant = v2Height.constant = v3Height.constant = 0.0;
        SHARED_APPDELEGATE.sameClass = SHARED_APPDELEGATE.sameInstructor = NO;
        
    }completion:^(BOOL finished){
        v1.hidden = v2.hidden = v3.hidden = YES;
        
        for (UIView *v in v1.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
            }
        }
    }];
    
    [self Schl_Get_ActiveSiteStartEndDate:[[arrSites objectAtIndex:idx] valueForKey:@"siteid"]];
    
    [self getStudentListByFamily:[[arrSites valueForKey:@"siteid"]objectAtIndex:idx]];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrStudentList.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
    sCell = nil;
    if (sCell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
        sCell  = [nib objectAtIndex:0];
    }
    sCell.selectionStyle = UITableViewCellSelectionStyleNone;
    sCell.delegate = self;
    sCell.tag = indexPath.row * 100;
    
    [sCell setStudentLessons:[arrStudentLessonType objectAtIndex:indexPath.row]];
    sCell.lbl_sname.text = [[arrStudentList objectAtIndex:indexPath.row]valueForKey:@"SFirstName"];
    return sCell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [CustomAnimation SlideUp:cell :0.5];
}

-(void)SelectedStudent:(NSInteger)tag :(UIButton *)btn
{
    [scroll viewWithTag:3].layer.borderColor = [[UIColor clearColor]CGColor];
    [temp_array addObject:[NSNumber numberWithInt:3]];
    
    [UIView animateWithDuration:0.5f animations:^{
        v2Height.constant = v3Height.constant = 0.0f;
        [self.view layoutIfNeeded];
        
    }completion:^(BOOL finished){
        
        [v2 setHidden:YES];
        [v3 setHidden:YES];
    }];
    
    NSDictionary *Sdic = [arrStudentList objectAtIndex:tag/100];
    NSDictionary *Ldic = [[arrStudentLessonType objectAtIndex:tag/100] objectAtIndex:btn.tag];
    
    if (!btn.selected)
    {
        [dicSelectedStudent removeObjectForKey:Sdic[@"SFirstName"]];
    }
    else
    {
        if ([[[NSUserDefaults standardUserDefaults]valueForKey:LAFITNESS]boolValue])
        {
            if ([[[arrStudentList objectAtIndex:tag/100]valueForKey:@"SAge"]floatValue] < 2.90)
            {
                SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
                sp.s_delegate = self;
                sp.msg = ProvideStudentValidationMsg;
                [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
                [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
                btn.selected = NO;
                [btn setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
                [btn.superview.superview setBackgroundColor:[UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0]];
                return;
            }
        }
        
        [dicSelectedStudent setObject:[NSString stringWithFormat:@"%@|%@|%@|%@",Sdic[@"StudentID"],Sdic[@"SFirstName"],Ldic[@"LessionValue"],Ldic[@"LessionType"]] forKey:Sdic[@"SFirstName"]];
    }
    
    NSLog(@"%@",dicSelectedStudent);
    
    __block int counter = 0;
    dicComboStudent = [[NSMutableDictionary alloc]init];
    
    /*
     */
    
    dicFilterResult = [[NSMutableDictionary alloc]init];
    dicTempFilterResult = [[NSMutableDictionary alloc]init];
    
    [dicSelectedStudent enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        
        NSString *strLessonType = [[((NSString *)obj)componentsSeparatedByString:@"|"]lastObject];
        //strLessonType = [strLessonType substringToIndex:strLessonType.length-3];
        NSString *strLessonValue = [[((NSString *)obj)componentsSeparatedByString:@"|"]objectAtIndex:2];
        
        NSArray *totalLessonTypes = [[dicSelectedStudent allValues] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"SELF contains[cd] %@",[NSString stringWithFormat:@"%@|%@",strLessonValue,strLessonType]]];
        [dicFilterResult setObject:totalLessonTypes forKey:strLessonType];
        [dicTempFilterResult setObject:totalLessonTypes forKey:strLessonType];
        
        if (totalLessonTypes.count >= 2 && ![[CommonClass clearString:strLessonType] isEqualToString:@"e"]) {
            //[dicComboStudent setObject:dicFilterResult[strLessonType] forKey:key];;
            [dicComboStudent setObject:obj forKey:key];;
            counter = (int)totalLessonTypes.count;
        }
    }];
    
    if (counter >= 2)
    {
        [UIView animateWithDuration:0.5f animations:^{
            v1Height.constant = 90.0f;
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            [v1 setHidden:NO];
        }];
    }
    else
    {
        [UIView animateWithDuration:0.5f animations:^{
            v1Height.constant = v2Height.constant = v3Height.constant = 0.0f;
            SHARED_APPDELEGATE.sameClass = SHARED_APPDELEGATE.sameInstructor = NO;
            
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            v1.hidden = v2.hidden = v3.hidden = YES;
            
            for (UIView *v in v1.subviews)
            {
                if ([v isKindOfClass:[UIButton class]])
                {
                    [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
                }
            }
        }];
    }
    
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width,btnNext.frame.size.height + tblHeight.constant + 120 + v1Height.constant + v2Height.constant + v3Height.constant + lViewHeight.constant)];
    [scroll scrollRectToVisible:btnNext.frame animated:YES];
}


-(void)popViewController
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end


//        BOOL isContain = NO; NSInteger index = 0;
//
//        for (NSString *str in array)
//        {
//            NSString *newstr = [[[[str componentsSeparatedByString:@"|"] objectAtIndex:1] componentsSeparatedByString:@" "]firstObject];
//            if ([newstr containsString:sender.titleLabel.text]) {
//                index = [array indexOfObject:str];
//                isContain = YES;
//            }
//        }
