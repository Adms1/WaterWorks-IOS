//
//  SelectPaymentViewController.h
//  WaterWorks
//
//  Created by Ankit on 22/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectPaymentViewController : UIViewController
{
    IBOutlet UIButton *btnCart, *btnHome;
    IBOutlet UITableView *tblPayment;
    IBOutlet UIView *tblFooter;
}
@end
