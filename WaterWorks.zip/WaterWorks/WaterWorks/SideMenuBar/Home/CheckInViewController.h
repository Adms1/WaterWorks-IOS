//
//  CheckInViewController.h
//  WaterWorks
//
//  Created by Ankit on 25/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckInViewController : UIViewController
{
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,assign)NSArray *arrCheckIn;
@end
