//
//  PaidRemainCell.m
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PaidRemainCell.h"

@implementation PaidRemainCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setRemainingLessonDetaList:(RemainingLessons *)objRemaining
{
    
    NSString *strFindCount = [self stringByStrippingHTML:objRemaining.Count];
    NSString *strCount = [NSString stringWithFormat:@"%@",[strFindCount stringByAppendingString:@""]];

    NSString *firstWord = [[strCount componentsSeparatedByString:@" "] objectAtIndex:0];

    NSLog(@"%@",firstWord);
//    lblLessonType.text = [lblLessonType.text stringByAppendingString:@"your text"];
    
    if ([firstWord isEqualToString:@"Past"]) {
        lblCount.textColor = [UIColor redColor];
    }else{
        lblCount.textColor = [UIColor blackColor];
    }
    
    lblLessonType.text = objRemaining.LessonType;
    lblCount.text = [self stringByStrippingHTML:objRemaining.Count];
}

-(NSString *) stringByStrippingHTML:(NSString *)str {
    NSRange r;
    
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    return str;
}

@end
