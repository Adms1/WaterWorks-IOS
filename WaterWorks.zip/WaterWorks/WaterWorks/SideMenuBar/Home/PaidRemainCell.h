//
//  PaidRemainCell.h
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RemainingLessons.h"

@interface PaidRemainCell : UICollectionViewCell

{
    IBOutlet UILabel *lblLessonType;
    IBOutlet UILabel *lblCount;
}

-(void)setRemainingLessonDetaList:(RemainingLessons *)objRemaining;

@end
