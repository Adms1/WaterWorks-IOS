//
//  SeeMoreViewControllr.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UpComingClass.h"
#import "SeeMoreCell.h"

@interface SeeMoreViewControllr : UIViewController

{
    IBOutlet UITableView *tblSeeMoreList;
    
    NSMutableArray *arrMoreLesson;
}

@property (nonatomic ,strong) NSMutableArray *arrSeeList;

@end
