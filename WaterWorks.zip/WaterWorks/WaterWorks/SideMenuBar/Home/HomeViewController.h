//
//  HomeViewController.h
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "PaidRemainCell.h"
#import "SeeMoreViewControllr.h"
#import "AsyImage.h"

@interface HomeViewController : MasterViewController

{
    IBOutlet UICollectionView *collRemainingList;
    IBOutlet UICollectionView *collRemainingFirstList;
    IBOutlet UICollectionView *collRemainingSecondList;
    
    IBOutlet UIScrollView *scrollV;
    
    //FirstTimeUserView
    IBOutlet UIView *viewFirst;
    IBOutlet UIView *viewNoLesson;
    
    IBOutlet UILabel *lblName;
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblInstructor;
    
    IBOutlet AsyImage *imgProfile;
    
    //SecondTimeUserView
    IBOutlet UIView *viewSecond;
    
    IBOutlet AsyImage *firstAsy;
    IBOutlet AsyImage *secondAsy;
    IBOutlet AsyImage *thirdAsy;
    
    IBOutlet AsyImage *asyFirst;
    IBOutlet AsyImage *asySecond;
    
    
    IBOutlet UILabel *lblFirstUserDate;
    IBOutlet UILabel *lblSecondUserDate;
    IBOutlet UILabel *lblFirstInstructor;
    IBOutlet UILabel *lblSecondInstructor;
    
    //ThirdView
    IBOutlet UIView *viewThird;
    
    IBOutlet UILabel *lblFirstDate;
    IBOutlet UILabel *lblSecondDate;
    IBOutlet UILabel *lblThirdDate;
    IBOutlet UILabel *lblFirstInstruc;
    IBOutlet UILabel *lblSecondInstruc;
    IBOutlet UILabel *lblThirdInstruc;
    
    IBOutlet UIButton *btnThirdMyScheduler;
    IBOutlet UIButton *btnThirdSchedulerLesson;
    IBOutlet UIButton *btnThirdBuyMoreLessong;
    IBOutlet UIButton *btnSeeMore;
    
    NSMutableArray *arrupcomingList;
    NSMutableArray *arrRemainingList;
    
    IBOutlet NSLayoutConstraint *seeMoreHeight;
    IBOutlet UIButton *btnCheckIn;
    
    IBOutlet NSLayoutConstraint *c1Height, *c2Height, *c3Height;
}
@end
