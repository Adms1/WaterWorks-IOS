//
//  SeeMoreViewControllr.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SeeMoreViewControllr.h"
#import "UpComingClass.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface SeeMoreViewControllr ()<CommonDelegate>

@end

@implementation SeeMoreViewControllr

@synthesize arrSeeList;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    arrMoreLesson = [[NSMutableArray alloc] init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    [params setObject:strToken forKey:@"Token"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:upComminfClass_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrAfterLogin count] > 0) {
                
                for (NSDictionary *dict in arrAfterLogin) {
                    
                    UpComingClass *objUpComing = [[UpComingClass alloc] init];
                    
                    objUpComing.StudentName = [dict safeObjectForKey:@"StudentName"];
                    objUpComing.Photo = [dict safeObjectForKey:@"Photo"];
                    objUpComing.ScheduleDate = [dict objectForKey:@"Schedule Date"];
                    objUpComing.Instructor = [dict objectForKey:@"Instructor"];
                    
                    [arrMoreLesson addObject:objUpComing];
                }
                [tblSeeMoreList reloadData];
            }
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"Msg"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksUpComing :self :nil :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 67.0f;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [arrMoreLesson count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"SeeMore";
    
    SeeMoreCell *cell = (SeeMoreCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SeeMoreCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    UpComingClass *objUpComing = [arrMoreLesson objectAtIndex:indexPath.row];
    [cell setSeeMoreListDeta:objUpComing];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
     SalonShopView *viewSalonShop = [[SalonShopView alloc] initWithNibName:@"SalonShopView" bundle:nil];
     viewSalonShop.strSalonTitle = [arrSalonList objectAtIndex:indexPath.row];
     [self.navigationController pushViewController:viewSalonShop animated:YES];
     */
    
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
