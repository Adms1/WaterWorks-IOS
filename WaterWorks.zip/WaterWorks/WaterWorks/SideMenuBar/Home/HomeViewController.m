//
//  HomeViewController.m
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "HomeViewController.h"
#import "CommonClass.h"
#import "UpComingClass.h"
#import "RemainingLessons.h"
#import "FirstTimeViewController.h"
#import "AppDelegate.h"
#import "MyScheduleViewController.h"
#import "SLViewController.h"
#import "BuyLessonsViewController.h"
#import "LegalDocViewController.h"
#import "CheckInViewController.h"
#import "PastDuePopUp.h"

@interface HomeViewController ()<PastDueDelegate>
{
    NSMutableArray *arrSelectedCheckIn;
    NSDictionary *dic;;
}
@end

@implementation HomeViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [CommonClass setNavigationTitle:NavigationWaterWorksAqu:self :nil :nil :NO :nil];
    
    [collRemainingList registerNib:[UINib nibWithNibName:@"PaidRemainCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    [collRemainingFirstList registerNib:[UINib nibWithNibName:@"PaidRemainCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    [collRemainingSecondList registerNib:[UINib nibWithNibName:@"PaidRemainCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    
    [scrollV setContentSize:CGSizeMake(scrollV.frame.size.width, scrollV.frame.size.height)];
}

-(void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    [[UIApplication sharedApplication]setStatusBarStyle:UIStatusBarStyleLightContent];
    [self setNeedsStatusBarAppearanceUpdate];
    imgProfile.layer.cornerRadius = imgProfile.frame.size.width/2;
    imgProfile.layer.masksToBounds = YES;
}

-(void)checkInStatus
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:ShowHideScanPrograms_Url parameters:@{@"Token" : [[NSUserDefaults standardUserDefaults] valueForKey:TOKEN]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSDictionary *dict = [[responseObject objectForKey:@"FinalArray"] firstObject];
            
            if(dict != nil)
            {
                arrSelectedCheckIn = [[NSMutableArray alloc]init];
                for (NSString *key in dict)
                {
                    if (![dict[key] isEqual:@0])
                    {
                        [arrSelectedCheckIn addObject:key];
                        
                        btnCheckIn.layer.cornerRadius = 15.0f;
                        btnCheckIn.layer.masksToBounds = YES;
                        
                        UIBarButtonItem *barBtnhome = [[UIBarButtonItem alloc] initWithCustomView:btnCheckIn];
                        self.navigationItem.rightBarButtonItems = @[barBtnhome];
                    }
                }
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)Schl_Page_Load
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [manager POST:Schl_Page_Load_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN],@"ScheduleType":@"0"} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"%@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            [[NSUserDefaults standardUserDefaults]setValue:@"NoPastDue" forKey:PastDue];
            dic = [[responseObject safeObjectForKey:@"LessonList"] objectAtIndex:0];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    //    [self getChildCount];
    [self checkInStatus];
    [self Schl_Page_Load];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    arrRemainingList = [[NSMutableArray alloc] init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    [params setObject:strToken forKey:@"Token"];
    [params setObject:@"0" forKey:@"ReqFrom"];
    
    NSLog(@"Params %@",params);
    
    [manager POST:remainingLesson_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceRemainingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            if ([arrAfterLogin count] > 0) {
                
                for (NSDictionary *dict in arrAfterLogin) {
                    
                    RemainingLessons *objRemaining = [[RemainingLessons alloc] init];
                    
                    objRemaining.LessonType = [dict valueForKey:@"LessonType"];
                    objRemaining.Count = [dict valueForKey:@"Count"];
                    
                    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"LAFitness"]boolValue])
                    {
                        if ([objRemaining.Count containsString:@"Past due"] || [objRemaining.Count containsString:@"0"])
                        {
                            for (UIView *v in viewNoLesson.subviews) {
                                if ([v isKindOfClass:[UILabel class]]) {
                                    [((UILabel *)v)setText:@""];
                                }
                            }
                            [[NSUserDefaults standardUserDefaults]setValue:@"PastDue" forKey:PastDue];
                            viewFirst.hidden = NO;
                            viewFirst.frame = self.view.bounds;
                            [self.view addSubview:viewFirst];
                            viewNoLesson.hidden = YES;
                        }
                    }
                    
                    if ([objRemaining.LessonType isEqualToString:@""])
                    {
                        c1Height.constant = c2Height.constant = c3Height.constant = 0.0f;
                        break;
                    }
                    [arrRemainingList addObject:objRemaining];
                    
                }
                [collRemainingFirstList reloadData];
                [collRemainingList reloadData];
                [collRemainingSecondList reloadData];
            }
            [self setLessonListing];
        }
        else
        {
            //            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"LAFitness"]boolValue])
            //            {
            //                for (UIView *v in viewNoLesson.subviews) {
            //                    if ([v isKindOfClass:[UILabel class]]) {
            //                        [((UILabel *)v)setText:@""];
            //                    }
            //                }
            //                viewNoLesson.hidden = YES;
            //            }
            viewFirst.hidden = NO;
            viewFirst.frame = self.view.bounds;
            [self.view addSubview:viewFirst];
            [self setLessonListing];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)setLessonListing{
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    arrupcomingList = [[NSMutableArray alloc] init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    [params setObject:strToken forKey:@"Token"];
    
    NSLog(@"Params %@",params);
    
    [manager POST:upComminfClass_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrAfterLogin count] > 0) {
                
                if ([[NSUserDefaults standardUserDefaults]valueForKey:PastDue] == nil) {
                    viewNoLesson.hidden = NO;
                }
                
                for (NSDictionary *dict in arrAfterLogin) {
                    
                    UpComingClass *objUpComing = [[UpComingClass alloc] init];
                    
                    objUpComing.StudentName = [dict safeObjectForKey:@"StudentName"];
                    objUpComing.Photo = [dict safeObjectForKey:@"Photo"];
                    objUpComing.ScheduleDate = [dict objectForKey:@"Schedule Date"];
                    objUpComing.Instructor = [dict objectForKey:@"Instructor"];
                    
                    [arrupcomingList addObject:objUpComing];
                }
                if (viewNoLesson.hidden == NO) {
                    [self setUpComingDataList];
                }
            }
        }else{
            for (UIView *v in viewNoLesson.subviews) {
                if ([v isKindOfClass:[UILabel class]]) {
                    [((UILabel *)v)setText:@""];
                }
            }
            viewNoLesson.hidden = YES;
            [self setUpComingDataList];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)setUpComingDataList
{
    if ([arrupcomingList count] == 0) {
        viewFirst.hidden = NO;
        viewSecond.hidden = YES;
        viewThird.hidden = YES;
        viewFirst.frame = self.view.bounds;
        [self.view addSubview:viewFirst];
    }
    else if ([arrupcomingList count] == 1) {
        viewFirst.hidden = NO;
        viewSecond.hidden = YES;
        viewThird.hidden = YES;
        viewFirst.frame = self.view.bounds;
        [self.view addSubview:viewFirst];
        if ([arrupcomingList firstObject]) {
            
            UpComingClass *objUpComing = [arrupcomingList firstObject];
            lblDate.text = [NSString stringWithFormat:@"%@",objUpComing.ScheduleDate];
            lblInstructor.text = objUpComing.Instructor;
            lblName.text = [NSString stringWithFormat:@"%@'s Next Lesson :",objUpComing.StudentName];
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                imgProfile.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [imgProfile loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
        }
    }else if ([arrupcomingList count] == 2){
        viewSecond.hidden = NO;
        viewThird.hidden = YES;
        viewFirst.hidden = YES;
        viewSecond.frame = self.view.bounds;
        [self.view addSubview:viewSecond];
        asyFirst.layer.cornerRadius = 20.0f;
        asySecond.layer.cornerRadius = 20.0f;
        
        if ([arrupcomingList firstObject]) {
            UpComingClass *objUpComing = [arrupcomingList firstObject];
            lblFirstUserDate.text = [NSString stringWithFormat:@"%@-%@",objUpComing.ScheduleDate,objUpComing.StudentName];
            lblFirstInstructor.text = objUpComing.Instructor;
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                asyFirst.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [asyFirst loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
        }
        if ([arrupcomingList lastObject]) {
            UpComingClass *objUpComing = [arrupcomingList lastObject];
            lblSecondUserDate.text = [NSString stringWithFormat:@"%@-%@",objUpComing.ScheduleDate,objUpComing.StudentName];
            lblSecondInstructor.text = objUpComing.Instructor;
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                asySecond.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [asySecond loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
            
        }
    }
    else if
        ([arrupcomingList count] >= 3)
    {
        viewThird.hidden = NO;
        viewSecond.hidden = YES;
        viewFirst.hidden = YES;
        [scrollV setContentSize:CGSizeMake(scrollV.frame.size.width, viewThird.frame.size.height + 80)];
        viewThird.frame = self.view.bounds;
        [self.view addSubview:viewThird];
        if ([arrupcomingList count] == 3) {
            btnSeeMore.hidden = YES;
            //            seeMoreHeight.constant = 0.0f;
            [self setMoreThenThreeUpComingData];
        }else{
            btnSeeMore.hidden = NO;
            [self setMoreThenThreeUpComingData];
        }
    }
}
-(void)setMoreThenThreeUpComingData
{
    for (int i = 0; i < 3; i++) {
        UpComingClass *objUpComing = [arrupcomingList objectAtIndex:i];
        
        firstAsy.layer.cornerRadius = 20.0f;
        secondAsy.layer.cornerRadius = 20.0f;
        thirdAsy.layer.cornerRadius = 20.0f;
        
        if (i == 0) {
            lblFirstDate.text = [NSString stringWithFormat:@"%@-%@",objUpComing.ScheduleDate,objUpComing.StudentName];
            lblFirstInstruc.text = objUpComing.Instructor;
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                firstAsy.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [firstAsy loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
        }
        if (i == 1) {
            lblSecondDate.text = [NSString stringWithFormat:@"%@-%@",objUpComing.ScheduleDate,objUpComing.StudentName];
            lblSecondInstruc.text = objUpComing.Instructor;
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                secondAsy.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [secondAsy loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
        }
        if (i == 2) {
            lblThirdDate.text = [NSString stringWithFormat:@"%@-%@",objUpComing.ScheduleDate,objUpComing.StudentName];
            lblThirdInstruc.text = objUpComing.Instructor;
            
            NSString *imageName;
            
            if (objUpComing.Photo == nil || [objUpComing.Photo isEqualToString:@""]) {
                thirdAsy.image = [UIImage imageNamed:@"AppLogo"];
            }else{
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[objUpComing.Photo substringFromIndex:1]];
                imageName = [NSString stringWithFormat:@"%@",strUrl];
                [thirdAsy loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
            }
        }
    }
}

#pragma mark - UICollectionView Datasource
#pragma mark -

-(NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section
{
    return [arrRemainingList count];
}

#pragma mark - UICollectionView Delegate

-(UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //NSString *string = [[NSBundle mainBundle] pathForResource:@"IMAGE_FILE_NAME" ofType:@"jpg"]; // or ofType:@"png", etc.
    
    PaidRemainCell *cell = (PaidRemainCell *)[collRemainingList dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    if ([arrRemainingList count] > 0) {
        RemainingLessons *objRemaining = [arrRemainingList objectAtIndex:indexPath.row];
        [cell setRemainingLessonDetaList:objRemaining];
    }
    
    return cell;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    // Add inset to the collection view if there are not enough cells to fill the width.
    CGFloat cellSpacing = ((UICollectionViewFlowLayout *) collectionViewLayout).minimumLineSpacing;
    CGFloat cellWidth = ((UICollectionViewFlowLayout *) collectionViewLayout).itemSize.width;
    NSInteger cellCount = [collectionView numberOfItemsInSection:section];
    CGFloat inset = (collectionView.bounds.size.width - (cellCount * cellWidth) - ((cellCount - 1)*cellSpacing)) * 0.5;
    inset = MAX(inset, 0.0);
    return UIEdgeInsetsMake(0.0, inset, 0.0, 0.0);
}

- (IBAction)onClickMySchedulerBtn:(id)sender {
    
    MyScheduleViewController *viewschedule =[[MyScheduleViewController alloc]initWithNibName:@"MyScheduleViewController" bundle:nil];
    [self.navigationController pushViewController:viewschedule animated:YES];
    
}

- (IBAction)onClickMoreLessonBtn:(id)sender {
    
    BuyLessonsViewController *viewBuyLessons = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
    viewBuyLessons.strType = @"Buy";
    SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
    viewBuyLessons.FromComfirmSchedule = NO;
    [self.navigationController pushViewController:viewBuyLessons animated:YES];
}

- (IBAction)onClickLessonBtn:(id)sender
{
    if (![dic[@"pastdue"]isEqualToString:@"0"])
    {
        PastDuePopUp *pdp = [[PastDuePopUp alloc] initWithNibName:@"PastDuePopUp" bundle:nil];
        pdp.pd_delegate = self;
        pdp.strMsg = dic[@"pastduemessage"];
        [pdp.view setFrame:CGRectMake(pdp.view.frame.origin.x, pdp.view.frame.origin.y, self.view.frame.size.width - 40, pdp.view.frame.size.height)];
        [self presentPopupViewController:pdp animationType:MJPopupViewAnimationFade];
    }
    else
    {
        SLViewController *slvc = [[SLViewController alloc] initWithNibName:@"SLViewController" bundle:nil];
        [self.navigationController pushViewController:slvc animated:YES];
    }
}

-(void)RemovePopup:(PastDuePopUp *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickSeeMoreBtn:(id)sender {
    
    SeeMoreViewControllr *viewSeeMore = [[SeeMoreViewControllr alloc] initWithNibName:@"SeeMoreViewControllr" bundle:nil];
    [self.navigationController pushViewController:viewSeeMore animated:YES];
}

- (IBAction)onClickCheckInBtn:(id)sender {
    
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    CheckInViewController *cvc = [storyBoard instantiateViewControllerWithIdentifier:@"CheckInViewController"];
    cvc.arrCheckIn = arrSelectedCheckIn;
    [self.navigationController pushViewController:cvc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
