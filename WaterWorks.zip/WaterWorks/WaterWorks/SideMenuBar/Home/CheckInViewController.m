//
//  CheckInViewController.m
//  WaterWorks
//
//  Created by Ankit on 25/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CheckInViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface CheckInViewController ()<CommonDelegate>

@end

@implementation CheckInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksCheckIn :self :btnHome :nil :YES :self];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    int i = 0;
    for (NSString *str in _arrCheckIn)
    {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(15, (i * 48)+50, self.view.frame.size.width - 30, 40)];
        [btn setTitle:[str isEqualToString:@"Aerobics"] ? @"Water Aerobics" : [self makeStringSplit:str] forState:0];
        [btn setBackgroundColor:[UIColor colorWithRed:(243.0/255.0) green:(243.0/255.0) blue:(243.0/255.0) alpha:1.0]];
        [btn setTitleColor:[UIColor blackColor] forState:0];
        btn.titleLabel.font = FONT_Bold(14);
        btn.tag = [str isEqualToString:@"SwimLessons"] ? 1 : [str isEqualToString:@"SwimTeam"] ? 2 : [str containsString:@"LapSwim"] ? 3 : [str containsString:@"Aerobics"] ? 4 : [str containsString:@"PhysicalTherapy"] ? 5 : 0;
        [btn addTarget:self action:@selector(btnCheckInClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        btn.layer.shadowColor = [[UIColor grayColor] CGColor];
        btn.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
        btn.layer.shadowOpacity = 1.0f;
        btn.layer.shadowRadius = 1.0f;
        [self.view addSubview:btn];
        i++;
        
        //        if ([_arrCheckIn containsObject:@"LapSwim"] && [_arrCheckIn containsObject:@"MonthlyLapSwim"]) {
        //
        //            if ([str isEqualToString:@"MonthlyLapSwim"]) {
        //
        //                i--;
        //                [btn removeFromSuperview];
        //            }
        //        }
    }
}

-(NSString *)makeStringSplit:(NSString *)string
{
    NSRegularExpression *regexp = [NSRegularExpression
                                   regularExpressionWithPattern:@"([a-z])([A-Z])"
                                   options:0
                                   error:NULL];
    NSString *newString = [regexp
                           stringByReplacingMatchesInString:string
                           options:0
                           range:NSMakeRange(0, string.length)
                           withTemplate:@"$1 $2"];
    return newString;
}
-(IBAction)btnCheckInClicked:(UIButton *)sender
{
    [self checkInStatus:[NSString stringWithFormat:@"%ld",(long)sender.tag]];
}

-(void)checkInStatus:(NSString *)strProgId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token" : [[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"flg1" : @"false",
                             @"programid" : strProgId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:ScanCardsPrograms_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [CommonClass showToastMsg:CheckInSuccess];
            [self.navigationController popViewControllerAnimated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
