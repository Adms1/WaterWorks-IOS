//
//  SeeMoreCell.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SeeMoreCell.h"

@implementation SeeMoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    imgInstructor.layer.cornerRadius = 20.0f;
}

-(void)setSeeMoreListDeta:(UpComingClass *)objLesson
{
    lblInstructor.text = objLesson.Instructor;//[NSString stringWithFormat:@"%@",[arrList valueForKey:@"Instructor"]];
    
    NSString *strStudnetName = [NSString stringWithFormat:@"%@ - %@",objLesson.ScheduleDate,objLesson.StudentName];
    lblTitle.text = strStudnetName;
    
    if (objLesson.Photo == nil || [objLesson.Photo isEqualToString:@""])
    {
        imgInstructor.image = [UIImage imageNamed:@"AppLogo"];
    }
    else
    {
        if ([objLesson.Photo isEqualToString:@""])
        {
            imgInstructor.image = [UIImage imageNamed:@"SimpleProfile"];
        }
        else
        {
            NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[objLesson.Photo substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            
            [imgInstructor sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                if (error != nil) {
                    imgInstructor.image = [UIImage imageNamed:@"AppLogo"];
                }
            }];
        }
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
