//
//  SeeMoreCell.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyImage.h"
#import "UpComingClass.h"

@interface SeeMoreCell : UITableViewCell

{
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblInstructor;
    
    IBOutlet AsyImage *imgInstructor;
}

-(void)setSeeMoreListDeta:(UpComingClass *)objLesson;

@end
