//
//  MyAccountCell.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "MyAccountCell.h"

@implementation MyAccountCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.lbl_count.layer.cornerRadius = self.lbl_count.frame.size.width/2 - 5;
    self.lbl_count.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
