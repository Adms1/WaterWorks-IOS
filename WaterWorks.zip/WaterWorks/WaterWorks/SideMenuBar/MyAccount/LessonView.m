//
//  LessonView.m
//  WaterWorks
//
//  Created by Ankit on 21/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "LessonView.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface LessonView ()<CommonDelegate>

@end

@implementation LessonView

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksViewAllLevels :self :btnHome :nil :YES :self];
}
-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
