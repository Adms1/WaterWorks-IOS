//
//  Locations.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ProgressReport.h"
#import "AppDelegate.h"
#import "MyAccountCell.h"
#import "CommonClass.h"
#import "AFHTTPRequestOperationManager.h"
#import "AFNetworking.h"
#import "ProgressReportDetails.h"

@interface ProgressReport ()<CommonDelegate>
{
    NSMutableArray *studentArray;
}
@end

@implementation ProgressReport

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksProgressReport :self :btnHome :nil :YES :self];
    
    [self GetStudentList];
}

-(void)GetStudentList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MyAcnt_Get_ProgressRpt_List_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            studentArray = [responseObject valueForKey:@"ProgresRptList"];
            
        }else{
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[[responseObject valueForKey:@"ChangePass"] valueForKey:@"Msg"] delegate:self];
        }
        
        [tblStudents reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return studentArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblStudents dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[studentArray objectAtIndex:indexPath.row] valueForKey:@"SFirstName"],[[studentArray objectAtIndex:indexPath.row] valueForKey:@"SLastName"]];
    
    maCell.bgView.layer.borderColor = [[UIColor blackColor] CGColor];
    maCell.bgView.layer.borderWidth = 0.5f;
    
    return maCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ProgressReportDetails *prd = [self.storyboard instantiateViewControllerWithIdentifier:@"ProgressReportDetails"];
    prd.studentArray = [studentArray objectAtIndex:indexPath.row];
    [[self navigationController]pushViewController:prd animated:YES];
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
