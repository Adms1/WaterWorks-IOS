//
//  Locations.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ManageStudent.h"
#import "AppDelegate.h"
#import "MyAccountCell.h"
#import "CommonClass.h"
#import "AFHTTPRequestOperationManager.h"
#import "AFNetworking.h"
#import "UpdateStudent.h"
#import "FirstTimeViewController.h"
#import "LegalDocViewController.h"

@interface ManageStudent ()<CommonDelegate>
{
    NSMutableArray *studentArray;
    BOOL LegalDocFlag;
}
@end

@implementation ManageStudent

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:@"Students" :self :nil :nil :YES :self];
    UIBarButtonItem *barBtnhome = [[UIBarButtonItem alloc] initWithCustomView:btnHome];
    self.navigationItem.rightBarButtonItems = @[barBtnhome];
    
    [[self navigationController]setNavigationBarHidden:NO];
    [self IsLAFitness_Check_Login];
    [self GetStudentList];
}
-(void)IsLAFitness_Check_Login
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:IsLAFitness_Check_Login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"IsLaFitness"] :@"1"]) {
            
            [self LegDoc_Update_StudentDocStatus];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Update_StudentDocStatus
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Update_StudentDocStatus_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self LegDoc_Check_LoginDoc];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Check_LoginDoc
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Check_LoginDoc_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            LegalDocFlag = YES;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)GetStudentList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:MyAcnt_Get_StudentList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            studentArray = [responseObject valueForKey:@"StudentList"];
            
        }else{
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[[responseObject valueForKey:@"ChangePass"] valueForKey:@"Msg"] delegate:self];
        }
        
        [tblStudent reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (studentArray.count == 0) {
        return 1;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0 && studentArray.count > 0) {
        return studentArray.count;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 25;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblStudent.frame.size.width, 25)];
    headerView.backgroundColor = [UIColor clearColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, tblStudent.frame.size.width, 20)];
    lblSection.backgroundColor = [UIColor clearColor];
    if (section == 0 && studentArray.count > 0) {
        lblSection.textColor = [UIColor blackColor];
        [lblSection setText:@"Current Students"];
    }else{
        lblSection.textColor = [UIColor colorWithRed:(247.0/255.0) green:(149.0/255.0) blue:(34.0/255.0) alpha:1.0];
        [lblSection setText:@"Register a New Student"];
        
        [lblSection setUserInteractionEnabled:YES];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        [lblSection addGestureRecognizer:tap];
    }
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblStudent dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[studentArray objectAtIndex:indexPath.row] valueForKey:@"SFirstName"],[[studentArray objectAtIndex:indexPath.row] valueForKey:@"SLastName"]];
    
    [self setBorderWithTitle:maCell :indexPath];
    return maCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UpdateStudent *ups = [self.storyboard instantiateViewControllerWithIdentifier:@"UpdateStudent"];
    ups.arr_Student = [studentArray objectAtIndex:indexPath.row];
    [[self navigationController]pushViewController:ups animated:YES];
}

-(void)tap:(UITapGestureRecognizer *)gesture
{
    if (studentArray.count >= 5) {
        [CommonClass showAlertWithTitle:@"Waterworks" andMessage:@"You may not register more than 5 students your account online. If you need to register an additional student, please contact our front office at (949) 450-0777 to resolve this issue." delegate:self];
    }else{
        FirstTimeViewController *viewFirstTime = [[FirstTimeViewController alloc] initWithNibName:@"FirstTimeViewController" bundle:nil];
        viewFirstTime.strNew = @"Register New";
        [self.navigationController pushViewController:viewFirstTime animated:YES];
    }
}

-(void)setBorderWithTitle :(MyAccountCell *)cell :(NSIndexPath *)path
{
    [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeLeft color:[UIColor blackColor] thickness:1.0]];
    [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeRight color:[UIColor blackColor] thickness:1.0]];
    
    if (path.row == 0)
    {
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:1.0]];
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:0.5]];
    }
    else if (path.row > 0 && path.row < [tblStudent numberOfRowsInSection:path.section]-1)
    {
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:0.5]];
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:0.5]];
    }
    else if (path.row == [tblStudent numberOfRowsInSection:path.section]-1)
    {
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:0.5]];
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:1.0]];
    }
    
}

- (CALayer *)prefix_addUpperBorder:(UIRectEdge)edge color:(UIColor *)color thickness:(CGFloat)thickness
{
    CALayer *border = [CALayer layer];
    
    switch (edge) {
        case UIRectEdgeTop:
            border.frame = CGRectMake(0, 0, CGRectGetWidth(tblStudent.frame), thickness);
            break;
        case UIRectEdgeBottom:
            border.frame = CGRectMake(0, 40 - thickness, CGRectGetWidth(tblStudent.frame), thickness);
            break;
        case UIRectEdgeLeft:
            border.frame = CGRectMake(0, 0, thickness, 40);
            break;
        case UIRectEdgeRight:
            border.frame = CGRectMake(CGRectGetWidth(tblStudent.frame) - thickness, 0, thickness, 40);
            break;
        default:
            break;
    }
    
    border.backgroundColor = color.CGColor;
    return border;
}


-(void)popViewController
{
    if (LegalDocFlag)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        LegalDocViewController *ldvc = [storyBoard instantiateViewControllerWithIdentifier:@"LegalDocViewController"];
        [[self navigationController]setNavigationBarHidden:YES];
        [[self navigationController]pushViewController:ldvc animated:YES];
    }
    else
    {
        [[self navigationController]popViewControllerAnimated:YES];
    }
}

-(IBAction)btnHome:(id)sender
{
    if (LegalDocFlag)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        LegalDocViewController *ldvc = [storyBoard instantiateViewControllerWithIdentifier:@"LegalDocViewController"];
        [[self navigationController]setNavigationBarHidden:YES];
        [[self navigationController]pushViewController:ldvc animated:YES];
    }
    else
    {
        [SHARED_APPDELEGATE setHomeViewController];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
