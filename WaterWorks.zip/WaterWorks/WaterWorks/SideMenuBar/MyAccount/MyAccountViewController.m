//
//  MyViewController.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "MyAccountViewController.h"
#import "MyAccountCell.h"
#import "AppDelegate.h"
#import "ChangeMail.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "Locations.h"
#import "ChangePassword.h"
#import "ManageStudent.h"
#import "ViewPaymentHistory.h"
#import "ProgressReport.h"
#import "ManageProfile.h"
#import "AddPayment.h"
#import "ManagePayment.h"

@interface MyAccountViewController ()<CommonDelegate>
{
    NSArray *arr_sectionTitle;
    NSDictionary *dicTitle;
    NSString *email,*studentCount;
    NSArray *arr_Locations;
    NSArray *arr_Location;
    ManageProfile *mp;
}
@end

@implementation MyAccountViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arr_sectionTitle = @[@"Email - ",@"Locations - ",@"Profile Settings",@"Payment Options"];
    
    dicTitle = @{
                 @"0":@"Change Email",
                 @"1":@"Change or Add Locations",
                 @"2":@"Manage Profile|Manage Students|Change Password|Payment History|Progress Report",
                 @"3":@"Add Payment Account|Manage Payment Account",
                 };
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMyAccount :self :btnHome :nil :NO :nil];
    [tblMyaccount setContentOffset:CGPointZero];
    [self GetStudentCount];
}

#pragma mark - Api Calling

-(void)Get_MyAccount
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID]
                             };
    
    [manager POST:Get_MyAccount_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            mp = [self.storyboard instantiateViewControllerWithIdentifier:@"ManageProfile"];
            mp.arrStudent = [[responseObject valueForKey:@"GetFamilyDtl"] objectAtIndex:0];
            
            email = [[[responseObject valueForKey:@"GetFamilyDtl"]objectAtIndex:0]valueForKey:@"Email"];
            
            arr_sectionTitle = @[[NSString stringWithFormat:@"Email - %@",email],@"Locations - ",@"Profile Settings",@"Payment Options"];
            
        }
        
        [self Schl_Get_SiteByFamily];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)Schl_Get_SiteByFamily
{
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        if (flag) {
            arr_Locations = [[responseObject valueForKey:@"SiteList"]valueForKey:@"sitename"];
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            for (NSString *str in arr_Locations)
            {
                NSRange replaceRange = [str rangeOfString:@" @ LA Fitness"];
                if (replaceRange.location != NSNotFound){
                    NSString* result = [str stringByReplacingCharactersInRange:replaceRange withString:@""];
                    [array addObject:result];
                }else{
                    [array addObject:str];
                }
            }
            
            arr_Location = [responseObject valueForKey:@"SiteList"];
            
            NSString *str = array.count > 2 ? [NSString stringWithFormat:@"%@,%@ & %lu Others",[array objectAtIndex:0],[array objectAtIndex:1],array.count - 2] : [array componentsJoinedByString:@","];
            
            arr_sectionTitle = @[[NSString stringWithFormat:@"Email - %@",email],[NSString stringWithFormat:@"Locations - %@",str],@"Profile Settings",@"Payment Options"];
        }
        else{
            if (![[[[responseObject valueForKey:@"SiteList"] valueForKey:@"Msg"]objectAtIndex:0]isEqual:[NSNull null]])
            {
                arr_Locations = [[NSArray alloc]init];
                arr_sectionTitle = @[@"Email - ",@"Locations - ",@"Profile Settings",@"Payment Options"];
            }
        }
        [tblMyaccount reloadData];
    }];
}

-(void)GetStudentCount
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetStudentCount_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            studentCount = [[[responseObject valueForKey:@"Student"]valueForKey:@"StudentCount"] objectAtIndex:0];
            
            if ([studentCount intValue] == 0) {
                dicTitle = @{
                             @"0":@"Change Email",
                             @"1":@"Change or Add Locations",
                             @"2":@"Manage Profile|Register a Student|Change Password|Payment History|Progress Report",
                             @"3":@"Add Payment Account|Manage Payment Account",
                             };
            }
        }
        
        [self Get_MyAccount];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
        case 1:
            return 1;
            
        case 2:
            return 5;
            
        case 3:
            return 2;
            
        default:
            break;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    CGSize size = [self getDynamicHeightOflbl:[arr_sectionTitle objectAtIndex:section]];
    return size.height+10 > 30 ? size.height+10 : 30;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGSize size = [self getDynamicHeightOflbl:[arr_sectionTitle objectAtIndex:section]];
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblMyaccount.frame.size.width,size.height+10 > 30 ? size.height+10 : 30)];
    headerView.backgroundColor = [UIColor clearColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, tblMyaccount.frame.size.width, size.height > 20 ? size.height: 20)];
    lblSection.backgroundColor = [UIColor clearColor];
    lblSection.textColor = [UIColor blackColor];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    lblSection.numberOfLines = 0;
    lblSection.lineBreakMode = NSLineBreakByWordWrapping;
    [lblSection setText:[arr_sectionTitle objectAtIndex:section]];
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblMyaccount dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    [self setBorderWithTitle:maCell :indexPath];
    return maCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        ChangeMail *cm = [self.storyboard instantiateViewControllerWithIdentifier:@"ChangeMail"];
        cm.str_currentEmail = email;
        [[self navigationController]pushViewController:cm animated:YES];
    }
    else if (indexPath.section == 1)
    {
        [self ViewController:[Locations new] :@"Locations"];
    }
    else if (indexPath.section == 2)
    {
        if (indexPath.row == 0)
        {
            [[self navigationController]pushViewController:mp animated:YES];;
        }
        else if (indexPath.row == 1)
        {
            [self ViewController:[ManageStudent new] :@"ManageStudent"];
        }
        else if (indexPath.row == 2)
        {
            [self ViewController:[ChangePassword new] :@"ChangePassword"];
        }
        else if (indexPath.row == 3)
        {
            [self ViewController:[ViewPaymentHistory new] :@"ViewPaymentHistory"];
        }
        else if (indexPath.row == 4)
        {
            [self ViewController:[ProgressReport new] :@"ProgressReport"];
        }
    }
    else if (indexPath.section == 3)
    {
        if (indexPath.row == 0)
        {
            [self ViewController:[AddPayment new] :@"AddPayment"];
        }
        else if (indexPath.row == 1)
        {
            [self ViewController:[ManagePayment new] :@"ManagePayment"];
        }
    }
}

#pragma mark - Actions

-(void)ViewController:(UIViewController *)vc :(NSString *)identifier
{
    vc = [self.storyboard instantiateViewControllerWithIdentifier:identifier];
    [[self navigationController]pushViewController:vc animated:YES];
}

-(void)setBorderWithTitle :(MyAccountCell *)cell :(NSIndexPath *)path
{
    [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeLeft color:[UIColor blackColor] thickness:1.0]];
    [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeRight color:[UIColor blackColor] thickness:1.0]];
    
    if (path.section == 2 && path.row == 1)
    {
        if ([studentCount intValue] == 0)
        {
            cell.lbl_count.text = @"!";
            cell.lbl_count.backgroundColor = [UIColor redColor];
        }
        else
        {
            cell.lbl_count.text = [NSString stringWithFormat:@"%@",studentCount];
            cell.lbl_count.backgroundColor = [UIColor colorWithRed:(122.0/255.0) green:(175.0/255.0) blue:(94.0/255.0) alpha:1.0];
        }
    }
    if (path.section == 2 || path.section == 3)
    {
        cell.lbl_name.text = [[[dicTitle valueForKey:[NSString stringWithFormat:@"%ld",(long)path.section]] componentsSeparatedByString:@"|"] objectAtIndex:path.row];
        if (path.row == 0)
        {
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:1.0]];
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:0.5]];
        }
        else if (path.row > 0 && path.row < [tblMyaccount numberOfRowsInSection:path.section]-1)
        {
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:0.5]];
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:0.5]];
        }
        else if (path.row == [tblMyaccount numberOfRowsInSection:path.section]-1)
        {
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:0.5]];
            [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:1.0]];
        }
    }
    else
    {
        cell.lbl_name.text = [dicTitle valueForKey:[NSString stringWithFormat:@"%ld",(long)path.section]];
        if (path.section == 1) {
            cell.lbl_count.text = [NSString stringWithFormat:@"%lu",(unsigned long)arr_Locations.count];
            cell.lbl_count.backgroundColor = [UIColor colorWithRed:(122.0/255.0) green:(175.0/255.0) blue:(94.0/255.0) alpha:1.0];
        }
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeTop color:[UIColor blackColor] thickness:1.0]];
        [cell.layer addSublayer:[self prefix_addUpperBorder:UIRectEdgeBottom color:[UIColor blackColor] thickness:1.0]];
    }
}

- (CALayer *)prefix_addUpperBorder:(UIRectEdge)edge color:(UIColor *)color thickness:(CGFloat)thickness
{
    CALayer *border = [CALayer layer];
    
    switch (edge) {
        case UIRectEdgeTop:
            border.frame = CGRectMake(0, 0, CGRectGetWidth(tblMyaccount.frame), thickness);
            break;
        case UIRectEdgeBottom:
            border.frame = CGRectMake(0, 40 - thickness, CGRectGetWidth(tblMyaccount.frame), thickness);
            break;
        case UIRectEdgeLeft:
            border.frame = CGRectMake(0, 0, thickness, 40);
            break;
        case UIRectEdgeRight:
            border.frame = CGRectMake(CGRectGetWidth(tblMyaccount.frame) - thickness, 0, thickness, 40);
            break;
        default:
            break;
    }
    
    border.backgroundColor = color.CGColor;
    return border;
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_Bold(14)}]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.view.frame.size.width - 20, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize size = rect.size;
    return size;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
