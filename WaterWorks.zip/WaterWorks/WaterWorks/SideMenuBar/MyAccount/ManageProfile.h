//
//  ManageProfile.h
//  WaterWorks
//
//  Created by Ankit on 20/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InputText.h"

@interface ManageProfile : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UIButton *btnHome,*btnUpdate;
    IBOutlet InputText *txt_pno,*txt_sno,*txt_street,*txt_substreet,*txt_zip,*txt_pfname,*txt_plname,*txt_sfname,*txt_slname;
    
    IBOutlet UITextField *txt_pno1,*txt_pno2,*txt_pno3,*txt_pno4,*txt_pno5,*txt_pno6;
    IBOutlet UIButton *btn_ppno,*btn_spno,*btn_pno1,*btn_pno2,*btn_pno3,*btn_pno4,*btn_pno5,*btn_pno6;
    IBOutlet UIView *v1,*v2,*v3,*v4,*v5,*v6;
    IBOutlet NSLayoutConstraint *av1,*av2,*av3,*av4,*av5,*av6;
}
@property(nonatomic,retain)NSArray *arrStudent;
@end
