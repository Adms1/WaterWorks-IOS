//
//  ManageProfile.m
//  WaterWorks
//
//  Created by Ankit on 20/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ManageProfile.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "NIDropDown.h"

@interface ManageProfile ()<NIDropDownDelegate,CommonDelegate>
{
    int count;
    NSArray *callType;
    NIDropDown *dropDown;
    UITextField* activeField;
}
@end

@implementation ManageProfile

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (UIView *v in [scroll_main subviews])
    {
        if([v isKindOfClass:[UILabel class]])
        {
            if(((UILabel *)v).tag != 100)
            {
                NSMutableAttributedString *text =
                [[NSMutableAttributedString alloc]
                 initWithAttributedString: ((UILabel *)v).attributedText];
                NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 1] options:NSCaseInsensitiveSearch];
                [text addAttribute:NSForegroundColorAttributeName
                             value:[UIColor redColor]
                             range:range];
                [((UILabel *)v) setAttributedText:text];
            }
        }
        else if([v isKindOfClass:[UITextField class]] || ([v isKindOfClass:[UIButton class]] && v.tag != 1000))
        {
            v.layer.borderWidth = 1.0f;
            v.layer.borderColor = RegisterTextColor.CGColor;
            
            if([v isKindOfClass:[UITextField class]])
            {
                ((UITextField *)v).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v).leftViewMode = UITextFieldViewModeAlways;
                ((UITextField *)v).rightViewMode = UITextFieldViewModeAlways;
            }
        }
        else if(![v isKindOfClass:[UILabel class]] && ![v isKindOfClass:[UIButton class]] && ![v isKindOfClass:[UITextField class]])
        {
            [v setHidden:YES];
            for (UIView *view in [v subviews])
            {
                if([view isKindOfClass:[UITextField class]] || ([view isKindOfClass:[UIButton class]] && view.tag != 1000))
                {
                    view.layer.borderWidth = 1.0f;
                    view.layer.borderColor = RegisterTextColor.CGColor;
                    
                    if([view isKindOfClass:[UITextField class]])
                    {
                        ((UITextField *)view).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                        ((UITextField *)view).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                        ((UITextField *)view).leftViewMode = UITextFieldViewModeAlways;
                        ((UITextField *)view).rightViewMode = UITextFieldViewModeAlways;
                    }
                }
            }
        }
    }
    
    av1.constant = av2.constant = av3.constant = av4.constant = av5.constant = av6.constant = 0.0f;
    callType = @[@"Home" ,@"Mom Cell" ,@"Dad Cell" ,@"Mom Work",@"Dad Work" ,@"Grand Parent" ,@"Baby Sitter" ,@"Relative" ,@"Fax" ,@"Other"];
    
    [self SetData];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksManageProfile :self :btnHome :nil :YES :self];
}

-(void)SetData
{
    [txt_pfname setText:[_arrStudent valueForKey:@"PFirstName"]];
    [txt_plname setText:[_arrStudent valueForKey:@"PLastName"]];
    [txt_sfname setText:[_arrStudent valueForKey:@"SFirstName"]];
    [txt_slname setText:[_arrStudent valueForKey:@"SLastName"]];
    
    if (![[_arrStudent valueForKey:@"Phone1"] isEqualToString:@"()-"]) {
        [txt_pno setText:[_arrStudent valueForKey:@"Phone1"]];
    }
    
    if (![[_arrStudent valueForKey:@"Phone2"] isEqualToString:@"()-"]) {
        [txt_sno setText:[_arrStudent valueForKey:@"Phone2"]];
    }
    
    if (![[_arrStudent valueForKey:@"Phone3"] isEqualToString:@"()-"]) {
        [txt_pno1 setText:[_arrStudent valueForKey:@"Phone3"]];
        if (txt_pno1.text.length > 0) {
            count = 0;
            txt_pno1.tag = 3;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType3"] integerValue] < 11) {
                [btn_pno1 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType3"] integerValue]-1] forState:0];
                [btn_pno1 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    if (![[_arrStudent valueForKey:@"Phone4"] isEqualToString:@"()-"]) {
        [txt_pno2 setText:[_arrStudent valueForKey:@"Phone4"]];
        if (txt_pno2.text.length > 0) {
            count = 1;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType4"] integerValue] < 11) {
                [btn_pno2 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType4"] integerValue]-1] forState:0];
                [btn_pno2 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    if (![[_arrStudent valueForKey:@"Phone5"] isEqualToString:@"()-"]) {
        [txt_pno3 setText:[_arrStudent valueForKey:@"Phone5"]];
        if (txt_pno3.text.length > 0) {
            count = 2;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType5"] integerValue] < 11) {
                [btn_pno3 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType5"] integerValue]-1] forState:0];
                [btn_pno3 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    if (![[_arrStudent valueForKey:@"Phone6"] isEqualToString:@"()-"]) {
        [txt_pno4 setText:[_arrStudent valueForKey:@"Phone6"]];
        if (txt_pno4.text.length > 0) {
            count = 3;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType6"] integerValue] < 11) {
                [btn_pno4 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType6"] integerValue]-1] forState:0];
                [btn_pno4 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    if (![[_arrStudent valueForKey:@"Phone7"] isEqualToString:@"()-"]) {
        [txt_pno5 setText:[_arrStudent valueForKey:@"Phone7"]];
        if (txt_pno5.text.length > 0) {
            count = 4;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType7"] integerValue] < 11) {
                [btn_pno5 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType7"] integerValue]-1] forState:0];
                [btn_pno5 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    if (![[_arrStudent valueForKey:@"Phone8"] isEqualToString:@"()-"]) {
        [txt_pno6 setText:[_arrStudent valueForKey:@"Phone8"]];
        if (txt_pno6.text.length > 0) {
            count = 5;
            [self btnAddAdditional:nil];
            if ([[_arrStudent valueForKey:@"PhoneType8"] integerValue] < 11) {
                [btn_pno6 setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType8"] integerValue]-1] forState:0];
                [btn_pno6 setTitleColor:[UIColor blackColor] forState:0];
            }
        }
    }
    
    
    for (UIView *v in scroll_main.subviews)
    {
        if([v isKindOfClass:[UITextField class]] && v.tag > 2)
        {
            v.tag = txt_pno1.tag == 3 ? v.tag+1 : v.tag;
        }
    }
    
    /*txt_street.tag = txt_pno1.tag == 3 ? txt_street.tag+1 : txt_street.tag;
     txt_substreet.tag = txt_pno1.tag == 3 ? txt_substreet.tag+1 : txt_substreet.tag;
     txt_pfname.tag = txt_pfname.tag == 3 ? txt_pfname.tag+1 : txt_pfname.tag;
     txt_plname.tag = txt_plname.tag == 3 ? txt_plname.tag+1 : txt_plname.tag;
     txt_sfname.tag = txt_sfname.tag == 3 ? txt_sfname.tag+1 : txt_sfname.tag;
     txt_slname.tag = txt_slname.tag == 3 ? txt_slname.tag+1 : txt_slname.tag;*/
    
    [txt_zip setText:[_arrStudent valueForKey:@"ZipeCode"]];
    [txt_street setText:[_arrStudent valueForKey:@"Address"]];
    
    if ([[_arrStudent valueForKey:@"PhoneType1"] integerValue]-1 >= 0) {
        [btn_ppno setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType1"] integerValue]-1] forState:0];
    }
    if ([[_arrStudent valueForKey:@"PhoneType2"] integerValue]-1 >= 0) {
        [btn_spno setTitle:[callType objectAtIndex:[[_arrStudent valueForKey:@"PhoneType2"] integerValue]-1] forState:0];
    }
}

//-(void)viewWillAppear:(BOOL)animated
//{
//    UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touch:)];
//    [recognizer setNumberOfTapsRequired:1];
//    [recognizer setNumberOfTouchesRequired:1];
//    [scroll_main addGestureRecognizer:recognizer];
//}
//
//-(void)touch:(UITapGestureRecognizer *)gesture
//{
//    //    [scroll_main setContentOffset:CGPointZero animated:YES];
//    //    [self.view endEditing:YES];
//}

-(void)UpdateStudentProfile
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"PFirstName":txt_pfname.text,
                             @"PLastName":txt_plname.text,
                             @"SFirstName":txt_sfname.text,
                             @"SLastName":txt_slname.text,
                             @"EmailAdd":[_arrStudent valueForKey:@"Email"],
                             @"ConfirmEmail":[_arrStudent valueForKey:@"ConfrmEmail"],
                             @"Password":[_arrStudent valueForKey:@"Confrmpassword"],
                             @"ConfrmPassword":[_arrStudent valueForKey:@"Confrmpassword"],
                             @"Address":[NSString stringWithFormat:@"%@ %@",txt_street.text,txt_substreet.text],
                             @"Zipcode":txt_zip.text,
                             @"State":[_arrStudent valueForKey:@"State"],
                             @"City":[_arrStudent valueForKey:@"City"],
                             @"SiteID":[_arrStudent valueForKey:@"WU_siteid"],
                             @"OrgPass":[_arrStudent valueForKey:@"Orgpassword"],
                             @"OrgCnfrmPass":[_arrStudent valueForKey:@"OrgConfrmpassword"],
                             @"strMaster":@"0",
                             @"strSecondary":@"0",
                             @"strChild":@"0",
                             @"strOther":[_arrStudent valueForKey:@"OtherTxt"],
                             @"status":[_arrStudent valueForKey:@"status"],
                             @"wu_MemStatus":[_arrStudent valueForKey:@"wu_MemStatus"],
                             
                             @"Phone1":txt_pno.text,
                             @"Phone2":txt_sno.text,
                             @"Phone3":txt_pno1.text,
                             @"Phone4":txt_pno2.text,
                             @"Phone5":txt_pno3.text,
                             @"Phone6":txt_pno4.text,
                             @"Phone7":txt_pno5.text,
                             @"Phone8":txt_pno6.text,
                             
                             @"PhoneType1": [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_ppno.titleLabel.text]+1],
                             @"PhoneType2": [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_spno.titleLabel.text]+1],
                             @"PhoneType3":[btn_pno1.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno1.titleLabel.text]+1],
                             @"PhoneType4":[btn_pno2.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno2.titleLabel.text]+1],
                             @"PhoneType5":[btn_pno3.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno3.titleLabel.text]+1],
                             @"PhoneType6":[btn_pno4.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno4.titleLabel.text]+1],
                             @"PhoneType7":[btn_pno5.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno5.titleLabel.text]+1],
                             @"PhoneType8":[btn_pno6.titleLabel.text isEqualToString:@"-Select Type-"] ? @"0" : [NSString stringWithFormat:@"%lu",(unsigned long)[callType indexOfObject:btn_pno6.titleLabel.text]+1],
                             
                             @"status":[_arrStudent valueForKey:@"wu_MemStatus"],
                             @"PLeavePrivate":[_arrStudent valueForKey:@"PLeavePrivate"],
                             @"SLeavePrivate":[_arrStudent valueForKey:@"SLeavePrivate"],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Update_MyAccount_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [CommonClass showToastMsg:ProfileUpdated];

            [[self navigationController]popViewControllerAnimated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(BOOL)ProfileValidation
{
    if (txt_pno.text.length == 0)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Phone no." delegate:self];
        return NO;
    }
    else if (txt_street.text.length == 0)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Address" delegate:self];
        return NO;
    }
    else if (txt_zip.text.length == 0)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter ZipCode" delegate:self];
        return NO;
    }
    else if (txt_pfname.text.length == 0)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter First Name" delegate:self];
        return NO;
    }
    else if (txt_plname.text.length == 0)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Last Name" delegate:self];
        return NO;
    }
    else if (av1.constant > 0 && ((UITextField *)v1.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v1.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v1.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
        else
        {
            if (((UITextField *)v1.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    else if (av2.constant > 0 && ((UITextField *)v2.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v2.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v2.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
                
            }
        }
        else
        {
            if (((UITextField *)v2.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    else if (av3.constant > 0 && ((UITextField *)v3.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v3.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v3.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
        else
        {
            if (((UITextField *)v3.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    else if (av4.constant > 0 && ((UITextField *)v4.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v4.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v4.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
        else
        {
            if (((UITextField *)v4.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    else if (av5.constant > 0 && ((UITextField *)v5.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v5.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v5.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
        else
        {
            if (((UITextField *)v5.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    else if (av6.constant > 0 && ((UITextField *)v6.subviews[0]).text.length > 0)
    {
        if ([((UITextField *)v6.subviews[0]).text containsString:@"-"])
        {
            if (((UITextField *)v6.subviews[0]).text.length < 14)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
        else
        {
            if (((UITextField *)v6.subviews[0]).text.length < 10)
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Phone no." delegate:self];
                return NO;
            }
        }
    }
    return YES;
}

-(IBAction)btnUpdateProfile:(UIButton *)sender
{
    if ([self ProfileValidation])
    {
        [self UpdateStudentProfile];
    }
}
-(IBAction)btnAddAdditional:(UIButton *)sender
{
    [self.view layoutIfNeeded];
    count++;
    if (count < 7) {
        [UIView animateWithDuration:0.5f animations:^{
            
            switch (count) {
                case 1:
                    [v1 setHidden:NO];
                    av1.constant = 45.0;
                    [self btnAdd:v1 :100];
                    break;
                    
                case 2:
                    [v2 setHidden:NO];
                    av2.constant = 45.0;
                    [self btnAdd:v2 :200];
                    break;
                    
                case 3:
                    [v3 setHidden:NO];
                    av3.constant = 45.0;
                    [self btnAdd:v3 :300];
                    break;
                    
                case 4:
                    [v4 setHidden:NO];
                    av4.constant = 45.0;
                    [self btnAdd:v4 :400];
                    break;
                    
                case 5:
                    [v5 setHidden:NO];
                    av5.constant = 45.0;
                    [self btnAdd:v5 :500];
                    
                    break;
                    
                case 6:
                    [v6 setHidden:NO];
                    av6.constant = 45.0;
                    [self btnAdd:v6 :600];
                    break;
                    
                default:
                    break;
            }
            
            [self.view layoutIfNeeded];
            
        }completion:nil];
        
    }else{
        [CommonClass showToastMsg:LimitExceeded];
    }
}

-(void)btnAdd:(UIView *)v :(NSInteger)tag
{
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectZero];
    [btn setBackgroundColor:[UIColor clearColor]];
    [btn addTarget:self action:@selector(btnSelectType:) forControlEvents:UIControlEventTouchUpInside];
    btn.frame = CGRectMake(btn_ppno.frame.origin.x,v.frame.origin.y, btn_ppno.frame.size.width, btn_ppno.frame.size.height);
    btn.tag = tag;
    [scroll_main addSubview:btn];
}
-(IBAction)btnSelectType:(UIButton *)sender
{
    [self Resign];
    if(dropDown == nil) {
        CGFloat f = 250;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :callType :nil :@"down"];
        dropDown.tag = 1000;
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
    [sender setTitleColor:[UIColor blackColor] forState:0];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    switch (sender.tag) {
        case 100:
            [self btn:btn_pno1 :idx :sender];
            break;
            
        case 200:
            [self btn:btn_pno2 :idx :sender];
            break;
            
        case 300:
            [self btn:btn_pno3 :idx :sender];
            break;
            
        case 400:
            [self btn:btn_pno4 :idx :sender];
            break;
            
        case 500:
            [self btn:btn_pno5 :idx :sender];
            break;
            
        case 600:
            [self btn:btn_pno6 :idx :sender];
            break;
            
        default:
            break;
    }
}

-(void)btn :(UIButton *)b :(NSInteger)i :(UIButton *)s
{
    [s setTitle:@"" forState:0];
    [b setTitle:[callType objectAtIndex:i] forState:0];
    [b setTitleColor:[UIColor blackColor] forState:0];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

-(void)Resign
{
    for (UIView *v in scroll_main.subviews)
    {
        if ([v isKindOfClass:[UITextField class]])
        {
            [v resignFirstResponder];
        }
    }
}
-(void)popViewController
{
    [[self navigationController] popViewControllerAnimated:YES];
}

#pragma mark - Textfield Delegate

-(void)addToolBar:(UITextField *)txtfld
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    txtfld.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    if ([sender.title isEqualToString:@">"])
    {
        if (activeField == txt_pno1)
        {
            if (av2.constant > 0)
            {
                [txt_pno2 becomeFirstResponder];
            }
            else
            {
                [txt_street becomeFirstResponder];
            }
        }
        else if (activeField == txt_pno2)
        {
            if (av3.constant > 0)
            {
                [txt_pno3 becomeFirstResponder];
            }
            else
            {
                [txt_street becomeFirstResponder];
            }
        }
        else if (activeField == txt_pno3)
        {
            if (av4.constant > 0)
            {
                [txt_pno4 becomeFirstResponder];
            }
            else
            {
                [txt_street becomeFirstResponder];
            }
        }
        else if (activeField == txt_pno4)
        {
            if (av5.constant > 0)
            {
                [txt_pno5 becomeFirstResponder];
            }
            else
            {
                [txt_street becomeFirstResponder];
            }
        }
        else if (activeField == txt_pno5)
        {
            if (av6.constant > 0)
            {
                [txt_pno6 becomeFirstResponder];
            }
            else
            {
                [txt_street becomeFirstResponder];
            }
        }
        else if (activeField == txt_pno6)
        {
            [txt_street becomeFirstResponder];
        }
        else
        {
            [self.view endEditing:YES];
        }
    }
    else
    {
        if (activeField == txt_pno1)
        {
            [txt_sno becomeFirstResponder];
        }
        else if (activeField == txt_pno2)
        {
            [txt_pno1 becomeFirstResponder];
        }
        else if (activeField == txt_pno3)
        {
            [txt_pno2 becomeFirstResponder];
        }
        else if (activeField == txt_pno4)
        {
            [txt_pno3 becomeFirstResponder];
        }
        else if (activeField == txt_pno5)
        {
            [txt_pno4 becomeFirstResponder];
        }
        else if (activeField == txt_pno6)
        {
            [txt_pno5 becomeFirstResponder];
        }
        else
        {
            [self.view endEditing:YES];
        }
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [((UIScrollView *)activeField.superview.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)activeField.superview.superview).contentSize.width - 1,((UIScrollView *)activeField.superview.superview).contentSize.height - 1, 1, 1) animated:YES];
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)activeField.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)activeField.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)activeField.superview.superview) scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [((UIScrollView *)activeField.superview.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)activeField.superview.superview).contentSize.width - 1,((UIScrollView *)activeField.superview.superview).contentSize.height - 1, 1, 1) animated:YES];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    if (activeField.keyboardType == UIKeyboardTypeNumberPad) {
        [self addToolBar:activeField];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return [CommonClass Textfield:textField :range];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
