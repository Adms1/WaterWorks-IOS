//
//  ChangeMail.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ChangeMail.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"

@interface ChangeMail ()<CommonDelegate>
{
    UITextField *activeField;
}
@end

@implementation ChangeMail

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if([v isKindOfClass:[UITextField class]])
        {
            v.layer.borderWidth = 1.0f;
            v.layer.borderColor = RegisterTextColor.CGColor;
            
            ((UITextField *)v).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
            ((UITextField *)v).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
            ((UITextField *)v).leftViewMode = UITextFieldViewModeAlways;
            ((UITextField *)v).rightViewMode = UITextFieldViewModeAlways;
        }
        else if([v isKindOfClass:[UILabel class]] && v.tag == 1)
        {
            NSMutableAttributedString *text =
            [[NSMutableAttributedString alloc]
             initWithAttributedString: ((UILabel *)v).attributedText];
            NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 1] options:NSCaseInsensitiveSearch];
            [text addAttribute:NSForegroundColorAttributeName
                         value:[UIColor redColor]
                         range:range];
            [((UILabel *)v) setAttributedText:text];
        }
    }
    
    lbl_currentEmail.text = _str_currentEmail;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksChangeEmail :self :btnHome :nil :YES :self];
}

#pragma mark - Api Calling

-(void)CheckEmailExistance
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:checkEmail_Url parameters:@{@"EmailID":txtEid.text} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arrEmailCheck = [responseObject safeObjectForKey:@"CheckEmail"];
            
            if ([arrEmailCheck count] > 0) {
                txtEid.text = txtCEid.text = @"";
                [txtEid becomeFirstResponder];
                
                arrEmailCheck = [responseObject safeObjectForKey:@"CheckEmail"];
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Email address already used." delegate:self];
                [txtEid becomeFirstResponder];
            }
        }
        else{
            [txtCEid becomeFirstResponder];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)ChangeEmailAddress
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"NewEmailID":txtEid.text
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:UpdateFamilyEmail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [CommonClass showToastMsg:EmailUpdate];
            
            [self.navigationController popViewControllerAnimated:YES];
            
        }else{
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[[responseObject valueForKey:@"ChangePass"] valueForKey:@"Msg"] delegate:self];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Actions

-(BOOL)EmailValidatation
{
    NSString *strCEid = [CommonClass trimString:txtCEid.text];
    if ([strCEid length] == 0) {
        [txtCEid becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideConfrimEmail delegate:self];
        return NO;
    }
    else if (![txtEid.text isEqualToString:txtCEid.text]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideEmailConfirmEmailMsg delegate:self];
        return NO;
    }
    return  YES;
}

- (IBAction)onClickUpdateEmailBtn:(id)sender
{
    if ([self EmailValidatation])
    {
        [self ChangeEmailAddress];
    }
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)activeField.superview) setContentInset:contentInsets];
    [((UIScrollView *)activeField.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)activeField.superview) scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    activeField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    activeField.layer.borderWidth = 0.5f;
    
    if(textField == txtCEid)
    {
        NSString *strEid = [CommonClass trimString:txtEid.text];
        if ([strEid length] == 0) {
            [txtEid becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNewEmailAddressMsg delegate:self];
        }
        else if (![CommonClass textIsValidEmailFormat:strEid])
        {
            [txtEid becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        else
        {
            [self CheckEmailExistance];
        }
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [activeField resignFirstResponder];
        [((UIScrollView *)activeField.superview) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)activeField.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
        [((UIScrollView *)activeField.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)activeField.superview).contentSize.width - 1,((UIScrollView *)activeField.superview).contentSize.height - 1, 1, 1) animated:YES];
        return YES;
    }
    return NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
