//
//  ProgressReport.h
//  WaterWorks
//
//  Created by Ankit on 17/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProgressReport : UIViewController
{
    IBOutlet UITableView *tblStudents;
    IBOutlet UIButton *btnHome;
}
@end
