//
//  FirstTimeViewController.h
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NIDropDown.h"
#import "MDDatePickerDialog.h"

@interface UpdateStudent : UIViewController<NIDropDownDelegate,MDDatePickerDialogDelegate>

{
    IBOutlet UIScrollView *scroll;
    IBOutlet UITextField *txtFirstName;
    IBOutlet UITextField *txtLastName;
    IBOutlet UIButton *btnDateOfBirth;
    IBOutlet UIButton *btnMale;
    IBOutlet UIButton *btnFirstAny;
    IBOutlet UIButton *btnSecondAny;
    
    IBOutlet UIButton *btnUpdateStudent;
    IBOutlet UIButton *btnHome;
    IBOutlet UILabel *lblLevel;
    
    NIDropDown *dropDown;
    NSDate *selectedDate;
    NSString *strBirthdate;
    IBOutlet UIView *TypeView;
    IBOutlet NSLayoutConstraint *TypeViewHeight;
}
@property(nonatomic) NSArray *arr_Student;
@property(nonatomic) NSDateFormatter *dateFormatter;
@property(nonatomic) MDDatePickerDialog *datePicker;
@end
