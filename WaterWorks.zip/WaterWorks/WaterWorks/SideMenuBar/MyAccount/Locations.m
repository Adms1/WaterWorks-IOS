//
//  Locations.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "Locations.h"
#import "AppDelegate.h"
#import "MyAccountCell.h"
#import "ChangeLocation.h"
#import "AddRemoveLocation.h"
#import "CommonClass.h"

@interface Locations ()<CommonDelegate>
{
    NSArray *locationArray;
}
@end

@implementation Locations

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblLocation.estimatedRowHeight = 40.0;
    tblLocation.rowHeight = UITableViewAutomaticDimension;
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksLocations :self :btnHome :nil :YES :self];
    
    [self Schl_Get_SiteByFamily];
}

#pragma mark - Api Calling

-(void)Schl_Get_SiteByFamily
{
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        
        if (flag) {
            locationArray = [responseObject valueForKey:@"SiteList"];
        }
        else{
            if (![[[[responseObject valueForKey:@"SiteList"] valueForKey:@"Msg"]objectAtIndex:0]isEqual:[NSNull null]])
            {
                locationArray = [[NSArray alloc]init];
            }
        }
        [tblLocation reloadData];
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return locationArray.count;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblLocation.frame.size.width, 20)];
    headerView.backgroundColor = [UIColor clearColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, tblLocation.frame.size.width, 20)];
    lblSection.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        lblSection.textColor = [UIColor blackColor];
        [lblSection setText:@"Current Locations"];
    }else{
        lblSection.textColor = [UIColor colorWithRed:(247.0/255.0) green:(149.0/255.0) blue:(34.0/255.0) alpha:1.0];
        [lblSection setText:@"Add a New Location"];
        
        [lblSection setUserInteractionEnabled:YES];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        [lblSection addGestureRecognizer:tap];
    }
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblLocation dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.bgView.layer.borderColor = [[UIColor blackColor]CGColor];
    maCell.bgView.layer.borderWidth = 0.5f;
    
    maCell.lbl_name.text = [NSString stringWithFormat:@"%@・%@・%@, %@",[[locationArray objectAtIndex:indexPath.row] valueForKey:@"sitename"],[[locationArray objectAtIndex:indexPath.row] valueForKey:@"Address1"],[[locationArray objectAtIndex:indexPath.row] valueForKey:@"City"],[[locationArray objectAtIndex:indexPath.row] valueForKey:@"State"]];
    
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithAttributedString: maCell.lbl_name.attributedText];
    
    NSRange range = [maCell.lbl_name.text rangeOfString:[[locationArray objectAtIndex:indexPath.row] valueForKey:@"sitename"] options:NSCaseInsensitiveSearch];
    [text addAttribute:NSFontAttributeName
                 value:FONT_Bold(13)
                 range:range];
    [maCell.lbl_name setAttributedText: text];
    
    return maCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddRemoveLocation *arl = [self.storyboard instantiateViewControllerWithIdentifier:@"AddRemoveLocation"];
    arl.arrLocation = [locationArray objectAtIndex:indexPath.row];
    arl.arrLocationCount = locationArray.count;
    arl.btnStatus = @"Remove Location";
    [[self navigationController]pushViewController:arl animated:YES];
}

-(void)tap:(UITapGestureRecognizer *)gesture
{
    ChangeLocation *cl = [self.storyboard instantiateViewControllerWithIdentifier:@"ChangeLocation"];
    [[self navigationController]pushViewController:cl animated:YES];
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
