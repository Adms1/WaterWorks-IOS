//
//  ChangeMail.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InputText.h"

@interface ChangeMail : UIViewController
{
    IBOutlet UILabel *lbl_currentEmail;
    IBOutlet UITextField *txtEid,*txtCEid;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,strong)NSString *str_currentEmail;
@end
