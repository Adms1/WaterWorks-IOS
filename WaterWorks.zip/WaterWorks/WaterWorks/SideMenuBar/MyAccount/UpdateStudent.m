//
//  FirstTimeViewController.m
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UpdateStudent.h"
#import "QuestionViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface UpdateStudent ()<QuestionDelegate,CommonDelegate>
{
    NSMutableArray *LessonIds,*LessonSelectedIds;
    NSArray *classTypes;
    NSString *Levelnum;
}
@end

@implementation UpdateStudent

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _dateFormatter = [[NSDateFormatter alloc] init];
    _dateFormatter.dateFormat = @"MMM dd, yyyy";
    
    txtFirstName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtFirstName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtFirstName.leftViewMode = UITextFieldViewModeAlways;
    txtFirstName.rightViewMode = UITextFieldViewModeAlways;
    txtFirstName.layer.borderWidth = 1.0f;
    txtFirstName.layer.borderColor = RegisterTextColor.CGColor;
    
    txtLastName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtLastName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtLastName.leftViewMode = UITextFieldViewModeAlways;
    txtLastName.rightViewMode = UITextFieldViewModeAlways;
    txtLastName.layer.borderWidth = 1.0f;
    txtLastName.layer.borderColor = RegisterTextColor.CGColor;
    
    btnMale.layer.borderWidth = 1.0f;
    btnMale.layer.borderColor = RegisterTextColor.CGColor;
    
    btnDateOfBirth.layer.borderWidth = 1.0f;
    btnDateOfBirth.layer.borderColor = RegisterTextColor.CGColor;
    
    btnFirstAny.layer.borderWidth = 1.0f;
    btnFirstAny.layer.borderColor = RegisterTextColor.CGColor;
    
    btnSecondAny.layer.borderWidth = 1.0f;
    btnSecondAny.layer.borderColor = RegisterTextColor.CGColor;
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *lname = [userDefault objectForKey:WU_LASTNAME];
    if(lname != nil){
        txtLastName.text = lname;
    }
    
    for (UIView *v in [scroll subviews])
    {
        if([v isKindOfClass:[UILabel class]])
        {
            if(((UILabel *)v).tag != 1)
            {
                NSMutableAttributedString *text =
                [[NSMutableAttributedString alloc]
                 initWithAttributedString: ((UILabel *)v).attributedText];
                NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 2] options:NSCaseInsensitiveSearch];
                [text addAttribute:NSForegroundColorAttributeName
                             value:[UIColor redColor]
                             range:range];
                [((UILabel *)v) setAttributedText:text];
            }
        }
    }
    
    [lblLevel setText:[NSString stringWithFormat:@"Level %@ - ",[_arr_Student valueForKey:@"SLevel"]]];
    Levelnum = [_arr_Student valueForKey:@"SLevel"];
    [txtLastName setText:[_arr_Student valueForKey:@"SLastName"]];
    [txtFirstName setText:[_arr_Student valueForKey:@"SFirstName"]];
    [btnMale setTitle:[_arr_Student valueForKey:@"WU_SGender"]  forState:0];
    [btnFirstAny setTitle:[[_arr_Student valueForKey:@"SInstrGender"]isEqualToString:@"Any"] ? @"No Preference" : [_arr_Student valueForKey:@"SInstrGender"] forState:0];
    [btnSecondAny setTitle:[[_arr_Student valueForKey:@"SInstrNature"]isEqualToString:@"Any"] ? @"No Preference" : [_arr_Student valueForKey:@"SInstrNature"] forState:0];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM-dd-yyyy"];
    
    [btnDateOfBirth setTitle:[_dateFormatter stringFromDate:[dateFormatter dateFromString:[_arr_Student valueForKey:@"DateOfBirth"]]] forState:0];
    [[NSUserDefaults standardUserDefaults] setObject:btnDateOfBirth.titleLabel.text forKey:UD_REGISTER_B_DATE];
    [self GetLessionList:NO];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:[NSString stringWithFormat:@"%@ %@",[_arr_Student valueForKey:@"SFirstName"],[_arr_Student valueForKey:@"SLastName"]] :self :btnHome :nil :YES :self];
}

-(void)addDynamicInstructorButton:(NSArray *)arr :(BOOL)Updateflag
{
    TypeViewHeight.constant = (arr.count * 35);
    [TypeView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    for (int i = 0 ; i < arr.count ; i++)
    {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(6, (5 + (i * 35)), TypeView.frame.size.width - 12, 35)];
        [btn setTitle:[[arr objectAtIndex:i] valueForKey:@"LessionName"] forState:0];
        btn.backgroundColor = [UIColor clearColor];
        btn.titleLabel.font = FONT_OpenSans(14);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"CheckInstructor"] forState:0];
        [btn setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:UIControlStateSelected];
        
        if ([classTypes containsObject:[[arr objectAtIndex:i] valueForKey:@"LessionName"]] && !Updateflag)
        {
            btn.selected = NO;
            [LessonSelectedIds addObject:[[arr objectAtIndex:i] valueForKey:@"LessionID"]];
        }
        else
        {
            btn.selected = YES;
            [LessonSelectedIds addObject:@""];
        }
        
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
        btn.tag = i;
        [btn addTarget:self action:@selector(selectUnselectInstructor:) forControlEvents:UIControlEventTouchUpInside];
        [TypeView addSubview:btn];
        [LessonIds addObject:[[arr objectAtIndex:i] valueForKey:@"LessionID"]];
    }
}
-(void)viewDidLayoutSubviews
{
    [btnUpdateStudent layoutIfNeeded];
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width, 400 + 150 + TypeViewHeight.constant + btnUpdateStudent.frame.size.height + 50)];
}
-(void)selectUnselectInstructor:(UIButton *)sender
{
    NSLog(@"%ld",(long)sender.tag);
    
    BOOL flag = sender.selected ? NO : YES;
    sender.selected = flag;
    
    if(!flag)
    {
        [LessonSelectedIds replaceObjectAtIndex:sender.tag withObject:[LessonIds objectAtIndex:sender.tag]];
    }
    else
    {
        [LessonSelectedIds replaceObjectAtIndex:sender.tag withObject:@""];
    }
    
    NSLog(@"%@",LessonSelectedIds);
}
-(void)GetLessionList:(BOOL)flagUpdate
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"level":Levelnum,
                             @"age":[CommonClass CalculateAge:[[NSUserDefaults standardUserDefaults] valueForKey:UD_REGISTER_B_DATE]],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    LessonSelectedIds = [[NSMutableArray alloc]init];
    LessonIds = [[NSMutableArray alloc]init];
    
    [manager POST:lessionLevelAge_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            classTypes = [[_arr_Student valueForKey:@"ClassType"]componentsSeparatedByString:@","];
        }
        
        [self addDynamicInstructorButton:[responseObject valueForKey:@"FinalArray"]:flagUpdate];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)UpdateStudent
{
    NSIndexSet *indexes = [LessonSelectedIds indexesOfObjectsPassingTest:^BOOL(NSString *string, NSUInteger idx, BOOL *stop) {
        return [[NSString stringWithFormat:@"%@",string] isEqualToString:@""];
    }];
    [LessonSelectedIds removeObjectsAtIndexes:indexes];
    
    NSLog(@"%@",LessonSelectedIds);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"lessonlist":[NSString stringWithFormat:@"%@,",[LessonSelectedIds componentsJoinedByString:@","]],
                             @"Description":@"",
                             @"ChildStrongWilledValue":@"1",
                             @"ChildSensitiveValue":@"",
                             @"ChildOutGoingValue":@"",
                             @"ChildStrongWilled":@"",
                             @"ChildSensitive":@"",
                             @"ChildOutGoing":@"",
                             @"chk1":@"false",
                             @"chk2":@"false",
                             @"chk3":@"false",
                             @"Swimgoals":@"",
                             @"levels":Levelnum,
                             @"FName":[userDefault objectForKey:UD_REGISTER_F_NAME],
                             @"LName":[userDefault objectForKey:UD_REGISTER_L_NAME],
                             @"Dob":[userDefault objectForKey:UD_REGISTER_B_DATE],
                             @"Age":[CommonClass CalculateAge:[[NSUserDefaults standardUserDefaults] valueForKey:UD_REGISTER_B_DATE]],
                             @"Gender":[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] firstObject],
                             @"InstructorNature":[[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] lastObject]isEqualToString:@"No Preference"] ? @"Any" : [[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] lastObject] ,
                             @"InstructorGender":[[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] objectAtIndex:1]isEqualToString:@"No Preference"] ? @"Any" : [[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] objectAtIndex:1] uppercaseString],
                             @"strYesNo1":@"Y",
                             @"strYesNo2":@"Y",
                             @"strallergiesmedical":[_arr_Student valueForKey:@"SAllergyDesc"],
                             @"studentid":[_arr_Student valueForKey:@"SstudentId"]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Update_MyAcnt_RegiserChild_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        //        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
        
        [CommonClass showToastMsg:StudentUpdated];
        
        [[self navigationController]popViewControllerAnimated:YES];
        //
        //        }else{
        //            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[[responseObject valueForKey:@"ChangePass"] valueForKey:@"Msg"] delegate:self];
        //        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}


#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [[self navigationController] popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtFirstName) {
        point = CGPointMake(0, 0);
    }else if(textField == txtLastName){
        point = CGPointMake(0, 0);
    }
    [scroll setContentOffset:point animated:YES];
}

- (IBAction)onClickMaleBtn:(id)sender {
    
    [self Resign];
    btnMale.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"Male",@"Female"];
    if(dropDown == nil) {
        CGFloat f = 74;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickFirstAnyBtn:(id)sender {
    
    [self Resign];
    btnFirstAny.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"No Preference",@"Male",@"Female"];
    if(dropDown == nil) {
        CGFloat f = 118;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickSecondAnyBtn:(id)sender {
    
    [self Resign];
    btnSecondAny.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"No Preference",@"Firm",@"Gentle"];
    if(dropDown == nil) {
        CGFloat f = 118;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

-(BOOL)registerChildValidate
{
    NSString *strFirstName  = [CommonClass trimString:txtFirstName.text];
    NSString *strLastName = [CommonClass trimString:txtLastName.text];
    
    if ([strFirstName length] == 0) {
        [txtFirstName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideFirstName delegate:self];
        return NO;
    }
    if ([strLastName length] == 0) {
        [txtLastName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideLastName delegate:self];
        return NO;
    }
    return  YES;
}
- (IBAction)onClickRecalculateBtn:(id)sender
{
    QuestionViewController *viewRegisterChild;
    
    if (isIpad) {
        viewRegisterChild = [[QuestionViewController alloc] initWithNibName:@"QuestionViewController" bundle:nil];
    }else{
        viewRegisterChild = [[QuestionViewController alloc] initWithNibName:@"QuestionViewController" bundle:nil];
    }
    viewRegisterChild.q_delegate = self;
    viewRegisterChild.type = @"Update";
    viewRegisterChild.strMedical = [_arr_Student valueForKey:@"SAllergyDesc"];
    [self.navigationController pushViewController:viewRegisterChild animated:YES];
    
}
- (IBAction)onClickUpdateStudentBtn:(id)sender {
    
    if ([self registerChildValidate])
    {
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:txtFirstName.text forKey:UD_REGISTER_F_NAME];
        [userDefault setObject:txtLastName.text forKey:UD_REGISTER_L_NAME];
        [userDefault setObject:btnDateOfBirth.titleLabel.text forKey:UD_REGISTER_B_DATE];
        
        [userDefault setObject:[NSString stringWithFormat:@"%@|%@|%@",btnMale.titleLabel.text,btnFirstAny.titleLabel.text,btnSecondAny.titleLabel.text] forKey:@"SDATA"];
        
        [self UpdateStudent];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if (btnMale.selected == YES) {
        btnMale.selected = NO;
        [userDefault setObject:btnMale.titleLabel.text forKey:UD_REGISTER_GENDER];
    }else if (btnFirstAny.selected == YES){
        btnFirstAny.selected = NO;
        [userDefault setObject:btnFirstAny.titleLabel.text forKey:UD_REGISTER_INSTRU_1];
    }else if (btnSecondAny.selected == YES){
        btnSecondAny.selected = NO;
        [userDefault setObject:btnSecondAny.titleLabel.text forKey:UD_REGISTER_INSTRU_2];
    }
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

- (IBAction)btnSelectDate:(UIButton *)sender {
    [self Resign];
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    _datePicker.selectedDate = [NSDate date];
    _datePicker.maximumDate = [NSDate date];
    _datePicker.tag = sender.tag;
    [_datePicker show];
}

- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    [btnDateOfBirth setTitle:[_dateFormatter stringFromDate:date] forState:UIControlStateNormal];
    [[NSUserDefaults standardUserDefaults] setObject:btnDateOfBirth.titleLabel.text forKey:UD_REGISTER_B_DATE];
}

-(void)Resign
{
    [txtFirstName resignFirstResponder];
    [txtLastName resignFirstResponder];
}


-(void)UpdateStudentQuestionLevel:(NSString *)levelNum
{
    [lblLevel setText:[NSString stringWithFormat:@"Level %@ - ",levelNum]];
    Levelnum = levelNum;
    [self GetLessionList:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
