//
//  Locations.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Locations : UIViewController
{
    IBOutlet UITableView *tblLocation;
    IBOutlet UIButton *btnHome;
}
@end
