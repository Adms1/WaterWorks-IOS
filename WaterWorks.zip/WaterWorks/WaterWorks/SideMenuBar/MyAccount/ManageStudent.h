//
//  ManageStudent.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManageStudent : UIViewController
{
    IBOutlet UITableView *tblStudent;
    IBOutlet UIButton *btnHome;
}
@end
