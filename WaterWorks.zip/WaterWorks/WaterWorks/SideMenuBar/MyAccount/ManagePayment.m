//
//  LessonView.m
//  WaterWorks
//
//  Created by Ankit on 21/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ManagePayment.h"
#import "AppDelegate.h"
#import "MyAccountCell.h"
#import "CommonClass.h"
#import "PopupView.h"

@interface ManagePayment ()<PopupViewDelegate,CommonDelegate>
{
    NSMutableArray *arrPaymentDetails;
    NSString *strSendId;
    NSString *strSiteID;
}
@end

@implementation ManagePayment

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *dict) {
        NSArray *array = [dict valueForKey:@"SiteList"];
        NSLog(@"%@",array);
        
        NSMutableArray *arrSiteIDS = [[NSMutableArray alloc]init];
        for (NSDictionary *dic in array) {
            [arrSiteIDS addObject:dic[@"siteid"]];
        }
        strSiteID = [arrSiteIDS componentsJoinedByString:@","];
        [self CardDetailBySite];
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMPAccounts :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

-(void)CardDetailBySite
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"strSiteID":strSiteID
                             };
    
    [manager POST:Pay_DGetACHCardDetailBySite_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrPaymentDetails = [responseObject valueForKey:@"ACHList"];
        }
        
        [tblManageAccount reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrPaymentDetails.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblManageAccount dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.bgView.layer.borderColor = [[UIColor blackColor]CGColor];
    maCell.bgView.layer.borderWidth = 0.5f;
    maCell.btnAdd.tag = indexPath.row;
    [maCell.btnAdd addTarget:self action:@selector(btnRemove:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([[[arrPaymentDetails valueForKey:@"wu_PayType"] objectAtIndex:indexPath.row] isEqualToString:@"Card"])
    {
        maCell.lbl_name.text = [NSString stringWithFormat:@"Card  %@",[[[arrPaymentDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:indexPath.row]substringFromIndex:6]];
    }
    else
    {
        maCell.lbl_name.text = [NSString stringWithFormat:@"Checking - %@",[[[arrPaymentDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:indexPath.row]substringFromIndex:5]];
    }
    
    return maCell;
}

-(void)btnRemove:(UIButton *)sender
{
    strSendId = [[arrPaymentDetails valueForKey:@"wu_SendId"] objectAtIndex:sender.tag];
    PopupView *pv = [[PopupView alloc] initWithNibName:@"PopupView" bundle:nil];
    pv.p_delegate = self;
    pv.check = YES;
    pv.strBtnText = @"YES";
    pv.strMsgText = @"Are you sure want to remove this payment account?";
    [pv.view setFrame:CGRectMake(pv.view.frame.origin.x, pv.view.frame.origin.y, self.view.frame.size.width - 40, pv.view.frame.size.height)];
    pv.strTitleText = @"Are you sure?";
    [self presentPopupViewController:pv animationType:MJPopupViewAnimationFade];
}

-(void)Continue_GoBack:(PopupView *)popup :(UIButton *)sender :(NSInteger)tag
{
    if (tag != 1) {
        [self RemovePaymentDetails];
    }
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)RemovePaymentDetails
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"sendid":strSendId,
                             @"familyid":[[NSUserDefaults standardUserDefaults] valueForKey:FAMILYID]
                             };
    
    [manager POST:DeletePaymentDetailsBySite_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
        
        [CommonClass showToastMsg:AccountRemoved];
        
        [[self navigationController]popViewControllerAnimated:YES];
        //        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
