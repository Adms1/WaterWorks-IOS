//
//  MyViewController.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface MyAccountViewController : MasterViewController
{
    IBOutlet UITableView *tblMyaccount;
    IBOutlet UIButton *btnHome;
}
@end
