//
//  MyAccountCell.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyAccountCell : UITableViewCell
//-Cell 1-
@property(nonatomic,retain)IBOutlet UILabel *lbl_name;
@property(nonatomic,retain)IBOutlet UILabel *lbl_count;
@property(nonatomic,retain)IBOutlet UIView *bgView;
@property(nonatomic,retain)IBOutlet UIButton *btnAdd;

//-Cell 2-
@property(nonatomic,retain)IBOutlet UILabel *lbl_date;
@property(nonatomic,retain)IBOutlet UILabel *lbl_siteName;
@property(nonatomic,retain)IBOutlet UILabel *lbl_Invoice;
@property(nonatomic,retain)IBOutlet UILabel *lbl_Amount;
@property(nonatomic,retain)IBOutlet UILabel *lbl_Payment;
@property(nonatomic,retain)IBOutlet UILabel *lbl_Description;
@property(nonatomic,retain)IBOutlet UIView *DesView;

//-Cell 3-
@property(nonatomic,retain)IBOutlet UILabel *lbl_ldate;
@property(nonatomic,retain)IBOutlet UILabel *lbl_skills;

//-Cell 4-
@property(nonatomic,retain)IBOutlet UIButton *btnEdit;
@property(nonatomic,retain)IBOutlet UILabel *lbl_payment;
@property(nonatomic,retain)IBOutlet UIButton *btn_check;
@end
