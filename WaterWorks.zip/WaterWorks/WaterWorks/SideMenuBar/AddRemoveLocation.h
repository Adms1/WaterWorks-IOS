//
//  AddRemoveLocation.h
//  WaterWorks
//
//  Created by Ankit on 17/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface AddRemoveLocation : UIViewController
{
    IBOutlet UIButton *btnHome,*btnLocation,*btnPhonoNo;
    IBOutlet MKMapView *mapView;
    IBOutlet UILabel *lblAddress;
}
@property(nonatomic,retain)NSArray *arrLocation;
@property(nonatomic,assign)NSInteger arrLocationCount;
@property(nonatomic,retain)NSString *btnStatus;
@end
