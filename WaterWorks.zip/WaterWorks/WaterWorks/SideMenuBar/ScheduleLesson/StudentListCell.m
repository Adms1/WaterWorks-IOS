//
//  StudentListCell.m
//  WaterWorks
//
//  Created by Ankit on 27/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "StudentListCell.h"
#import "YBPulseButton.h"

@implementation StudentListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.img_fm.layer.cornerRadius = self.img_fm.frame.size.width/2;
    self.img_fm.layer.masksToBounds = YES;
    
    self.img_instructor.layer.cornerRadius = self.img_instructor.frame.size.width/2;
    self.img_instructor.layer.masksToBounds = YES;
    
    self.img_instructor_photo.layer.cornerRadius = self.img_instructor_photo.frame.size.width/2;
    self.img_instructor_photo.layer.masksToBounds = YES;
    
    self.bgView.layer.shadowColor = [[UIColor lightGrayColor] CGColor];
    self.bgView.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    self.bgView.layer.shadowOpacity = 1.0f;
    self.bgView.layer.shadowRadius = 1.0f;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
-(void)setStudentLessons:(NSArray *)array
{
    NSInteger width = 0;
    for (int i = 0 ; i < array.count ; i++)
    {
        CGSize stringsize = [[[array objectAtIndex:i] valueForKey:@"LessionType"] sizeWithAttributes:@{NSFontAttributeName:FONT_OpenSans(14)}];
        YBPulseButton *btn = [[YBPulseButton alloc]initWithFrame:CGRectMake(width, 0, stringsize.width + 30.0, 35)];
        width += stringsize.width + 35.0;
        [btn setTitle:[[array objectAtIndex:i] valueForKey:@"LessionType"] forState:0];
        btn.backgroundColor = [UIColor clearColor];
        btn.titleLabel.font = FONT_OpenSans(14);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
        btn.tag = i;
        
        btn.pulseColor = [Top_Color colorWithAlphaComponent:0.5];
        btn.pulseRadius = 3;
        btn.pulseDuration = 1.0;
        
//        [btn setRippleOverBounds:YES];
//        [btn setRippleColor:[Top_Color colorWithAlphaComponent:0.3]];
//        [btn setRipplePercent:1.5];
//        [btn setRippleBackgroundColor:[UIColor clearColor]];
        
        //        [btn setPulseColor:[UIColor redColor]];
        //        [btn setPulseRadius:10];
        //        [btn setPulseDuration:0.5];
        
        [btn addTarget:self action:@selector(btn_click:) forControlEvents:UIControlEventTouchUpInside];
        [_scroll addSubview:btn];
        
        if ([[[array objectAtIndex:i] valueForKey:@"Enable"]isEqual:[NSNumber numberWithInt:0]]) {
            [btn setEnabled:NO];
        }
        [_scroll setContentSize:CGSizeMake(btn.frame.size.width + btn.frame.origin.x, _scroll.frame.size.height)];
    }
}
-(void)StudentLessonsSchedule:(NSMutableDictionary *)dic :(NSMutableArray *)array :(NSMutableDictionary *)idxDic :(NSString *)sname
{
    dictionary = dic;
    //---------Student Schedule Day-----------//
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSArray *days = [dateFormatter shortWeekdaySymbols];
    NSMutableArray *fulldays = [[dateFormatter weekdaySymbols]mutableCopy];
    id object = [fulldays objectAtIndex:0];
    [fulldays removeObjectAtIndex:0];
    [fulldays addObject:object];
    
    for (UIView *v in _scheduleView.subviews) {
        if (v.tag != 1000) {
            [v removeFromSuperview];
        }
    }
    
    for (int i = 0; i < days.count; i++)
    {
        CGFloat lblwidth = (self.contentView.frame.size.width/7)-1.5;
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake((i * lblwidth)+((1.5/2)*7)+1, 0, lblwidth-3, 25)];
        if (i == days.count -1) {
            [lbl setText:[days objectAtIndex:0]];
        }else{
            [lbl setText:[days objectAtIndex:i+1]];
        }
        [lbl setTextAlignment:NSTextAlignmentCenter];
        [lbl setTextColor:[UIColor darkGrayColor]];
        [lbl setFont:FONT_OpenSans(12)];
        [lbl setBackgroundColor:[UIColor clearColor]];
        lbl.tag = i;
        [_scheduleView addSubview:lbl];
        
        int cnt = ((NSArray *)[dic valueForKey:[NSString stringWithFormat:@"Time_%@",[fulldays objectAtIndex:i]]]).count;
        CGFloat height = (cnt * 25)+35;
        CGFloat width = lbl.frame.size.width;
        
        CGFloat btnHeight = 20.0;
        if (width < 80.0)
        {
            height = height*3;
            btnHeight = btnHeight*3;
        }
        UIView *weekView = [[UIView alloc]initWithFrame:CGRectMake(lbl.frame.origin.x, 35, width, height)];
        weekView.backgroundColor = [UIColor clearColor];
        weekView.tag = (i+1) * 100;
        [_scheduleView addSubview:weekView];
        
        for (int j = 0 ; j < cnt ; j++)
        {
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0,  (btnHeight == 20.0) ? j * 22 : j * 66, lbl.frame.size.width,btnHeight)];
            [btn setTitleColor:[UIColor blackColor] forState:0];
            [btn.titleLabel setFont:FONT_OpenSans(11)];
            
            NSString *key_date = [NSString stringWithFormat:@"Date_%@",[fulldays objectAtIndex:i]];
            NSString *key_time = [NSString stringWithFormat:@"Time_%@",[fulldays objectAtIndex:i]];
            
            NSString *str = (btnHeight == 20.0) ? @" " : @"\n";
            NSString *str_date_time = [NSString stringWithFormat:@"%@ %@%@",[[dic valueForKey:key_time] objectAtIndex:j],str,[[dic valueForKey:key_date] objectAtIndex:j]];
            
            /*
             */
            
            NSMutableArray *as1 = ((NSMutableArray *)[str_date_time componentsSeparatedByString:@":"]);
            [as1 removeLastObject];
            
            NSMutableArray *as2 = ((NSMutableArray *)[str_date_time componentsSeparatedByString:@" "]);
            [as2 removeObjectAtIndex:0];
            
            /*
             */
            
            str_date_time = [NSString stringWithFormat:@"%@%@%@",[as1 componentsJoinedByString:@":"],str,[as2 componentsJoinedByString:@" "]];
            
            [btn setTitle:str_date_time forState:0];
            NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc] initWithString:btn.titleLabel.text];
            [mutableString addAttribute:NSFontAttributeName value:FONT_OpenSans(11) range:NSMakeRange(0, 7)];
            [mutableString addAttribute:NSFontAttributeName value:FONT_Bold(11) range:[btn.titleLabel.text rangeOfString:[[dic valueForKey:key_date] objectAtIndex:j]]];
            [btn setAttributedTitle:mutableString forState:UIControlStateNormal];
            
            NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:btn.titleLabel.text];
            [attrStr addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(0, btn.titleLabel.text.length)];
            [btn setAttributedTitle:mutableString forState:UIControlStateSelected];
            
            btn.tag = j;
            btn.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
            btn.titleLabel.textAlignment = NSTextAlignmentCenter;
            [btn addTarget:self action:@selector(btnSelectTime:) forControlEvents:UIControlEventTouchUpInside];
            [weekView addSubview:btn];
            
            if ([idxDic valueForKey:sname] != nil)
            {
                NSArray *arrIdx = [idxDic valueForKey:sname];
                if ([arrIdx containsObject:[NSString stringWithFormat:@"%ld|%ld|%ld",(long)btn.tag,btn.superview.tag,btn.superview.superview.superview.tag]])
                {
                    [btn setSelected:YES];
                    [btn setBackgroundColor:botomColor];
                }
                else
                {
                    btn.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.2];
                }
            }
            else
            {
                btn.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.2];
            }
        }
    }
}
-(void)btnSelectTime:(UIButton *)sender
{
    if (_delegate &&[_delegate respondsToSelector:@selector(SelectedStudentSchedule::)]) {
        [_delegate SelectedStudentSchedule:sender :dictionary];
    }
}

-(IBAction)btn_click:(UIButton *)sender
{
    for (UIView *v in _scroll.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            if(sender !=  ((UIButton *)v))
            {
                ((UIButton *)v).selected = NO;
                [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
            }
        }
    }
    
    if(sender.selected == NO)
    {
        [sender setImage:[UIImage imageNamed:@"CheckRadio"] forState:0];
        sender.selected = YES;
        [_bgView setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
    }
    else
    {
        [sender setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
        sender.selected = NO;
        [_bgView setBackgroundColor:[UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0]];
    }
    
    if (_delegate &&[_delegate respondsToSelector:@selector(SelectedStudent::)]) {
        [_delegate SelectedStudent:self.tag :sender];
    }
}
@end
