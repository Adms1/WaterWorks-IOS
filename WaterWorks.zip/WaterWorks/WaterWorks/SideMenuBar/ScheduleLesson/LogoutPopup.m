//
//  LogoutPopup.m
//  WaterWorks
//
//  Created by Ankit on 01/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "LogoutPopup.h"

@interface LogoutPopup ()

@end

@implementation LogoutPopup

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickLogoutCancel:(UIButton *)sender
{
    if (_ldelegate && [_ldelegate respondsToSelector:@selector(Logout::)]) {
        [_ldelegate Logout:sender.tag :self];
    }
}
@end
