//
//  StudentListCell.h
//  WaterWorks
//
//  Created by Ankit on 27/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ScheduleDelegate <NSObject>

@optional
-(void)SelectedStudent:(NSInteger)tag :(UIButton *)btn;
-(void)SelectedStudentSchedule:(UIButton *)btn :(NSMutableDictionary *)dic;
@end

@interface StudentListCell : UITableViewCell<CAAnimationDelegate>
{
    NSMutableDictionary *dictionary;
}

//cell-1
@property(nonatomic,retain)IBOutlet UIView *scheduleView;
@property(nonatomic,retain)IBOutlet UIView *bgView;
@property(nonatomic,retain)IBOutlet UIScrollView *scroll;
@property(nonatomic,retain)IBOutlet UILabel *lbl_sname;

//cell-2
@property(nonatomic,retain)IBOutlet UILabel *lbl_fm_name;
@property(nonatomic,retain)IBOutlet UIImageView *img_fm;
@property(nonatomic,retain)IBOutlet UIButton *btnSelect;
@property(nonatomic,retain)IBOutlet UIButton *btnViewShift;
@property(nonatomic,retain)IBOutlet UIButton *btnViewBio;

//cell-3
@property(nonatomic,retain)IBOutlet UILabel *lbl_instructor_name;
@property(nonatomic,retain)IBOutlet UIImageView *img_instructor;

//cell-4
@property(nonatomic,retain)IBOutlet UILabel *lbl_schedule_time;
@property(nonatomic,retain)IBOutlet UILabel *lbl_LessonType;
@property(nonatomic,retain)IBOutlet UILabel *lbl_SiteName;
@property(nonatomic,retain)IBOutlet UIImageView *img_instructor_photo;

//cell-5
@property(nonatomic,retain)IBOutlet UILabel *lbl_day_name;
@property(nonatomic,retain)IBOutlet UILabel *lbl_schedule;

//Delegate
@property (nonatomic , strong) id<ScheduleDelegate> delegate;

-(void)setStudentLessons:(NSArray *)array;
-(void)StudentLessonsSchedule:(NSMutableDictionary *)dic :(NSMutableArray *)array :(NSMutableDictionary *)idxDic :(NSString *)sname;
@end
