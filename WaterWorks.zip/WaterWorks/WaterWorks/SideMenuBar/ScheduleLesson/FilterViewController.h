//
//  FilterViewController.h
//  WaterWorks
//
//  Created by Ankit on 14/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol FilterDelegate <NSObject>
-(void)FilterValue:(NSMutableDictionary *)filterdata :(NSMutableDictionary *)filterInstructor :(NSString *)str;
@end

@interface FilterViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UIView *WeekMainView, *viewHeader;
    
    IBOutlet UITableView *tblList;
    IBOutlet UITableView *tblShiftList;
    
    IBOutlet UIView *viewShift;
    IBOutlet UIView *viewBio;
    IBOutlet UIView *tblFooterView;
    
    IBOutlet UIView *TimeDateView;
    IBOutlet UIView *TimeView;
    IBOutlet UIView *InstructorView;
    IBOutlet UIView *AdvancedView;
    
    IBOutlet UIButton *btnTime;
    IBOutlet NSLayoutConstraint *viewHeight;
    
    IBOutlet UIImageView *img_instructor;
    IBOutlet UITextView *txt_instructor;
    IBOutlet UILabel *lbl_instructor;
    
    IBOutlet UIWebView *webView;
    IBOutlet UIButton *btnStartEndTime;
}
@property(nonatomic,retain)NSMutableDictionary *dictionary;
@property(nonatomic,retain)id<FilterDelegate>f_delegate;
@end
