//
//  ScheduleViewController.m
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ScheduleViewController.h"
#import "SchedulePopup.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "ScheduleClassViewController.h"
#import "CustomTabbar.h"

@interface ScheduleViewController ()<SchedulePopupDelegate,CommonDelegate>
{
    NSArray *time;
    NSMutableArray *selectedScheduleArray;
    NSMutableDictionary *selectedScheduleDic;
    NSString *StudentName;
    NSMutableDictionary *studentDictionary2;
    NSMutableArray *temp_time;
    NSMutableArray *arrString;
    NSMutableArray *arr_days;
    UIView *vStripe;
    NSInteger previousTag;
    UIButton *btnTemp;
    NSMutableDictionary *dicDays;
}
@end

@implementation ScheduleViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    selectedScheduleArray = [[NSMutableArray alloc]init];
    selectedScheduleDic = [[NSMutableDictionary alloc]init];
    studentDictionary2 = [[NSMutableDictionary alloc]init];
    dicDays = [[NSMutableDictionary alloc]init];
    
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterTimeDate"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterInstructor"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"AdvancedFilter"];
    
    StudentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0] ;
}

-(void)viewDidLayoutSubviews
{
    [self.view layoutIfNeeded];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :([[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? 0 : 1 ) :[[[NSUserDefaults standardUserDefaults] valueForKey:MAKEUPCOUNT] integerValue]];
    [self.view insertSubview:ct atIndex:0];
    
    [WeekMainView layoutIfNeeded];
    if (WeekMainView.subviews.count < 8)
    {
        [self DynamicAddScheduleView];
        [self SelectedChangecolor:StudentName];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
    
    time = @[@"8:00-11:40 AM",@"12:00-3:40 PM",@"4:00-7:40 PM"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    arr_days = [[dateFormatter weekdaySymbols]mutableCopy];
    id object = [arr_days objectAtIndex:0];
    [arr_days removeObjectAtIndex:0];
    [arr_days addObject:object];
}

#pragma mark - Button Actions

-(void)DynamicAddScheduleView
{
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:scroll_main :self];
    StudentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
    
    //---------Student Schedule Grid-----------//
    
    for(int i = 0 ; i < 7 ; i++)
    {
        CGFloat height = 35.0f;
        UIView *weekView = [[UIView alloc]initWithFrame:CGRectMake(48, (i * 43) + 8, WeekMainView.frame.size.width - 48, height)];
        weekView.backgroundColor = [UIColor clearColor];
        weekView.tag = (i+1) * 100;
        [WeekMainView addSubview:weekView];
        
        CGFloat staticWidth = (WeekMainView.frame.size.width - 48)/3;
        CGFloat staticSpace = 5;
        
        for (int j = 0 ; j < 3 ; j++)
        {
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(j * staticWidth-staticSpace+5, 0, staticWidth-staticSpace, height)];
            btn.backgroundColor = [UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(245.0/255.0) alpha:1.0];
            [btn setTitleColor:[UIColor blackColor] forState:0];
            [btn.titleLabel setFont:FONT_OpenSans(11)];
            [btn setTitle:[time objectAtIndex:j] forState:0];
            btn.tag = j;
            [btn addTarget:self action:@selector(btnSelectTime:) forControlEvents:UIControlEventTouchUpInside];
            [weekView addSubview:btn];
        }
    }
}

-(void)SelectedChangecolor:(NSString *)sname
{
    if ([selectedScheduleDic valueForKey:sname] != nil)
    {
        NSArray *array = (NSArray *)[selectedScheduleDic valueForKey:sname];
        NSLog(@"%@",array);
        
        for (int i = 0; i < array.count; i++)
        {
            NSInteger vtag = [[[[array objectAtIndex:i] componentsSeparatedByString:@"|"] firstObject]integerValue];
            NSInteger btag = [[[[array objectAtIndex:i] componentsSeparatedByString:@"|"] lastObject]integerValue];
            UIButton *btn = ((UIButton *)[[WeekMainView viewWithTag:vtag]viewWithTag:btag]);
            [btn setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
            [btn setTitleColor:[UIColor whiteColor] forState:0];
            [btn setSelected:YES];
        }
        
        [btnSelectReset setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
        [btnSelectReset setTitle:@"Reset" forState:0];
        [btnSelectReset setTitleColor:[UIColor whiteColor] forState:0];
        [btnSelectReset setSelected:YES];
    }
    else
    {
        [btnSelectReset setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
        [btnSelectReset setTitle:@"Select All" forState:0];
        [btnSelectReset setTitleColor:[UIColor blackColor] forState:0];
        [btnSelectReset setSelected:NO];
    }
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        scroll_main.transform = CGAffineTransformMakeTranslation(scroll_main.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll_main.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        scroll_main.transform = CGAffineTransformMakeTranslation(-scroll_main.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll_main.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }

    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    for (UIView *v in WeekMainView.subviews)
    {
        if([v isKindOfClass:[UIView class]])
        {
            for (UIView *sv in [v subviews])
            {
                [((UIButton *)sv) setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
                [((UIButton *)sv) setTitleColor:[UIColor blackColor] forState:0];
                [((UIButton *)sv) setSelected:NO];
            }
        }
    }
    
    StudentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    [self SelectedChangecolor:StudentName];
    
    selectedScheduleArray = [[NSMutableArray alloc]init];
    if ([selectedScheduleDic valueForKey:StudentName] != nil)
    {
        selectedScheduleArray = (NSMutableArray *)[selectedScheduleDic valueForKey:StudentName];
    }
}

-(void)btnSelectTime:(UIButton *)sender
{
    [scroll_header viewWithTag:([SHARED_APPDELEGATE.arrStudentName indexOfObject:StudentName]+1)*100].layer.borderColor = [[UIColor clearColor]CGColor];
    sender.selected = !sender.selected;
    if (sender.selected)
    {
        [selectedScheduleArray addObject:[NSString stringWithFormat:@"%ld|%ld",sender.superview.tag,(long)sender.tag]];
        [sender setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
        [sender setTitleColor:[UIColor whiteColor] forState:0];
    }
    else
    {
        [selectedScheduleArray removeObject:[NSString stringWithFormat:@"%ld|%ld",sender.superview.tag,(long)sender.tag]];
        [sender setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
        [sender setTitleColor:[UIColor blackColor] forState:0];
    }
    
    [selectedScheduleDic setObject:selectedScheduleArray forKey:StudentName];
    
    NSLog(@"%@",selectedScheduleDic);
    
    /*
     */
    
    temp_time = [[NSMutableArray alloc]init];
    BOOL flag = NO;
    for (UIView *v in WeekMainView.subviews)
    {
        if([v isKindOfClass:[UIView class]])
        {
            NSMutableArray *select_time = [[NSMutableArray alloc]init];
            for (UIView *sv in [v subviews])
            {
                if([sv isKindOfClass:[UIButton class]])
                {
                    if ([sv.backgroundColor isEqual:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]])
                    {
                        flag = YES;
                        [select_time addObject:@"true"];
                    }
                    else
                    {
                        [select_time addObject:@"false"];
                    }
                }
            }
            [temp_time addObject:[select_time componentsJoinedByString:@"_"]];
        }
    }
    
    if(flag)
    {
        arrString = [[NSMutableArray alloc]init];
        for (int i = 0 ; i < arr_days.count ; i++)
        {
            [temp_time replaceObjectAtIndex:i withObject:[arr_days objectAtIndex:i]];
            [arrString addObject:[NSString stringWithFormat:@"%@|True|%@",[temp_time objectAtIndex:i],[temp_time objectAtIndex:i+7]]];
        }
        
        NSInteger idx = [SHARED_APPDELEGATE.arrStudentName indexOfObject:StudentName];
        [dicDays setObject:[arrString componentsJoinedByString:@"-"] forKey:[NSString stringWithFormat:@"pair%ld_DayTime",idx+1]];
        //[arr addObject:[arrString componentsJoinedByString:@"-"]];
        
        [studentDictionary2 setObject:[NSString stringWithFormat:@"%@$%@",[_dic_SelectedSameInstructor valueForKey:StudentName],[arrString componentsJoinedByString:@"$"]] forKey:StudentName];
    }
    else
    {
        [studentDictionary2 removeObjectForKey:StudentName];
    }
    
    NSLog(@"%@",studentDictionary2);
    
    /*
     */
    
    for (UIView *v in WeekMainView.subviews)
    {
        if([v isKindOfClass:[UIView class]])
        {
            for (UIView *sv in [v subviews])
            {
                if ([sv.backgroundColor isEqual:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]])
                {
                    [btnSelectReset setSelected:YES];
                    [btnSelectReset setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
                    [btnSelectReset setTitle:@"Reset" forState:0];
                    [btnSelectReset setTitleColor:[UIColor whiteColor] forState:0];
                    return;
                }
                else
                {
                    [btnSelectReset setSelected:NO];
                    [btnSelectReset setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
                    [btnSelectReset setTitle:@"Select All" forState:0];
                    [btnSelectReset setTitleColor:[UIColor blackColor] forState:0];
                }
            }
        }
    }
}

-(IBAction)btn_SelectAll_Reset:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [scroll_header viewWithTag:([SHARED_APPDELEGATE.arrStudentName indexOfObject:StudentName]+1)*100].layer.borderColor = [[UIColor clearColor]CGColor];
    selectedScheduleArray = [[NSMutableArray alloc]init];
    temp_time = [[NSMutableArray alloc]init];
    
    if ([sender.titleLabel.text isEqualToString:@"Select All"])
    {
        for(int i = 0; i < 7; i++)
        {
            for(int j = 0; j < 3; j++)
            {
                [selectedScheduleArray addObject:[NSString stringWithFormat:@"%d|%d",(i+1)*100,j]];
            }
        }
        
        [sender setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
        [sender setTitle:@"Reset" forState:0];
        [sender setTitleColor:[UIColor whiteColor] forState:0];
        [selectedScheduleDic setObject:selectedScheduleArray forKey:StudentName];
        
        arrString = [[NSMutableArray alloc]init];
        for(int i = 0 ; i < 7 ; i++)
        {
            [temp_time addObject:@"true_true_true"];
            [arrString addObject:[NSString stringWithFormat:@"%@|True|%@",[arr_days objectAtIndex:i],[temp_time objectAtIndex:i]]];
        }
        //[arr addObject:[arrString componentsJoinedByString:@"-"]];
        
        NSInteger idx = [SHARED_APPDELEGATE.arrStudentName indexOfObject:StudentName];
        [dicDays setObject:[arrString componentsJoinedByString:@"-"] forKey:[NSString stringWithFormat:@"pair%ld_DayTime",idx+1]];
        
        [studentDictionary2 setObject:[NSString stringWithFormat:@"%@$%@",[_dic_SelectedSameInstructor valueForKey:StudentName],[arrString componentsJoinedByString:@"$"]] forKey:StudentName];
        NSLog(@"%@",studentDictionary2);
    }
    else
    {
        [sender setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
        [sender setTitle:@"Select All" forState:0];
        [sender setTitleColor:[UIColor blackColor] forState:0];
        [selectedScheduleDic removeObjectForKey:StudentName];
        
        [studentDictionary2 removeObjectForKey:StudentName];
    }
    
    for (UIView *v in WeekMainView.subviews)
    {
        if([v isKindOfClass:[UIView class]])
        {
            for (UIView *sv in [v subviews])
            {
                if ([sv isKindOfClass:[UIButton class]])
                {
                    [((UIButton *)sv) setBackgroundColor:sender.backgroundColor];
                    [((UIButton *)sv) setTitleColor:[sender titleColorForState:0] forState:0];
                    [((UIButton *)sv) setSelected:sender.selected];
                }
            }
        }
    }
}

-(IBAction)btnNextStepClicked:(UIButton *)sender
{
    BOOL flag = NO;
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        if ([studentDictionary2 valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] == nil)
        {
            if (btnTemp == nil) {
                btnTemp = ((UIButton *)[scroll_header viewWithTag:i]);
            }
            [scroll_header scrollRectToVisible:[scroll_header viewWithTag:(i+1)*100].frame animated:YES];
            [scroll_header viewWithTag:(i+1)*100].layer.borderColor = [[UIColor redColor]CGColor];
            [scroll_header viewWithTag:(i+1)*100].layer.borderWidth = 1.0f;
            flag = YES;
        }
    }
    
    if (flag)
    {
        SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
        sp.s_delegate = self;
        sp.msg = provideSelectAllTime;
        [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
        [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
    }
    else
    {
        NSMutableArray *arrfinal = [[NSMutableArray alloc]init];
        NSMutableArray *arrStudent = [[NSMutableArray alloc]init];
        NSMutableArray *arrStudents1 = [[NSMutableArray alloc]init];
        NSMutableArray *arrStudents2 = [[NSMutableArray alloc]init];
        
        for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count ; i++)
        {
            [arrfinal addObject:[studentDictionary2 valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]]];
            [arrStudent addObject:[SHARED_APPDELEGATE.dicTemp valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]]];
            
            [arrStudents1 addObject:[_dic_SelectedSameInstructor valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]]];
            NSMutableArray *arr1 = (NSMutableArray *)[[[arrStudents1 lastObject]componentsSeparatedByString:@"$"]subarrayWithRange:NSMakeRange(0, 2)];
            NSMutableArray *arr2 = (NSMutableArray *)[[[arrStudents1 lastObject]componentsSeparatedByString:@"$"]subarrayWithRange:NSMakeRange(0, 3)];
            [arrStudents1 replaceObjectAtIndex:i withObject:[arr1 componentsJoinedByString:@"|"]];
            [arrStudents2 addObject:[arr2 componentsJoinedByString:@"*"]];
        }
        
        ScheduleClassViewController *scvc = [[ScheduleClassViewController alloc] initWithNibName:@"ScheduleClassViewController" bundle:nil];
        //        scvc.str_pair1_DayTime = [arr objectAtIndex:0];
        //        if (arr.count == 2) {
        //            scvc.str_pair2_DayTime = [arr objectAtIndex:1];
        //        }
        scvc.dicselectedDays = dicDays;
        scvc.finalString = [arrfinal componentsJoinedByString:@","];
        scvc.studentString = [arrStudents1 componentsJoinedByString:@","];
        scvc.strStudent = arrStudents2;
        scvc.arrid = arrStudent;
        [self.navigationController pushViewController:scvc animated:YES];
    }
}
#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)Continue:(SchedulePopup *)popup
{
    [self btnSelectStudent:btnTemp];
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    btnTemp = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
