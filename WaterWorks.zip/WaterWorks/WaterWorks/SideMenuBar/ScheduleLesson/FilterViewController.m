//
//  FilterViewController.m
//  WaterWorks
//
//  Created by Ankit on 14/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "FilterViewController.h"
#import "AppDelegate.h"
#import "StudentListCell.h"
#import "SLViewController.h"
#import "CommonClass.h"

@interface FilterViewController ()<CommonDelegate>
{
    UIView *vStripe;
    NSMutableArray *arr_days, *arrShift, *Days, *arr_Instructor,*arr_UserInfo, *arrSelectedInstructor, *arr_temp;
    NSArray *arr_tcm;
    NSMutableDictionary *DicTimes, *dicTimesDays_Filter, *dicInstructor_Filter;
    UIButton *btnSelected;
    NSString *strStartTime, *strEndTime, *temp_Instructor, *studentName;
    NSInteger previousTag;
    NSString *newstr;
}
@end

@implementation FilterViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    newstr = @"60";
    [viewHeader setHidden:YES];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    arr_days = [[dateFormatter shortWeekdaySymbols]mutableCopy];
    id object = [arr_days objectAtIndex:0];
    [arr_days removeObjectAtIndex:0];
    [arr_days addObject:object];
    
    dicTimesDays_Filter = [[NSMutableDictionary alloc]init];
    dicInstructor_Filter = [[NSMutableDictionary alloc]init];
    
    arr_tcm = @[@"m",@"t",@"w",@"th",@"f",@"sa",@"su"];
    
    vStripe = [[UIView alloc]init];
    vStripe.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
    
    [scroll_header addSubview:vStripe];
    
    if (SHARED_APPDELEGATE.arrStudentName.count > 1)
    {
        [((UIButton *)[self.view viewWithTag:2])setTitleColor:[UIColor blackColor] forState:0];
        [((UIButton *)[self.view viewWithTag:2])setEnabled:YES];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksFilterResult :self :nil :nil :YES :self];
}

-(void)viewDidLayoutSubviews
{
    [self.view layoutIfNeeded];
    if (studentName == nil)
    {
        [self DynamicAddScheduleView];
    }
}

#pragma mark - Time & Date Filter

-(void)getTimeDateValueForFilter:(NSInteger)cnt
{
    arr_Instructor = [[NSMutableArray alloc]init];
    arrSelectedInstructor = [[NSMutableArray alloc]init];
    
    NSArray *arr = [_dictionary valueForKey:[NSString stringWithFormat:@"ClassAvailList%ld",cnt+1]];
    temp_Instructor = [[arr valueForKey:@"instructors"] objectAtIndex:0];
    if (arr.count > 0)
    {
        [arr_Instructor addObject:[arr objectAtIndex:0]];
        
        for (int i = 1; i < arr.count; i++)
        {
            if (![temp_Instructor isEqualToString:[[arr valueForKey:@"instructors"] objectAtIndex:i]])
            {
                [arr_Instructor addObject:[arr objectAtIndex:i]];
                temp_Instructor = [[arr valueForKey:@"instructors"] objectAtIndex:i];
            }
        }
        
        NSArray *newarray = [[[NSUserDefaults standardUserDefaults]valueForKey:@"FilterInstructor"]valueForKey:studentName];
        if (newarray != nil) {
            arr_temp = [[NSMutableArray alloc]init];
            for (int i = 0; i < arr_Instructor.count; i++) {
                if ([newarray containsObject:[[arr_Instructor valueForKey:@"instructors"] objectAtIndex:i]]) {
                    //[arr_Instructor removeObjectAtIndex:i];
                    [arr_temp addObject:[arr_Instructor objectAtIndex:i]];
                }
            }
        }
        
        //        if (arr_temp.count > 0) {
        //            arr_Instructor = arr_temp;
        //        }
        
        /*
         */
        
        arr_UserInfo = [[NSMutableArray alloc]init];
        NSArray *array = [SHARED_APPDELEGATE.selectedInstructors valueForKey:studentName];
        for (int i = 0; i < array.count; i++)
        {
            if ([[arr_Instructor valueForKey:@"instructors"]containsObject:[NSString stringWithFormat:@"%@",[[array objectAtIndex:i] valueForKey:@"Username"]]])
            {
                [arr_UserInfo addObject:[array objectAtIndex:i]];
            }
        }
        
        /*
         */
        
        NSDictionary *dict = [[NSUserDefaults standardUserDefaults]valueForKey:@"FilterInstructor"];
        if ([dict valueForKey:studentName] == nil)
        {
            [arrSelectedInstructor addObjectsFromArray:[arr_UserInfo valueForKey:@"Username"]];;
        }
        else
        {
            [arrSelectedInstructor addObjectsFromArray:[dict valueForKey:studentName]];
        }
        
        [dicInstructor_Filter setObject:arrSelectedInstructor forKey:studentName];
        
        /*
         */
        
        Days = [[NSMutableArray alloc]init];
        DicTimes = [[NSMutableDictionary alloc]init];
        for (int j = 0; j < arr_days.count; j++)
        {
            NSMutableArray *temp_array_time = [[NSMutableArray alloc]init];
            
            for(int i = 0 ; i < arr.count ; i++)
            {
                if (![[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_select",[arr_tcm objectAtIndex:j]]] isEqualToString:@""])
                {
                    [temp_array_time addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]];
                }
            }
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"hh:mm:ss a"];
            [dateFormatter setAMSymbol:@"AM"];
            [dateFormatter setPMSymbol:@"PM"];
            
            NSArray *sortedTimes = [temp_array_time sortedArrayUsingComparator:^NSComparisonResult(NSString *obj1, NSString *obj2)
                                    {
                                        NSDate *date1 = [dateFormatter dateFromString:obj1];
                                        NSDate *date2 = [dateFormatter dateFromString:obj2];
                                        return [date1 compare:date2];
                                    }];
            
            [DicTimes setObject:sortedTimes forKey:[NSString stringWithFormat:@"Time_%@",[arr_days objectAtIndex:j]]];
            if (temp_array_time.count > 0) {
                [Days addObject:[arr_days objectAtIndex:j]];
            }
        }
        [self setDayTime];
    }
    
    [tblList reloadData];
}

-(void)getShift:(NSString *)intrlist
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    //    __block NSString *str;
    //    [_dicValues enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
    //        NSLog(@"%@",obj);
    //        str = [[obj componentsSeparatedByString:@"|"]firstObject];
    //    }];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"calstartdate":SHARED_APPDELEGATE.startDate,
                             @"Makeupflg":@"0",
                             @"intrlist":intrlist,
                             @"sselected":@"",
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_Step2_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrShift = [[responseObject objectForKey:@"InstructorList"] objectAtIndex:0];
            
            [tblShiftList reloadData];
            
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getBio:(NSString *)iId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"InstructorID":iId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetInstructorBio_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr =[responseObject objectForKey:@"FinalArray"];
            
            img_instructor.layer.cornerRadius = img_instructor.frame.size.width / 2;
            img_instructor.layer.masksToBounds = YES;
            
            if ([[arr objectAtIndex:0]valueForKey:@"wu_Photo"] == nil || [[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] isEqualToString:@""])
            {
                img_instructor.image = [UIImage imageNamed:@"AppLogo"];
            }
            else
            {
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                [img_instructor sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (error != nil) {
                        img_instructor.image = [UIImage imageNamed:@"AppLogo"];
                    }
                }];
            }
            
            lbl_instructor.text = [[arr objectAtIndex:0]valueForKey:@"wu_InsName"];
            //txt_instructor.text = [CommonClass stringByStrippingHTML:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"]];
            if (![[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] isEqual:[NSNull null]]) {
                [webView loadHTMLString:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] baseURL:nil];
            }
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Button Actions

-(void)DynamicAddScheduleView
{
    //---------Student Buttons-----------//
    for (int x = 0; x < SHARED_APPDELEGATE.arrStudentName.count; x++)
    {
        CGFloat btnwidth = ((self.view.frame.size.width - 10)/SHARED_APPDELEGATE.arrStudentName.count);
        if (btnwidth < 100)
        {
            btnwidth = 100.0;
        }
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(x * btnwidth, 0, btnwidth, 25)];
        btn.backgroundColor = [UIColor clearColor];
        
        if (x == 0)
        {
            [btn setTitleColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0] forState:0];
        }
        else
        {
            [btn setTitleColor:[UIColor colorWithRed:(0.0/255.0) green:(60.0/255.0) blue:(111.0/255.0) alpha:1.0] forState:0];
        }
        
        [btn.titleLabel setFont:FONT_Bold(13)];
        [btn setTitle:[[[SHARED_APPDELEGATE.arrStudentName objectAtIndex:x] componentsSeparatedByString:@" "] firstObject] forState:0];
        btn.tag = x;
        [btn addTarget:self action:@selector(btnSelectStudent:) forControlEvents:UIControlEventTouchUpInside];
        [scroll_header addSubview:btn];
        
        studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
        [scroll_header setContentSize:CGSizeMake((btnwidth * SHARED_APPDELEGATE.arrStudentName.count), scroll_header.frame.size.height)];
        
        CGSize stringsize = [[SHARED_APPDELEGATE.arrStudentName objectAtIndex:x] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((btnwidth/2) - (stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20)/2, 27, stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20, 3)];
    }
    
    //---------Student Filter Schedule Grid-----------//
    
    [self getTimeDateValueForFilter:0];
}

-(void)setDayTime
{
    [WeekMainView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    viewHeight.constant = (Days.count * 45) + 10;
    
    for(int i = 0 ; i < Days.count ; i++)
    {
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(8, (i * 45)+8, 38, 35)];
        lbl.backgroundColor = [UIColor clearColor];
        [lbl setTextColor:[UIColor darkGrayColor]];
        [lbl setTextAlignment:NSTextAlignmentCenter];
        [lbl setFont:FONT_Bold(14)];
        [lbl setText:[Days objectAtIndex:i]];
        [WeekMainView addSubview:lbl];
        
        
        CGFloat height = 35.0f;
        UIView *weekView = [[UIView alloc]initWithFrame:CGRectMake(50, (i * 45) + 8, self.view.frame.size.width - 50, height)];
        weekView.backgroundColor = [UIColor clearColor];
        weekView.tag = i;
        [WeekMainView addSubview:weekView];
        
        CGFloat staticWidth = (self.view.frame.size.width - 50)/3;
        
        for (int j = 0 ; j < 3 ; j++)
        {
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(j * staticWidth, 0, staticWidth, height)];
            btn.backgroundColor = [UIColor clearColor];
            [btn setTitleColor:[UIColor darkGrayColor] forState:0];
            [btn.titleLabel setFont:FONT_Semibold(14)];
            
            NSDictionary *dictionry = [[[NSUserDefaults standardUserDefaults] valueForKey:@"FilterTimeDate"] valueForKey:studentName];
            NSDictionary *dict = dictionry != nil ? dictionry : [dicTimesDays_Filter valueForKey:studentName];
            
            NSString *dats1 = dict == nil ? (j == 0 ? [[DicTimes valueForKey:[NSString stringWithFormat:@"Time_%@",[Days objectAtIndex:i]]] firstObject] : [[DicTimes valueForKey:[NSString stringWithFormat:@"Time_%@",[Days objectAtIndex:i]]] lastObject]) : (j == 0 ? [[dict valueForKey:[Days objectAtIndex:i]] firstObject]:[[dict valueForKey:[Days objectAtIndex:i]] lastObject]);
            
            NSDateFormatter *dateFormatter3 = [[NSDateFormatter alloc] init];
            [dateFormatter3 setDateStyle:NSDateFormatterMediumStyle];
            [dateFormatter3 setDateFormat:@"hh:mm:ss a"];
            [dateFormatter3 setAMSymbol:@"AM"];
            [dateFormatter3 setPMSymbol:@"PM"];
            
            NSDate *date1 = [dateFormatter3 dateFromString:dats1];
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"hh:mm a"];
            [formatter setAMSymbol:@"AM"];
            [formatter setPMSymbol:@"PM"];
            
            [btn setTitle:[formatter stringFromDate:date1] forState:0];
            
            if (j == 0 || j != 1)
            {
                [btn setTitle:[formatter stringFromDate:date1] forState:0];
            }
            else if (j == 1)
            {
                [btn setTitle:@"→" forState:0];
            }
            
            btn.tag = j;
            if (j != 1) {
                [btn addTarget:self action:@selector(btnSelectTime:) forControlEvents:UIControlEventTouchUpInside];
            }else{
                [btn setUserInteractionEnabled:NO];
            }
            [weekView addSubview:btn];
        }
    }
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [self PrepateFilterData];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    UIView *v = [self.view.subviews.lastObject isEqual:InstructorView] ? tblList : TimeDateView.subviews[0];
    [self getTimeDateValueForFilter:sender.tag];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        v.transform = CGAffineTransformMakeTranslation(v.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            v.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        v.transform = CGAffineTransformMakeTranslation(-v.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            v.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:[UIColor colorWithRed:(0.0/255.0) green:(60.0/255.0) blue:(111.0/255.0) alpha:1.0] forState:0];
        }
    }
    [sender setTitleColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0] forState:0];
}

-(void)btnSelectTime:(UIButton *)sender
{
    [btnStartEndTime setTitle:[NSString stringWithFormat:@"Adjust your %@ time",sender.tag == 0 ? @"start" : @"end"] forState:0];
    
    btnSelected = sender;
    strStartTime = [[DicTimes valueForKey:[NSString stringWithFormat:@"Time_%@",[Days objectAtIndex:sender.superview.tag]]] firstObject];
    strEndTime = [[DicTimes valueForKey:[NSString stringWithFormat:@"Time_%@",[Days objectAtIndex:sender.superview.tag]]] lastObject];
    
    [btnTime setTitle:sender.titleLabel.text forState:0];
    [TimeView setFrame:self.view.bounds];
    [self.view addSubview:TimeView];
}

-(IBAction)btnAddRemoveApply:(UIButton *)sender
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    if (sender.tag == 1 || sender.tag == 2)
    {
        [formatter setDateFormat:@"hh:mm a"];
        [formatter setAMSymbol:@"AM"];
        [formatter setPMSymbol:@"PM"];
        
        NSDate *add20_40Min = [[formatter dateFromString:btnTime.titleLabel.text] dateByAddingTimeInterval:(sender.tag == 1 ? 20*60 : (-20*60))];
        [UIView performWithoutAnimation:^{
            [btnTime setTitle:[formatter stringFromDate:add20_40Min] forState:0];
            [btnTime layoutIfNeeded];
        }];
    }
    else if (sender.tag == 3)
    {
        [formatter setDateFormat:@"hh:mm a"];
        [formatter setAMSymbol:@"AM"];
        [formatter setPMSymbol:@"PM"];
        NSDate *date = [formatter dateFromString:btnTime.titleLabel.text];
        [formatter setDateFormat:@"hh:mm:ss a"];
        [formatter setAMSymbol:@"AM"];
        [formatter setPMSymbol:@"PM"];
        
        [self checkTimeInbetweenOrNot:strStartTime EndTime:strEndTime CurrentTime:[formatter stringFromDate:date] :^(BOOL flag, NSString *msg) {
            if (flag)
            {
                [btnSelected setTitle:btnTime.titleLabel.text forState:0];
                [TimeView removeFromSuperview];
            }
            else
            {
                [CommonClass showToastMsg:msg];
            }
        }];
    }
    else{
        [TimeView removeFromSuperview];
    }
}

-(void)checkTimeInbetweenOrNot:(NSString *)startTime EndTime:(NSString *)endTime CurrentTime:(NSString *)currentTime :(void (^)(BOOL flag, NSString *msg))completion
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"hh:mm:ss a"];
    [formatter setAMSymbol:@"AM"];
    [formatter setPMSymbol:@"PM"];
    
    int start   = [self minutesSinceMidnight:[formatter dateFromString:startTime]];
    int end     = [self minutesSinceMidnight:[formatter dateFromString:endTime]];
    int current = [self minutesSinceMidnight:[formatter dateFromString:currentTime]];;
    
    if (start <= current && current <= end)
        completion(YES,@"");
    
    else if (current > end)
        completion(NO,@"Time cannot be later than original time");
    else
        completion(NO,@"This time is not allowed.");
}

-(int) minutesSinceMidnight:(NSDate *)date
{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:date];
    return 60 * (int)[components hour] + (int)[components minute];
}

-(NSMutableDictionary *)PrepateFilterData
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    int i = -1;
    for (UIView *v in WeekMainView.subviews)
    {
        if (![v isKindOfClass:[UILabel class]])
        {
            NSMutableArray *array = [[NSMutableArray alloc]init];
            for (UIView *view in v.subviews)
            {
                if (![((UIButton *)view).titleLabel.text isEqualToString:@"→"])
                {
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    [formatter setDateFormat:@"hh:mm a"];
                    [formatter setAMSymbol:@"AM"];
                    [formatter setPMSymbol:@"PM"];
                    
                    NSDate *date = [formatter dateFromString:((UIButton *)view).titleLabel.text];
                    [formatter setDateFormat:@"hh:mm:ss a"];
                    [formatter setAMSymbol:@"AM"];
                    [formatter setPMSymbol:@"PM"];
                    
                    [array addObject:[formatter stringFromDate:date]];
                }
                else
                {
                    i++;
                }
            }
            [dic setObject:array.count > 0 ? array : nil forKey:[Days objectAtIndex:i]];
        }
    }
    [dicTimesDays_Filter setObject:dic forKey:studentName];
    return dicTimesDays_Filter;
}

//-(NSMutableDictionary *)PrepateFilterData
//{
//    NSMutableDictionary *dicFilter = [[NSMutableDictionary alloc]init];
//    for (NSString *str in SHARED_APPDELEGATE.arrStudentName)
//    {
//        NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
//        int i = -1;
//        for (UIView *v in WeekMainView.subviews)
//        {
//            if (![v isKindOfClass:[UILabel class]])
//            {
//                NSMutableArray *array = [[NSMutableArray alloc]init];
//                for (UIView *view in v.subviews)
//                {
//                    if (![((UIButton *)view).titleLabel.text isEqualToString:@"→"])
//                    {
//                        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//                        [formatter setDateFormat:@"hh:mm a"];
//                        NSDate *date = [formatter dateFromString:((UIButton *)view).titleLabel.text];
//                        [formatter setDateFormat:@"hh:mm:ss a"];
//                        [array addObject:[formatter stringFromDate:date]];
//                    }
//                    else
//                    {
//                        i++;
//                    }
//                }
//                [dic setObject:array forKey:[Days objectAtIndex:i]];
//            }
//        }
//        [dicFilter setObject:dic forKey:str];
//    }
//    NSLog(@"%@",dicFilter);
//    return dicFilter;
//}

#pragma mark - Main Button Actions

-(IBAction)btnClicked:(UIButton *)sender
{
    switch (sender.tag) {
        case 0:
            [CommonClass setNavigationTitle:NavigationWaterWorksFilterTimeDays :self :nil :nil :YES :self];
            [self viewMaker:TimeDateView :InstructorView :AdvancedView];
            break;
            
        case 1:
            [CommonClass setNavigationTitle:NavigationWaterWorksFilterInstructor :self :nil :nil :YES :self];
            [self viewMaker:InstructorView :TimeDateView :AdvancedView];
            break;
            
        case 2:
            if ([[NSUserDefaults standardUserDefaults]valueForKey:@"AdvancedFilter"] != nil) {
                NSInteger tag = [[[NSUserDefaults standardUserDefaults]valueForKey:@"AdvancedFilter"]integerValue];
                [((UIButton *)[AdvancedView viewWithTag:tag])setSelected:YES];
            }else{
                [((UIButton *)[AdvancedView viewWithTag:60])setSelected:YES];
            }
            [CommonClass setNavigationTitle:NavigationWaterWorksAdvancedFilter :self :nil :nil :YES :self];
            [self viewMaker:AdvancedView :InstructorView :TimeDateView];
            [viewHeader setHidden:YES];
            break;
            
        case 3:
            //            [[NSUserDefaults standardUserDefaults]setObject:[self PrepateFilterData] forKey:@"FilterTimeDate"];
            [[NSUserDefaults standardUserDefaults]setObject:dicInstructor_Filter forKey:@"FilterInstructor"];
            [self.f_delegate FilterValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"FilterTimeDate"]:dicInstructor_Filter :newstr];
            [[self navigationController]popViewControllerAnimated:YES];
            break;
            
        case 4:
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [SLViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            break;
            
        case 5:
            [[NSUserDefaults standardUserDefaults]setObject:[self PrepateFilterData] forKey:@"FilterTimeDate"];
            [self viewRemove:TimeDateView];
            break;
            
        case 6:
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-3] animated:YES];
            break;
            
        case 7:
            [self viewRemove:InstructorView];
            break;
            
        case 8:
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-4] animated:YES];
            break;
            
        case 9:
            [self viewRemove:AdvancedView];
            break;
            
        default:
            break;
    }
}

-(void)viewMaker:(UIView *)v :(UIView *)rv :(UIView *)rv1
{
    [self.view.subviews makeObjectsPerformSelector:@selector(setHidden:)];
    [rv removeFromSuperview];
    [rv1 removeFromSuperview];
    [viewHeader setHidden:NO];
    [v setFrame:CGRectMake(0, 50, self.view.frame.size.width, self.view.frame.size.height - 50)];
    [self.view addSubview:v];
    [viewHeader setHidden:NO];
}

-(void)viewRemove:(UIView *)rv
{
    self.navigationItem.titleView = [SHARED_APPDELEGATE getNavigationCenterWithTitle:NavigationWaterWorksFilterResult fontSize:18];
    [self.view.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
    [rv removeFromSuperview];
    [viewHeader setHidden:YES];
}

-(IBAction)btnSelected:(UIButton *)sender
{
    [[NSUserDefaults standardUserDefaults]setInteger:sender.tag forKey:@"AdvancedFilter"];
    for (UIView *v in AdvancedView.subviews) {
        if ([v isKindOfClass:[UIButton class]]) {
            [((UIButton *)v) setSelected:NO];
        }
    }
    sender.selected = YES;
    newstr = [NSString stringWithFormat:@"%ld",(long)sender.tag];
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (tableView == tblList)
    {
        CGFloat height = (self.view.frame.size.width * 140) / 320;
        return height;
    }
    return 0;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (tableView == tblList)
    {
        return tblFooterView;
    }
    return nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == tblList)
    {
        return arr_Instructor.count;
    }else{
        return 7;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return tableView == tblList ? 80 : 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (tableView == tblList)
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:1];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        sCell.lbl_fm_name.text = [[arr_UserInfo objectAtIndex:indexPath.row]valueForKey:@"Username"];
        
        if ([[arr_UserInfo objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] == nil || [[[arr_UserInfo objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] isEqualToString:@""])
        {
            sCell.img_fm.image = [UIImage imageNamed:@"AppLogo"];
        }
        else
        {
            NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[[[arr_UserInfo objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            [sCell.img_fm sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                if (error != nil) {
                    sCell.img_fm.image = [UIImage imageNamed:@"AppLogo"];
                }
            }];
        }
        
        if (![[dicInstructor_Filter valueForKey:studentName]containsObject:[NSString stringWithFormat:@"%@",sCell.lbl_fm_name.text]])
        {
            if ([[[arr_UserInfo objectAtIndex:indexPath.row]valueForKey:@"gender"]isEqualToString:@"M"])
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(138.0/255.0) green:(215.0/255.0) blue:(253.0/255.0) alpha:1.0];
            }
            else
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(254.0/255.0) green:(214.0/255.0) blue:(215.0/255.0) alpha:1.0];
            }
            [sCell.btnSelect setSelected:NO];
        }
        else
        {
            [sCell.bgView setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
            [sCell.btnSelect setSelected:YES];
        }
        
        sCell.btnSelect.tag = indexPath.row;
        sCell.btnViewShift.tag = indexPath.row;
        sCell.btnViewBio.tag = indexPath.row;
        
        [sCell.btnViewShift addTarget:self action:@selector(btn_View_Shift:) forControlEvents:UIControlEventTouchUpInside];
        [sCell.btnViewBio addTarget:self action:@selector(btn_View_Bio:) forControlEvents:UIControlEventTouchUpInside];
        [sCell.btnSelect addTarget:self action:@selector(btn_Select:) forControlEvents:UIControlEventTouchUpInside];
        return sCell;
    }
    else
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:4];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        NSArray  *arr = ShortFormTime;
        
        sCell.lbl_day_name.text = [arr_days objectAtIndex:indexPath.row];
        sCell.lbl_schedule.text = [NSString stringWithFormat:@"%@",[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr objectAtIndex:indexPath.row]]]];
        
        if([[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr objectAtIndex:indexPath.row]]] isEqualToString:@""]){
            sCell.lbl_schedule.text = @"Not available";
        }
        return sCell;
    }
}

#pragma mark - Table Button Actions

-(void)btn_Select:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected)
    {
        [arrSelectedInstructor addObject:[[arr_UserInfo objectAtIndex:sender.tag] valueForKey:@"Username"]];
    }
    else
    {
        [arrSelectedInstructor removeObject:[[arr_UserInfo objectAtIndex:sender.tag] valueForKey:@"Username"]];
        if (arrSelectedInstructor.count == 0)
        {
            sender.selected = YES;
            [arrSelectedInstructor addObject:[[arr_UserInfo objectAtIndex:sender.tag] valueForKey:@"Username"]];
            
            [CommonClass showToastMsg:OneInstructorSelection];
            return;
        }
    }
    [dicInstructor_Filter setObject:arrSelectedInstructor forKey:studentName];
    [tblList reloadData];
}
-(void)btn_View_Bio:(UIButton *)sender
{
    [self resetBio];
    [self getBio:[[arr_UserInfo objectAtIndex:sender.tag]valueForKey:@"UserID"]];
    [viewBio setFrame:self.view.bounds];
    [self.view addSubview:viewBio];
}

-(void)btn_View_Shift:(UIButton *)sender
{
    [self getShift:[NSString stringWithFormat:@"%@:%@",[[arr_UserInfo objectAtIndex:sender.tag]valueForKey:@"UserID"],[[arr_UserInfo objectAtIndex:sender.tag]valueForKey:@"Username"]]];
    [viewShift setFrame:self.view.bounds];
    [self.view addSubview:viewShift];
}

-(IBAction)btn_Done_Close:(UIButton *)sender
{
    [viewShift removeFromSuperview];
    [viewBio removeFromSuperview];
}

-(void)resetBio
{
    [lbl_instructor setText:@""];
    img_instructor.image = nil;
    [webView loadHTMLString:@"" baseURL:nil];
}

-(void)popViewController
{
    if (viewHeader.hidden == NO || (AdvancedView.hidden == NO && [self.view.subviews containsObject:AdvancedView])) {
        [self viewRemove:InstructorView];
        [self viewRemove:AdvancedView];
        [self viewRemove:TimeDateView];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end



/*if (sender.tag == 1)
 {
 if (m == 40.0)
 {
 h++;
 if (h == 13) {
 h = 1;
 }
 if (h == 12) {
 str = [str isEqualToString:@"PM"] ? @"AM" : @"PM";
 }
 m = 0;
 }
 else
 {
 m+= 20;
 }
 }
 else if (sender.tag == 2)
 {
 if (m == 0)
 {
 h--;
 if (h == 0) {
 str = [str isEqualToString:@"PM"] ? @"AM" : @"PM";
 h = 12;
 }
 m = 40;
 }
 else
 {
 m-= 20;
 }
 }
 else if (sender.tag == 3)
 {
 //[btnSelected setTitle:[NSString stringWithFormat:@"%@%d:%@%d %@",h < 10?@"0":@"",h,m < 20?@"0":@"",m , str] forState:0];
 [TimeView removeFromSuperview];
 }
 else{
 [TimeView removeFromSuperview];
 }
 [btnTime setTitle:[NSString stringWithFormat:@"%@%d:%@%d %@",h < 10?@"0":@"",h,m < 20?@"0":@"",m , str] forState:0];*/
