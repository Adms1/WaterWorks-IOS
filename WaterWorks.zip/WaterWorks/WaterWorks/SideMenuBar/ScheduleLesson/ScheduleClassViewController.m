//
//  ScheduleClassViewController.m
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ScheduleClassViewController.h"
#import "StudentListCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "GetScheduleViewController.h"
#import "SchedulePopup.h"
#import "ScheduleClassViewController.h"
#import "FilterViewController.h"
#import "PopupView.h"
#import "CustomTabbar.h"

@interface ScheduleClassViewController ()<ScheduleDelegate,SchedulePopupDelegate,PopupViewDelegate,FilterDelegate,CommonDelegate>
{
    NSMutableDictionary *dicStudentSchedule,*finalStudentSchedule, *dict,*finalScheduleDic, *dic_selectedIndex, *dicFilter ,*dicFilterInstructor, *dicTemp;
    NSArray *arr_tcm, *arrShift;
    NSString *studentName,*strNo;
    NSMutableArray *arr_days, *arr_instrutor, *arr_selectedSchedule, *arr_selectedIndex, *arr_Info;
    NSInteger previousTag;
    UIView *vStripe;
}
@end

@implementation ScheduleClassViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    arr_days = [[dateFormatter weekdaySymbols]mutableCopy];
    id object = [arr_days objectAtIndex:0];
    [arr_days removeObjectAtIndex:0];
    [arr_days addObject:object];
    
    arr_tcm = @[@"m",@"t",@"w",@"th",@"f",@"sa",@"su"];
    strNo = @"60";
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
    [scroll_main setContentOffset:CGPointZero animated:YES];
    [scroll_main scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
        
        SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
        sp.s_delegate = self;
        sp.title_msg = @"Searching for lessons...";
        
        int extra = 0;
        if ([[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"])
        {
            sp.msg = SHARED_APPDELEGATE.endDate == nil ? provideScheduleStartMsg1 : [NSString stringWithFormat:@"%@\n%@",provideScheduleStartMsg1,provideScheduleStartMsg2];
            extra = SHARED_APPDELEGATE.endDate == nil ? 0 : 20;
        }
        else
        {
            sp.msg = provideScheduleStartMsg1;
        }
        
        [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width, sp.view.frame.size.height + extra)];
        [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
    }
    
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :([[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? 0 : 1 ) :[[[NSUserDefaults standardUserDefaults] valueForKey:MAKEUPCOUNT] integerValue]];
    [self.view insertSubview:ct atIndex:0];
}

-(void)Continue:(SchedulePopup *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    [self getStudentSchedule];
}

#pragma mark - Api Calling

-(void)getStudentSchedule
{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *s1 = [[[_arrid objectAtIndex:0]componentsSeparatedByString:@","]firstObject];
    NSString *intrlist = s1;
    if (_arrid.count == 2) {
        intrlist = [NSString stringWithFormat:@"%@,%@",s1,[[[_arrid objectAtIndex:1]componentsSeparatedByString:@","]firstObject]];
    }
    
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : NO;
    
    NSArray *arrStudentIds_Combo1 = [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]] objectAtIndex:0];
    NSArray *arrStudentIds_Combo2 = SHARED_APPDELEGATE.arrStudentName.count > 1 ? [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] objectAtIndex:0] : nil;
    
    NSArray *arrStudentName_Combo1 = [[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]componentsSeparatedByString:@"&"];
    NSArray *arrStudentName_Combo2 = SHARED_APPDELEGATE.arrStudentName.count > 1 ? [[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]componentsSeparatedByString:@"&"] : nil;
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             
                             @"calstartdate":SHARED_APPDELEGATE.startDate,
                             @"calenddate":SHARED_APPDELEGATE.endDate == nil ? @"" : SHARED_APPDELEGATE.endDate,
                             
                             @"strstudentarry":_finalString,
                             @"intrlist":[_arrid objectAtIndex:0],//intrlist,
                             
                             @"pair1_InstrList":[_arrid objectAtIndex:0],
                             @"pair2_InstrList":(_arrid.count == 2) ? [_arrid objectAtIndex:1] : @"",
                             
                             @"pair1_DayTime":[_dicselectedDays valueForKey:@"pair1_DayTime"],
                             @"pair2_DayTime":[_dicselectedDays valueForKey:@"pair2_DayTime"] == nil ? @"" : [_dicselectedDays valueForKey:@"pair2_DayTime"],
                             
                             @"siteid":[[NSUserDefaults standardUserDefaults] valueForKey:SITEID],
                             @"Makeupflg":[[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? @"0" : @"1",
                             @"reserveforever":SHARED_APPDELEGATE.endDate == nil ? @"1" : @"0",
                             @"Type":@"2",
                             
                             @"schedulechoices":[[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? IsCombo ? @"1" : @"7" : @"7",
                             @"scheduletype":@"0",
                             @"SelectStudList":@"",
                             
                             @"pair1Check":IsCombo ? @"1" : @"0",
                             @"pair2Check":IsCombo && arrStudentName_Combo2.count > 0 ? @"1" : @"0",
                             
                             @"pair1lessontype":IsCombo ? [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]] objectAtIndex:2] : @"",
                             @"pair2lessontype":IsCombo && arrStudentName_Combo2.count > 0 ?[[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] objectAtIndex:2] : @"",
                             
                             @"pair1_Cmbo1":IsCombo ? [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo1 objectAtIndex:0],[arrStudentName_Combo1 objectAtIndex:0]] : @"0",
                             @"pair1_Cmbo2":IsCombo ? [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo1 objectAtIndex:1],[arrStudentName_Combo1 objectAtIndex:1]] : @"0",
                             @"pair1_Cmbo3":IsCombo && arrStudentIds_Combo1.count > 2 ?  [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo1 objectAtIndex:2],[arrStudentName_Combo1 objectAtIndex:2]] : @"0",
                             @"pair1_Cmbo4":@"0",
                             
                             @"pair2_Cmbo1":IsCombo && arrStudentName_Combo2.count > 0 ? [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo2 objectAtIndex:0],[arrStudentName_Combo2 objectAtIndex:0]] : @"0",
                             @"pair2_Cmbo2":IsCombo && arrStudentName_Combo2.count > 0 ? [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo2 objectAtIndex:1],[arrStudentName_Combo2 objectAtIndex:1]] : @"0",
                             @"pair2_Cmbo3":IsCombo && arrStudentIds_Combo2.count > 2 ?  [NSString stringWithFormat:@"%@:%@",[arrStudentIds_Combo2 objectAtIndex:2],[arrStudentName_Combo2 objectAtIndex:2]] : @"0",
                             @"pair2_Cmbo4":@"0"
                             };
    
    NSLog(@"%@",params);
    
    dicStudentSchedule = [[NSMutableDictionary alloc]init];
    finalScheduleDic = [[NSMutableDictionary alloc]init];
    arr_selectedIndex = [[NSMutableArray alloc]init];
    dic_selectedIndex = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    //    AFJSONResponseSerializer *responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingAllowFragments];
    //    manager.responseSerializer = responseSerializer;
    //    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager.requestSerializer setTimeoutInterval:18000];
    [manager POST:Schl_Get_Step3_AddSchedule_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            for (int i = 1; i < 6; i++)
            {
                NSArray *arr =[responseObject objectForKey:[NSString stringWithFormat:@"ClassAvailList%d",i]];
                if (arr.count > 0)
                {
                    [dicStudentSchedule setObject:arr forKey:[NSString stringWithFormat:@"ClassAvailList%d",i]];
                }
            }
            
            [tblList setHidden:NO];
            [EmptyView setHidden:YES];
            [btnFilter setHidden:NO];
            scrlTop.constant = 110.0f;
            [self UpdateSchedule:0];
            
            /*NSMutableArray *array = [[dicStudentSchedule valueForKey:@"ClassAvailList1"]valueForKey:@"instructors"];
             [arr_instrutor addObject:[array objectAtIndex:0]];
             [arr_height addObject:@"0"];
             int x = 0;
             
             NSMutableArray *temp = [[NSMutableArray alloc]init];
             for (int i = 1; i < array.count; i++)
             {
             if (![[arr_instrutor objectAtIndex:x]isEqualToString:[array objectAtIndex:i]])
             {
             [finalStudentSchedule setObject:temp forKey:[arr_instrutor lastObject]];
             temp = [[NSMutableArray alloc]init];
             [arr_instrutor addObject:[array objectAtIndex:i]];
             [arr_height addObject:@"0"];
             x++;
             }
             else
             {
             [temp addObject:[[dicStudentSchedule valueForKey:@"ClassAvailList1"]objectAtIndex:i-1]];
             }
             }
             [finalStudentSchedule setObject:temp forKey:[arr_instrutor lastObject]];
             NSLog(@"%@",finalStudentSchedule);
             
             [tblList reloadData];
             tblHeight.constant = tblList.contentSize.height;
             
             [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblHeight.constant + 30)];*/
            
        }
        else
        {
            [EmptyView setHidden:NO];
            [tblList setHidden:YES];
            [btnFilter setHidden:YES];
            scrlTop.constant = 50.0f;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        [tblList reloadData];
        tblHeight.constant = tblList.contentSize.height;
        
        [scroll_main setContentOffset:CGPointZero animated:YES];
        [scroll_main scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [EmptyView setHidden:NO];
        [tblList setHidden:YES];
        [btnFilter setHidden:YES];
        scrlTop.constant = 50.0f;
        [tblList reloadData];
        tblHeight.constant = tblList.contentSize.height;
        
        [scroll_main setContentOffset:CGPointZero animated:YES];
        [scroll_main scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error.description);
    }];
}

-(void)getShift:(NSString *)intrlist
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    //    __block NSString *str;
    //    [_dicValues enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
    //        NSLog(@"%@",obj);
    //        str = [[obj componentsSeparatedByString:@"|"]firstObject];
    //    }];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"calstartdate":SHARED_APPDELEGATE.startDate,
                             @"Makeupflg":[[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? @"0" : @"1",
                             @"intrlist":intrlist,
                             @"sselected":@"",
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_Step2_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrShift = [[responseObject objectForKey:@"InstructorList"] objectAtIndex:0];
            
            [tblShift reloadData];
            
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getBio:(NSString *)iId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"InstructorID":iId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetInstructorBio_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr =[responseObject objectForKey:@"FinalArray"];
            
            img_instructor.layer.cornerRadius = img_instructor.frame.size.width / 2;
            img_instructor.layer.masksToBounds = YES;
            
            if ([[arr objectAtIndex:0]valueForKey:@"wu_Photo"] == nil || [[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] isEqualToString:@""])
            {
                img_instructor.image = [UIImage imageNamed:@"AppLogo"];
            }
            else
            {
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                [img_instructor sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (error != nil) {
                        img_instructor.image = [UIImage imageNamed:@"AppLogo"];
                    }
                }];
            }
            
            lbl_instructor.text = [[arr objectAtIndex:0]valueForKey:@"wu_InsName"];
            //txt_instructor.text = [CommonClass stringByStrippingHTML:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"]];
            if (![[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] isEqual:[NSNull null]]) {
                [webView loadHTMLString:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] baseURL:nil];
            }
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - Button Actions

-(void)DynamicAddStudents
{
    //---------Student Buttons-----------//
    
    vStripe= [CommonClass dynamicAddChild:scroll_header scrollToview:scroll_main :self];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
    
    //    /*
    //     */
    //
    //    arr_Info = [[NSMutableArray alloc]init];
    //    NSArray *arr = [SHARED_APPDELEGATE.selectedInstructors valueForKey:studentName];
    //    for (int i = 0; i < SHARED_APPDELEGATE.selectedInstructors.count; i++)
    //    {
    //        if (arr_instrutor.count > 0)
    //        {
    //            if ([arr_instrutor containsObject:[NSString stringWithFormat:@"%@",[[arr objectAtIndex:i] valueForKey:@"Username"]]])
    //            {
    //                [arr_Info addObject:[arr objectAtIndex:i]];
    //            }
    //        }
    //    }
}

-(void)UpdateSchedule:(NSInteger)idx
{
    arr_selectedSchedule = [[NSMutableArray alloc]init];
    arr_selectedIndex = [[NSMutableArray alloc]init];
    
    /*
     */
    
    NSDictionary *newdic = [finalScheduleDic valueForKey:studentName];
    for (NSString *str in [newdic allKeys])
    {
        if (![[newdic valueForKey:str] isEqualToString:@""])
        {
            NSArray *temp_array = [[newdic valueForKey:str] componentsSeparatedByString:@","];
            for (NSString *new_str in temp_array)
            {
                [arr_selectedSchedule addObject:new_str];
            }
        }
    }
    
    /*
     */
    
    NSArray *newIndexArray = [dic_selectedIndex valueForKey:studentName];
    if (newIndexArray.count > 0) {
        [arr_selectedIndex addObjectsFromArray:newIndexArray];
    }
    
    /*
     */
    
    [self advancedFilter:idx];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        scroll_main.transform = CGAffineTransformMakeTranslation(scroll_main.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll_main.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        scroll_main.transform = CGAffineTransformMakeTranslation(-scroll_main.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll_main.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    [self UpdateSchedule:sender.tag];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return tableView == tblList ? (self.view.frame.size.width - 40)/6.5 + 30 : 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *sampleView = [[UIView alloc] init];
    sampleView.frame = CGRectMake(0, 0, self.view.frame.size.width, (self.view.frame.size.width - 40)/6.5 + 30);
    sampleView.backgroundColor = [UIColor clearColor];
    
    btnNext.frame = CGRectMake(0, 0, (self.view.frame.size.width - 40), (self.view.frame.size.width - 40)/6.5);
    btnNext.center = CGPointMake(sampleView.frame.size.width/2, sampleView.frame.size.height/2 - 10);
    [sampleView addSubview:btnNext];
    return sampleView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    for (int i = 0; i < arr_instrutor.count; i++) {
        NSArray *arr = [finalStudentSchedule valueForKey:[arr_instrutor objectAtIndex:i]];
        if (arr == nil) {
            [arr_instrutor removeObjectAtIndex:i];
        }
    }
    return tableView == tblList ? arr_instrutor.count : 7;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == tblList)
    {
        NSArray *arr = [finalStudentSchedule valueForKey:[arr_instrutor objectAtIndex:indexPath.row]];
        
        NSInteger arrCount = 0;
        for (int j = 0; j < arr_days.count; j++)
        {
            NSMutableArray *temp_array_date = [[NSMutableArray alloc]init];
            for(int k = 0 ; k < arr.count ; k++)
            {
                if (![[[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]] isEqualToString:@""])
                {
                    if ([dicFilter valueForKey:studentName]!= nil)
                    {
                        NSString *key = [[arr_days objectAtIndex:j]substringToIndex:3];
                        if ([self checkTimeInbetweenOrNot:[[[dicFilter valueForKey:studentName] valueForKey:key] objectAtIndex:0] EndTime:[[[dicFilter valueForKey:studentName] valueForKey:key] objectAtIndex:1] CurrentTime:[[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]])
                        {
                            if ([[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]] != nil)
                            {
                                [temp_array_date addObject:[[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]];
                            }
                        }
                    }
                    else
                    {
                        if ([[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]] != nil)
                        {
                            [temp_array_date addObject:[[arr objectAtIndex:k]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]];
                        }
                    }
                }
            }
            if (arrCount > temp_array_date.count)
            {
                arrCount = arrCount;
            }
            else
            {
                arrCount = temp_array_date.count;
            }
        }
        return (arrCount * 66) + 105;
    }
    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (tableView == tblList)
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        sCell = nil;
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:2];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        sCell.tag = indexPath.row;
        
        NSArray *arr = [finalStudentSchedule valueForKey:[arr_instrutor objectAtIndex:indexPath.row]];
        
        if (arr.count > 0)
        {
            sCell.lbl_instructor_name.text = [[arr objectAtIndex:0]valueForKey:@"instructors"];
            if ([[arr objectAtIndex:0]valueForKey:@"wu_Photo"] == nil || [[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] isEqualToString:@""])
            {
                sCell.img_instructor.image = [UIImage imageNamed:@"AppLogo"];
            }
            else
            {
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                [sCell.img_instructor sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (error != nil) {
                        sCell.img_instructor.image = [UIImage imageNamed:@"AppLogo"];
                    }
                }];
            }
            
            
            NSMutableDictionary *dayDic = [[NSMutableDictionary alloc]init];
            for (int j = 0; j < arr_days.count; j++)
            {
                NSMutableArray *temp_array_date = [[NSMutableArray alloc]init];
                NSMutableArray *temp_array_time = [[NSMutableArray alloc]init];
                NSMutableArray *temp_array_select = [[NSMutableArray alloc]init];
                
                for(int i = 0 ; i < arr.count ; i++)
                {
                    if (![[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_select",[arr_tcm objectAtIndex:j]]] isEqualToString:@""])
                    {
                        if ([dicFilter valueForKey:studentName] != nil)
                        {
                            NSString *key = [[arr_days objectAtIndex:j]substringToIndex:3];
                            if ([self checkTimeInbetweenOrNot:[[[dicFilter valueForKey:studentName] valueForKey:key] objectAtIndex:0] EndTime:[[[dicFilter valueForKey:studentName] valueForKey:key] objectAtIndex:1] CurrentTime:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]])
                            {
                                if ([[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]] != nil)
                                {
                                    [temp_array_date addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_dt",[arr_tcm objectAtIndex:j]]]];
                                    [temp_array_time addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]];
                                    [temp_array_select addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_select",[arr_tcm objectAtIndex:j]]]];
                                }
                            }
                        }
                        else
                        {
                            if ([[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]] != nil)
                            {
                                [temp_array_date addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_dt",[arr_tcm objectAtIndex:j]]]];
                                [temp_array_time addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_time",[arr_tcm objectAtIndex:j]]]];
                                [temp_array_select addObject:[[arr objectAtIndex:i]valueForKey:[NSString stringWithFormat:@"tc%@_select",[arr_tcm objectAtIndex:j]]]];
                            }
                        }
                    }
                }
                [dayDic setObject:temp_array_date forKey:[NSString stringWithFormat:@"Date_%@",[arr_days objectAtIndex:j]]];
                [dayDic setObject:temp_array_time forKey:[NSString stringWithFormat:@"Time_%@",[arr_days objectAtIndex:j]]];
                [dayDic setObject:temp_array_select forKey:[NSString stringWithFormat:@"Select_%@",[arr_days objectAtIndex:j]]];
            }
            
            /*
             */
            
            NSArray *arr = [arr_Info valueForKey:@"Username"];
            NSInteger idx = [arr indexOfObject:sCell.lbl_instructor_name.text];
            
            if ([[[arr_Info objectAtIndex:idx]valueForKey:@"gender"]isEqualToString:@"M"])
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(138.0/255.0) green:(215.0/255.0) blue:(253.0/255.0) alpha:1.0];
            }
            else
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(254.0/255.0) green:(214.0/255.0) blue:(215.0/255.0) alpha:1.0];
            }
            
            sCell.contentView.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, sCell.frame.size.height);
            sCell.delegate = self;
            sCell.contentView.tag = (indexPath.row+1) * 1000;
            [sCell StudentLessonsSchedule:dayDic :arr_selectedSchedule :dic_selectedIndex :studentName];
            
            sCell.btnViewShift.tag = idx;
            sCell.btnViewBio.tag = idx;
            
            [sCell.btnViewShift addTarget:self action:@selector(btn_View_Shift:) forControlEvents:UIControlEventTouchUpInside];
            [sCell.btnViewBio addTarget:self action:@selector(btn_View_Bio:) forControlEvents:UIControlEventTouchUpInside];
        }
        return sCell;
    }
    else
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:4];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        NSArray  *arr = ShortFormTime;
        
        sCell.lbl_day_name.text = [[arr_days objectAtIndex:indexPath.row] substringToIndex:3];
        sCell.lbl_schedule.text = [NSString stringWithFormat:@"%@",[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr objectAtIndex:indexPath.row]]]];
        
        if([[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr objectAtIndex:indexPath.row]]] isEqualToString:@""]){
            sCell.lbl_schedule.text = @"Not available";
        }
        return sCell;
    }
}

#pragma mark - Table Button Actions

-(void)SelectedStudentSchedule:(UIButton *)btn :(NSMutableDictionary *)dic
{
    btn.selected = !btn.selected;
    
    if (btn.selected)
    {
        [arr_selectedSchedule addObject:[[dic valueForKey:[NSString stringWithFormat:@"Select_%@",[arr_days objectAtIndex:btn.superview.tag/100-1]]] objectAtIndex:btn.tag]];
        
        [arr_selectedIndex addObject:[NSString stringWithFormat:@"%ld|%ld|%ld",(long)btn.tag,btn.superview.tag,btn.superview.superview.superview.tag]];
        
        [btn setBackgroundColor:botomColor];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        
    }
    else
    {
        [arr_selectedSchedule removeObject:[[dic valueForKey:[NSString stringWithFormat:@"Select_%@",[arr_days objectAtIndex:btn.superview.tag/100-1]]] objectAtIndex:btn.tag]];
        
        [arr_selectedIndex removeObject:[NSString stringWithFormat:@"%ld|%ld|%ld",(long)btn.tag,btn.superview.tag,btn.superview.superview.superview.tag]];
        
        [btn setBackgroundColor:[UIColor colorWithRed:(245.0/255.0) green:(245.0/255.0) blue:(244.0/255.0) alpha:1.0]];
        [btn setTitleColor:[UIColor blackColor] forState:0];
    }
    
    [dic_selectedIndex setObject:arr_selectedIndex forKey:studentName];
    
    dict = [[NSMutableDictionary alloc]init];
    for(int i = 0 ; i < arr_days.count ; i++)
    {
        NSMutableArray *temp = [[NSMutableArray alloc]init];
        for (int j = 0; j < arr_selectedSchedule.count; j++)
        {
            if ([((NSString *)[arr_selectedSchedule objectAtIndex:j])containsString:[arr_days objectAtIndex:i]])
            {
                [temp addObject:[arr_selectedSchedule objectAtIndex:j]];
            }
        }
        NSString *schedule_str = [temp componentsJoinedByString:@","];
        [dict setObject:schedule_str forKey:[arr_days objectAtIndex:i]];
    }
    
    [finalScheduleDic setObject:dict forKey:studentName];
    
}

-(void)btn_View_Bio:(UIButton *)sender
{
    [self resetBio];
    [self getBio:[[arr_Info objectAtIndex:sender.tag]valueForKey:@"UserID"]];
    [viewBio setFrame:self.view.bounds];
    [self.view addSubview:viewBio];
}

-(void)btn_View_Shift:(UIButton *)sender
{
    [self getShift:[NSString stringWithFormat:@"%@:%@",[[arr_Info objectAtIndex:sender.tag]valueForKey:@"UserID"],[[arr_Info objectAtIndex:sender.tag]valueForKey:@"Username"]]];
    [viewShift setFrame:self.view.bounds];
    [self.view addSubview:viewShift];
}

-(IBAction)btn_Done_Close:(UIButton *)sender
{
    [viewShift removeFromSuperview];
    [viewBio removeFromSuperview];
}

-(IBAction)btnNextStepClicked:(UIButton *)sender
{
    BOOL flag = NO,test = NO;
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        if ([dic_selectedIndex valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] == nil)
        {
            flag = YES;
        }
        else
        {
            NSArray *arr = [dic_selectedIndex valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]];
            if (arr.count == 0)
            {
                flag = YES;
            }
            else
            {
                test = YES;
            }
        }
    }
    
    if (flag)
    {
        PopupView *pv = [[PopupView alloc] initWithNibName:@"PopupView" bundle:nil];
        pv.p_delegate = self;
        pv.check = *(&(test));
        pv.strBtnText = @"Continue";
        pv.strMsgText = @"Lesson times have not been selected for all students.\nAre you sure you want to continue ?";
        pv.strTitleText = @"Alert";
        [pv.view setFrame:CGRectMake(pv.view.frame.origin.x, pv.view.frame.origin.y, self.view.frame.size.width - 40, pv.view.frame.size.height)];
        [self presentPopupViewController:pv animationType:MJPopupViewAnimationFade];
    }
    else
    {
        [self goToNext];
    }
}

-(void)goToNext
{
    NSMutableDictionary *dicTempSchedule = [[NSMutableDictionary alloc]init];
    NSMutableDictionary *dicMakeupSelection = [[NSMutableDictionary alloc]init];
    
    BOOL checkFlag = NO;
    NSInteger TotalArrayCount = 0;
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : NO;
    
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count ; i++)
    {
        NSArray *arr_temp;
        NSMutableArray *arrfinal = [[NSMutableArray alloc]init];
        NSString *arrfinalstring;
        
        if ([dicMakeupSelection valueForKey:[[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] objectAtIndex:1]] == nil) {
            TotalArrayCount = 0;
        }
        else{
            TotalArrayCount = [[dicMakeupSelection valueForKey:[[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] objectAtIndex:1]] integerValue];
        }
        
        NSLog(@"%@",dicMakeupSelection);
        
        for (int j = 0; j < arr_days.count; j++)
        {
            arr_temp = [finalScheduleDic valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]];
            if (arr_temp.count > 0)
            {
                if (![[arr_temp valueForKey:[arr_days objectAtIndex:j]] isEqualToString:@""])
                {
                    [arrfinal addObject:[[finalScheduleDic valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] valueForKey:[arr_days objectAtIndex:j]]];
                    
                    if (![[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"])
                    {
                        NSLog(@"%@",SHARED_APPDELEGATE.dicStudentDetails);
                        NSInteger TotalMakeup = [[[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] objectAtIndex:4]integerValue];
                        
                        if (IsCombo)
                        {
                            NSInteger TotalStuCombo = ((NSArray *)[[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i] componentsSeparatedByString:@"&"]).count;
                            TotalMakeup = (NSInteger)TotalMakeup/TotalStuCombo;
                        }
                        
                        NSArray *arrTempNew = [[arrfinal lastObject]componentsSeparatedByString:@","];
                        
                        TotalArrayCount += arrTempNew.count;
                        
                        [dicMakeupSelection setValue:[NSString stringWithFormat:@"%ld",(long)TotalArrayCount] forKey:[[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] objectAtIndex:1]];
                        
                        if (TotalArrayCount > TotalMakeup)
                        {
                            [CommonClass showToastMsg:NoMakeUpSelection];
                            checkFlag = YES;
                            break;
                        }
                    }
                }
            }
        }
        if (arrfinal.count > 0 && arr_temp.count > 0) {
            arrfinalstring = [NSString stringWithFormat:@"%@*%@",[_strStudent objectAtIndex:i],[arrfinal componentsJoinedByString:@","]];
            [dicTempSchedule setObject:arrfinalstring forKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]];
        }
    }
    
    if (!checkFlag)
    {
        GetScheduleViewController *gsvc = [[GetScheduleViewController alloc] initWithNibName:@"GetScheduleViewController" bundle:nil];
        gsvc.strStudent = _studentString;
        gsvc.dicStudentSchedule = dicTempSchedule;
        [[self navigationController] pushViewController:gsvc animated:YES];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterTimeDate"];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterInstructor"];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"AdvancedFilter"];
    }
}
-(void)Continue_GoBack:(PopupView *)popup :(UIButton *)sender :(NSInteger)tag
{
    if (tag != 1) {
        [self goToNext];
    }
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)resetBio
{
    [lbl_instructor setText:@""];
    img_instructor.image = nil;
    [webView loadHTMLString:@"" baseURL:nil];
}

#pragma mark - Filter Actions

-(IBAction)btnFilterClicked:(UIButton *)sender
{
    FilterViewController *fvc = [[FilterViewController alloc]initWithNibName:@"FilterViewController" bundle:nil];
    fvc.dictionary = dicStudentSchedule;
    fvc.f_delegate = self;
    [[self navigationController]pushViewController:fvc animated:NO];
}
-(IBAction)btnClicked:(UIButton *)sender
{
    if (sender.tag == 0) {
        [[self navigationController]popViewControllerAnimated:YES];
    }else{
        //        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
        [SHARED_APPDELEGATE setScheduleViewController];
    }
}

-(void)FilterValue:(NSMutableDictionary *)filterdata :(NSMutableDictionary *)filterInstructor :(NSString *)str
{
    /*
     *------------- Filter Time & Day  - Instrutor -------------
     */
    
    strNo = str;
    dicFilter = filterdata;
    dicFilterInstructor = filterInstructor;
    arr_instrutor = [dicFilterInstructor valueForKey:studentName];
    for (int i = 0; i < arr_instrutor.count; i++)
    {
        NSInteger idx = [SHARED_APPDELEGATE.arrStudentName indexOfObject:[NSString stringWithFormat:@"%@",studentName]];
        NSArray *filtered = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%ld",idx+1]] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(instructors == %@)", [arr_instrutor objectAtIndex:i]]];
        
        [finalStudentSchedule setObject:filtered forKey:[arr_instrutor objectAtIndex:i]];
    }
    
    /*
     *------------- Advanced Filter ------------------
     */
    
    NSInteger sno = [SHARED_APPDELEGATE.arrStudentName indexOfObject:[NSString stringWithFormat:@"%@",studentName]];
    [self advancedFilter:sno];
}

#pragma mark - Advanced Filter

-(void)advancedFilter:(NSInteger)index
{
    finalStudentSchedule = [[NSMutableDictionary alloc]init];
    arr_instrutor = [[NSMutableArray alloc]init];
    
    NSMutableArray *array = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%ld",index+1]]valueForKey:@"instructors"];
    if (array > 0)
    {
        if ([dicFilterInstructor valueForKey:studentName] == nil)
        {
            NSString *str = [array objectAtIndex:0];
            [arr_instrutor addObject:str];
            for (int i = 0; i < array.count; i++)
            {
                if (![[array objectAtIndex:i] isEqualToString:str])
                {
                    str = [array objectAtIndex:i];
                    [arr_instrutor addObject:str];
                }
                
                NSArray *filtered = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%d",index+1]] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(instructors == %@)", [array objectAtIndex:i]]];
                
                [finalStudentSchedule setObject:filtered forKey:[array objectAtIndex:i]];
            }
        }
        else
        {
            arr_instrutor = [dicFilterInstructor valueForKey:studentName];
            for (int i = 0; i < arr_instrutor.count; i++)
            {
                NSArray *filtered = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%ld",index+1]] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(instructors == %@)", [arr_instrutor objectAtIndex:i]]];
                
                [finalStudentSchedule setObject:filtered forKey:[arr_instrutor objectAtIndex:i]];
            }
        }
    }
    
    /*
     *-------------Advanced Filter---------------------
     */
    
    if (![strNo isEqualToString:@"60"])
    {
        NSMutableDictionary *dicFinalFilterResults = [[NSMutableDictionary alloc]init];
        
        for (NSString *instructor in arr_instrutor)
        {
            NSMutableArray *arr1 = [[NSMutableArray alloc]init];
            for (NSString *day in arr_tcm)
            {
                NSArray *arr = [finalStudentSchedule valueForKey:instructor];
                for(NSDictionary *dicData in arr)
                {
                    //int j = 0;
                    NSString *T = [NSString stringWithFormat:@"tc%@_time",day];
                    NSString *D = [NSString stringWithFormat:@"tc%@_dt",day];
                    
                    NSString *string = [dicData valueForKey:T];
                    NSString *currentDay = [dicData valueForKey:D];
                    
                    int Min = -([strNo intValue] * 60); // 20|40 * 60
                    for (int i = 0; i < 2; i++)
                    {
                        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                        [formatter setDateFormat:@"hh:mm:ss a"];
                        [formatter setAMSymbol:@"AM"];
                        [formatter setPMSymbol:@"PM"];
                        
                        NSDate *date = [[formatter dateFromString:string] dateByAddingTimeInterval:Min];
                        Min = ([strNo intValue] * 60); // 20|40 * 60
                        
                        int j = 0;
                        while (j < SHARED_APPDELEGATE.arrStudentName.count)
                        {
                            if (j != index)
                            {
                                NSPredicate *predicate;
                                if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor)
                                {
                                    predicate  = [NSPredicate predicateWithFormat:@"(%K == %@) AND (%K == %@) AND (instructors == %@)",T,[formatter stringFromDate:date],D,currentDay,instructor];
                                    // Same Instructor
                                }
                                else
                                {
                                    //AND (instructors != %@)
                                    predicate  = [NSPredicate predicateWithFormat:@"(%K == %@) AND (%K == %@)",T,[formatter stringFromDate:date],D,currentDay];
                                    // Different Instructor
                                }
                                
                                NSArray *arr_compare = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%d",j+1]] filteredArrayUsingPredicate:predicate];
                                
                                if (arr_compare.count > 0)
                                {
                                    NSArray *filtered = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(%K == %@)",T,string]]; // from filter
                                    
                                    NSMutableDictionary *dicFilterResults = [[NSMutableDictionary alloc]init];
                                    
                                    for (int  i = 0; i < filtered.count; i++)
                                    {
                                        [dicFilterResults setObject:[[filtered objectAtIndex:i] valueForKey:T] forKey:T];
                                        [dicFilterResults setObject:[[filtered objectAtIndex:i] valueForKey:[T stringByReplacingOccurrencesOfString:@"time" withString:@"select"]] forKey:[T stringByReplacingOccurrencesOfString:@"time" withString:@"select"]];
                                        [dicFilterResults setObject:[[filtered objectAtIndex:i] valueForKey:[T stringByReplacingOccurrencesOfString:@"time" withString:@"dt"]] forKey:[T stringByReplacingOccurrencesOfString:@"time" withString:@"dt"]];
                                        [dicFilterResults setObject:[[filtered objectAtIndex:i] valueForKey:@"instructors"] forKey:@"instructors"];
                                        if (![arr1 containsObject:dicFilterResults]) {
                                            [arr1 addObject:dicFilterResults];
                                        }
                                    }
                                    [dicFinalFilterResults setObject:arr1 forKey:instructor];
                                    j = 1000; // dummy no
                                }
                                else
                                {
                                    j++;
                                }
                            }
                            else
                            {
                                j++;
                            }
                        }
                    }
                }
            }
        }
        finalStudentSchedule  = dicFinalFilterResults;
    }
    
    arr_Info = [[NSMutableArray alloc]init];
    NSArray *arr = [SHARED_APPDELEGATE.selectedInstructors valueForKey:studentName];
    for (int i = 0; i < arr.count; i++)
    {
        if ([arr_instrutor containsObject:[NSString stringWithFormat:@"%@",[[arr objectAtIndex:i] valueForKey:@"Username"]]])
        {
            [arr_Info addObject:[arr objectAtIndex:i]];
        }
    }
    
    [tblList reloadData];
    tblHeight.constant = tblList.contentSize.height;
    
    [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblHeight.constant + 30)];
    [scroll_main setContentOffset:CGPointZero animated:YES];
    [scroll_main scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
    
}

-(NSArray *)getInstructor:(int)index
{
    arr_instrutor = [[NSMutableArray alloc]init];
    NSMutableArray *array = [[dicStudentSchedule valueForKey:[NSString stringWithFormat:@"ClassAvailList%d",index]]valueForKey:@"instructors"];
    if (array > 0)
    {
        if ([dicFilterInstructor valueForKey:studentName] == nil)
        {
            NSString*str = [array objectAtIndex:0];
            [arr_instrutor addObject:str];
            for (int i = 0; i < array.count; i++)
            {
                if (![[array objectAtIndex:i] isEqualToString:str])
                {
                    str = [array objectAtIndex:i];
                    [arr_instrutor addObject:str];
                }
            }
        }
        else
        {
            arr_instrutor = [dicFilterInstructor valueForKey:studentName];
        }
    }
    return arr_instrutor;
}
-(BOOL)checkTimeInbetweenOrNot:(NSString *)startTime EndTime:(NSString *)endTime CurrentTime:(NSString *)currentTime
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"hh:mm:ss a"];
    [formatter setAMSymbol:@"AM"];
    [formatter setPMSymbol:@"PM"];
    
    int start   = [self minutesSinceMidnight:[formatter dateFromString:startTime]];
    int end     = [self minutesSinceMidnight:[formatter dateFromString:endTime]];
    int current = [self minutesSinceMidnight:[formatter dateFromString:currentTime]];;
    
    if (start <= current && current <= end)
        return YES;
    return NO;
}

-(int) minutesSinceMidnight:(NSDate *)date
{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:date];
    return 60 * (int)[components hour] + (int)[components minute];
}


-(void)popViewController
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterTimeDate"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterInstructor"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"AdvancedFilter"];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
