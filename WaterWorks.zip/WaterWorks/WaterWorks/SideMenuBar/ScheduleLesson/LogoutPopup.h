//
//  LogoutPopup.h
//  WaterWorks
//
//  Created by Ankit on 01/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LogoutPopup;

@protocol LogoutPopupDelegate <NSObject>
-(void)Logout:(NSInteger)selectedIndex :(LogoutPopup *)lcvc;
@end

@interface LogoutPopup : UIViewController
@property (assign, nonatomic) id <LogoutPopupDelegate> ldelegate;
@end
