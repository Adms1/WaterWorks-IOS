//
//  GetScheduleViewController.m
//  WaterWorks
//
//  Created by Ankit on 09/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "GetScheduleViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "StudentListCell.h"
#import "SchedulePopup.h"
#import "ScheduleClassViewController.h"
#import "ConfirmScheduleViewController.h"
#import "CustomTabbar.h"
#import "BuyLessonsViewController.h"
#import "SLViewController.h"

@interface GetScheduleViewController ()<SchedulePopupDelegate,CommonDelegate>
{
    NSMutableArray *arr_Schedule;
    NSMutableArray *arr_checkboxDlt;
    NSMutableDictionary *dic_checkboxDlt;
    NSMutableDictionary *dic_Schedule;
    NSString *studentName;
    NSTimer *timer;
    NSInteger previousTag;
    UIView *vStripe;
    NSString *strSub1, *strSub2;
    NSArray *arrStudentIds_Combo1, *arrStudentIds_Combo2;
}
@end

@implementation GetScheduleViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
    //    UIBackgroundTaskIdentifier bgTask =0;
    //    UIApplication  *app = [UIApplication sharedApplication];
    //    bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
    //        [app endBackgroundTask:bgTask];
    //    }];
    //    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateLabel) userInfo:nil repeats:YES];
    //    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    
    SHARED_APPDELEGATE.min = 1,SHARED_APPDELEGATE.sec = 60;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :([[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? 0 : 1 ) :[[[NSUserDefaults standardUserDefaults] valueForKey:MAKEUPCOUNT] integerValue]];
    [self.view insertSubview:ct atIndex:0];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
        [self getStudentScheduleConfirmed];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
    
    /*
     */
    
    NSDateFormatter *dateFormatter=[NSDateFormatter new];
    [dateFormatter setDateFormat:@"hh:mm:ss a"];
    [[NSUserDefaults standardUserDefaults]setValue:[dateFormatter stringFromDate:[NSDate date]] forKey:@"StartTime"];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateLabel) userInfo:nil repeats:YES];
}

#pragma mark - Api Calling

-(void)getStudentScheduleConfirmed
{
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : NO;
    
    NSString *strSch1 = [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]] == nil ? @"" : [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]];
    
    NSString *strSch2 = SHARED_APPDELEGATE.arrStudentName.count > 1 ? [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] == nil ? @"" : [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] : @"";
    
    NSString *strSch3 = SHARED_APPDELEGATE.arrStudentName.count > 2 ? [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:2]] == nil ? @"" : [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:2]] : @"";
    
    NSString *strSch4 = SHARED_APPDELEGATE.arrStudentName.count > 3 ?[_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:3]] == nil ? @"" : [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:3]] : @"";
    
    NSString *strSch5 = SHARED_APPDELEGATE.arrStudentName.count > 4 ?[_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:4]] == nil ? @"" : [_dicStudentSchedule valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:4]] : @"";
    
    NSLog(@"%@",SHARED_APPDELEGATE.dicStudentDetails);
    
    arrStudentIds_Combo1 = [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]] objectAtIndex:0];
    arrStudentIds_Combo2 = SHARED_APPDELEGATE.arrStudentName.count > 1 ? [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] objectAtIndex:0] : nil;
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             @"SelectStudList":_strStudent,
                             
                             // 1-5-4,2-3-4
                             @"Cls_schedule1":strSch1,
                             @"Cls_schedule2":IsCombo ? arrStudentIds_Combo1.count > 2 && arrStudentIds_Combo2.count > 0 ?[strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : arrStudentIds_Combo2.count > 1 ? [strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:1]] : @"" : strSch2,
                             
                             @"Cls_schedule3":IsCombo ? arrStudentIds_Combo1.count > 2 && arrStudentIds_Combo2.count > 0  ?[strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:1]] :arrStudentIds_Combo2.count > 2 ? [strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:2]] : arrStudentIds_Combo2.count > 0 && (arrStudentIds_Combo1.count == arrStudentIds_Combo2.count) ? [strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : @"" : strSch3,
                             
                             @"Cls_schedule4":IsCombo ?arrStudentIds_Combo1.count > 2 ? [strSch1 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo1 objectAtIndex:0] withString:[arrStudentIds_Combo1 objectAtIndex:2]] : arrStudentIds_Combo2.count > 0 && (arrStudentIds_Combo1.count != arrStudentIds_Combo2.count) ? [strSch2 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : @"" : strSch4,
                             
                             @"Cls_schedule5":IsCombo && arrStudentIds_Combo1.count > 0 ? [strSch1 stringByReplacingOccurrencesOfString:[arrStudentIds_Combo1 objectAtIndex:0] withString:[arrStudentIds_Combo1 objectAtIndex:1]] : strSch5 ,
                             
                             @"siteid":[[NSUserDefaults standardUserDefaults] valueForKey:SITEID],
                             @"Makeupflg":[[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? @"0" : @"1",
                             @"schedulechoices":@"7",
                             @"scheduletype":@"0",
                             
                             @"pair1_Cmbo1":IsCombo ? [arrStudentIds_Combo1 objectAtIndex:0] : @"0",
                             @"pair1_Cmbo2":IsCombo ? [arrStudentIds_Combo1 objectAtIndex:1] : @"0",
                             @"pair1_Cmbo3":IsCombo  && arrStudentIds_Combo1.count > 2 ? [arrStudentIds_Combo1 objectAtIndex:2] : @"0",
                             @"pair1_Cmbo4":@"0",
                             
                             @"pair2_Cmbo1":IsCombo && arrStudentIds_Combo2.count > 0 ? [arrStudentIds_Combo2 objectAtIndex:0] : @"0",
                             @"pair2_Cmbo2":IsCombo && arrStudentIds_Combo2.count > 1 ? [arrStudentIds_Combo2 objectAtIndex:1] : @"0",
                             @"pair2_Cmbo3":IsCombo  && arrStudentIds_Combo2.count > 2 ? [arrStudentIds_Combo2 objectAtIndex:2] : @"0",
                             @"pair2_Cmbo4":@"0",
                             };
    
    NSLog(@"%@",params);
    
    dic_Schedule = [[NSMutableDictionary alloc]init];
    dic_checkboxDlt = [[NSMutableDictionary alloc]init];
    arr_Schedule = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_Confirm_classesList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            lbl_Instruction.text = ConfirmInstruction1;
            if ([[responseObject safeObjectForKey:@"LaFitness"]isEqualToString:@"1"])
            {
                if ([[[NSUserDefaults standardUserDefaults]valueForKey:PastDue]isEqualToString:@"PastDue"])
                {
                    lbl_Instruction.text = [NSString stringWithFormat:@"%@%@",ConfirmInstruction1,ConfirmInstruction2];
                }
            }
            
            for (int i = 1; i < 6; i++)
            {
                NSArray *arr =[responseObject objectForKey:[NSString stringWithFormat:@"ConformList%d",i]];
                if (arr.count > 0)
                {
                    [dic_Schedule setObject:arr forKey:[NSString stringWithFormat:@"ConformList%d",i]];
                }
            }
            
            [tblSchedule reloadData];
            tblHeight.constant = tblSchedule.contentSize.height;
            [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblSchedule.contentSize.height + scroll_header.superview.frame.origin.y + scroll_header.frame.size.height + 20)];
            
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error.description);
    }];
}

-(void)ConfirmSchedule:(NSMutableArray *)newarray
{
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : NO;
    
    NSArray *arrStudentNames_Combo1 = [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0]] objectAtIndex:3];
    NSArray *arrStudentNames_Combo2 = SHARED_APPDELEGATE.arrStudentName.count > 1 ? [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:1]] objectAtIndex:3] : nil;
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             
                             @"calstartdate":SHARED_APPDELEGATE.startDate,
                             
                             @"strconfirmschedule1":[newarray objectAtIndex:0],
                             @"strconfirmschedule2":IsCombo ? arrStudentIds_Combo1.count > 2 &&
                             arrStudentIds_Combo2.count > 0 && newarray.count > 1 ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : arrStudentIds_Combo2.count > 1 && newarray.count > 1 ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:1]] : @"" : newarray.count > 1 ? [newarray objectAtIndex:1] : @"",
                             
                             @"strconfirmschedule3":IsCombo ? arrStudentIds_Combo1.count > 2 &&
                             arrStudentIds_Combo2.count > 0 && newarray.count > 1 ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:1]] : arrStudentIds_Combo2.count > 2 && newarray.count > 1 ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:2]] : arrStudentIds_Combo2.count > 0 && (arrStudentIds_Combo1.count == arrStudentIds_Combo2.count) &&newarray.count > 1 ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : @""  : newarray.count > 2 ? [newarray objectAtIndex:2] : @"",
                             
                             @"strconfirmschedule4":IsCombo ? arrStudentIds_Combo1.count > 2 ? [[newarray objectAtIndex:0]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo1 objectAtIndex:0] withString:[arrStudentIds_Combo1 objectAtIndex:2]] : arrStudentIds_Combo2.count > 0  && newarray.count > 1  && (arrStudentIds_Combo1.count != arrStudentIds_Combo2.count) ? [[newarray objectAtIndex:1]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo2 objectAtIndex:0] withString:[arrStudentIds_Combo2 objectAtIndex:0]] : @"" : newarray.count > 3 ? [newarray objectAtIndex:3] : @"",
                             
                             @"strconfirmschedule5":IsCombo && arrStudentIds_Combo1.count > 1 ? [[newarray objectAtIndex:0]stringByReplacingOccurrencesOfString:[arrStudentIds_Combo1 objectAtIndex:0] withString:[arrStudentIds_Combo1 objectAtIndex:1]] : newarray.count > 4 ? [newarray objectAtIndex:4] : @"",
                             
                             @"SelectStudList":_strStudent,
                             
                             @"siteid":[[NSUserDefaults standardUserDefaults] valueForKey:SITEID],
                             @"siteText":[[NSUserDefaults standardUserDefaults] valueForKey:SITENAME],
                             @"Makeupflg":[[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? @"0" : @"1",
                             @"reserveforever":@"0",
                             @"schedulechoices":@"7",
                             @"scheduletype":@"0",
                             
                             @"pair1_Cmbo1":IsCombo ? [arrStudentIds_Combo1 objectAtIndex:0] : @"0",
                             @"pair1_Cmbo2":IsCombo ? [arrStudentIds_Combo1 objectAtIndex:1] : @"0",
                             @"pair1_Cmbo3":IsCombo && arrStudentIds_Combo1.count > 2 ? [arrStudentIds_Combo1 objectAtIndex:2] : @"0",
                             @"pair1_Cmbo4":@"0",
                             
                             @"pair2_Cmbo1":IsCombo && arrStudentIds_Combo2.count > 0 ? [arrStudentIds_Combo2 objectAtIndex:0] : @"0",
                             @"pair2_Cmbo2":IsCombo && arrStudentIds_Combo2.count > 1 ? [arrStudentIds_Combo2 objectAtIndex:1] : @"0",
                             @"pair2_Cmbo3":IsCombo && arrStudentIds_Combo2.count > 2 ? [arrStudentIds_Combo2 objectAtIndex:2] : @"0",
                             @"pair2_Cmbo4":@"0",
                             
                             @"pair1_Cmbo1Text":IsCombo ? [arrStudentNames_Combo1 objectAtIndex:0] : @"",
                             @"pair1_Cmbo2Text":IsCombo ? [arrStudentNames_Combo1 objectAtIndex:1] : @"",
                             @"pair1_Cmbo3Text":IsCombo && arrStudentNames_Combo1.count > 2 ? [arrStudentNames_Combo1 objectAtIndex:2] : @"",
                             @"pair1_Cmbo4Text":@"",
                             
                             @"pair2_Cmbo1Text":IsCombo && arrStudentNames_Combo2.count > 0 ? [arrStudentNames_Combo2 objectAtIndex:0] : @"",
                             @"pair2_Cmbo2Text":IsCombo && arrStudentNames_Combo2.count > 1 ? [arrStudentNames_Combo2 objectAtIndex:1] : @"",
                             @"pair2_Cmbo3Text":IsCombo && arrStudentNames_Combo2.count > 2 ? [arrStudentNames_Combo2 objectAtIndex:2] : @"",
                             @"pair2_Cmbo4Text":@"",
                             
                             };
    
    NSLog(@"%@",params);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Add_Confirm_SchedulesLesson_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([[responseObject safeObjectForKey:@"LaFitness"]isEqualToString:@"1"])
            {
                if ([[[NSUserDefaults standardUserDefaults]valueForKey:PastDue]isEqualToString:@"PastDue"])
                {
                    BuyLessonsViewController *viewBuyLessons = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
                    viewBuyLessons.strType = @"Buy";
                    viewBuyLessons.FromComfirmSchedule = YES;
                    SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
                    [self.navigationController pushViewController:viewBuyLessons animated:YES];
                }
                else
                {
                    ConfirmScheduleViewController *csvc = [[ConfirmScheduleViewController alloc]initWithNibName:@"ConfirmScheduleViewController" bundle:nil];
                    csvc.dictonary = dic_Schedule;
                    [[self navigationController]pushViewController:csvc animated:NO];
                }
            }
            else
            {
                ConfirmScheduleViewController *csvc = [[ConfirmScheduleViewController alloc]initWithNibName:@"ConfirmScheduleViewController" bundle:nil];
                csvc.dictonary = dic_Schedule;
                [[self navigationController]pushViewController:csvc animated:NO];
            }
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error.description);
        
    }];
}

#pragma mark - Actions

-(void)updateLabel
{
    SHARED_APPDELEGATE.sec--;
    if (SHARED_APPDELEGATE.min <= 0)
    {
        if (SHARED_APPDELEGATE.sec <= 0 || SHARED_APPDELEGATE.min < 0)
        {
            SHARED_APPDELEGATE.sec = 1,SHARED_APPDELEGATE.min = 0;
            [timer invalidate];
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"StartTime"];
            
            SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
            sp.s_delegate = self;
            sp.msg = ProvideTimeUpMsg;
            [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
            [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
        }
    }
    if (SHARED_APPDELEGATE.sec == -1) {
        SHARED_APPDELEGATE.min--;
        SHARED_APPDELEGATE.sec = 59;
    }
    lbl_timer.text = [NSString stringWithFormat:@"0%d:%@%d",SHARED_APPDELEGATE.min,SHARED_APPDELEGATE.sec < 10 ? @"0":@"",SHARED_APPDELEGATE.sec];
}

-(void)Continue:(SchedulePopup *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)DynamicAddStudents
{
    //---------Student Buttons-----------//
    
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:tblSchedule :self];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        tblSchedule.transform = CGAffineTransformMakeTranslation(tblSchedule.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblSchedule.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        tblSchedule.transform = CGAffineTransformMakeTranslation(-tblSchedule.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblSchedule.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    
    [tblSchedule reloadData];
    tblHeight.constant = tblSchedule.contentSize.height;
    [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblSchedule.contentSize.height + scroll_header.superview.frame.origin.y + scroll_header.frame.size.height + 20)];
}

#pragma mark - Tableview DataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if([dic_Schedule valueForKey:[NSString stringWithFormat:@"ConformList%ld",previousTag+1]] != nil)
    {
        return ((NSArray *)[dic_Schedule valueForKey:[NSString stringWithFormat:@"ConformList%ld",previousTag+1]]).count;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  footerView.frame.size.height;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 97;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
    if (sCell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
        sCell  = [nib objectAtIndex:3];
    }
    sCell.selectionStyle = UITableViewCellSelectionStyleNone;
    sCell.tag = indexPath.row;
    
    NSArray *arr = [dic_Schedule valueForKey:[NSString stringWithFormat:@"ConformList%ld",previousTag+1]];
    if ([[arr objectAtIndex:0]valueForKey:@"InstructorPhoto"] == nil || [[[arr objectAtIndex:0]valueForKey:@"InstructorPhoto"] isEqualToString:@""])
    {
        sCell.img_instructor_photo.image = [UIImage imageNamed:@"AppLogo"];
    }
    else
    {
        NSString *strUrl = [[NSString stringWithFormat:@"%@%@",Image_Url,[[[arr objectAtIndex:0]valueForKey:@"InstructorPhoto"] substringFromIndex:1]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [sCell.img_instructor_photo sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            if (error != nil) {
                sCell.img_instructor_photo.image = [UIImage imageNamed:@"AppLogo"];
            }
        }];
    }
    
    sCell.lbl_schedule_time.text = [[arr objectAtIndex:indexPath.row]valueForKey:@"ScheduleTime"];
    sCell.lbl_LessonType.text = [NSString stringWithFormat:@"%@ (%@)",[[arr objectAtIndex:indexPath.row]valueForKey:@"LessonType"],[[arr objectAtIndex:indexPath.row]valueForKey:@"InstructorName"]];
    sCell.lbl_SiteName.text = [[arr objectAtIndex:indexPath.row]valueForKey:@"SiteName"];
    
    return sCell;
}
- (IBAction)onClickScheduleBtn:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        //        for (UIViewController*vc in [self.navigationController viewControllers])
        //        {
        //            if ([vc isKindOfClass: [SLViewController class]])
        //            {
        //                [self.navigationController popToViewController:vc animated:YES];
        //                return;
        //            }
        //        }
        [SHARED_APPDELEGATE setScheduleViewController];
    }
    else
    {
        [timer invalidate];
        SHARED_APPDELEGATE.sec = 60,SHARED_APPDELEGATE.min = 1;
        
        NSArray *arr = [_strStudent componentsSeparatedByString:@","];
        
        NSMutableArray *arrSchedule = [[NSMutableArray alloc]init];
        for (int i = 0; i < arr.count; i++)
        {            
            NSArray *array = [[dic_Schedule valueForKey:[NSString stringWithFormat:@"ConformList%d",i+1]] valueForKey:@"CheckBoxDtl"];
            NSString *strLessonType = [[SHARED_APPDELEGATE.dicStudentDetails valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] objectAtIndex:2];
            
            NSLog(@"%@",SHARED_APPDELEGATE.dicStudentDetails);
            
            if (array.count > 0)
            {
                if (![[[[arr objectAtIndex:i]componentsSeparatedByString:@"|"]firstObject] isEqualToString:[[[array objectAtIndex:0] componentsSeparatedByString:@"|"] firstObject]])
                {
                    NSString *strNew = [[[arr objectAtIndex:i]componentsSeparatedByString:@"|"]firstObject];
                    NSString *strExist = [[[array objectAtIndex:0]componentsSeparatedByString:@"|"]firstObject];
                    
                    NSMutableArray *arrNew = [[NSMutableArray alloc]init];
                    for (NSString *str in array)
                    {
                        NSString *newStr = [str stringByReplacingOccurrencesOfString:strExist withString:strNew];
                        [arrNew addObject:newStr];
                    }
                    array = arrNew;
                }
                [arrSchedule addObject:[NSString stringWithFormat:@"%@|%@_%@",[[arr objectAtIndex:i]stringByReplacingOccurrencesOfString:@"|" withString:@"*"],strLessonType,[array componentsJoinedByString:@","]]];
            }
        }
        [self ConfirmSchedule:arrSchedule];
    }
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
