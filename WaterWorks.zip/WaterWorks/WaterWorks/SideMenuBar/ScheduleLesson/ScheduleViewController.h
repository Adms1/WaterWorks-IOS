//
//  ScheduleViewController.h
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScheduleViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_header, *scroll_main;
    IBOutlet UIView *WeekMainView;
    IBOutlet UIButton *btnSelectReset, *btnHome;
}
@property(nonatomic,assign)NSMutableDictionary *dic_SelectedSameInstructor;
@end
