//
//  ConfirmScheduleViewController.m
//  WaterWorks
//
//  Created by Ankit on 10/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ConfirmScheduleViewController.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "AppDelegate.h"
#import "MyScheduleViewController.h"
#import "BuyLessonsViewController.h"
#import <EventKit/EventKit.h>
#import "CustomTabbar.h"

@interface ConfirmScheduleViewController ()<CommonDelegate>

@end

@implementation ConfirmScheduleViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
}

-(void)viewDidLayoutSubviews
{
    [self.view layoutIfNeeded];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :0 :[[[NSUserDefaults standardUserDefaults] valueForKey:MAKEUPCOUNT] integerValue]];
    [self.view insertSubview:ct atIndex:0];
}

#pragma mark - Button Action

- (IBAction)onButtonClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 0:
            [self Event];
            break;
            
        case 1:
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [BuyLessonsViewController class]])
                {
                    BuyLessonsViewController *buyvc;
                    buyvc.strType = @"Buy";
                    buyvc.FromComfirmSchedule = NO;
                    SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            [SHARED_APPDELEGATE setBuyLessonViewController];
            break;
            
        case 2:
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [MyScheduleViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            [SHARED_APPDELEGATE setMyScheduleViewController];
            break;
            
        case 3:
            [SHARED_APPDELEGATE setHomeViewController];
            break;
            
        default:
            break;
    }
}

#pragma mark - Import Event to Calender

-(void)Event
{
    //    eventStore = [[EKEventStore alloc] init];
    //
    //    EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
    //    event.title     = @"EVENT TITLE";
    //
    //    event.startDate = [[NSDate alloc] init];
    //    event.endDate   = [[NSDate alloc] initWithTimeInterval:600 sinceDate:event.startDate];
    //
    //    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
    //    NSError *err;
    //    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];
    
    EKEventStore *store = [EKEventStore new];
    [store requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        if (!granted) { return; }
        
        BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : NO;
        
        for (int i = 1; i < 6; i++)
        {
            NSArray *arr = [_dictonary objectForKey:[NSString stringWithFormat:@"ConformList%d",i]];
            if (arr.count > 0)
            {
                for (int j = 0; j < arr.count; j++)
                {
                    EKEvent *event = [EKEvent eventWithEventStore:store];
                    NSString *strStudentName = [[arr objectAtIndex:j] valueForKey:@"StudentName"];
                    if ((i == 1 || i == 5 || i == 4) && IsCombo)
                    {
                        if (i == 1)
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]firstObject];
                        }
                        else if (i == 5)
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]objectAtIndex:1];
                        }
                        else
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]objectAtIndex:2];
                        }
                    }
                    else if((i == 2 || i == 3 || i == 4) && IsCombo)
                    {
                        if (i == 2)
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]firstObject];
                        }
                        else if (i == 3)
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]objectAtIndex:1];
                        }
                        else
                        {
                            strStudentName = [[strStudentName componentsSeparatedByString:@"&"]objectAtIndex:2];
                        }
                    }
                    event.title = [NSString stringWithFormat:@"%@ %@ - Waterworks",strStudentName,[[arr objectAtIndex:j] valueForKey:@"ScheduleTime"]];
                    
                    NSString *dateString = [[arr objectAtIndex:j] valueForKey:@"ScheduleTime"];
                    __block NSDate *startdate;
                    
                    //Detect.
                    NSDataDetector *detector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingAllTypes error:nil];
                    [detector enumerateMatchesInString:dateString
                                               options:kNilOptions
                                                 range:NSMakeRange(0, [dateString length])
                                            usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop)
                     { startdate = result.date; }];
                    
                    event.startDate = startdate;
                    NSDate *enddate = [NSDate dateWithTimeInterval:1200 sinceDate:event.startDate];
                    event.endDate = enddate;
                    event.location = [NSString stringWithFormat:@"Swim Lesson in %s","Irvine"];
                    event.calendar = [store defaultCalendarForNewEvents];
                    NSError *err = nil;
                    [store saveEvent:event span:EKSpanThisEvent commit:YES error:&err];
                }
            }
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"calshow://"]];
        });
        //        dispatch_sync(dispatch_get_main_queue(), ^{
        //            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"calshow://"]];
        //        });
    }];
}

-(void)popViewController
{
    [SHARED_APPDELEGATE setHomeViewController];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
