//
//  ScheduleClassViewController.h
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MDButton.h"

@interface ScheduleClassViewController : UIViewController
{
    IBOutlet UITableView *tblList;
    IBOutlet UITableView *tblShift;
    
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UIButton *btnHome;
    IBOutlet MDButton *btnNext;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIView *EmptyView;
    
    IBOutlet NSLayoutConstraint *tblHeight;
    IBOutlet NSLayoutConstraint *scrlTop;
    
    IBOutlet UIView *viewShift;
    IBOutlet UIView *viewBio;
    
    IBOutlet UIImageView *img_instructor;
    IBOutlet UITextView *txt_instructor;
    IBOutlet UIWebView *webView;
    IBOutlet UILabel *lbl_instructor;
}
@property(nonatomic,strong)NSMutableArray *arrid;
@property(nonatomic,strong)NSString *finalString;
@property(nonatomic,strong)NSString *studentString;
@property(nonatomic,strong)NSArray *strStudent;
@property(nonatomic,strong)NSMutableDictionary *dicselectedDays;
@end
