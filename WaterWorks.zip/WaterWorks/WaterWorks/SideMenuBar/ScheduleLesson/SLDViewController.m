//
//  SLDViewController.m
//  WaterWorks
//
//  Created by Ankit on 28/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SLDViewController.h"
#import "AFNetworking.h"
#import "StudentListCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "ScheduleViewController.h"
#import "SchedulePopup.h"

@interface SLDViewController ()<SchedulePopupDelegate,CommonDelegate>
{
    NSMutableArray *arrStudentSelectionLevel, *arrStudentSelectionLevel_Female,*arrStudentSelectionLevel_Male;
    
    NSString *choose_gender;
    NSArray *temp, *arrStudentNameore;
    NSString *studentName;
    UIView *vStripe;
    NSInteger previousTag;
    UIButton *btnTemp;
    
    __block NSMutableArray *arr_StudentIds;
    NSMutableArray *arr_SelectedInstructors;
    NSMutableArray *arrTemp,*arr_days,*arrShift;
    NSMutableArray *arr_SubTemp;
    NSArray *arr_tcm;
    
    NSMutableDictionary *dic_InstructorSelection;
    NSMutableDictionary *dic_SelectedStudent;
    NSMutableDictionary *dic_SelectedSameInstructor;
    __block NSMutableDictionary *dicFinalResult;
    
    NSArray *arrStudentIds;
}
@end

@implementation SLDViewController
int select_counter = 0;

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterTimeDate"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"FilterInstructor"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"AdvancedFilter"];
    
    
    dic_InstructorSelection = [[NSMutableDictionary alloc]init];
    dic_SelectedStudent = [[NSMutableDictionary alloc]init];
    dic_SelectedSameInstructor = [[NSMutableDictionary alloc]init];
    
    SHARED_APPDELEGATE.dicTemp = [[NSMutableDictionary alloc]init];
    SHARED_APPDELEGATE.selectedInstructors = [[NSMutableDictionary alloc]init];
    
    tblFMlist.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width, 100)];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    arr_days = [[dateFormatter shortWeekdaySymbols]mutableCopy];
    id object = [arr_days objectAtIndex:0];
    [arr_days removeObjectAtIndex:0];
    [arr_days addObject:object];
    
    arr_tcm = ShortFormTime;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ScheduleTab :self :([[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"] ? 0 : 1 ):[[[NSUserDefaults standardUserDefaults] valueForKey:MAKEUPCOUNT] integerValue]];
    [self.view insertSubview:ct atIndex:0];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
        [self getStudentSelectionLevel:0];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksScheduleLesson :self :btnHome :nil :YES :self];
    
    SHARED_APPDELEGATE.arrStudentName = [[NSMutableArray alloc]init];
    SHARED_APPDELEGATE.arrStudentComboName = [[NSMutableArray alloc]init];
    
    __block NSMutableArray *arrFinalStudentDetails = [[NSMutableArray alloc]init];
    __block NSMutableArray *arrFinalStudentComboDetails = [[NSMutableArray alloc]init];
    
    dicFinalResult = [[NSMutableDictionary alloc]init];
    __block NSMutableDictionary  *dicComboFinalResult = [[NSMutableDictionary alloc]init];
    
    [_dicFilterResult enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        
        __block NSString *stuName,*strStuId,*strStuName,*strLTT,*strLTV,*strMakeupCount;
        __block NSMutableArray *arr_StuName = [[NSMutableArray alloc]init];
        __block NSMutableArray *arr_StuIds  = [[NSMutableArray alloc]init];
        
        [obj enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            strMakeupCount = [[key componentsSeparatedByString:@"["] lastObject];
            strStuId = [[obj componentsSeparatedByString:@"|"] firstObject];
            strStuName = [[obj componentsSeparatedByString:@"|"] objectAtIndex:1];
            strLTV = [[obj componentsSeparatedByString:@"|"] objectAtIndex:2];
            strLTT = [[obj componentsSeparatedByString:@"|"] objectAtIndex:3];
            
            if (!SHARED_APPDELEGATE.sameClass && !SHARED_APPDELEGATE.sameInstructor)
            {
                [dicFinalResult setObject:[NSMutableArray arrayWithObjects:strStuId,[CommonClass clearString:key],strLTV,strStuName,[strMakeupCount substringToIndex:[strMakeupCount length]-1], nil] forKey:strStuName];
                NSLog(@"%@",dicFinalResult);
                
                [arrFinalStudentDetails addObject:strStuName];
            }
            else
            {
                if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor)
                {
                    [dicComboFinalResult setObject:[NSMutableArray arrayWithObjects:strStuId,[CommonClass clearString:key],strLTV,strStuName,[strMakeupCount substringToIndex:[strMakeupCount length]-1], nil] forKey:strStuName];
                    
                    NSLog(@"%@",dicComboFinalResult);
                    
                    [arrFinalStudentComboDetails addObject:strStuName];
                }
                NSString *strStudentName = [NSString stringWithFormat:@"%@%@%@",stuName != nil ? stuName : @"",stuName != nil ? @"&" : @"", [[[[obj componentsSeparatedByString:@"|"]objectAtIndex:1] componentsSeparatedByString:@" "] firstObject]];
                stuName = strStudentName;
                [arr_StuIds addObject:strStuId];
                [arr_StuName addObject:strStuName];
                
                if (![[[NSUserDefaults standardUserDefaults] valueForKey:SCHEDULE] isEqualToString:@"Lessons"])
                {
                    strLTT = [CommonClass clearString:strLTT];
                }
            }
        }];
        
        if (SHARED_APPDELEGATE.sameClass || SHARED_APPDELEGATE.sameInstructor)
        {
            [arrFinalStudentDetails addObject:stuName];
            [dicFinalResult setObject:[NSMutableArray arrayWithObjects:arr_StuIds,strLTT,strLTV,arr_StuName,[strMakeupCount substringToIndex:[strMakeupCount length]-1], nil] forKey:stuName];
        }
    }];
    
    if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor)
    {
        [SHARED_APPDELEGATE.arrStudentComboName addObjectsFromArray:arrFinalStudentComboDetails];
        SHARED_APPDELEGATE.dicStudentDetails = dicComboFinalResult;
    }
    
    [SHARED_APPDELEGATE.arrStudentName addObjectsFromArray:arrFinalStudentDetails];
    
    if ((SHARED_APPDELEGATE.sameClass) || (!SHARED_APPDELEGATE.sameClass && !SHARED_APPDELEGATE.sameInstructor))
    {
        SHARED_APPDELEGATE.dicStudentDetails = dicFinalResult;
    }
    
    
    if (studentName != nil) {
        [self getStudentSelectionLevel:[SHARED_APPDELEGATE.arrStudentName indexOfObject:studentName]];
    }
}

#pragma mark - API CALLING

-(void)getShift:(NSString *)intrlist
{
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : SHARED_APPDELEGATE.sameInstructor ? YES : NO;
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             @"calstartdate":SHARED_APPDELEGATE.startDate,
                             @"Makeupflg":@"0",
                             @"intrlist":intrlist,
                             @"sselected":IsCombo ? [[[dicFinalResult valueForKey:studentName] objectAtIndex:0] objectAtIndex:0] : [[dicFinalResult valueForKey:studentName] objectAtIndex:0]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_Step2_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrShift = [[responseObject objectForKey:@"InstructorList"] objectAtIndex:0];
            
            [tblShiftList reloadData];
            
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getBio:(NSString *)iId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"InstructorID":iId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetInstructorBio_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr =[responseObject objectForKey:@"FinalArray"];
            
            img_instructor.layer.cornerRadius = img_instructor.frame.size.width / 2;
            img_instructor.layer.masksToBounds = YES;
            
            if ([[arr objectAtIndex:0]valueForKey:@"wu_Photo"] == nil || [[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] isEqualToString:@""])
            {
                img_instructor.image = [UIImage imageNamed:@"AppLogo"];
            }
            else
            {
                NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[[[arr objectAtIndex:0]valueForKey:@"wu_Photo"] substringFromIndex:1] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
                [img_instructor sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (error != nil) {
                        img_instructor.image = [UIImage imageNamed:@"AppLogo"];
                    }
                }];
            }
            
            lbl_instructor.text = [[arr objectAtIndex:0]valueForKey:@"wu_InsName"];
            //txt_instructor.text = [CommonClass stringByStrippingHTML:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"]];
            if (![[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] isEqual:[NSNull null]]) {
                [webView loadHTMLString:[[arr objectAtIndex:0]valueForKey:@"wu_Bio"] baseURL:nil];
            }
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentSelectionLevel:(NSInteger)idx;
{
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : SHARED_APPDELEGATE.sameInstructor ? YES : NO;
    
    arrStudentIds = [[dicFinalResult valueForKey:studentName] objectAtIndex:0];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             @"Pair1_CmbValue1":IsCombo ? [arrStudentIds objectAtIndex:0] : @"0",
                             @"Pair1_CmbValue2":IsCombo && arrStudentIds.count > 1 ? [arrStudentIds objectAtIndex:1] : @"0",
                             @"Pair1_CmbValue3":IsCombo && arrStudentIds.count > 2 ? [arrStudentIds objectAtIndex:2] : @"0",
                             @"Pair1_CmbValue4":@"0",
                             
                             @"LevelType":@"1",
                             @"lessontypeText":[[dicFinalResult valueForKey:studentName] objectAtIndex:1],
                             @"lessontypeValue":[[dicFinalResult valueForKey:studentName] objectAtIndex:2],
                             
                             @"StudentId":IsCombo ? [arrStudentIds componentsJoinedByString:@","] : arrStudentIds,
                             
                             @"siteid":[[NSUserDefaults standardUserDefaults] valueForKey:SITEID],
                             @"schedulechoices":IsCombo ? @"1" : @"0",
                             };
    
    arrStudentSelectionLevel = [[NSMutableArray alloc]init];
    arrStudentSelectionLevel_Male = [[NSMutableArray alloc]init];
    arrStudentSelectionLevel_Female = [[NSMutableArray alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager POST:Schl_Get_instrlistbyStudSelectionLevel_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr =[responseObject objectForKey:@"InstructorList"];
            if (arr.count > 0)
            {
                [arrStudentSelectionLevel addObjectsFromArray: [arr objectAtIndex:0]];
                [arrStudentSelectionLevel enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([[obj valueForKey:@"gender"]isEqualToString:@"M"])
                    {
                        [arrStudentSelectionLevel_Male addObject:obj];
                    }
                    else
                    {
                        [arrStudentSelectionLevel_Female addObject:obj];
                    }
                }];
            }
            
            [tblFMlist reloadData];
            
            [scroll setContentOffset:CGPointZero animated:YES];
            [scroll scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - BUTTON ACTIONS

-(void)DynamicAddStudents
{
    //---------Student Buttons-----------//
    
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:scroll :self];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        scroll.transform = CGAffineTransformMakeTranslation(scroll.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        scroll.transform = CGAffineTransformMakeTranslation(-scroll.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            scroll.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    [self UpdateViewAsPerStudentChanged:sender.tag];
}

-(void)UpdateViewAsPerStudentChanged:(NSInteger)tag
{
    [self getStudentSelectionLevel:tag];
    
    if ([dic_InstructorSelection valueForKey:[NSString stringWithFormat:@"BS_%@",studentName]] != nil)
    {
        for (UIView *v in instructorView.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                if ([[dic_InstructorSelection valueForKey:[NSString stringWithFormat:@"BS_%@",studentName]]integerValue] == v.tag)
                {
                    [((UIButton *)v)setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
                }
                else
                {
                    [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
                }
            }
        }
    }
    else
    {
        for (UIView *v in instructorView.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
            }
        }
    }
    
    /*
     */
    
    for (UIView *v in FMlistView.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            BOOL flag = [[dic_InstructorSelection valueForKey:[NSString stringWithFormat:@"STATUS_%ld%@",(long)v.tag,studentName]] boolValue];
            [((UIButton *)v)setSelected:flag];
        }
    }
    
    /*
     */
    
    [UIView animateWithDuration:0.5f animations:^{
        
        vHeight.constant = [[dic_InstructorSelection valueForKey:[NSString stringWithFormat:@"VHEIGHT_%@",studentName]]floatValue];
        tblHeight.constant = vHeight.constant - 50.0;
        [scroll setContentSize:CGSizeMake(self.view.frame.size.width, vHeight.constant + 200 + btnNext.frame.size.height)];
        [self.view layoutIfNeeded];
        
        /*
         */
        
        NSString *str = [dic_InstructorSelection valueForKey:[NSString stringWithFormat:@"GC_%@",studentName]];
        select_counter = [[[str componentsSeparatedByString:@"|"]lastObject]intValue];
        choose_gender = [[str componentsSeparatedByString:@"|"]firstObject];
        //[tblFMlist reloadData];
        
        /*
         */
        
        if (vHeight.constant > 0)
        {
            [FMlistView setHidden:NO];
        }
        else
        {
            [FMlistView setHidden:YES];
        }
        
        [tblFMlist reloadData];
        
        [scroll setContentOffset:CGPointZero animated:YES];
        [scroll scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        
    }completion:nil];
}

-(IBAction)btnSelectClicked:(UIButton *)sender
{
    [dic_InstructorSelection setObject:[NSString stringWithFormat:@"%ld",(long)sender.tag] forKey:[NSString stringWithFormat:@"BS_%@",studentName]];
    
    for (UIView *v in instructorView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
        }
    }
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
    
    /*
     */
    
    arr_SelectedInstructors = [[NSMutableArray alloc]init];
    arrTemp = [[NSMutableArray alloc]init];
    arr_SubTemp = [[NSMutableArray alloc]init];
    
    if (sender.tag == 0)
    {
        for(int i = 0 ; i < arrStudentSelectionLevel.count ; i++)
        {
            arrStudentNameore = arrStudentSelectionLevel;
            [arr_SelectedInstructors addObject:[NSString stringWithFormat:@"%@*%@*%@*%@",[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"gender"],[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"NextDate"],[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"Username"]]];
            
            [arrTemp addObject:[NSString stringWithFormat:@"%@:%@",[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel objectAtIndex:i] valueForKey:@"Username"]]];
        }
    }
    else if(sender.tag == 1)
    {
        for(int i = 0 ; i < arrStudentSelectionLevel_Male.count ; i++)
        {
            arrStudentNameore = arrStudentSelectionLevel_Male;
            [arr_SelectedInstructors addObject:[NSString stringWithFormat:@"%@*%@*%@*%@",[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"gender"],[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"NextDate"],[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"Username"]]];
            
            [arrTemp addObject:[NSString stringWithFormat:@"%@:%@",[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel_Male objectAtIndex:i] valueForKey:@"Username"]]];
        }
    }
    else if(sender.tag == 2)
    {
        for(int i = 0 ; i < arrStudentSelectionLevel_Female.count ; i++)
        {
            arrStudentNameore = arrStudentSelectionLevel_Female;
            [arr_SelectedInstructors addObject:[NSString stringWithFormat:@"%@*%@*%@*%@",[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"gender"],[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"NextDate"],[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"Username"]]];
            
            [arrTemp addObject:[NSString stringWithFormat:@"%@:%@",[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"UserID"],[[arrStudentSelectionLevel_Female objectAtIndex:i] valueForKey:@"Username"]]];
        }
    }
    
    [self setDictionary];
    
    /*
     */
    
    if(sender.tag == 3)
    {
        [FMlistView setHidden:NO];
        [UIView animateWithDuration:0.5 animations:^{
            
            vHeight.constant = tblFMlist.contentSize.height + 50.0;
            tblHeight.constant = tblFMlist.contentSize.height;
            [scroll setContentSize:CGSizeMake(self.view.frame.size.width, vHeight.constant + 200 + btnNext.frame.size.height)];
            [self.view layoutIfNeeded];
        }];
    }
    else
    {
        [FMlistView setHidden:YES];
        [UIView animateWithDuration:0.5f animations:^{
            
            vHeight.constant = 0.0;
            tblHeight.constant = 0.0;
            [self.view layoutIfNeeded];
            
        }completion:nil];
        
        [scroll setContentSize:CGSizeMake(self.view.frame.size.width, 100)];
    }
    
    //[tblFMlist reloadData];
    [dic_InstructorSelection setObject:[NSString stringWithFormat:@"%f",vHeight.constant] forKey:[NSString stringWithFormat:@"VHEIGHT_%@",studentName]];
}

-(void)setDictionary
{
    BOOL IsCombo = SHARED_APPDELEGATE.sameClass ? YES : SHARED_APPDELEGATE.sameInstructor ? YES : NO;
    
    arrStudentIds = [[dicFinalResult valueForKey:studentName]objectAtIndex:0];
    
    if (arr_SelectedInstructors > 0 && arrTemp.count > 0) {
        
        [scroll_header viewWithTag:([SHARED_APPDELEGATE.arrStudentName indexOfObject:studentName]+1)*100].layer.borderColor = [[UIColor clearColor]CGColor];
        
        if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor)
        {
            int i = 0;
            for (NSString *sName in SHARED_APPDELEGATE.arrStudentComboName)
            {
                if ([studentName containsString:[[sName componentsSeparatedByString:@" "] firstObject]])
                {
                    [SHARED_APPDELEGATE.dicTemp setObject:[arrTemp componentsJoinedByString:@","]forKey:sName];
                    [SHARED_APPDELEGATE.selectedInstructors setObject:arrStudentNameore forKey:sName];
                    [dic_SelectedSameInstructor setObject:[NSString stringWithFormat:@"%@$%@$%@$%@",IsCombo ?[arrStudentIds objectAtIndex:i] : arrStudentIds,sName,[[dicFinalResult valueForKey:studentName] objectAtIndex:2],[arr_SelectedInstructors componentsJoinedByString:@"|"]]forKey:sName];
                    i++;
                }
            }
        }
        else
        {
            [SHARED_APPDELEGATE.dicTemp setObject:[arrTemp componentsJoinedByString:@","]forKey:studentName];
            [SHARED_APPDELEGATE.selectedInstructors setObject:arrStudentNameore forKey:studentName];
            [dic_SelectedSameInstructor setObject:[NSString stringWithFormat:@"%@$%@$%@$%@",IsCombo ?[arrStudentIds objectAtIndex:0] : arrStudentIds,studentName,[[dicFinalResult valueForKey:studentName] objectAtIndex:2],[arr_SelectedInstructors componentsJoinedByString:@"|"]]forKey:studentName];
        }
        [dic_SelectedStudent setObject:[NSString stringWithFormat:@"%@$%@$%@$%@",IsCombo ?[arrStudentIds objectAtIndex:0] : arrStudentIds,studentName,[[dicFinalResult valueForKey:studentName] objectAtIndex:2],[arr_SelectedInstructors componentsJoinedByString:@"|"]]forKey:studentName];
    }
    else
    {
        [SHARED_APPDELEGATE.dicTemp removeObjectForKey:studentName];
        [dic_SelectedStudent removeObjectForKey:studentName];
    }
    
    NSLog(@"%@",dic_SelectedStudent);
}
-(IBAction)btnShowOnlyClicked:(UIButton *)sender
{
    choose_gender = sender.titleLabel.text;
    sender.selected = !sender.selected;
    
    [dic_InstructorSelection setObject:[NSNumber numberWithBool:sender.selected] forKey:[NSString stringWithFormat:@"STATUS_%ld%@",(long)sender.tag,studentName]];
    
    if(!sender.selected)
    {
        select_counter--;
        if([choose_gender containsString:@"Female"])
        {
            choose_gender = @"Male";
        }
        else
        {
            choose_gender = @"Female";
        }
    }
    else
    {
        select_counter++;
    }
    [tblFMlist reloadData];
    
    [scroll setContentOffset:CGPointZero animated:YES];
    [scroll scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
    
    [dic_InstructorSelection setObject:[NSString stringWithFormat:@"%@|%d",choose_gender,select_counter] forKey:[NSString stringWithFormat:@"GC_%@",studentName]];
    
    [UIView animateWithDuration:0.5f animations:^{
        
        vHeight.constant = tblFMlist.contentSize.height + 50.0;
        tblHeight.constant = tblFMlist.contentSize.height;
        
        [scroll layoutIfNeeded];
        [scroll setContentSize:CGSizeMake(scroll.frame.size.width, vHeight.constant + 200 + btnNext.frame.size.height)];
        
        [dic_InstructorSelection setObject:[NSString stringWithFormat:@"%f",vHeight.constant] forKey:[NSString stringWithFormat:@"VHEIGHT_%@",studentName]];
        
    }completion:nil];
}

-(IBAction)btnNextStepClicked:(UIButton *)sender
{
    BOOL flag = NO;
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        if ([dic_SelectedStudent valueForKey:[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]] == nil)
        {
            if (btnTemp == nil) {
                btnTemp = ((UIButton *)[scroll_header viewWithTag:i]);
            }
            [scroll_header scrollRectToVisible:[scroll_header viewWithTag:(i+1)*100].frame animated:YES];
            [scroll_header viewWithTag:(i+1)*100].layer.borderColor = [[UIColor redColor]CGColor];
            [scroll_header viewWithTag:(i+1)*100].layer.borderWidth = 1.0f;
            flag = YES;
        }
    }
    
    if (!flag)
    {
        ScheduleViewController *svc = [[ScheduleViewController alloc] initWithNibName:@"ScheduleViewController" bundle:nil];
        svc.dic_SelectedSameInstructor = dic_SelectedStudent;
        if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor) {
            svc.dic_SelectedSameInstructor = dic_SelectedSameInstructor;
            SHARED_APPDELEGATE.arrStudentName = SHARED_APPDELEGATE.arrStudentComboName;
            NSLog(@"%@",SHARED_APPDELEGATE.arrStudentName);
        }
        //        [[NSUserDefaults standardUserDefaults]setObject:arrLessonType forKey:LESSONTYPE];
        [self.navigationController pushViewController:svc animated:YES];
    }
    else
    {
        SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
        sp.s_delegate = self;
        sp.msg = provideSelectAllStudent;
        [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
        [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
    }
}
-(void)Continue:(SchedulePopup *)popup
{
    [self btnSelectStudent:btnTemp];
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    btnTemp = nil;
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == tblFMlist)
    {
        if (select_counter == 0 || select_counter == 2) {
            return arrStudentSelectionLevel.count;
        }else{
            if (select_counter == 1 && [choose_gender containsString:@"Female"]) {
                return arrStudentSelectionLevel_Female.count;
            }
            else{
                return arrStudentSelectionLevel_Male.count;
            }
        }
    }else{
        return 7;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return tableView == tblFMlist ? 80 : 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (tableView == tblFMlist)
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:1];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        if (select_counter == 0 || select_counter == 2) {
            temp = arrStudentSelectionLevel;
        }else{
            if (select_counter == 1 && [choose_gender containsString:@"Female"]) {
                temp = arrStudentSelectionLevel_Female;
            }
            else{
                temp = arrStudentSelectionLevel_Male;
            }
        }
        
        if (temp.count > 0)
        {
            sCell.lbl_fm_name.text = [[temp objectAtIndex:indexPath.row]valueForKey:@"Username"];
            
            if ([[temp objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] == nil || [[[temp objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] isEqualToString:@""])
            {
                sCell.img_fm.image = [UIImage imageNamed:@"AppLogo"];
            }
            else
            {
                NSString *strUrl = [[NSString stringWithFormat:@"%@%@",Image_Url,[[[temp objectAtIndex:indexPath.row]valueForKey:@"wu_photo"] substringFromIndex:1]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                [sCell.img_fm sd_setImageWithURL:[NSURL URLWithString:strUrl] placeholderImage:[UIImage imageNamed:@"AppLogo"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    if (error != nil) {
                        sCell.img_fm.image = [UIImage imageNamed:@"AppLogo"];
                    }
                }];
            }
            
            if ([[[temp objectAtIndex:indexPath.row]valueForKey:@"gender"]isEqualToString:@"M"])
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(138.0/255.0) green:(215.0/255.0) blue:(253.0/255.0) alpha:1.0];
            }
            else
            {
                sCell.bgView.backgroundColor = [UIColor colorWithRed:(254.0/255.0) green:(214.0/255.0) blue:(215.0/255.0) alpha:1.0];
            }
            
            [sCell.btnSelect setSelected:NO];
            
            NSArray *arrtemp = [[SHARED_APPDELEGATE.dicTemp valueForKey:studentName]componentsSeparatedByString:@","];
            if ([arrtemp containsObject:[NSString stringWithFormat:@"%@:%@",[[temp objectAtIndex:indexPath.row] valueForKey:@"UserID"],[[temp objectAtIndex:indexPath.row] valueForKey:@"Username"]]])
            {
                [sCell.bgView setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
                [sCell.btnSelect setSelected:YES];
            }
            
            sCell.btnSelect.tag = indexPath.row;
            sCell.btnViewShift.tag = indexPath.row;
            sCell.btnViewBio.tag = indexPath.row;
            
            [sCell.btnViewShift addTarget:self action:@selector(btn_View_Shift:) forControlEvents:UIControlEventTouchUpInside];
            [sCell.btnViewBio addTarget:self action:@selector(btn_View_Bio:) forControlEvents:UIControlEventTouchUpInside];
            [sCell.btnSelect addTarget:self action:@selector(btn_Select:) forControlEvents:UIControlEventTouchUpInside];
        }
        return sCell;
    }
    else
    {
        StudentListCell *sCell = (StudentListCell *)[tableView dequeueReusableCellWithIdentifier:@"sCell"];
        if (sCell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"StudentListCell" owner:self options:nil];
            sCell  = [nib objectAtIndex:4];
        }
        sCell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        sCell.lbl_day_name.text = [arr_days objectAtIndex:indexPath.row];
        sCell.lbl_schedule.text = [NSString stringWithFormat:@"%@",[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr_tcm objectAtIndex:indexPath.row]]]];
        
        if([[arrShift valueForKey:[NSString stringWithFormat:@"%@str",[arr_tcm objectAtIndex:indexPath.row]]] isEqualToString:@""]){
            sCell.lbl_schedule.text = @"Not available";
        }
        return sCell;
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == tblFMlist)
    {
        if (select_counter == 2 && [choose_gender containsString:@"Male"])
        {
            [CustomAnimation SlideCellDown:cell];
        }
        else
        {
            [CustomAnimation SlideUp:cell :0.5];
        }
    }
}

#pragma mark - Table Button Actions

-(void)btn_View_Bio:(UIButton *)sender
{
    [self resetBio];
    [self getBio:[[temp objectAtIndex:sender.tag]valueForKey:@"UserID"]];
    [viewBio setFrame:self.view.bounds];
    [self.view addSubview:viewBio];
}

-(void)btn_View_Shift:(UIButton *)sender
{
    [self getShift:[NSString stringWithFormat:@"%@:%@",[[temp objectAtIndex:sender.tag]valueForKey:@"UserID"],[[temp objectAtIndex:sender.tag]valueForKey:@"Username"]]];
    [viewShift setFrame:self.view.bounds];
    [self.view addSubview:viewShift];
}

-(IBAction)btn_Done_Close:(UIButton *)sender
{
    [viewShift removeFromSuperview];
    [viewBio removeFromSuperview];
}

-(void)btn_Select:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if(sender.selected)
    {
        [arr_SubTemp addObject:[temp objectAtIndex:sender.tag]];
        
        [arr_SelectedInstructors addObject:[NSString stringWithFormat:@"%@*%@*%@*%@",[[temp objectAtIndex:sender.tag] valueForKey:@"UserID"],[[temp objectAtIndex:sender.tag] valueForKey:@"gender"],[[temp objectAtIndex:sender.tag] valueForKey:@"NextDate"],[[temp objectAtIndex:sender.tag] valueForKey:@"Username"]]];
        [arrTemp addObject:[NSString stringWithFormat:@"%@:%@",[[temp objectAtIndex:sender.tag] valueForKey:@"UserID"],[[temp objectAtIndex:sender.tag] valueForKey:@"Username"]]];
        
        [sender.superview setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
    }
    else
    {
        [arr_SubTemp removeObject:[temp objectAtIndex:sender.tag]];
        
        [arr_SelectedInstructors removeObject:[NSString stringWithFormat:@"%@*%@*%@*%@",[[temp objectAtIndex:sender.tag] valueForKey:@"UserID"],[[temp objectAtIndex:sender.tag] valueForKey:@"gender"],[[temp objectAtIndex:sender.tag] valueForKey:@"NextDate"],[[temp objectAtIndex:sender.tag] valueForKey:@"Username"]]];
        
        [arrTemp removeObject:[NSString stringWithFormat:@"%@:%@",[[temp objectAtIndex:sender.tag] valueForKey:@"UserID"],[[temp objectAtIndex:sender.tag] valueForKey:@"Username"]]];
        
        if ([[[temp objectAtIndex:sender.tag]valueForKey:@"gender"]isEqualToString:@"M"])
        {
            sender.superview.backgroundColor = [UIColor colorWithRed:(138.0/255.0) green:(215.0/255.0) blue:(253.0/255.0) alpha:1.0];
        }
        else
        {
            sender.superview.backgroundColor = [UIColor colorWithRed:(254.0/255.0) green:(214.0/255.0) blue:(215.0/255.0) alpha:1.0];
        }
    }
    
    arrStudentNameore = temp;
    [self setDictionary];
    
    if (!SHARED_APPDELEGATE.sameClass && SHARED_APPDELEGATE.sameInstructor)
    {
        for (NSString *sName in SHARED_APPDELEGATE.arrStudentComboName)
        {
            [SHARED_APPDELEGATE.selectedInstructors setObject:arr_SubTemp forKey:sName];
        }
    }
    else
    {
        [SHARED_APPDELEGATE.selectedInstructors setObject:arr_SubTemp forKey:studentName];
    }
}

-(void)resetBio
{
    [lbl_instructor setText:@""];
    img_instructor.image = nil;
    [webView loadHTMLString:@"" baseURL:nil];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
