//
//  GetScheduleViewController.h
//  WaterWorks
//
//  Created by Ankit on 09/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MDProgress.h"

@interface GetScheduleViewController : UIViewController
{
    IBOutlet UILabel *lbl_timer, *lbl_Instruction;
    IBOutlet UITableView *tblSchedule;
    IBOutlet UIScrollView *scroll_header,*scroll_main;
    IBOutlet NSLayoutConstraint *tblHeight;
    IBOutlet UIButton *btnHome;
    IBOutlet UIView *footerView;
}
@property(nonatomic,strong)NSString *strStudent;
@property(nonatomic,strong)NSMutableDictionary *dicStudentSchedule;
@end
