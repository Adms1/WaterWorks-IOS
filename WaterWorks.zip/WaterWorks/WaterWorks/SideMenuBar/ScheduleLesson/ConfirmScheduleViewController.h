//
//  ConfirmScheduleViewController.h
//  WaterWorks
//
//  Created by Ankit on 10/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmScheduleViewController : UIViewController
{
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,strong)NSMutableDictionary *dictonary;
@property(nonatomic,strong)NSArray *arr_student;
@property(nonatomic,strong)NSString *str_student;
@property(nonatomic,assign)NSMutableArray *array_sid;
@property(nonatomic,assign)NSMutableArray *array_sname;
@property(nonatomic,assign)int flag;
@end
