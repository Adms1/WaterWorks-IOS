//
//  SLDViewController.h
//  WaterWorks
//
//  Created by Ankit on 28/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomTabbar.h"
#import "AppDelegate.h"
#import "MDButton.h"

@interface SLDViewController : UIViewController
{
    IBOutlet UIScrollView *scroll,*scroll_header;
    IBOutlet UITableView *tblFMlist;
    
    IBOutlet UIView *instructorView;
    IBOutlet UIView *FMlistView;
    
    IBOutlet UIView *viewShift;
    IBOutlet UITableView *tblShiftList;
    
    IBOutlet UIView *viewBio;
    
    IBOutlet NSLayoutConstraint *tblHeight;
    IBOutlet NSLayoutConstraint *vHeight;
    IBOutlet UIButton *btnHome;
    IBOutlet MDButton *btnNext;
    
    IBOutlet UIImageView *img_instructor;
    IBOutlet UITextView *txt_instructor;
    IBOutlet UIWebView *webView;
    IBOutlet UILabel *lbl_instructor;
    
}
@property(nonatomic,retain)NSMutableDictionary *dicFilterResult;
@end
