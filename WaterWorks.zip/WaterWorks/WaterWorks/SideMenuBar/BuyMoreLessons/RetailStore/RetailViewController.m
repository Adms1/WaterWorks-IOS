//
//  RetailViewController.m
//  WaterWorks
//
//  Created by Darshan on 30/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RetailViewController.h"
#import "UIImageView+WebCache.h"
#import "NIDropDown.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"
#import "SizeChart.h"

@interface RetailViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSString *strColorName,*strColorId,*strSizeID,*strSizeName,*strQty,*strTypeId;
    NSMutableArray *arr;
    NSDictionary *dic;
}
@end

@implementation RetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :1 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnAddToCart :YES :self];
    
    if (_productCount == 0)
    {
        [scroll_main.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
        [viewProduct setHidden:YES];
        
        if (_dicProduct == nil)
        {
            lbl_rPrice.text = [NSString stringWithFormat:@"Regular Price: $%@",[_arrayProduct valueForKey:@"OriginalPrice"]];
            lbl_oPrice.text = [NSString stringWithFormat:@"Our Price:        $%@",[_arrayProduct valueForKey:@"Price"]];
            lbl_description.text = [self stringByStrippingHTML:[_arrayProduct valueForKey:@"Description"]];
            lbl_description.text = [NSString stringWithFormat:@"‣  %@",[lbl_description.text substringFromIndex:3]];
            
            [imgTshirt sd_setImageWithURL:[NSURL URLWithString:[_arrayProduct valueForKey:@"ImageUrl"]] placeholderImage:[UIImage imageNamed:@"download"]];
            strQty =  strTypeId = @"1";
            strColorName = [[[_arrayProduct valueForKey:@"Color"] valueForKey:@"ColorName"]objectAtIndex:0];
            //strColorId = [[[_arrayProduct valueForKey:@"Color"] valueForKey:@"ColorID"]objectAtIndex:0];
        }
        else
        {
            lbl_description.text = _dicProduct[@"Description"];
            lbl_rPrice.text = [NSString stringWithFormat:@"Price: $%@",_dicProduct[@"Price"]];
            [imgTshirt sd_setImageWithURL:[NSURL URLWithString:_dicProduct[@"ImageUrl"]] placeholderImage:[UIImage imageNamed:@"download"]];
        }
    }
    else
    {
        [scroll_main.subviews makeObjectsPerformSelector:@selector(setHidden:)];
        [viewProduct setHidden:NO];
        
        if (((NSArray *)[[[_arrayProduct valueForKey:@"Categories"] valueForKey:@"Products"] objectAtIndex:0]).count > 0)
        {
            dic = [[[[_arrayProduct valueForKey:@"Categories"] valueForKey:@"Products"] objectAtIndex:0] objectAtIndex:0];
            
            [imgProduct sd_setImageWithURL:[NSURL URLWithString:dic[@"ImageURL"]] placeholderImage:[UIImage imageNamed:@"download"]];
            lblSize.text = [NSString stringWithFormat:@"%@\n$%@",dic[@"ProductName"],dic[@"Price"]];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
            viewProduct.userInteractionEnabled = YES;
            [viewProduct addGestureRecognizer:tap];
        }
        else
        {
            [viewProduct.subviews.lastObject setBackgroundColor:[UIColor clearColor]];
        }
        
        lblProductName.text = [[[_arrayProduct valueForKey:@"Categories"] valueForKey:@"CategoryName"] objectAtIndex:0];
        NSMutableParagraphStyle *style =  [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        style.alignment = NSTextAlignmentLeft;
        style.firstLineHeadIndent = 10.0f;
        
        NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:lblProductName.text attributes:@{ NSParagraphStyleAttributeName : style}];
        lblProductName.attributedText = attrText;
    }
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnsizeChart:)];
    lblsizeChart.userInteractionEnabled = YES;
    [lblsizeChart addGestureRecognizer:tap];
}

-(void)tap:(UITapGestureRecognizer *)gesture
{
    [self getProductDetails];
}

-(void)tapOnsizeChart:(UITapGestureRecognizer *)gesture
{
    SizeChart *sc = [[SizeChart alloc]initWithRect:self.view.bounds];
    [self.view addSubview:sc];
}

-(void)getProductDetails
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"ProductID":dic[@"ProductID"],
                             };
    
    [manager GET:Get_ProductDetailsByID_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        RetailViewController *rvc = [[RetailViewController alloc] initWithNibName:@"RetailViewController" bundle:nil];
        rvc.count = _productCount;
        rvc.productCount = 0;
        rvc.arrayProduct = dic;
        rvc.dicProduct = responseObject;
        rvc.productStock = [dic[@"ProductStock"] integerValue];
        [[self navigationController]pushViewController:rvc animated:YES];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(IBAction)btnTshirtChooseClicked:(UIButton *)sender
{
    //strTypeId = [NSString stringWithFormat:@"%ld",(long)sender.tag];
    for (UIView *v in scroll_main.subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && (v.tag == 1 || v.tag == 2))
        {
            ((UIButton *)v).selected = NO;
        }
    }
    sender.selected = YES;
    
    strSizeName = [[[[[_arrayProduct valueForKey:@"Color"]valueForKey:@"Size"]valueForKey:@"SizeName"] objectAtIndex:0] objectAtIndex:0];
    [btnSize setTitle:strSizeName forState:0];
    
    strSizeID = [[[[[_arrayProduct valueForKey:@"Color"]valueForKey:@"Size"]valueForKey:@"SizeID"] objectAtIndex:0]objectAtIndex:0];
    
    strColorId = [[[_arrayProduct valueForKey:@"Color"] valueForKey:@"ColorID"]objectAtIndex:sender.tag - 1];
    strColorName = [[[_arrayProduct valueForKey:@"Color"] valueForKey:@"ColorName"]objectAtIndex:sender.tag - 1];
    NSString *productColor = [NSString stringWithFormat:@"%@/productimages/%@ThermalSuit.jpg",Image_Url,strColorName];
    [imgTshirt sd_setImageWithURL:[NSURL URLWithString:productColor] placeholderImage:[UIImage imageNamed:@"download"]];
}

-(IBAction)btnSelect_Size_Quantity:(UIButton *)sender
{
    if(dropDown == nil) {
        CGFloat f = 250;
        
        arr = [[NSMutableArray alloc]init];
        if (sender.tag == 3)
        {
            if (strColorId != nil)
            {
                arr = [[[[_arrayProduct valueForKey:@"Color"]valueForKey:@"Size"]valueForKey:@"SizeName"] objectAtIndex:0];
            }
            else
            {
                [CommonClass showToastMsg:SingleColorSelection];
            }
        }
        else
        {
            for (int i = 1; i <= _productStock; i++)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",i]];
            }
        }
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :arr :@"down"];
        dropDown.tag = 1000;
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}
- (void)select:(UIButton *)sender :(NSInteger) idx
{
    if (sender.tag == 3)
    {
        strSizeName = sender.titleLabel.text;
        NSInteger idx = [[[[[_arrayProduct valueForKey:@"Color"]valueForKey:@"Size"]valueForKey:@"SizeName"] objectAtIndex:0]indexOfObject:strSizeName];
        strSizeID = [[[[[_arrayProduct valueForKey:@"Color"]valueForKey:@"Size"]valueForKey:@"SizeID"] objectAtIndex:0]objectAtIndex:idx];
    }
    else
    {
        strQty = [NSString stringWithFormat:@"%ld",idx+1];
    }
}
- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

-(NSString *) stringByStrippingHTML :(NSString *)str {
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        str = [str stringByReplacingCharactersInRange:r withString:@"\n"];
    str = [str stringByReplacingOccurrencesOfString:@"\n\n" withString:@"\n‣ "];
    return [str substringToIndex:[str length]-2];
}

-(void)AddToCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"siteid":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID],
                             @"ProductID":[_arrayProduct valueForKey:@"ProductID"],
                             @"typeid":strTypeId,
                             @"SizeID":strSizeID == nil ? @"0" : strSizeID,
                             @"ColorName":strColorName == nil ? @"" : strColorName,
                             @"DepartmentID":[_arrayProduct valueForKey:@"DepartmentID"] == nil ? @"0" : [_arrayProduct valueForKey:@"DepartmentID"],
                             @"SizeName":strSizeName == nil ? @"" : strSizeName,
                             @"wu_Price":[_arrayProduct valueForKey:@"Price"],
                             @"qty":strQty == nil ? @"1" : strQty,
                             @"ColorID":strColorId == nil ? @"0" : strColorId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:Get_ThermalProductAddToCart_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

- (IBAction)onClickAddToCartBtn:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
    {
        if (_dicProduct == nil)
        {
            if (strSizeID != nil)
            {
                [self AddToCart];
            }
            else
            {
                [CommonClass showToastMsg:SelectSize];
            }
        }
        else
        {
            strTypeId = [NSString stringWithFormat:@"%ld",_count+1];
            [self AddToCart];
        }
    }else{
        
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success)
            {
                if (_dicProduct == nil)
                {
                    if (strSizeID != nil)
                    {
                        [self AddToCart];
                    }
                    else
                    {
                        [CommonClass showToastMsg:SelectSize];
                    }
                }
                else
                {
                    strTypeId = [NSString stringWithFormat:@"%ld",_count+1];
                    [self AddToCart];
                }
            }
        }];
    }
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
