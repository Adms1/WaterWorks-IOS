//
//  RetailViewController.h
//  WaterWorks
//
//  Created by Darshan on 30/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RetailViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UIImageView *imgTshirt;
    IBOutlet UILabel *lbl_rPrice,*lbl_oPrice,*lbl_description;
    IBOutlet UIButton *btnHome, *btnAddToCart, *btnSize;
    
    IBOutlet UIView  *viewProduct;
    IBOutlet UILabel *lblProductName;
    IBOutlet UILabel *lblSize;
    IBOutlet UILabel *lblsizeChart;
    IBOutlet UIImageView *imgProduct;
}
@property(nonatomic,retain)NSMutableArray *arrayProduct;
@property(nonatomic,retain)NSDictionary *dicProduct;
@property(nonatomic,assign)NSInteger productCount;
@property(nonatomic,assign)NSInteger count;
@property(nonatomic,assign)NSInteger productStock;
@end
