//
//  SizeChart.h
//  WaterWorks
//
//  Created by ADMS on 19/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SizeChart : UIView
- (id)initWithRect:(CGRect)frame;
@end
