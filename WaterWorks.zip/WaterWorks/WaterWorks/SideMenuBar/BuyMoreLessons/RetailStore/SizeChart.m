//
//  SizeChart.m
//  WaterWorks
//
//  Created by ADMS on 19/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SizeChart.h"

@implementation SizeChart

- (id)initWithRect:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    self.backgroundColor = [[UIColor clearColor]colorWithAlphaComponent:0.5f];
    [self setUserInteractionEnabled:YES];
    
    UIImageView *imgChart = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width - 40, self.frame.size.width - 40)];
    [imgChart setCenter:self.center];
    [imgChart setImage:[UIImage imageNamed:@"chart_bold"]];
    [self addSubview:imgChart];
    
    return self;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self removeFromSuperview];
}

@end
