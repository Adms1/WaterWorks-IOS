//
//  UpdateCardViewController.m
//  WaterWorks
//
//  Created by ADMS on 01/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "UpdateCardViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "CustomTabbar.h"

@interface UpdateCardViewController ()<CommonDelegate,NIDropDownDelegate>
{
    NSArray *arrCardDetails, *arrState;
    UITextField *txtfld;
    NSString *strCardType;
    NSMutableArray *arrCardUpdateDetails;
    NIDropDown *dropDown;
}
@end

@implementation UpdateCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnCart :YES :self];
    
    [self getStateName];
    [self getCardDetails];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)getCardDetails
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"Basketid":[[NSUserDefaults standardUserDefaults] valueForKey:BASKETID],
                             @"pmtId":_strPmtId,
                             @"CustomerId":_strCustomerId
                             };
    
    [manager POST:GetCardDetailByPmtID_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrCardDetails = [[responseObject valueForKey:@"ACHList"]objectAtIndex:0];
            
            for (UIView *v in scrollView.subviews[0].subviews)
            {
                if ([v isKindOfClass:[UITextField class]])
                {
                    if ([((UITextField *)v).placeholder isEqualToString:@"Card Number"])
                    {
                        [((UITextField *)v)setText:[arrCardDetails valueForKey:@"wu_CardAccNumber"]];
                    }
                    else if ([((UITextField *)v).placeholder isEqualToString:@"Address line 1"] || [((UITextField *)v).placeholder isEqualToString:@"Address line 2"])
                    {
                        [((UITextField *)v)setText:[arrCardDetails valueForKey:[NSString stringWithFormat:@"wu_%@",[((UITextField *)v).placeholder stringByReplacingOccurrencesOfString:@" line " withString:@""]]]];
                    }
                    else
                    {
                        [((UITextField *)v)setText:[arrCardDetails valueForKey:[NSString stringWithFormat:@"wu_%@",[((UITextField *)v).placeholder stringByReplacingOccurrencesOfString:@" " withString:@""]]]];
                    }
                }
            }
            
            [btnState setTitle:[arrCardDetails valueForKey:@"wu_State"] forState:0];
            [btnExpireMonth setTitle:[[[[arrCardDetails valueForKey:@"wu_ExpDate"] componentsSeparatedByString:@"/"] firstObject] stringByReplacingOccurrencesOfString:@" Exp Date :" withString:@""] forState:0];
            [btnExpireYear setTitle:[NSString stringWithFormat:@"20%@",[[[arrCardDetails valueForKey:@"wu_ExpDate"] componentsSeparatedByString:@"/"] lastObject]] forState:0];
            strCardType = [arrCardDetails valueForKey:@"wu_CardType"];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStateName
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager POST:Get_StateList_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        arrState = [[responseObject valueForKey:@"StateList"]valueForKey:@"State"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)updateCard
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"Basketid":[[NSUserDefaults standardUserDefaults] valueForKey:BASKETID],
                             @"pmtid":_strPmtId,
                             @"strCreditDtl":[arrCardUpdateDetails componentsJoinedByString:@"|"]
                             };
    
    [manager POST:Pay_EditPaymentDetails_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self.navigationController popViewControllerAnimated:YES];
        }
        
        [CommonClass showToastMsg:[responseObject safeObjectForKey:@"Msg"]];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(IBAction)btnSelect_Month_year_State:(UIButton *)sender
{
    [self doneClicked:nil];
    if(dropDown == nil) {
        CGFloat f = 250;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        NSString *yearString = [formatter stringFromDate:[NSDate date]];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        for(int i = 1 ; i <= 12 ;i++)
        {
            if (sender.tag == 0)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",i]];
            }
            else if (sender.tag == 1)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",[yearString intValue]+i-1]];
            }
            else
            {
                arr = [arrState mutableCopy];
            }
        }
        
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :sender.tag == 3 ? @"up" : @"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    for (UIView *v in scrollView.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UITextField class]])
        {
            if (((UITextField *)v).keyboardType == UIKeyboardTypeNumberPad)
            {
                ((UITextField *)v).inputAccessoryView = keyboardtoolBar;
                ((UITextField *)v).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v).leftViewMode = UITextFieldViewModeAlways;
                ((UITextField *)v).rightViewMode = UITextFieldViewModeAlways;
            }
        }
    }
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = txtfld.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [txtfld resignFirstResponder];
        [((UIScrollView *)txtfld.superview.superview) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollView scrollRectToVisible:CGRectOffset(scrollView.subviews.lastObject.frame, 0, 20) animated:YES];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [((UIScrollView *)txtfld.superview.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [scrollView scrollRectToVisible:CGRectOffset(scrollView.subviews.lastObject.frame, 0, 20) animated:YES];
    [self.view endEditing:YES];
}

#pragma mark - Keyboard

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)txtfld.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = txtfld.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = txtfld.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:txtfld.frame animated:YES];
    }
}

#pragma mark - UITextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    txtfld = textField;
    [textField becomeFirstResponder];
    textField.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    if (textField.keyboardType == UIKeyboardTypeNumberPad) {
        [self addToolBar];
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    txtfld = textField;
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [((UIScrollView *)textField.superview.superview) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)textField.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollView scrollRectToVisible:CGRectOffset(scrollView.subviews.lastObject.frame, 0, 20) animated:YES];
        return YES;
    }
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 3 && range.location > 5 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        textField.rightViewMode = UITextFieldViewModeAlways;
        NSString *strImagename;
        switch ([[textField.text substringWithRange:NSMakeRange(0, 2)]integerValue])
        {
            case 34:
            case 37:
                strImagename = @"american_express";
                strCardType = @"American Express";
                break;
                
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
                strImagename = @"mastercard";
                strCardType = @"Master Card";
                break;
                
            default:
                break;
        }
        if ([[textField.text substringWithRange:NSMakeRange(0, 4)]integerValue] == 6011)
        {
            strImagename = @"discover";
            strCardType = @"Discover";
        }
        else if ([[textField.text substringWithRange:NSMakeRange(0, 1)]integerValue] == 4)
        {
            strImagename = @"visa";
            strCardType = @"Visa";
        }
        [[NSUserDefaults standardUserDefaults]setValue:strCardType forKey:@"CardType"];
        textField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:strImagename]];
    }
    
    if ((textField.tag == 3 || textField.tag == 2) && range.location > 15 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if (textField.tag == 7 && range.location > 5 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    return YES;
}

-(IBAction)btnUpdateCardClicked:(UIButton *)sender
{
    if ([self CheckCardDetailsValidation])
    {
        if (strCardType == nil)
        {
            [[[UIAlertView alloc]initWithTitle:@"" message:@"Card Type is missing." delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
            return;
        }
        NSString *strCardNum = [arrCardUpdateDetails objectAtIndex:2];
        int cnt = 0;
        for (int i = 2; i < 6; i++)
        {
            [arrCardUpdateDetails insertObject:[strCardNum substringWithRange:NSMakeRange(cnt, (cnt+4 >strCardNum.length) ? 4-((cnt+4)-strCardNum.length) : 4)] atIndex:i];
            cnt+=4;
        }
        [arrCardUpdateDetails replaceObjectAtIndex:6 withObject:strCardType];
        [arrCardUpdateDetails insertObject:@"" atIndex:7];
        [self updateCard];
    }
}

- (BOOL)CheckCardDetailsValidation
{
    [self doneClicked:nil];
    arrCardUpdateDetails = [[NSMutableArray alloc]init];
    for (UIView *v in scrollView.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 10)
        {
            if (![arrCardUpdateDetails containsObject:((UIButton *)v).titleLabel.text]) {
                [arrCardUpdateDetails addObject:((UIButton *)v).titleLabel.text];
            }
        }
        else if ([v isKindOfClass:[UITextField class]])
        {
            if(((UITextField *)v).text.length == 0)
            {
                if (v.tag != 5)
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:[NSString stringWithFormat:@"Please Enter %@",((UITextField *)v).placeholder] delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
            }
            else
            {
                if (v.tag == 3 && ((UITextField *)v).text.length < 5)
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Card Number Number." delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
            }
            [arrCardUpdateDetails addObject:((UITextField *)v).text];
        }
    }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
