//
//  LessonDetailCell.m
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LessonDetailCell.h"

@implementation LessonDetailCell

@synthesize btnSelect;
@synthesize lessDelegate;
@synthesize index;


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setPrivetLessonPriceDataList:(PrivateLesson *)objPrivate
{
    lblQtr.text = objPrivate.Quantity;
    
    NSArray *arrDate = [objPrivate.Price componentsSeparatedByString:@"."];
    
    if ([objPrivate.Popular isEqualToString:@"Y"]) {
        [lblCost setTextColor:[UIColor orangeColor]];
        [lblReq setTextColor:[UIColor orangeColor]];
        [lblSaving setTextColor:[UIColor orangeColor]];
        [lblQtr setTextColor:[UIColor orangeColor]];
    }
    
    NSString *StrCost = [NSString stringWithFormat:@"%@",[arrDate firstObject]];
    NSInteger cost = [StrCost integerValue];
    NSNumberFormatter * formatter1 = [NSNumberFormatter new];
    [formatter1 setNumberStyle:NSNumberFormatterDecimalStyle];
    [formatter1 setMaximumFractionDigits:1];
    NSString * strCosting =  [formatter1 stringFromNumber:[NSNumber numberWithInteger:cost]];
    
    lblCost.text = [NSString stringWithFormat:@"$%@",strCosting];
    
    NSInteger price = [objPrivate.OrgPrice integerValue];
    NSNumberFormatter * formatter = [NSNumberFormatter new];
    [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [formatter setMaximumFractionDigits:1]; 
    NSString * strReq =  [formatter stringFromNumber:[NSNumber numberWithInteger:price]];

    lblReq.text = [NSString stringWithFormat:@"$%@",strReq];
    
    NSInteger saving = [objPrivate.Saving integerValue];
    NSNumberFormatter * formatter2 = [NSNumberFormatter new];
    [formatter2 setNumberStyle:NSNumberFormatterDecimalStyle];
    [formatter2 setMaximumFractionDigits:1];
    NSString * strSaving =  [formatter2 stringFromNumber:[NSNumber numberWithInteger:saving]];
    
    lblSaving.text = [NSString stringWithFormat:@"$%@",strSaving];
}

- (IBAction)onClickSelectBtn:(id)sender {
    
    if (lessDelegate && [lessDelegate respondsToSelector:@selector(setCompanyPatientIntroductionIndex:)]) {
        [lessDelegate setCompanyPatientIntroductionIndex:index];
    }
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
