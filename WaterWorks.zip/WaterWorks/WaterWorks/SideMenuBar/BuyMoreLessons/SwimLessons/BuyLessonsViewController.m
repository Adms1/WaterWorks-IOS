//
//  BuyLessonsViewController.m
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "BuyLessonsViewController.h"
#import "OtherViewController.h"
#import "Location.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "RetailViewController.h"
#import "CustomTabbar.h"
#import "MyCartViewController.h"
#import "SchedulePopup.h"
#import "NIDropDown.h"
#import "SLViewController.h"

@interface BuyLessonsViewController ()<SchedulePopupDelegate,NIDropDownDelegate,CommonDelegate>
{
    NSTimer *newtimer;
    NIDropDown *dropDown;
}
@end

@implementation BuyLessonsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [collectionBuyList registerNib:[UINib nibWithNibName:@"BuyLessonsCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
    
    SHARED_APPDELEGATE.min = 9,SHARED_APPDELEGATE.sec = 60;
    
    if ([_strType isEqualToString:@"Buy"] && [[[NSUserDefaults standardUserDefaults]valueForKey:PastDue]isEqualToString:@"PastDue"] && _FromComfirmSchedule)
    {
        NSDateFormatter *dateFormatter=[NSDateFormatter new];
        [dateFormatter setDateFormat:@"hh:mm:ss a"];
        [[NSUserDefaults standardUserDefaults]setValue:[dateFormatter stringFromDate:[NSDate date]] forKey:@"StartTime"];
        
        newtimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateLabel) userInfo:nil repeats:YES];
    }
    [((UILabel *)scroll_main.subviews[3])setText:@""];
    
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        
        if (flag) {
            
            arrLocationList = [[NSMutableArray alloc] init];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"SiteList"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"sitename"];
                    objLocation.siteid = [dict valueForKey:@"siteid"];
                    objLocation.Lafitness = [dict valueForKey:@"Lafitness"];
                    objLocation.Address1 = [dict valueForKey:@"Address1"];
                    objLocation.Address2 = [dict valueForKey:@"Address2"];
                    objLocation.City = [dict valueForKey:@"City"];
                    objLocation.State = [dict valueForKey:@"State"];
                    objLocation.ZipCode = [dict valueForKey:@"ZipCode"];
                    objLocation.Phone = [dict valueForKey:@"Phone"];
                    
                    [arrLocationList addObject:objLocation];
                    
                    [viewLocation setHidden:NO];
                    viewLocationConstant.constant = 97.0f;
                    
                }
                
                [[NSUserDefaults standardUserDefaults]setValue:[[arrLocation valueForKey:@"siteid"]objectAtIndex:0] forKey:SITEID];
                
                if ([arrLocationList count] == 1) {
                    
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    NSString *strLAfit = [NSString stringWithFormat:@"%@",objLocation.Lafitness];
                    
                    [btnSelectLocation setTitle:strTitle forState:UIControlStateNormal];
                    
                    [viewLocation setHidden:YES];
                    viewLocationConstant.constant = 0.0f;
                    
                    [[NSUserDefaults standardUserDefaults] setObject:strLocationID forKey:SITEID];
                    [[NSUserDefaults standardUserDefaults] setObject:strLAfit forKey:LAFITNESS];
                    
                    if ([_strType isEqualToString:@"Buy"]) {
                        [((UILabel *)scroll_main.subviews[3])setText:@"Select Lesson Type"];
                        [self setBuyLessonList];
                    }else{
                        [scroll_main.subviews makeObjectsPerformSelector:@selector(setHidden:)];
                        [((UILabel *)scroll_main.subviews[3])setText:@""];
                        [collectionBuyList setHidden:NO];
                        
                        arrTemp = [[NSMutableArray alloc]init];
                        [arrTemp addObject:[NSNumber numberWithBool:YES]];
                        [self getRetailStoreHideProduct:@"0"];
                        [self getRetailStoreHideProduct:@"1"];
                    }
                }
            }else{
                
                [viewLocation setHidden:YES];
                viewLocationConstant.constant = 0.0f;
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Records Not Found" delegate:self];
            }
        }
    }];
}

-(void)viewDidAppear:(BOOL)animated
{
    if (self.view.subviews.count > 1) {
        [self.view.subviews[0] removeFromSuperview];
    }
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :[_strType isEqualToString:@"Buy"] ? 0 : 1 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    [btnSelectLocation setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectLocation.frame.size.width - 20, 0, 0)];
    
    if ([_strType isEqualToString:@"Buy"] && [[[NSUserDefaults standardUserDefaults]valueForKey:PastDue]isEqualToString:@"PastDue"] && _FromComfirmSchedule)
    {
        lblTitle.hidden = NO;
        [viewPastDue setHidden:NO];
    }
    else
    {
        [viewPastDue setHidden:YES];
        [lblTitle setText:@""];
    }
}

-(void)updateLabel
{
    SHARED_APPDELEGATE.sec--;
    if (SHARED_APPDELEGATE.min <= 0)
    {
        if (SHARED_APPDELEGATE.sec <= 0 || SHARED_APPDELEGATE.min < 0)
        {
            SHARED_APPDELEGATE.sec = 1,SHARED_APPDELEGATE.min = 0;
            [newtimer invalidate];
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"StartTime"];
            
            SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
            sp.s_delegate = self;
            sp.msg = @"It looks like you may need more time. Please go to Schedule a Lesson when you are ready to set up a schedule and make payment for lessons.";
            [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
            [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
        }
    }
    if (SHARED_APPDELEGATE.sec == -1) {
        SHARED_APPDELEGATE.min--;
        SHARED_APPDELEGATE.sec = 59;
    }
    lbl_timer.text = [NSString stringWithFormat:@"0%d:%@%d",SHARED_APPDELEGATE.min,SHARED_APPDELEGATE.sec < 10 ? @"0":@"",SHARED_APPDELEGATE.sec];
}

-(void)Continue:(SchedulePopup *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    //    for (UIViewController*vc in [self.navigationController viewControllers])
    //    {
    //        if ([vc isKindOfClass: [SLViewController class]])
    //        {
    //            [self.navigationController popToViewController:vc animated:YES];
    //            return;
    //        }
    //    }
    [SHARED_APPDELEGATE setScheduleViewController];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnAddToCart :YES :self];
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSelectLocation :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    if ([_strType isEqualToString:@"Buy"]) {
        [((UILabel *)scroll_main.subviews[3])setText:@"Select Lesson Type"];
    }
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx] forKey:SITEID];
    [userDefault setObject:[[arrLocationList valueForKey:@"Lafitness"] objectAtIndex:idx]forKey:LAFITNESS];
    
    if ([_strType isEqualToString:@"Buy"])
    {
        [self setBuyLessonList];
    }
    else
    {
        arrTemp = [[NSMutableArray alloc]init];
        [arrTemp addObject:[NSNumber numberWithBool:YES]];
        [self getRetailStoreHideProduct:@"0"];
        [self getRetailStoreHideProduct:@"1"];
    }
}

#pragma mark - UICollectionView Datasource
#pragma mark -

-(NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section
{
    if ([_strType isEqualToString:@"Buy"])
    {
        if ([arrBuyLessonList count] > 0) {
            return [arrBuyLessonList count];
        }
    }
    else
    {
        __block NSUInteger totalNumberOfCheck = 0;
        [arrTemp enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isEqual:@1]) {
                totalNumberOfCheck+= 1;
            }
        }];
        NSLog(@"%lu",(unsigned long)totalNumberOfCheck);
        return totalNumberOfCheck;
    }
    return 0;
}

#pragma mark - UICollectionView Delegate

-(UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //NSString *string = [[NSBundle mainBundle] pathForResource:@"IMAGE_FILE_NAME" ofType:@"jpg"]; // or ofType:@"png", etc.
    
    BuyLessonsCell *cell =(BuyLessonsCell *)[cv dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.lessonBuyDelegate = self;
    cell.index = (int)indexPath.row;
    
    if ([_strType isEqualToString:@"Buy"])
    {
        if ([arrBuyLessonList count] > 0) {
            [cell setBuyLessonListData:[arrBuyLessonList objectAtIndex:indexPath.row]];
        }
    }
    else
    {
        if(indexPath.row == 0)
        {
            cell.lblLessonTitle.text = @"Thermal Suits";
            cell.imgLesson.image = [UIImage imageNamed:@"promo_thermal"];
        }
        else if(indexPath.row == 1)
        {
            cell.lblLessonTitle.text = @"Goggles";
            cell.imgLesson.image = [UIImage imageNamed:@"download"];
        }
        else
        {
            cell.lblLessonTitle.text = @"Swim Caps";
            cell.imgLesson.image = [UIImage imageNamed:@"download"];
        }
    }
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *strLafitTure = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:LAFITNESS]];
    
    if ([strLafitTure isEqualToString:@"1"] || arrTemp.count > 0 || arrBuyLessonList.count < 4) {
        return CGSizeMake(self.view.frame.size.width/2, self.view.frame.size.width/2);
    }else
        return CGSizeMake(self.view.frame.size.width/2-15, self.view.frame.size.width/2-15);
}

-(void)getRetailStoreHideProduct:(NSString *)Type
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"type":Type,
                             @"SiteID":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:ShowHideProductCategory_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            if ([[[[responseObject valueForKey:@"FinalArray"] valueForKey:@"ShowCategory"] objectAtIndex:0] boolValue] == 1)
            {
                [arrTemp addObject:[NSNumber numberWithBool:YES]];
            }
            else
            {
                [arrTemp addObject:[NSNumber numberWithBool:NO]];
            }
            
            [collectionBuyList reloadData];
            collectionConstant.constant = collectionBuyList.collectionViewLayout.collectionViewContentSize.height;
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)getRetailStore:(NSInteger)idx
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *webUrl;
    NSDictionary *params;
    if (idx == 0)
    {
        webUrl = Get_ThermalProductDetails_Url;
        params = @{
                   @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN]
                   };
    }
    else
    {
        webUrl = Get_InhouseProductDetails_Url;
        params = @{
                   @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                   @"basketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                   @"siteid":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID],
                   @"type":[NSString stringWithFormat:@"%ld",idx+1],
                   };
    }
    
    [manager GET:webUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        RetailViewController *rvc = [storyBoard instantiateViewControllerWithIdentifier:@"RetailViewController"];
        rvc.arrayProduct = responseObject;
        rvc.productCount = idx;
        rvc.productStock = 50;
        [self.navigationController pushViewController:rvc animated:YES];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)setBuyLessonList
{
    arrBuyLessonList = [[NSMutableArray alloc] init];
    
    lblTitle.hidden = NO;
    
    NSString *strLafitTure = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:LAFITNESS]];
    
    if ([strLafitTure isEqualToString:@"1"]) {
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Private" titleId:@"1" andImageName:@"ImgPrivate"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Semi-Private" titleId:@"2" andImageName:@"ImgSemiPrivate"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Adult" titleId:@"4" andImageName:@"ImgAdult"]];
    }else{
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Private" titleId:@"1" andImageName:@"ImgPrivate"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Semi-Private" titleId:@"2" andImageName:@"ImgSemiPrivate"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Parent & Me\n(Beginner/Intermediate)" titleId:@"9" andImageName:@"ImgParentBeginner"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Parent & Me\n(Advanced)" titleId:@"6" andImageName:@"ImgParentAdvanced"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Stroke Clinics" titleId:@"5" andImageName:@"ImgStrokeClinics"]];
        [arrBuyLessonList addObject:[self getLocationToFindLessonTitle:@"Adult" titleId:@"4" andImageName:@"ImgAdult"]];
    }
    
    [collectionBuyList reloadData];
    collectionConstant.constant = collectionBuyList.collectionViewLayout.collectionViewContentSize.height;
    [scroll_main setContentSize:CGSizeMake(scroll_main.frame.size.width, viewPastDue.frame.size.height + viewLocationConstant.constant + collectionConstant.constant + 20)];
}
-(NSMutableDictionary *)getLocationToFindLessonTitle:(NSString *)title titleId:(NSString *)strTitleID andImageName:(NSString *)strImgName
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:title forKey:@"title"];
    [dict setObject:strTitleID forKey:@"titleID"];
    [dict setObject:strImgName forKey:@"LessonImg"];
    return dict;
}

-(void)selectBuyLessonIndex:(int)index
{
    if ([_strType isEqualToString:@"Buy"])
    {
        NSString *strTitleID = [[arrBuyLessonList objectAtIndex:index] valueForKey:@"titleID"];
        NSString *strTitle = [[arrBuyLessonList objectAtIndex:index] valueForKey:@"title"];
        
        PrivateLessonsViewController *viewPrivateLesson = [[PrivateLessonsViewController alloc] initWithNibName:@"PrivateLessonsViewController" bundle:nil];
        viewPrivateLesson.strLessonID = strTitleID;
        viewPrivateLesson.strLessonTitle = strTitle;
        [self.navigationController pushViewController:viewPrivateLesson animated:YES];
    }
    else
    {
        if (index == 0) {
            [self getRetailStore:index];
        }else{
            if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] == nil)
            {
                [CommonClass setGetBasketID:^(BOOL success) {
                    if (success) {
                        [self getRetailStore:index];
                    }
                }];
            }
            else{
                [self getRetailStore:index];
            }
        }
    }
}

-(void)popViewController
{
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
