//
//  PaymentSuccessViewController.m
//  WaterWorks
//
//  Created by Ankit on 04/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PaymentSuccessViewController.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "SLViewController.h"
#import "MyScheduleViewController.h"
#import "CommonClass.h"

@interface PaymentSuccessViewController ()<CommonDelegate>

@end

@implementation PaymentSuccessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [l1 setText:_strMsg1];
    [l2 setText:_strMsg2];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :nil :btnCart :NO :self];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}

- (IBAction)onButtonClick:(UIButton *)sender
{
    switch (sender.tag) {
        case 0:
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [SLViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            [SHARED_APPDELEGATE setScheduleViewController];
            break;
            
        case 1:
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [MyScheduleViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            [SHARED_APPDELEGATE setMyScheduleViewController];
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
