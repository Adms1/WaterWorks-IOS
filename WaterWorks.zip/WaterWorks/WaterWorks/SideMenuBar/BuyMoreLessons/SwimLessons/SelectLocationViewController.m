//
//  SelectLocationViewController.m
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SelectLocationViewController.h"

@interface SelectLocationViewController ()

@end

@implementation SelectLocationViewController

@synthesize locDelegate;
@synthesize arrLcationList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    tblList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width,tblList.contentSize.height < self.view.frame.size.height ? tblList.contentSize.height : self.view.frame.size.height);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrLcationList count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdenti = @"Event1";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdenti];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[[arrLcationList valueForKey:@"sitename"] objectAtIndex:indexPath.row]];
    cell.textLabel.font = FONT_OpenSans(12);
    
    return  cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strLocation = [[arrLcationList valueForKey:@"sitename"] objectAtIndex:indexPath.row];
    NSString *strLocationID = [[arrLcationList valueForKey:@"siteid"] objectAtIndex:indexPath.row];
    NSString *strLafit = [[arrLcationList valueForKey:@"Lafitness"] objectAtIndex:indexPath.row];
    
    if (locDelegate &&[locDelegate respondsToSelector:@selector(selectLocationIDPopUp:laFitness:andReturnType:)]) {
        [locDelegate selectLocationIDPopUp:strLocationID laFitness:strLafit andReturnType:strLocation];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
