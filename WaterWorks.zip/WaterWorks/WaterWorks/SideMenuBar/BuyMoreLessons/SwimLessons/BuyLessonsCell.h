//
//  BuyLessonsCell.h
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BuyLessonDelegate <NSObject>

-(void)selectBuyLessonIndex:(int)index;

@end

@interface BuyLessonsCell : UICollectionViewCell

@property(nonatomic,retain)IBOutlet UIView *viewBack;
@property(nonatomic,retain)IBOutlet UIImageView *imgLesson;
@property(nonatomic,retain)IBOutlet UILabel *lblLessonTitle;


//Delegate
@property (nonatomic , strong) id<BuyLessonDelegate> lessonBuyDelegate;

//Integer
@property (nonatomic) int index;

-(void)setBuyLessonListData:(NSDictionary *)dictParam;
-(void)setRetailListData:(NSArray *)arrParam;
@end
