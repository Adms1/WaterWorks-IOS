//
//  UpdateCardViewController.h
//  WaterWorks
//
//  Created by ADMS on 01/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateCardViewController : UIViewController
{
    IBOutlet UIButton *btnCart, *btnHome;
    IBOutlet UIButton *btnExpireMonth, *btnExpireYear, *btnState;
    IBOutlet UIScrollView *scrollView;
}
@property(nonatomic,retain)NSString *strPmtId, *strCustomerId;
@end
