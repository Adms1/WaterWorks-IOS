//
//  BuyLessonsViewController.h
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BuyLessonsCell.h"
#import "PrivateLessonsViewController.h"
#import "SelectLocationViewController.h"

@interface BuyLessonsViewController : UIViewController<LocationDelegate,BuyLessonDelegate>
{
    IBOutlet UIScrollView *scroll_main;
    
    IBOutlet UILabel *lblTitle;
    IBOutlet UIView *viewPastDue;
    IBOutlet UIView *viewLocation;
    
    IBOutlet UICollectionView *collectionBuyList;
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnAddToCart;
    IBOutlet UIButton *btnSelectLocation;
    
    NSMutableArray *arrBuyLessonList;
    NSMutableArray *arrTemp;
    NSMutableArray *arrLocationList;
    
    IBOutlet UILabel *lbl_timer;
    IBOutlet NSLayoutConstraint *viewLocationConstant;
    IBOutlet NSLayoutConstraint *collectionConstant;
}
@property(nonatomic,retain)NSString *strType;
@property(nonatomic,assign)BOOL FromComfirmSchedule;
@end
