//
//  MakePaymentViewController.h
//  WaterWorks
//
//  Created by Ankit on 22/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MakePaymentViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UIView *v1,*v2;
    IBOutlet UIImageView *arrow1,*arrow2;
    IBOutlet UIButton *btn1,*btn2;
    IBOutlet UIButton *btnCardChecked,*btnBankChecked;
    IBOutlet NSLayoutConstraint *vh1,*vh2;
    IBOutlet UIButton *btnCart, *btnHome;
}
@end
