//
//  PrivateLessonsViewController.m
//  WaterWorks
//
//  Created by Darshan on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PrivateLessonsViewController.h"
#import "PrivateLesson.h"
#import "CommonClass.h"
#import "OtherViewController.h"
#import "BuyLessonsViewController.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"

@interface PrivateLessonsViewController ()<CommonDelegate>

@end

@implementation PrivateLessonsViewController

@synthesize strLessonID;
@synthesize strLessonTitle;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    btnAddToCart.layer.shadowColor = [[UIColor grayColor] CGColor];
    btnAddToCart.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    btnAddToCart.layer.shadowOpacity = 1.0f;
    btnAddToCart.layer.shadowRadius = 2.0f;
    
    btnContinue.layer.shadowColor = [[UIColor grayColor] CGColor];
    btnContinue.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    btnContinue.layer.shadowOpacity = 1.0f;
    btnContinue.layer.shadowRadius = 2.0f;
    
    lblLesson.text =  [NSString stringWithFormat:@"%@ Lessons",[strLessonTitle containsString:@"Beginner"]||[strLessonTitle containsString:@"Advanced"] ? [[strLessonTitle componentsSeparatedByString:@"\n"] lastObject] : strLessonTitle];
    lblLesson.text = [lblLesson.text stringByReplacingOccurrencesOfString:@"(" withString:@""];
    lblLesson.text = [lblLesson.text stringByReplacingOccurrencesOfString:@")" withString:@""];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    arrPraivateLesson = [[NSMutableArray alloc] init];
    arrSelected = [[NSMutableArray alloc] init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *strFamilyID = [[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID];
    NSString *strSiteID = [[NSUserDefaults standardUserDefaults]objectForKey:SITEID];
    
    [params setObject:strToken forKey:@"Token"];
    [params setObject:strFamilyID forKey:@"FamilyID"];
    [params setObject:strSiteID forKey:@"SiteID"];
    [params setObject:strLessonID forKey:@"LessonTypeID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:purchaseLesson_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrLesson = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrLesson count] > 0) {
                
                for (NSDictionary *dict in arrLesson) {
                    
                    PrivateLesson *objPrivate = [[PrivateLesson alloc] init];
                    
                    objPrivate.Quantity = [dict safeObjectForKey:@"Quantity"];
                    objPrivate.PackageID = [dict safeObjectForKey:@"PackageID"];
                    objPrivate.Price = [dict objectForKey:@"Price"];
                    objPrivate.Popular = [dict objectForKey:@"Popular"];
                    objPrivate.OrgPrice = [dict objectForKey:@"OrgPrice"];
                    objPrivate.Saving = [dict objectForKey:@"Saving"];
                    
                    [arrPraivateLesson addObject:objPrivate];
                }
                [tblPrivateLessonsList reloadData];
            }
        }else{
            //            NSMutableArray *arrPrivate = [responseObject safeObjectForKey:@"FinalArray"];
            //            NSDictionary *dict = [arrPrivate firstObject];
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
    NSLog(@"ALL VUEW CONTROLLER  %@", [self.navigationController viewControllers]);
    
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnAddCart :YES :self];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return viewHeader.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  viewFooter.frame.size.height;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrPraivateLesson count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"LessonDetailCell";
    
    LessonDetailCell *cell = (LessonDetailCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"LessonDetailCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.lessDelegate = self;
    cell.index = (int)indexPath.row;
    
    
    PrivateLesson *objPrivate = [arrPraivateLesson objectAtIndex:indexPath.row];
    
    if([strSelectPacID isEqualToString:objPrivate.PackageID]){
        cell.btnSelect.selected = YES;
    }else{
        cell.btnSelect.selected = NO;
    }
    [cell setPrivetLessonPriceDataList:objPrivate];
    
    return  cell;
}

/*-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Remove seperator inset
 if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
 [cell setSeparatorInset:UIEdgeInsetsZero];
 }
 // Prevent the cell from inheriting the Table View's margin settings
 if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
 [cell setPreservesSuperviewLayoutMargins:NO];
 }
 // Explictly set your cell's layout margins
 if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
 [cell setLayoutMargins:UIEdgeInsetsZero];
 }
 }*/

-(void)setCompanyPatientIntroductionIndex:(int)index
{
    PrivateLesson *objPrivate = [arrPraivateLesson objectAtIndex:index];
    strSelectPacID = [NSString stringWithFormat:@"%@",objPrivate.PackageID];
    [tblPrivateLessonsList reloadData];
}
- (IBAction)onClickAddToCartBtn:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
    {
        if (strSelectPacID != nil)
        {
            [self AddToCart];
        }
        else
        {
            [CommonClass showToastMsg:OnePackageSelection];
        }
    }else{
        
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success)
            {
                if (strSelectPacID != nil)
                {
                    [self AddToCart];
                }
                else
                {
                    [CommonClass showToastMsg:OnePackageSelection];
                }
            }
        }];
    }
}

-(void)AddToCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"LessonID":strLessonID,
                             @"PackageID":strSelectPacID,
                             @"SiteID":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:MakePurchase_Submit_LesPacWise_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

- (IBAction)onClickSwimLessonsBtn:(id)sender {
    imgSwim.hidden = NO;
    imgRetail.hidden = YES;
    imgOther.hidden = YES;
    
    BuyLessonsViewController *viewBuyLessons = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
    [self.navigationController popToViewController:viewBuyLessons animated:YES];
}

- (IBAction)onClickRetailStoreBtn:(id)sender {
    
    imgSwim.hidden = NO;
    imgRetail.hidden = YES;
    imgOther.hidden = YES;
    
}

- (IBAction)onClickOtherProgramsBtn:(id)sender {
    
    imgSwim.hidden = YES;
    imgRetail.hidden = YES;
    imgOther.hidden = NO;
    
    OtherViewController *viewOther = [[OtherViewController alloc] initWithNibName:@"OtherViewController" bundle:nil];
    [self.navigationController pushViewController:viewOther animated:YES];
}
- (IBAction)onClickContinueShopingBtn:(id)sender {
    [self popViewController];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
