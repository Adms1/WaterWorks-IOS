//
//  PaymentSuccessViewController.h
//  WaterWorks
//
//  Created by Ankit on 04/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface PaymentSuccessViewController : MasterViewController
{
    IBOutlet UIButton *btnCart;
    IBOutlet UILabel *l1, *l2;
}
@property(nonatomic,retain)NSString *strMsg1;
@property(nonatomic,retain)NSString *strMsg2;
@end
