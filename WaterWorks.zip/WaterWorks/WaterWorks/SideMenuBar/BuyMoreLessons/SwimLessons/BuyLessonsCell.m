//
//  BuyLessonsCell.m
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "BuyLessonsCell.h"
#import "UIImageView+WebCache.h"

@implementation BuyLessonsCell

@synthesize lessonBuyDelegate;
@synthesize index,lblLessonTitle,imgLesson,viewBack;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    viewBack.backgroundColor = btnUnSlectBackgroundColor;
    viewBack.layer.shadowColor = [[UIColor grayColor] CGColor];
    viewBack.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
    viewBack.layer.shadowOpacity = 1.0f;
    viewBack.layer.shadowRadius = 2.0f;
}

-(void)setBuyLessonListData:(NSDictionary *)dictParam
{
    lblLessonTitle.text = [dictParam objectForKey:@"title"];
    imgLesson.image = [UIImage imageNamed:[dictParam objectForKey:@"LessonImg"]];
}
-(void)setRetailListData:(NSArray *)arrParam
{
    lblLessonTitle.text = [arrParam valueForKey:@"ProductName"];
    [imgLesson sd_setImageWithURL:[NSURL URLWithString:[arrParam valueForKey:@"ImageUrl"]] placeholderImage:[UIImage imageNamed:@"download"]];
}

- (IBAction)onClickPressBtn:(id)sender {
    
    if (lessonBuyDelegate &&[lessonBuyDelegate respondsToSelector:@selector(selectBuyLessonIndex:)]) {
        [lessonBuyDelegate selectBuyLessonIndex:index];
    }
}

@end
