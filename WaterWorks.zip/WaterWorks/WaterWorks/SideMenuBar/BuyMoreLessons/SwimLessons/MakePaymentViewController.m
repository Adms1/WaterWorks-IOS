//
//  MakePaymentViewController.m
//  WaterWorks
//
//  Created by Ankit on 22/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "MakePaymentViewController.h"
#import "NIDropDown.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "AppDelegate.h"
#import "CustomTabbar.h"
#import "MyCartViewController.h"

@interface MakePaymentViewController ()<UITextFieldDelegate,NIDropDownDelegate,CommonDelegate>
{
    UITextField *txtfld;
    NIDropDown *dropDown;
    NSArray *arr_state;
    NSMutableArray *arrPaymentdetails;
    NSString *strCardType,*strCardNum;
}
@end

@implementation MakePaymentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    vh1.constant = vh2.constant = 0.0f;
    [v1 setHidden:YES];
    [v2 setHidden:YES];
    
    [self getStateName];
    [self addToolBar];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnCart :YES :self];
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    NSArray *arrView = @[v1,v2];
    for (UIView *view in arrView)
    {
        for (UIView *v in view.subviews)
        {
            if ([v isKindOfClass:[UITextField class]])
            {
                if (((UITextField *)v).keyboardType == UIKeyboardTypeNumberPad)
                {
                    ((UITextField *)v).inputAccessoryView = keyboardtoolBar;
                }
            }
        }
    }
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    for (UIView *v in v1.subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 10)
        {
            [((UIButton *)v) setImageEdgeInsets:UIEdgeInsetsMake(0, v.frame.size.width - 15, 0, 0)];
        }
    }
    for (UIView *v in v2.subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 20)
        {
            [((UIButton *)v) setImageEdgeInsets:UIEdgeInsetsMake(0, v.frame.size.width - 15, 0, 0)];
        }
    }
    
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
    
}

-(void)popViewController
{
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}

-(void)getStateName
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager POST:Get_StateList_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        arr_state = [[responseObject valueForKey:@"StateList"]valueForKey:@"State"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)PaymentConfirm
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"chkSaveCard":vh1.constant > 0 && btnCardChecked.selected ? @"True" : @"False",
                             @"chkSaveACH":vh2.constant > 0 && btnBankChecked.selected ? @"True" : @"False",
                             @"strCheckDtl":vh1.constant == 0 ?[arrPaymentdetails componentsJoinedByString:@"|"] : @"",
                             @"ShippingAddress":@"",
                             @"wu_recurring":@"0",
                             @"strCreditDtl":vh1.constant == 0 ? @"" :[arrPaymentdetails componentsJoinedByString:@"|"],
                             @"strType":vh1.constant == 0 ? @"1" : @"0",
                             @"RBPaymentType":vh1.constant == 0 ? @"0" : @"1",
                             @"pmtid":@"0",
                             @"BasketID":[[NSUserDefaults standardUserDefaults]valueForKey:BASKETID],
                             @"chkagree":@"True",
                             @"strCard":strCardNum,
                             @"ChkAddShippingAddress":@"True"
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Pay_ConformPaymnet_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if (![[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCheck"] objectAtIndex:0] isEqualToString:@""])
            {
                [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"PaymentCredit"];
                [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCheck"] objectAtIndex:0] forKey:@"PaymentCheck"];
            }
            else
            {
                [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"PaymentCheck"];
                [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCredit"] objectAtIndex:0] forKey:@"PaymentCredit"];
            }
            
            if ([strCardType isEqualToString:@"Checking"] || strCardType == nil)
            {
                [[NSUserDefaults standardUserDefaults]setValue:[[arrPaymentdetails objectAtIndex:2] substringFromIndex:[[arrPaymentdetails objectAtIndex:2] length]-4] forKey:@"CreditCardNum"];
            }
            else
            {
                [[NSUserDefaults standardUserDefaults]setValue:[[arrPaymentdetails objectAtIndex:2] substringFromIndex:[[arrPaymentdetails objectAtIndex:2] length]-4] forKey:@"CreditCardNum"];
            }
            [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentBillingAddress"] objectAtIndex:0] forKey:@"AddressDetails"];
            
            SHARED_APPDELEGATE.IsPlaceOrder = YES;
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [MyCartViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnSelectPaymentMethod:(UIButton *)sender
{
    /*[UIView animateWithDuration:0.5f animations:^{
     vh1.constant = vh2.constant = 0.0f;
     [self.view layoutIfNeeded];
     
     }completion:^(BOOL finished){
     
     [v1 setHidden:YES];
     [v2 setHidden:YES];
     }];*/
    [self.view endEditing:YES];
    sender.selected = !sender.selected;
    if (sender.tag == 0)
    {
        [v2 setHidden:YES];
        for (UIView *v in v1.subviews) {
            if (sender.selected) {
                [v setHidden:NO];
            }else{
                [v setHidden:YES];
            }
        }
        [UIView animateWithDuration:0.5f animations:^{
            
            arrow2.transform = CGAffineTransformIdentity;
            btn2.selected = NO;
            vh2.constant = 0.0f;
            [v2 setHidden:YES];
            
            if (sender.selected) {
                arrow1.transform = CGAffineTransformMakeRotation(M_PI_2);
                vh1.constant = 440.0f;
            }else{
                vh1.constant = 0.0f;
                arrow1.transform = CGAffineTransformIdentity;
            }
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            
            if (sender.selected) {
                [v1 setHidden:NO];
            }else{
                [v1 setHidden:YES];
            }
        }];
    }
    else
    {
        [v1 setHidden:YES];
        for (UIView *v in v2.subviews) {
            if (sender.selected) {
                [v setHidden:NO];
            }else{
                [v setHidden:YES];
            }
        }
        [UIView animateWithDuration:0.5f animations:^{
            
            arrow1.transform = CGAffineTransformIdentity;
            btn1.selected = NO;
            vh1.constant = 0.0f;
            [v1 setHidden:YES];
            
            if (sender.selected) {
                arrow2.transform = CGAffineTransformMakeRotation(M_PI_2);
                vh2.constant = 405.0f;
            }else{
                vh2.constant = 0.0f;
                arrow2.transform = CGAffineTransformIdentity;
            }
            [self.view layoutIfNeeded];
            
        }completion:^(BOOL finished){
            
            if (sender.selected) {
                [v2 setHidden:NO];
            }else{
                [v2 setHidden:YES];
            }
        }];
    }
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = txtfld.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [txtfld resignFirstResponder];
        [scroll_main setContentInset:UIEdgeInsetsZero];
        [scroll_main setScrollIndicatorInsets:UIEdgeInsetsZero];
        if (vh1.constant > 0) {
            [scroll_main scrollRectToVisible:CGRectOffset([v1 viewWithTag:10].frame, 0, 100) animated:YES];
        }else{
            [scroll_main scrollRectToVisible:CGRectOffset([v2 viewWithTag:20].frame, 0, 100)animated:YES];
        }
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [scroll_main setContentInset:UIEdgeInsetsZero];
    [scroll_main setScrollIndicatorInsets:UIEdgeInsetsZero];
    if (vh1.constant > 0) {
        [scroll_main scrollRectToVisible:CGRectOffset([v1 viewWithTag:10].frame, 0, 100) animated:YES];
    }else{
        [scroll_main scrollRectToVisible:CGRectOffset([v2 viewWithTag:20].frame, 0, 100)animated:YES];
    }
    [self.view endEditing:YES];
}

- (BOOL)CheckAccountValidation:(UIView *)view
{
    [self doneClicked:nil];
    arrPaymentdetails = [[NSMutableArray alloc]init];
    for (UIView *v in view.subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 10 && v.tag != 20)
        {
            if([((UIButton *)v).titleLabel.text isEqualToString:@"State"])
            {
                [CommonClass showAlertWithTitle:provideAlert andMessage:[NSString stringWithFormat:@"Please Select %@",((UIButton *)v).titleLabel.text] delegate:self];
                return NO;
            }
            if (![arrPaymentdetails containsObject:((UIButton *)v).titleLabel.text]) {
                [arrPaymentdetails addObject:((UIButton *)v).titleLabel.text];
            }
        }
        else if ([v isKindOfClass:[UITextField class]])
        {
            if(((UITextField *)v).text.length == 0)
            {
                if ((view == v1 && v.tag != 5)||(view == v2 && v.tag != 6))
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:[NSString stringWithFormat:@"Please Enter %@",((UITextField *)v).placeholder] delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
            }
            else
            {
                if (view == v2 && v.tag == 1 && ((UITextField *)v).text.length < 9)
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Routing Number should be 9 digit." delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
                else if (view == v2 && v.tag == 2 && ((UITextField *)v).text.length < 5)
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Account Number Number." delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
                else if (view == v1 && v.tag == 2 && ((UITextField *)v).text.length < 5)
                {
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please Enter Valid Card Number Number." delegate:self];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
            }
            [arrPaymentdetails addObject:((UITextField *)v).text];
        }
    }
    return YES;
}

-(IBAction)btnSaveforfutureUse:(UIButton *)sender
{
    sender.selected = !sender.selected;
}

-(IBAction)Account_Credit:(UIButton *)sender
{
    if (sender.tag == 10)
    {
        if ([self CheckAccountValidation:v1])
        {
            if (strCardType == nil)
            {
                [[[UIAlertView alloc]initWithTitle:@"" message:@"Card Type is missing." delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
                return;
            }
            NSString *strCardNumTemp = [arrPaymentdetails objectAtIndex:2];
            int cnt = 0;
            for (int i = 2; i < 6; i++)
            {
                [arrPaymentdetails insertObject:[strCardNumTemp substringWithRange:NSMakeRange(cnt, (cnt+4 >strCardNumTemp.length) ? 4-((cnt+4)-strCardNumTemp.length) : 4)] atIndex:i];
                cnt+=4;
            }
            strCardNum = [arrPaymentdetails objectAtIndex:6];
            [arrPaymentdetails replaceObjectAtIndex:6 withObject:strCardType];
            [self PaymentConfirm];
        }
    }
    else
    {
        if ([self CheckAccountValidation:v2])
        {
            [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"CardType"];
            strCardNum = [arrPaymentdetails objectAtIndex:2];
            [self PaymentConfirm];
        }
    }
}

-(IBAction)btnSelect_Month_year_State:(UIButton *)sender
{
    [self doneClicked:nil];
    if(dropDown == nil) {
        CGFloat f = 250;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        NSString *yearString = [formatter stringFromDate:[NSDate date]];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        for(int i = 1 ; i <= 12 ;i++)
        {
            if (sender.tag == 0)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",i]];
            }
            else if (sender.tag == 1)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",[yearString intValue]+i-1]];
            }
            else
            {
                arr = [arr_state mutableCopy];
            }
        }
        
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :sender.tag == 3 ? @"up" : @"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
    [sender setTitleColor:[UIColor blackColor] forState:0];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}


#pragma mark - Keyboard

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)txtfld.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = txtfld.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = txtfld.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:txtfld.frame animated:YES];
    }
}

#pragma mark - UITextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    txtfld = textField;
    [textField becomeFirstResponder];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    txtfld = textField;
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [((UIScrollView *)textField.superview.superview) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)textField.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
        if (vh1.constant > 0) {
            [scroll_main scrollRectToVisible:CGRectOffset([v1 viewWithTag:10].frame, 0, 100) animated:YES];
        }else{
            [scroll_main scrollRectToVisible:CGRectOffset([v2 viewWithTag:20].frame, 0, 100)animated:YES];
        }
        return YES;
    }
    return NO;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 2 && range.location > 5 && textField.keyboardType == UIKeyboardTypeNumberPad && textField.superview == v1)
    {
        textField.rightViewMode = UITextFieldViewModeAlways;
        NSString *strImagename;
        switch ([[textField.text substringWithRange:NSMakeRange(0, 2)]integerValue])
        {
            case 34:
            case 37:
                strImagename = @"american_express";
                strCardType = @"American Express";
                break;
                
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
                strImagename = @"mastercard";
                strCardType = @"Master Card";
                break;
                
            default:
                break;
        }
        if ([[textField.text substringWithRange:NSMakeRange(0, 4)]integerValue] == 6011)
        {
            strImagename = @"discover";
            strCardType = @"Discover";
        }
        else if ([[textField.text substringWithRange:NSMakeRange(0, 1)]integerValue] == 4)
        {
            strImagename = @"visa";
            strCardType = @"Visa";
        }
        [[NSUserDefaults standardUserDefaults]setValue:strCardType forKey:@"CardType"];
        textField.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:strImagename]];
    }
    
    if (textField.tag == 2 && range.location > 15 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if (textField.tag == 1 && range.location > 8 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if ((textField.tag == 7 || textField.tag == 8) && range.location > 5 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if (textField.tag == 3 && range.location > 3 && textField.superview == v1)
    {
        return NO;
    }
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
