//
//  SelectLocationViewController.h
//  WaterWorks
//
//  Created by Darshan on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol LocationDelegate <NSObject>
@optional
-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType;

@end

@interface SelectLocationViewController : UIViewController
{
    IBOutlet UITableView *tblList;
}

@property (nonatomic , strong) NSMutableArray *arrLcationList;

@property (assign, nonatomic) id <LocationDelegate> locDelegate;

@end
