//
//  LessonDetailCell.h
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PrivateLesson.h"

@protocol lessonDelegate <NSObject>

-(void)setCompanyPatientIntroductionIndex:(int)index;

@end

@interface LessonDetailCell : UITableViewCell

{
    IBOutlet UILabel *lblQtr;
    IBOutlet UILabel *lblCost;
    IBOutlet UILabel *lblReq;
    IBOutlet UILabel *lblSaving;
}

//Delegate
@property (nonatomic , strong) id<lessonDelegate> lessDelegate;

@property (nonatomic , strong) IBOutlet UIButton *btnSelect;

//Integer
@property (nonatomic) int index;

-(void)setPrivetLessonPriceDataList:(PrivateLesson *)objPrivate;

@end
