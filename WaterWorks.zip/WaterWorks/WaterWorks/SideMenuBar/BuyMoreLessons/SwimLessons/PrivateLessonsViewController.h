//
//  PrivateLessonsViewController.h
//  WaterWorks
//
//  Created by Darshan on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LessonDetailCell.h"

@interface PrivateLessonsViewController : UIViewController<lessonDelegate>

{
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    IBOutlet UITableView *tblPrivateLessonsList;
    
    NSMutableArray *arrPraivateLesson;
    
    NSMutableArray *arrSelected;
    NSMutableArray *arrSelectedID;
    
    IBOutlet UIImageView *imgSwim;
    IBOutlet UIImageView *imgRetail;
    IBOutlet UIImageView *imgOther;
    
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnAddToCart;
    IBOutlet UIButton *btnAddCart;
    IBOutlet UIButton *btnContinue;
    
    NSString *strSelectPacID;
    
    IBOutlet UILabel *lblLesson;
}

@property (nonatomic , strong) NSString *strLessonID;
@property (nonatomic , strong) NSString *strLessonTitle;

@end
