//
//  OtherCell.h
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
}

-(void)setShowOtherListData:(NSDictionary *)dictParam;
@property(nonatomic,retain)IBOutlet UILabel *lblTitle;
@end
