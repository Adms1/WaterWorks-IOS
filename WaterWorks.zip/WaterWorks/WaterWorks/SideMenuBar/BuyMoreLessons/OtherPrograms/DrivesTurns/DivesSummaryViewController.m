//
//  DivesSummaryViewController.m
//  WaterWorks
//
//  Created by Darshan on 07/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DivesSummaryViewController.h"
#import "CommonClass.h"
#import "AddCart.h"
#import "AppDelegate.h"
#import "CustomTabbar.h"

@interface DivesSummaryViewController ()<CommonDelegate>
{
    NSMutableArray *arrSessionList;
    NSMutableArray *arrFooterData;
    NSMutableArray *arr_sid;
    NSDictionary *dict;
    int extra;
}
@end

@implementation DivesSummaryViewController

@synthesize arrStudentID;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    viewBack.layer.borderColor = [UIColor grayColor].CGColor;
    viewBack.layer.borderWidth = 0.5f;
    
    viewFooter2.subviews[0].layer.borderColor = [UIColor grayColor].CGColor;
    viewFooter2.subviews[0].layer.borderWidth = 0.5f;
    
    NSString *strSiteID = [[NSUserDefaults standardUserDefaults]objectForKey:SITEID];
    
    if ([strSiteID isEqualToString:@""] || strSiteID == nil) {
        strSiteID = @"0";
    }
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    if ([strBasketID isEqualToString:@""] || strBasketID == nil) {
        strBasketID = @"";
    }
    
    arrSelectSession = [[NSMutableArray alloc] init];
    arrFooterData = [[NSMutableArray alloc] init];
    
    NSString *weburl;
    NSString *headerTitle;
    
    if ([_strprogramid isEqualToString:@"5"]){
        weburl = GetDivesandStep3_Url;
        headerTitle = @"Dives and Turns Summary";
    }
    else if ([_strprogramid isEqualToString:@"6"]){
        weburl = GetGuardPrepStep3_Url;
        headerTitle = @"Junior Lifeguard Prep Summary";
        
    }
    else if ([_strprogramid isEqualToString:@"7"]){
        weburl = GetSwimmingMeritBadgesStep3_Url;
        headerTitle = @"Merit Badge Course Summary";
        
    }
    else if ([_strprogramid isEqualToString:@"8"]){
        weburl = GetActivityBadgesStep3_Url;
        headerTitle = @"Activity Badge Course Summary";
        
    }
    else if ([_strprogramid isEqualToString:@"9"]) {
        weburl = GetWaterPoloStep3_Url;
        headerTitle = @"Water Polo Clinics Summary";
        
    }
    else if ([_strprogramid isEqualToString:@"10"]){
        weburl = Prg_Get_GirlScoutBadges_Step3_Url;
        headerTitle = @"Girls Scout Course Summary";
        
    }
    else{
        weburl = MakePurchase_LoadStep3New_Url;
        headerTitle = @"Selected Events Summary";
    }
    
    tblSessionList.estimatedRowHeight = 200.0f;
    tblSessionList.rowHeight = UITableViewAutomaticDimension;
    
    [lblHeader setText:[NSString stringWithFormat:@"Step 3: %@",headerTitle]];
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    arr_sid = [[NSMutableArray alloc]init];
    NSMutableArray *arr_tid = [[NSMutableArray alloc]init];
    
    for (NSString *str in arrStudentID) {
        NSString *sid = [[str componentsSeparatedByString:@"|"]firstObject];
        NSString *tid = [[str componentsSeparatedByString:@"|"]lastObject];
        
        if(![arr_sid containsObject:sid])
        {
            if (arr_sid.count > 0 && arr_tid.count > 0) {
                [arr_sid replaceObjectAtIndex:arr_sid.count-1 withObject:[NSString stringWithFormat:@"%@|%@",[arr_sid lastObject],[arr_tid componentsJoinedByString:@"*"]]];
                arr_tid = [[NSMutableArray alloc]init];
            }
            [arr_sid addObject:sid];
        }
        [arr_tid addObject:tid];
    }
    
    [arr_sid replaceObjectAtIndex:arr_sid.count-1 withObject:[NSString stringWithFormat:@"%@|%@",[arr_sid lastObject],[arr_tid componentsJoinedByString:@"*"]]];
    
    if ([_strprogramid isEqualToString:@"4"])
    {
        [params setObject:strToken forKey:@"Token"];
        [params setObject:[_arrStuSessID componentsJoinedByString:@"|"] forKey:@"StudentSession"];
        [params setObject:[_arrStuEOID componentsJoinedByString:@"|"] forKey:@"StudentDropOff"];
        [params setObject:strSiteID forKey:@"siteid"];
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:FAMILYID] forKey:@"FamilyID"];
        [params setObject:[arrStudentID componentsJoinedByString:@"|"] forKey:@"StudentList"];
    }
    else
    {
        [params setObject:strToken forKey:@"Token"];
        [params setObject:strBasketID forKey:@"basketid"];
        [params setObject:strSiteID forKey:@"siteid"];
        [params setObject:[arr_sid componentsJoinedByString:@","] forKey:@"strStuList"];
    }
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"Responce Login %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrSessionList = [responseObject safeObjectForKey:![_strprogramid isEqualToString:@"4"] ? @"StudentSessionList" : @"FinalArray"];
            
            if ([_strprogramid isEqualToString:@"4"])
            {
                dict = [[responseObject safeObjectForKey:@"FinalTotal"] objectAtIndex:0];
                [arrFooterData addObject:dict[@"TotalChild"]];
                [arrFooterData addObject:dict[@"Totalsession"]];
                [arrFooterData addObject:dict[@"TotalsessionPrice"]];
                if([dict[@"SessionDiscount"] isEqualToString:@"N/A"]){
                    extra = (lblMultiSession.frame.size.height + 8);
                    [lblMultiSession setText:@""];
                    Space.constant = 0.0f;
                    [arrFooterData addObject:@""];
                }else{
                    [arrFooterData addObject:dict[@"SessionDiscount"]];
                }
                [arrFooterData addObject:dict[@"SublingAccount"]];
                [arrFooterData addObject:dict[@"EarlyDropOff"]];
                [arrFooterData addObject:dict[@"OutStandingBalance"]];
                
                [self SetFooter];
            }
            
            for (NSDictionary *dictSession in arrSessionList) {
                
                NSMutableArray *arrStudentSession = [dictSession safeObjectForKey:[_strprogramid isEqualToString:@"4"] ? @"StudentDetail" : @"StudSessionDtl"];
                
                for (NSDictionary *dictionary in arrStudentSession) {
                    
                    AddCart *objAddCart = [[AddCart alloc] init];
                    
                    if (![_strprogramid isEqualToString:@"4"])
                    {
                        objAddCart.StudentID = [dictionary safeObjectForKey:@"StudentID"];
                        objAddCart.StudentName = [dictionary safeObjectForKey:@"StudentName"];
                        objAddCart.Line = [dictionary safeObjectForKey:@"Line#"];
                        objAddCart.Sess = [dictionary safeObjectForKey:@"Sess#"];
                        objAddCart.Description = [dictionary safeObjectForKey:@"Description"];
                        objAddCart.Date = [dictionary safeObjectForKey:@"Date"];
                        objAddCart.Time = [dictionary safeObjectForKey:@"Time"];
                        objAddCart.Price = [dictionary safeObjectForKey:@"Price"];
                        [arrSelectSession addObject:objAddCart];
                    }
                }
            }
            
            lblTotalChildrenReg.text = [responseObject safeObjectForKey:@"TotalChildrenRegistered"];
            lblTotalSessionsEnter.text = [responseObject safeObjectForKey:@"TotalSessionsEntered"];
            lblTotalSessionsPrice.text = [NSString stringWithFormat:@"$%@",[responseObject safeObjectForKey:@"TotalSessionsPrice"]];
            lblStudentDiscount.text = [NSString stringWithFormat:@"Total Amount of Sibling Discount = (10%% off of %lu children)",(unsigned long)((NSArray *)[arrSessionList valueForKey:@"StudentName"]).count-1];
            
            if (![_strprogramid isEqualToString:@"10"] && ![_strprogramid isEqualToString:@"4"]){
                extra = lblOutStandingBalance.frame.size.height;
                [lblOutStandingBalance setText:@""];
                [((UILabel *)viewFooter1.subviews[0].subviews.lastObject)setText:lblOutStandingBalance.text];
                
            }else{
                [((UILabel *)viewFooter1.subviews[0].subviews.lastObject)setText:lblTotalSessionsPrice.text];
            }
            
            [tblSessionList reloadData];
            
        }else{
            
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:[[_strTitle componentsSeparatedByString:@"/"] lastObject] :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)SetFooter
{
    for (UIView *v in viewFooter2.subviews[0].subviews)
    {
        if (v.tag == 1)
        {
            [((UILabel *)v)setText:[arrFooterData objectAtIndex:[viewFooter2.subviews[0].subviews indexOfObject:v]]];
        }
    }
    [((UILabel *)viewFooter2.subviews[1])setText:[arrFooterData lastObject]];
}
#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (![_strprogramid isEqualToString:@"4"])
    {
        return viewHeader.frame.size.height;
    }
    else
    {
        if (section == 0)
            return viewHeader.frame.size.height + 30;
        else
            return 30;
    }
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        if ([_strprogramid isEqualToString:@"4"])
        {
            [viewHeader.subviews[2] setHidden:NO];
            [((UILabel *)viewHeader.subviews[2].subviews[0]) setText:[[arrSessionList valueForKey:@"StudentName"] objectAtIndex:section]];
        }
        return viewHeader;
    }
    else
    {
        UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblSessionList.frame.size.width, 30)];
        
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(8, 0, tblSessionList.frame.size.width - 16, 30)];
        [view setBackgroundColor:[UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0]];
        [headerView addSubview:view];
        
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(3, 4, tblSessionList.frame.size.width, 21)];
        [lbl setFont:FONT_Bold(14)];
        [lbl setTextColor:[UIColor blackColor]];
        [lbl setText:[[arrSessionList valueForKey:@"StudentName"] objectAtIndex:section]];
        [view addSubview:lbl];
        
        return headerView;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  [_strprogramid isEqualToString:@"4"] ? (section == [tableView numberOfSections] - 1 ? viewFooter2.frame.size.height - extra : 0) : viewFooter1.frame.size.height - extra;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [_strprogramid isEqualToString:@"4"] ? (section == [tableView numberOfSections] - 1 ? viewFooter2 : nil) : viewFooter1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [_strprogramid isEqualToString:@"4"] ? ((NSArray *)[arrSessionList valueForKey:@"StudentName"]).count: 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    if ([_strprogramid isEqualToString:@"4"]) {
    //        return UITableViewAutomaticDimension;
    //    }
    //    else{
    //        DivesSessionsCell *cell = (DivesSessionsCell *)[tableView dequeueReusableCellWithIdentifier:@"DivesSessionsCell"];
    //        if (cell == nil)
    //        {
    //            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DivesSessionsCell" owner:self options:nil];
    //            cell = [nib objectAtIndex:0];
    //        }
    //        AddCart *objAddCart = [arrSelectSession objectAtIndex:indexPath.row];
    //        [cell setAddToCartDataList:objAddCart];
    //        [cell layoutIfNeeded];
    return UITableViewAutomaticDimension;
    //    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ![_strprogramid isEqualToString:@"4"] ? [arrSelectSession count] : ((NSArray *)[[arrSessionList objectAtIndex:section] valueForKey:@"StudentDetail"]).count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"DivesSessionsCell";
    
    DivesSessionsCell *cell = (DivesSessionsCell *)[tblSessionList dequeueReusableCellWithIdentifier:simpleTableIdenti];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DivesSessionsCell" owner:self options:nil];
        if ([_strprogramid isEqualToString:@"4"]) {
            if (indexPath.row < [tblSessionList numberOfRowsInSection:indexPath.section]-1) {
                cell = [nib objectAtIndex:2];
            }else{
                cell = [nib objectAtIndex:3];
            }
        }else
            cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if ([_strprogramid isEqualToString:@"4"]) {
        if (indexPath.row < [tblSessionList numberOfRowsInSection:indexPath.section]-1)
        {
            NSDictionary *dic = [[[arrSessionList objectAtIndex:indexPath.section] valueForKey:@"StudentDetail"] objectAtIndex:indexPath.row];
            [cell setAddToCartSwimCapsList:dic];
        }
        else
        {
            NSDictionary *dic = [arrSessionList objectAtIndex:indexPath.section];
            [cell setExtraSwimCapsList:dic];
        }
    }else{
        AddCart *objAddCart = [arrSelectSession objectAtIndex:indexPath.row];
        cell.btnselect.hidden = YES;
        [cell setAddToCartDataList:objAddCart];
    }
    return  cell;
}

- (IBAction)onClickContinueBtn:(id)sender {
    
    NSString *strSiteID = [[NSUserDefaults standardUserDefaults]objectForKey:SITEID];
    
    if ([strSiteID isEqualToString:@""] || strSiteID == nil) {
        strSiteID = @"0";
    }
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    if ([strBasketID isEqualToString:@""] || strBasketID == nil) {
        strBasketID = @"";
    }
    
    /*
     */
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    for (NSString *str in arrStudentID)
    {
        NSString *newstr = [str stringByReplacingOccurrencesOfString:@"|" withString:@":"];
        [array addObject:newstr];
    }
    arrStudentID = array;
    
    /*
     */
    
    NSString *weburl;
    
    if ([_strprogramid isEqualToString:@"5"]){
        weburl = DivesandAddCart_Url;
        
    }
    else if ([_strprogramid isEqualToString:@"6"]){
        weburl = GuardAddCart_Url;
        
    }
    else if ([_strprogramid isEqualToString:@"7"]){
        weburl = SwimmingMeritBadgesAddCart_Url;
        
    }
    else if ([_strprogramid isEqualToString:@"8"]){
        weburl = ActivityBadgesAddCart_Url;
        
    }
    else if ([_strprogramid isEqualToString:@"9"]) {
        weburl = WaterPoloAddCart_Url;
        
    }
    else if ([_strprogramid isEqualToString:@"10"]){
        weburl = Prg_GirlScoutBadges_AddToCart_Url;
        
    }
    else{
        weburl = MakePurchase_SwimCampAddtoCart_Url;
    }
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    arrStudentSessionList = [[NSMutableArray alloc] init];
    
    [params setObject:strToken forKey:@"Token"];
    
    if ([_strprogramid isEqualToString:@"4"])
    {
        [params setObject:strSiteID forKey:@"SiteID"];
        [params setObject:strBasketID forKey:@"BasketID"];
        [params setObject:dict[@"arrsession"] forKey:@"ArraySession"];
        [params setObject:dict[@"arrsession1"] forKey:@"ArraySession1"];
        [params setObject:dict[@"arrsibdisc"] forKey:@"ArraySidDisc"];
        [params setObject:[arrStudentID componentsJoinedByString:@"|"] forKey:@"SelectedStudentList"];
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:FAMILYID] forKey:@"FamilyID"];
    }
    else
    {
        [params setObject:strSiteID forKey:@"siteid"];
        [params setObject:strBasketID forKey:@"basketid"];
        [params setObject:[arrStudentID componentsJoinedByString:@","] forKey:@"Studlist"];
    }
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }else{
            [CommonClass showToastMsg:InternalError];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
