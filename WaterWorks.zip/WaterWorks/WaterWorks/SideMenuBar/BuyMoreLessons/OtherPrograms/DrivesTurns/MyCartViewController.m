//
//  MyCartViewController.m
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MyCartViewController.h"
#import "CommonClass.h"
#import "ListMyCart.h"
#import "AppDelegate.h"
#import "MyCartCell.h"
#import "SelectPaymentViewController.h"
#import "SchedulePopup.h"
#import "CustomTabbar.h"
#import "PaymentSuccessViewController.h"
#import "BuyLessonsViewController.h"

@interface MyCartViewController ()<SchedulePopupDelegate,CommonDelegate>
{
    NSMutableArray *arrMyCartList;
    UITextField *activeField;
    PaymentSuccessViewController *psvc;
}
@end

@implementation MyCartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"CreditCardNum"];
    
    txtPromoCode.layer.borderColor = [UIColor lightGrayColor].CGColor;
    txtPromoCode.layer.borderWidth = 1.0f;
    txtPromoCode.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPromoCode.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPromoCode.leftViewMode = UITextFieldViewModeAlways;
    txtPromoCode.rightViewMode = UITextFieldViewModeAlways;
    
    tblMyCartList.estimatedRowHeight = 200.0f;
    tblMyCartList.rowHeight = UITableViewAutomaticDimension;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)popViewController
{
    if (vf1.hidden == YES)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SelectPaymentViewController *spvc = [storyboard instantiateViewControllerWithIdentifier:@"SelectPaymentViewController"];
        [[self navigationController]pushViewController:spvc animated:YES];
    }
    else
    {
        for (UIViewController*vc in [self.navigationController viewControllers])
        {
            if ([vc isKindOfClass: [BuyLessonsViewController class]])
            {
                BuyLessonsViewController *buyvc;
                buyvc.strType = @"Buy";
                buyvc.FromComfirmSchedule = NO;
                SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
                [self.navigationController popToViewController:vc animated:YES];
                return;
            }
        }
        [SHARED_APPDELEGATE setBuyLessonViewController];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnCart :YES :self];
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
    {
        [self MyCartPayment];
    }else{
        
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success)
            {
                [self MyCartPayment];
            }
        }];
    }
}

-(void)MyCartPayment
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"Basketid":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    arrMyCartList = [[NSMutableArray alloc] init];
    
    [manager GET:FillDateMyCart_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            lblSubTotal.text = [NSString stringWithFormat:@"$%@",[responseObject safeObjectForKey:@"SubTotalSum"]];
            if (![[responseObject safeObjectForKey:@"TaxSum"] isEqualToString:@"0.00"])
            {
                lblSalesTaxTitle.text = @"Sales Tax:";
                lblSalesTax.text = [NSString stringWithFormat:@"$%@",[responseObject safeObjectForKey:@"TaxSum"]];
                s1.constant = s2.constant = 5.0f;
            }
            else
            {
                lblSalesTaxTitle.text = @"";
                lblSalesTax.text = @"";
                s1.constant = s2.constant = 0.0f;
            }
            lblTotal.text = [NSString stringWithFormat:@"$%@",[responseObject safeObjectForKey:@"Total"]];
            
            //            if (![[responseObject safeObjectForKey:@"TaxSum"] isEqualToString:@""]) {
            //
            //                lblTaxTitle.text = @"Tax Sum:";
            //                lblTaxSum.text = [NSString stringWithFormat:@"$%@",[responseObject safeObjectForKey:@"TaxSum"]];
            //                t1.constant = t2.constant = 5.0f;
            //            }
            if (![[responseObject safeObjectForKey:@"promotext"] isEqualToString:@""]) {
                
                lblPromoTitle.text = @"PROMO:";
                lblPromo.text = [NSString stringWithFormat:@"%@",[responseObject safeObjectForKey:@"promotext"]];
                p1.constant = p2.constant = 5.0f;
            }
            
            //txtPromoCode.text = [responseObject safeObjectForKey:@"promocode"];
            
            NSMutableArray *arrFinalArray = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrFinalArray count] > 0) {
                
                for (UIView *v in viewFooter.subviews[0].subviews) {
                    if ([v isKindOfClass:[UILabel class]]) {
                        [v setHidden:NO];
                    }
                }
                
                for (NSDictionary *dict in arrFinalArray) {
                    
                    ListMyCart *objListMyCart = [[ListMyCart alloc] init];
                    
                    objListMyCart.StudentName = [dict safeObjectForKey:@"StudentName"];
                    objListMyCart.index = [dict safeObjectForKey:@"index"];
                    objListMyCart.ItemTypeID = [dict safeObjectForKey:@"ItemTypeID"];
                    objListMyCart.ItemTypeName = [dict safeObjectForKey:@"ItemTypeName"];
                    objListMyCart.Type = [dict safeObjectForKey:@"Type"];
                    objListMyCart.Item = [dict safeObjectForKey:@"Item"];
                    objListMyCart.Package = [dict safeObjectForKey:@"Package"];
                    objListMyCart.Price = [dict safeObjectForKey:@"Price"];
                    objListMyCart.Qty = [dict safeObjectForKey:@"Qty"];
                    objListMyCart.Tax = [dict safeObjectForKey:@"Tax"];
                    objListMyCart.Subtotal = [dict safeObjectForKey:@"Subtotal"];
                    objListMyCart.Delete = [dict safeObjectForKey:@"Delete"];
                    objListMyCart.Description = [dict safeObjectForKey:@"Description"];
                    objListMyCart.Location = [dict safeObjectForKey:@"Location"];
                    objListMyCart.Promocode = [dict safeObjectForKey:@"Promocode"];
                    objListMyCart.DeleteEblDble = [dict safeObjectForKey:@"DeleteEblDble"];
                    
                    [arrMyCartList addObject:objListMyCart];
                }
                [tblMyCartList setScrollEnabled:YES];
                [lblEmpty setHidden:YES];
            }
        }else{
            
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:BASKETID];
            
            [tblMyCartList setScrollEnabled:NO];
            [lblEmpty setHidden:NO];
            for (UIView *v in viewFooter.subviews[0].subviews) {
                if ([v isKindOfClass:[UILabel class]]) {
                    [v setHidden:YES];
                }
                //                [vf1.subviews[0] setHidden:YES];
                //                [txtPromoCode setHidden:YES];
                //                [btnApply setHidden:YES];
            }
        }
        [tblMyCartList reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)DeleteProduct:(NSInteger)idx :(NSString *)strDetailId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"DetailID":strDetailId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:MakePurchase_DeleteInvoice_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            //[arrMyCartList removeObjectAtIndex:idx];
            //[tblMyCartList reloadData];
            
            [self MyCartPayment];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)PromoCodeApply
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":arrMyCartList.count == 0 ? @"0" : [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"PromoCode":txtPromoCode.text
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:MakePurchase_ApplyPromocode_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [txtPromoCode setText:@""];
            [self MyCartPayment];
            
        }else{
            [CommonClass showToastMsg:InvalidPromoCode];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)EmptyCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:MakePurchase_EmptyBasket_ByBacketID_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            [CommonClass showToastMsg:BasketRefreshed];
            
            [self MyCartPayment];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)PlaceOrder
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"strPaymentCheck":[[NSUserDefaults standardUserDefaults]objectForKey:@"PaymentCheck"],
                             @"strPaymentBillingAddress":[[NSUserDefaults standardUserDefaults] valueForKey:@"AddressDetails"],
                             @"pastduepaymentFlag":@"false",
                             @"Userid1":@"",
                             @"strPaymentCredit":[[NSUserDefaults standardUserDefaults]objectForKey:@"PaymentCredit"],
                             @"pastdueInvoiceId":@"",
                             @"strPaymentShippingAddress":[[NSUserDefaults standardUserDefaults] valueForKey:@"AddressDetails"],
                             @"creditexp":@"",
                             @"Total":lblTotal.text
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:Pay_Conform_SubmitPayment_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"] && [[[[responseObject valueForKey:@"ConformMsgDisplay"]valueForKey:@"Msg"] objectAtIndex:0]isEqualToString:@"Not Submitted Successfully...."])
        {
            SchedulePopup *sp = [[SchedulePopup alloc] initWithNibName:@"SchedulePopup" bundle:nil];
            sp.s_delegate = self;
            sp.msg = [[[[[responseObject valueForKey:@"ConformMsgDisplay"]valueForKey:@"ErrorMsg"] objectAtIndex:0] componentsSeparatedByString:@"<"] firstObject];
            sp.title_msg = @"Alert";
            [sp.view setFrame:CGRectMake(sp.view.frame.origin.x, sp.view.frame.origin.y, self.view.frame.size.width - 40, sp.view.frame.size.height)];
            [self presentPopupViewController:sp animationType:MJPopupViewAnimationFade];
            [SHARED_APPDELEGATE hideLoadingView];
        }
        else
        {
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            psvc = [storyBoard instantiateViewControllerWithIdentifier:@"PaymentSuccessViewController"];
            psvc.strMsg1 = [[[responseObject valueForKey:@"ConformMsgDisplay"]valueForKey:@"Msg1"] objectAtIndex:0];
            psvc.strMsg2 = [[[responseObject valueForKey:@"ConformMsgDisplay"]valueForKey:@"Msg2"] objectAtIndex:0];
            
            [self ViewPasDueBal_InvoiceData:[[[responseObject valueForKey:@"ConformMsgDisplay"] valueForKey:@"InvoiceID"] objectAtIndex:0]];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)ViewPasDueBal_InvoiceData:(NSString *)InvoiceID
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"InvoiceID":InvoiceID
                             };
    
    NSLog(@"Params %@",params);
    
    [manager GET:ViewPasDueBal_InvoiceData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        [self Pay_Invoice_Load:InvoiceID :[responseObject valueForKey:@"pastdueAmount"]];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)Pay_Invoice_Load:(NSString *)InvoiceId :(NSString *)pastdueAmount
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"BasketID":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"InvoiceId":InvoiceId,
                             @"pastdueAmount":pastdueAmount
                             };
    
    NSLog(@"Params %@",params);
    
    [manager GET:Pay_Invoice_Load_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:BASKETID];
            
            [[self navigationController]pushViewController:psvc animated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)Continue:(SchedulePopup *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SelectPaymentViewController *spvc = [storyboard instantiateViewControllerWithIdentifier:@"SelectPaymentViewController"];
    [[self navigationController]pushViewController:spvc animated:YES];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popToViewController
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:NO];
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (!SHARED_APPDELEGATE.IsPlaceOrder) {
        [vf1 setHidden:NO];
        [vf2 setHidden:YES];
        return 340 + (s1.constant > 0 ? (p1.constant > 0 ? 50 : 25) : 0);
    }else{
        [vf1 setHidden:YES];
        [vf2 setHidden:NO];
        if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"CardType"]isEqualToString:@""])
        {
            [lblCreditNum setText:[NSString stringWithFormat:@"Checking - %@",[[NSUserDefaults standardUserDefaults]valueForKey:@"CreditCardNum"]]];
        }
        else
        {
            NSString *str = [[NSUserDefaults standardUserDefaults]valueForKey:@"CreditCardNum"];
            [lblCreditNum setText:[NSString stringWithFormat:@"%@ %@",[[NSUserDefaults standardUserDefaults]valueForKey:@"CardType"],[str containsString:@"*"] ? str : [NSString stringWithFormat:@"*****%@",str]]];
        }
        return 340 - 125 + (s1.constant > 0 ? (p1.constant > 0 ? 50 : 25) : 0);
    }
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblMyCartList.frame.size.width, 30)];
    headerView.backgroundColor = [UIColor whiteColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 200, 25)];
    lblSection.textColor = [UIColor darkGrayColor];
    [lblSection setText:vf1.hidden == NO ? @"My Cart" : @"Order Summary"];
    lblSection.font = FONT_Semibold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrMyCartList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListMyCart *objListMyCart = [arrMyCartList objectAtIndex:indexPath.row];
    static NSString *simpleTableIdenti;
    if ([objListMyCart.Type isEqualToString:@"Lessons"] && ![objListMyCart.Item containsString:@"Family Swim"])
    {
        simpleTableIdenti = @"MyCartCell1";
    }
    else
    {
        simpleTableIdenti = @"MyCartCell2";
    }
    
    MyCartCell *cell = (MyCartCell *)[tblMyCartList dequeueReusableCellWithIdentifier:simpleTableIdenti];
    
    //    //cell = nil;
    //    if (cell == nil)
    //    {
    //        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MyCartCell" owner:self options:nil];
    //        if ([objListMyCart.Type isEqualToString:@"Lessons"] && ![objListMyCart.Item containsString:@"Family Swim"])
    //        {
    //            cell = [nib objectAtIndex:0];
    //        }
    //        else
    //        {
    //            cell = [nib objectAtIndex:1];
    //        }
    //    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if (!SHARED_APPDELEGATE.IsPlaceOrder)
    {
        [cell.btnDelete setHidden:NO];
        [cell.btnDelete addTarget:self action:@selector(btnDeleteclick:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnDelete.tag = indexPath.row;
    }
    else
    {
        [cell.btnDelete setHidden:YES];
    }
    
    if ([objListMyCart.Type isEqualToString:@"Lessons"] && ![objListMyCart.Item containsString:@"Family Swim"])
    {
        [cell setListOfCartData1:objListMyCart];
    }
    else
    {
        [cell setListOfCartData2:objListMyCart];
    }
    
    return  cell;
}

-(void)btnDeleteclick:(UIButton *)sender
{
    [self DeleteProduct:sender.tag :[[arrMyCartList objectAtIndex:sender.tag] valueForKey:@"Delete"]];
}

-(IBAction)btnApplyclick:(UIButton *)sender
{
    if (txtPromoCode.text.length > 0)
    {
        [self PromoCodeApply];
    }
    else
    {
        [CommonClass showToastMsg:EnterPromoCode];
    }
}
-(IBAction)btnSelect:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        if (arrMyCartList.count > 0) {
            
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SelectPaymentViewController *spvc = [storyboard instantiateViewControllerWithIdentifier:@"SelectPaymentViewController"];
            [[self navigationController]pushViewController:spvc animated:YES];
            
        }else{
            [CommonClass showToastMsg:CartEmpty];
        }
    }
    else if (sender.tag == 1)
    {
        if([[NSUserDefaults standardUserDefaults]valueForKey:BASKETID] != nil)
        {
            [self EmptyCart];
        }
        else
        {
            [CommonClass showToastMsg:EmptyCardMsg];
        }
    }
    else
    {
        for (UIViewController*vc in [self.navigationController viewControllers])
        {
            if ([vc isKindOfClass: [BuyLessonsViewController class]])
            {
                BuyLessonsViewController *buyvc;
                buyvc.strType = @"Buy";
                buyvc.FromComfirmSchedule = NO;
                SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
                [self.navigationController popToViewController:vc animated:YES];
                return;
            }
        }
        [SHARED_APPDELEGATE setBuyLessonViewController];
    }
}

-(IBAction)btnPlaceOrderclick:(UIButton *)sender
{
    [self PlaceOrder];
}

-(IBAction)btnMyCartclick:(UIButton *)sender
{
    if (SHARED_APPDELEGATE.IsPlaceOrder)
    {
        SHARED_APPDELEGATE.IsPlaceOrder = NO;
        [tblMyCartList reloadData];
    }
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)activeField.superview.superview.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)activeField.superview.superview.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.superview.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)activeField.superview.superview.superview.superview) scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [self resign];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self resign];
    return YES;
}

-(void)resign
{
    [((UIScrollView *)activeField.superview.superview.superview.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)activeField.superview.superview.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)activeField.superview.superview.superview.superview)scrollRectToVisible:tblMyCartList.subviews.lastObject.frame animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
