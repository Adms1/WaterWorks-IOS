//
//  DrivesTurnCell.h
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentList.h"

@protocol SelectStudentDelegate <NSObject>

-(void)selectStudentListAtIndex:(NSInteger)index andSelectCell:(NSString *)strSelectedCell;

@end

@interface DrivesTurnCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
}
@property(nonatomic,retain)IBOutlet UILabel *lblTitle;
@property(nonatomic,retain)IBOutlet UIButton *btnselect;

@property (assign, nonatomic) id <SelectStudentDelegate> delegate;
//Integer
@property (nonatomic) int index;

-(void)setPrivetLessonPriceDataList:(StudentList*)objStudants;

@end
