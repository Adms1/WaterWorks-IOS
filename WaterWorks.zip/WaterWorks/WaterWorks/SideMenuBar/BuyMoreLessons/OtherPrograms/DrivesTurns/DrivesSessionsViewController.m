//
//  DrivesSessionsViewController.m
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DrivesSessionsViewController.h"
#import "DivesSummaryViewController.h"
#import "RemainingLessons.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "CustomTabbar.h"

@interface DrivesSessionsViewController ()<CommonDelegate>
{
    UIView *vStripe;
    NSString *studentName;
    NSMutableArray *arrDivesand;
    UIButton *btnTemp;
    NSInteger previousTag;
}
@end

@implementation DrivesSessionsViewController

@synthesize arrStudentID;
@synthesize arrStudentName;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] == nil)
    {
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success) {
                [self setSessionList];
            }
        }];
    }
    else
    {
        [self setSessionList];
    }
    
    vStripe = [[UIView alloc]init];
    vStripe.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
    
    tblSessionsList.estimatedRowHeight = 120.0f;
    tblSessionsList.rowHeight = UITableViewAutomaticDimension;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    if (studentName == nil) {
        [self DynamicAddStudents];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:[[_strTitle componentsSeparatedByString:@"/"] lastObject] :self :btnHome :nil :YES :self];
}

-(void)DynamicAddStudents
{
    //---------Student Buttons-----------//
    for (int x = 0; x < arrStudentName.count; x++)
    {
        CGFloat btnwidth = ((self.view.frame.size.width - 10)/arrStudentName.count);
        if (btnwidth < 150)
        {
            btnwidth = 150.0;
        }
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(x * btnwidth, 0, btnwidth, 30)];
        btn.backgroundColor = [UIColor clearColor];
        
        if (x == 0)
        {
            [btn setTitleColor:[UIColor whiteColor] forState:0];
            [btn setBackgroundColor:Top_Color];
        }
        else
        {
            [btn setTitleColor:[UIColor blackColor] forState:0];
        }
        
        [btn.titleLabel setFont:FONT_Bold(13)];
        [btn setTitle:[arrStudentName objectAtIndex:x] forState:0];
        btn.tag = x+1;
        [btn addTarget:self action:@selector(btnSelectStudent:) forControlEvents:UIControlEventTouchUpInside];
        [scroll_header addSubview:btn];
        [scroll_header setContentSize:CGSizeMake((btnwidth * arrStudentName.count), scroll_header.frame.size.height)];
        
        studentName = [arrStudentName objectAtIndex:0];
        CGSize stringsize = [studentName sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((btnwidth/2) - (stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20)/2, 27, stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20, 3)];
    }
    [scroll_header addSubview:vStripe];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    studentName = [arrStudentName objectAtIndex:sender.tag-1];
    arrSelectStudentIds = [[NSMutableArray alloc] init];
    arrSelectSessionID = [[NSMutableArray alloc] init];
    arrSelectEarlyDropOffID = [[NSMutableArray alloc] init];
    
    [self ReloadData:[arrStudentID objectAtIndex:sender.tag-1]];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setBackgroundColor:[UIColor clearColor]];
            [((UIButton *)v) setTitleColor:[UIColor blackColor] forState:0];
        }
    }
    [sender setBackgroundColor:Top_Color];
    [sender setTitleColor:[UIColor whiteColor] forState:0];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setSessionList{
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    if ([strBasketID isEqualToString:@""] || strBasketID == nil) {
        strBasketID = @"";
    }
    
    NSString *strSiteID =  [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:SITEID]];
    if ([strSiteID isEqualToString:@""] || strSiteID == nil) {
        strSiteID = @"0";
    }
    
    arrSelectStudentIds = [[NSMutableArray alloc] init];
    arrSelectSessionID = [[NSMutableArray alloc] init];
    arrSelectEarlyDropOffID = [[NSMutableArray alloc] init];
    dicSelectIds = [[NSMutableDictionary alloc] init];
    dicSelectSIds = [[NSMutableDictionary alloc] init];
    dicSelectEDIds = [[NSMutableDictionary alloc] init];
    
    NSString *weburl;
    NSString *reponseKey;
    NSString *headerTitle;
    
    if ([_strprogramid isEqualToString:@"5"]){
        weburl = GetDivesandStep2_Url;
        reponseKey = @"Divesandclinics";
        headerTitle = @"Dives and Turns Sessions";
        
    }
    else if ([_strprogramid isEqualToString:@"6"]){
        weburl = GetGuardPrepStep2_Url;
        reponseKey = @"GuardPrep";
        headerTitle = @"Junior Lifeguard Prep Courses";
        
    }
    else if ([_strprogramid isEqualToString:@"7"]){
        weburl = GetSwimmingMeritBadgesStep2_Url;
        reponseKey = @"SwimmingMeritBadges";
        headerTitle = @"Merit Badge Courses";
        
    }
    else if ([_strprogramid isEqualToString:@"8"]){
        weburl = GetActivityBadgesStep2_Url;
        reponseKey = @"SwimmingActivityBadges";
        headerTitle = @"Activity Badges Courses";
        
    }
    else if ([_strprogramid isEqualToString:@"9"]) {
        weburl = GetWaterPoloStep2_Url;
        reponseKey = @"WaterPoloCond";
        headerTitle = @"Water Polo Clinics";
        
    }
    else if ([_strprogramid isEqualToString:@"10"]){
        weburl = Prg_Get_GirlScoutBadges_Step2_Url;
        reponseKey = @"GirlScoutBadges";
        headerTitle = @"Girls Scount Courses";
        
    }
    else{
        weburl = MakePurchase_LoadStep2_Url;
        reponseKey = @"FinalArray";
        headerTitle = @"Swim Camp Events";
    }
    
    [lblHeader setText:[NSString stringWithFormat:@"Step 2: Select %@",headerTitle]];
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStream = [arrStudentID componentsJoinedByString:@","];
    [params setObject:strSiteID forKey:@"Siteid"];
    
    if (![_strprogramid isEqualToString:@"4"])
    {
        [params setObject:strToken forKey:@"Token"];
        [params setObject:strStream forKey:@"strStuList"];
        [params setObject:@"true" forKey:@"ShowFlg"];
        [params setObject:strBasketID forKey:@"BasketID"];
    }
    else
    {
        [params setObject:strToken forKey:@"Token"];
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:FAMILYID] forKey:@"FamilyID"];
        [params setObject:strStream forKey:@"SelectedStudent"];
    }
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrDivesand = [responseObject safeObjectForKey:reponseKey];
            
            [self ReloadData:[arrStudentID objectAtIndex:0]];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)ReloadData:(NSString *)strId
{
    arrDivesSelect = [[NSMutableArray alloc] init];
    
    if ([arrDivesand count] > 0) {
        
        for (NSDictionary *dict in arrDivesand) {
            
            DrivesTurns *objDrives = [[DrivesTurns alloc] init];
            
            if (![_strprogramid isEqualToString:@"4"]) {
                
                objDrives.FullName = [dict safeObjectForKey:@"Fullname"];
                if (objDrives.FullName.length == 0) {
                    objDrives.FullName = [dict safeObjectForKey:@"FullName"];
                }
                objDrives.Studentid = [dict safeObjectForKey:@"Studentid"];
                objDrives.tbid = [dict safeObjectForKey:@"tbid"];
                objDrives.sessionname = [dict safeObjectForKey:@"sessionname"];
                objDrives.startdate = [dict safeObjectForKey:@"startdate"];
                objDrives.enddate = [dict safeObjectForKey:@"enddate"];
                objDrives.Time = [dict safeObjectForKey:@"Time"];
                objDrives.unitprice = [dict safeObjectForKey:@"unitprice"];
                objDrives.sitename = [dict safeObjectForKey:@"sitename"];
                objDrives.alreadyshopped = [dict safeObjectForKey:@"alreadyshopped"];
                objDrives.Remark = [dict safeObjectForKey:@"Remark"];
            }
            else
            {
                objDrives.Studentid = [dict safeObjectForKey:@"StudentID"];
                objDrives.Description = [dict safeObjectForKey:@"Description"];
                objDrives.startdate = [dict safeObjectForKey:@"Start Date"];
                objDrives.enddate = [dict safeObjectForKey:@"End Date"];
                objDrives.unitprice = [dict safeObjectForKey:@"Unit Price"];
                objDrives.SessionID = [dict safeObjectForKey:@"AddName"];
                objDrives.EarlyDropOffID = [dict safeObjectForKey:@"EarlyDropOffID"];
            }
            if ([objDrives.Studentid isEqualToString:strId])
            {
                [arrDivesSelect addObject:objDrives];
            }
        }
    }
    [tblSessionsList reloadData];
    
    [tblSessionsList setContentOffset:CGPointZero animated:YES];
    //[tblSessionsList scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_OpenSans(12) }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.view.frame.size.width - 100, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize size = rect.size;
    return size;
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return viewHeader.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  viewFooter.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![_strprogramid isEqualToString:@"4"])
    {
        /*DivesSessionsCell *cell = (DivesSessionsCell *)[tableView dequeueReusableCellWithIdentifier:@"DivesSessionsCell"];
         if (cell == nil)
         {
         NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DivesSessionsCell" owner:self options:nil];
         cell = [nib objectAtIndex:0];
         }
         DrivesTurns *objLessons = [arrDivesSelect objectAtIndex:indexPath.row];
         [cell setLessonPriceDataList:objLessons];
         CGSize size = [self getDynamicHeightOflbl:objLessons.Remark];
         [cell layoutIfNeeded];
         return cell.lbl.frame.origin.y + ((size.height) > 17 ? size.height : 17);*/
        return UITableViewAutomaticDimension;
    }
    else
    {
        return 98;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrDivesSelect count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"DivesSessionsCell";
    
    DivesSessionsCell *cell = (DivesSessionsCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DivesSessionsCell" owner:self options:nil];
        if ([_strprogramid isEqualToString:@"4"]) {
            cell = [nib objectAtIndex:1];
            
        }else{
            cell = [nib objectAtIndex:0];
        }
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.delegate = self;
    cell.index = (int)indexPath.row;
    
    if (![_strprogramid isEqualToString:@"4"]) {
        
        DrivesTurns *objLessons = [arrDivesSelect objectAtIndex:indexPath.row];
        [cell setLessonPriceDataList:objLessons];
        
        NSArray *arr = [dicSelectIds valueForKey:studentName];
        if ([arr containsObject:[NSString stringWithFormat:@"%@|%@",objLessons.Studentid,objLessons.tbid]])
        {
            cell.btnselect.selected = YES;
            if (![arrSelectStudentIds containsObject:[NSString stringWithFormat:@"%@|%@",objLessons.Studentid,objLessons.tbid]])
            {
                [arrSelectStudentIds addObject:[NSString stringWithFormat:@"%@|%@",objLessons.Studentid,objLessons.tbid]];
            }
        }
    }
    else
    {
        DrivesTurns *objLessons = [arrDivesSelect objectAtIndex:indexPath.row];
        cell.btnAdd.tag = indexPath.row;
        cell.btnEdO.tag = arrDivesSelect.count + indexPath.row;
        [cell setSwimCampsDataList:objLessons];
        
        NSArray *arr1 = [dicSelectSIds valueForKey:studentName];
        NSArray *arr2 = [dicSelectEDIds valueForKey:studentName];
        
        NSString *strId = [arrStudentID objectAtIndex:[arrStudentName indexOfObject:studentName]];
        if ([arr1 containsObject:[NSString stringWithFormat:@"%@:%@",strId,objLessons.SessionID]])
        {
            cell.btnAdd.selected = YES;
            if (![arrSelectSessionID containsObject:[NSString stringWithFormat:@"%@:%@",strId,objLessons.SessionID]])
            {
                [arrSelectSessionID addObject:[NSString stringWithFormat:@"%@:%@",strId,objLessons.SessionID]];
            }
        }
        if ([arr2 containsObject:[NSString stringWithFormat:@"%@:%@",objLessons.Studentid,objLessons.EarlyDropOffID]])
        {
            cell.btnEdO.selected = YES;
            if (![arrSelectEarlyDropOffID containsObject:[NSString stringWithFormat:@"%@:%@",objLessons.Studentid,objLessons.EarlyDropOffID]])
            {
                [arrSelectEarlyDropOffID addObject:[NSString stringWithFormat:@"%@:%@",strId,objLessons.EarlyDropOffID]];
            }
        }
    }
    return  cell;
}

-(void)selectStudentListAtIndex:(NSInteger)index andSelectCell:(NSString *)strSelectedCell
{
    NSInteger idx = [arrStudentName indexOfObject:studentName];
    [scroll_header viewWithTag:idx+1].layer.borderColor = [[UIColor clearColor]CGColor];
    
    if (![_strprogramid isEqualToString:@"4"])
    {
        DrivesTurns *objDrives = [arrDivesSelect objectAtIndex:index];
        if ([arrSelectStudentIds containsObject:[NSString stringWithFormat:@"%@|%@",objDrives.Studentid,objDrives.tbid]]) {
            [arrSelectStudentIds removeObject:[NSString stringWithFormat:@"%@|%@",objDrives.Studentid,objDrives.tbid]];
        }
        else{
            [arrSelectStudentIds addObject:[NSString stringWithFormat:@"%@|%@",objDrives.Studentid,objDrives.tbid]];
        }
        [dicSelectIds setValue:arrSelectStudentIds forKey:studentName];
    }
    else
    {
        NSInteger idx = 0;
        NSString *strId = [arrStudentID objectAtIndex:[arrStudentName indexOfObject:studentName]];
        
        if (index < arrDivesSelect.count) {
            idx = index;
            
            DrivesTurns *objDrives = [arrDivesSelect objectAtIndex:idx];
            if ([arrSelectSessionID containsObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.SessionID]]) {
                [arrSelectSessionID removeObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.SessionID]];
            }
            else{
                [arrSelectSessionID addObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.SessionID]];
            }
            [dicSelectSIds setValue:arrSelectSessionID forKey:studentName];
        }
        else{
            idx = index - arrDivesSelect.count;
            
            DrivesTurns *objDrives = [arrDivesSelect objectAtIndex:idx];
            if ([arrSelectEarlyDropOffID containsObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.EarlyDropOffID]]) {
                [arrSelectEarlyDropOffID removeObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.EarlyDropOffID]];
            }
            else{
                [arrSelectEarlyDropOffID addObject:[NSString stringWithFormat:@"%@:%@",strId,objDrives.EarlyDropOffID]];
            }
            [dicSelectEDIds setValue:arrSelectEarlyDropOffID forKey:studentName];
        }
    }
}

- (IBAction)onClickContinueBtn:(id)sender {
    
    DivesSummaryViewController *viewDivesSummary = [[DivesSummaryViewController alloc] initWithNibName:@"DivesSummaryViewController" bundle:nil];
    viewDivesSummary.arrStudentID = [[NSMutableArray alloc]init];
    viewDivesSummary.arrStuSessID = [[NSMutableArray alloc]init];
    viewDivesSummary.arrStuEOID = [[NSMutableArray alloc]init];
    
    int i = 0;
    for (UIView *v in scroll_header.subviews) {
        v.layer.borderColor = [[UIColor clearColor]CGColor];
    }
    
    for (NSString *str in arrStudentName)
    {
        if (![_strprogramid isEqualToString:@"4"])
        {
            NSInteger idx = [arrStudentName indexOfObject:str];
            if(((NSArray *)[dicSelectIds valueForKey:str]).count == 0)
            {
                [scroll_header scrollRectToVisible:[scroll_header viewWithTag:idx+1].frame animated:YES];
                [scroll_header viewWithTag:idx+1].layer.borderColor = [[UIColor redColor]CGColor];
                [scroll_header viewWithTag:idx+1].layer.borderWidth = 1.0f;
                //                CGPoint point =  CGPointMake(idx < arrStudentName.count - 1 ? (idx * scroll_header.subviews[0].frame.size.width) : ((idx - 1) * scroll_header.subviews[0].frame.size.width),0);
                //                [scroll_header setContentOffset:CGPointMake((idx == 0 ? 0 : point.x),point.y) animated:YES];
                
                if (btnTemp == nil) {
                    btnTemp = ((UIButton *)[scroll_header viewWithTag:idx+1]);
                }
                [self btnSelectStudent:btnTemp];
                [CommonClass showToastMsg:ChooseSSession];
                btnTemp = nil;
                return;
            }
            else
            {
                [viewDivesSummary.arrStudentID addObjectsFromArray:((NSArray *)[dicSelectIds valueForKey:str])];
            }
        }
        else
        {
            NSInteger idx = [arrStudentName indexOfObject:str];
            if(((NSArray *)[dicSelectSIds valueForKey:str]).count == 0)
            {
                [scroll_header scrollRectToVisible:[scroll_header viewWithTag:idx+1].frame animated:YES];
                [scroll_header viewWithTag:idx+1].layer.borderColor = [[UIColor redColor]CGColor];
                [scroll_header viewWithTag:idx+1].layer.borderWidth = 1.0f;
                //                CGPoint point =  CGPointMake(idx < arrStudentName.count - 1 ? (idx * scroll_header.subviews[0].frame.size.width) : ((idx - 1) * scroll_header.subviews[0].frame.size.width),0);
                //                [scroll_header setContentOffset:CGPointMake((idx == 0 ? 0 : point.x),point.y) animated:YES];
                
                if (btnTemp == nil) {
                    btnTemp = ((UIButton *)[scroll_header viewWithTag:idx+1]);
                }
                [self btnSelectStudent:btnTemp];
                [CommonClass showToastMsg:ChooseSession];
                btnTemp = nil;
                return;
            }
            else
            {
                if (![viewDivesSummary.arrStudentID containsObject:[NSString stringWithFormat:@"%@:%@",[arrStudentID objectAtIndex:i],str]])
                {
                    [viewDivesSummary.arrStudentID addObject:[NSString stringWithFormat:@"%@:%@",[arrStudentID objectAtIndex:i],str]];
                }
                [viewDivesSummary.arrStuSessID addObjectsFromArray:((NSArray *)[dicSelectSIds valueForKey:str])];
                [viewDivesSummary.arrStuEOID addObjectsFromArray:((NSArray *)[dicSelectEDIds valueForKey:str])];
            }
            i++;
        }
    }
    viewDivesSummary.strprogramid = _strprogramid;
    viewDivesSummary.strTitle = _strTitle;
    
    if ([_strprogramid isEqualToString:@"5"]){
        
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN] forKey:@"Token"];
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:BASKETID] forKey:@"basketid"];
        [params setObject:[[NSUserDefaults standardUserDefaults] valueForKey:SITEID] forKey:@"siteid"];
        [params setObject:[viewDivesSummary.arrStudentID componentsJoinedByString:@","] forKey:@"strStuList"];
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [manager POST:GetDivesandStep3_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"Responce Login %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                [self.navigationController pushViewController:viewDivesSummary animated:YES];
            }
            else
            {
                if ([[responseObject safeObjectForKey:@"StudentSessionList"] containsString:@"-1"]) {
                    [CommonClass showToastMsg:CapacityFull];
                    
                }else{
                    [CommonClass showToastMsg:[responseObject safeObjectForKey:@"StudentSessionList"]];
                }
            }
            
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
    else{
        [self.navigationController pushViewController:viewDivesSummary animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
