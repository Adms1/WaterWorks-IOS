//
//  MyCartCell.h
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListMyCart.h"

@interface MyCartCell : UITableViewCell
{
    IBOutlet UILabel *lblPrivate;
    IBOutlet UILabel *lblPackage;
    IBOutlet UILabel *lblPrice;
    IBOutlet UILabel *lblEntryDate;
    IBOutlet UILabel *lblSwimType;
    IBOutlet UILabel *lblStudentName;
    IBOutlet UILabel *lblLocation;
}
@property (nonatomic , strong) IBOutlet UIButton *btnDelete;
-(void)setListOfCartData1:(ListMyCart*)objListCart;
-(void)setListOfCartData2:(ListMyCart*)objListCart;
@end
