//
//  DrivesTurnsViewController.h
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectLocationViewController.h"
#import "DrivesTurnCell.h"
#import "AFNetworking.h"

@interface DrivesTurnsViewController : UIViewController<LocationDelegate,SelectStudentDelegate>

{
    IBOutlet UITextView *txtInstruction;
    IBOutlet UILabel *lblTesting;
    IBOutlet UITableView *tblDrivesList;
    IBOutlet UIButton *btnSelectSite, *btnHome;
    
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    NSMutableArray *arrLocationList;
    NSMutableArray *arrStudentList;
    
    NSMutableArray *arrSelectStudentName;
    NSMutableArray *arrSelectStudentID;
    NSString *strSiteId;
}

@property (nonatomic , strong) NSString *strprogramid;
@property (nonatomic , strong) NSString *strTitle;

@end
