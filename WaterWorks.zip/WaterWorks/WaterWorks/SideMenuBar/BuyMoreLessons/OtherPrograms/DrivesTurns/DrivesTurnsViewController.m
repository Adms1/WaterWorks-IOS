//
//  DrivesTurnsViewController.m
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DrivesTurnsViewController.h"
#import "DrivesSessionsViewController.h"
#import "CommonClass.h"
#import "Location.h"
#import "StudentList.h"
#import "AppDelegate.h"
#import "CustomTabbar.h"
#import "NIDropDown.h"

@interface DrivesTurnsViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    UIButton *btn;
}
@end

@implementation DrivesTurnsViewController

@synthesize strprogramid;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strprogramid forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:programInstruction_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                txtInstruction.text = [dict safeObjectForKey:@"Instruction"];
                [txtInstruction setTextContainerInset:UIEdgeInsetsMake(0, 0, 0, 0)];
                
                btn = [[UIButton alloc]initWithFrame:CGRectOffset(btnSelectSite.frame, 0, 0)];
                [btn addTarget:self action:@selector(onClickSelectLocationBtn:) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:btn];
                
                [self setLocationDataList];
            }
        }else{
            [self setLocationDataList];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
    lblTesting.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    lblTesting.layer.borderWidth = 0.5f;
    
    arrSelectStudentName = [[NSMutableArray alloc] init];
    arrSelectStudentID = [[NSMutableArray alloc] init];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:[[_strTitle componentsSeparatedByString:@"/"] lastObject] :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setLocationDataList
{
    NSString *weburl;
    
    if ([strprogramid isEqualToString:@"5"]){
        weburl = DrivesTutns_Url;
        
    }
    else if ([strprogramid isEqualToString:@"6"]){
        weburl = GuardPrep_Url;
        
    }
    else if ([strprogramid isEqualToString:@"8"] || [strprogramid isEqualToString:@"7"]){
        
        weburl = MeritBadges_Url;
    }
    else if ([strprogramid isEqualToString:@"9"]) {
        weburl = WaterPolo_Url;
        
    }
    else if ([strprogramid isEqualToString:@"10"]){
        weburl = Get_GirlsScoutSiteList_Url;
        
    }
    else{   // strprogramid  = 4
        weburl = Get_SiteWiseSwimCampSessionList_Url;
    }
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrLocationList = [[NSMutableArray alloc] init];
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:[weburl isEqualToString:Get_SiteWiseSwimCampSessionList_Url] ? @"SitesFlgList" : @"Sites"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"SiteName"];
                    objLocation.siteid = [dict valueForKey:@"SiteID"];
                    
                    [arrLocationList addObject:objLocation];
                }
                
                if (arrLocation.count == 1) {
                    
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    strSiteId = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    
                    [self setPriceInfoList];
                    [btnSelectSite setTitle:strTitle forState:UIControlStateNormal];
                    
                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                    
                    [userDefault setObject:strSiteId forKey:SITEID];
                }
            }
            
            if ([strprogramid isEqualToString:@"5"]){
                [self setStudentList:@"Dives and Turns Clinic"];
                
            }else if ([strprogramid isEqualToString:@"6"]){
                [self setStudentList:@"Jr. Guard Prep"];
            }
            else if ([strprogramid isEqualToString:@"8"] || [strprogramid isEqualToString:@"7"]){
                
                [self setStudentList:@"Lifesaving/Swimming Merit Badges"];
                
            }else if ([strprogramid isEqualToString:@"9"]) {
                [self setStudentList:@"Water Polo Conditioning"];
                
            }else if ([strprogramid isEqualToString:@"10"]){
                [self setStudentList:@"Girl Scout Swim Programs"];
                
            }else{
                [self setStudentList:nil];
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)setStudentList :(NSString *)str {
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    [params setObject:strToken forKey:@"Token"];
    if (str != nil) {
        [params setObject:str forKey:@"ProgName"];
    }
    [params setObject:[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID] forKey:@"FamilyID"];
    
    NSLog(@"Params %@",params);
    
    [manager POST:(str != nil) ? Prg_Get_StudentList_Url : MakePurchase_SwimCamp_StuList_FamilyWise_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrStudentList = [[NSMutableArray alloc] init];
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:(str != nil) ? @"StudentList" : @"FinalArray"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    StudentList *objStudent = [[StudentList alloc] init];
                    
                    objStudent.SFirstName = [dict valueForKey:@"StudentName"];
                    objStudent.StudentID = [dict valueForKey:@"Studentid"];
                    if (objStudent.StudentID.length == 0) {
                        objStudent.StudentID = [[dict valueForKey:@"StudentID"] stringValue];
                    }
                    
                    [arrStudentList addObject:objStudent];
                }
            }
            [tblDrivesList reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    //CGSize expectedLabelSize = [((UILabel *)viewHeader.subviews.lastObject).text sizeWithFont:((UILabel *)viewHeader.subviews.lastObject).font constrainedToSize:CGSizeMake(((UILabel *)viewHeader.subviews.lastObject).frame.size.width, CGFLOAT_MAX) lineBreakMode:NSLineBreakByWordWrapping]; // deprecated
    
    CGRect expectedLabelSize = [((UILabel *)viewHeader.subviews.lastObject).text boundingRectWithSize:CGSizeMake(((UILabel *)viewHeader.subviews.lastObject).frame.size.width, CGFLOAT_MAX)  options:NSStringDrawingUsesLineFragmentOrigin| NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:((UILabel *)viewHeader.subviews.lastObject).font} context:nil];
    
    [viewHeader layoutIfNeeded];
    return viewHeader.subviews.lastObject.frame.origin.y + expectedLabelSize.size.height + 8;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  viewFooter.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrStudentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"DrivesTurnCell";
    
    DrivesTurnCell *cell = (DrivesTurnCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DrivesTurnCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.delegate = self;
    cell.index = (int)indexPath.row;
    
    [cell setPrivetLessonPriceDataList:[arrStudentList objectAtIndex:indexPath.row]];
    
    if (arrSelectStudentID.count > 0)
    {
        StudentList *Slist = [arrStudentList objectAtIndex:indexPath.row];
        if ([arrSelectStudentID containsObject:Slist.StudentID])
        {
            cell.btnselect.selected = YES;
        }
    }
    return  cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    btn.frame = CGRectMake(btn.frame.origin.x, btnSelectSite.frame.origin.y - tblDrivesList.contentOffset.y, btn.frame.size.width, btn.frame.size.height);
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSelectSite :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    strSiteId = [[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx];
    [self setPriceInfoList];
}

- (IBAction)onClickContinueBtn:(id)sender {
    
    if (arrSelectStudentName.count > 0 && strSiteId != nil)
    {
        DrivesSessionsViewController *viewDrivesSessions = [[DrivesSessionsViewController alloc] initWithNibName:@"DrivesSessionsViewController" bundle:nil];
        viewDrivesSessions.strprogramid = strprogramid;
        viewDrivesSessions.arrStudentName = arrSelectStudentName;
        viewDrivesSessions.arrStudentID = arrSelectStudentID;
        viewDrivesSessions.strTitle = _strTitle;
        [self.navigationController pushViewController:viewDrivesSessions animated:YES];
    }
    else
    {
        if (strSiteId == nil)
        {
            [CommonClass showToastMsg:SiteSelection];
        }
        else
        {
            [CommonClass showToastMsg:OneChildSelection];
        }
    }
}

-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType
{
    strSiteId = strID;
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:strSiteId forKey:SITEID];
    
    [userDefault setObject:strType forKey:@"SiteName"];
    
    [btnSelectSite setTitle:strType forState:UIControlStateNormal];
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    [self setPriceInfoList];
}

-(void)setPriceInfoList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    if ([strSiteId isEqualToString:@""] || strSiteId == nil) {
        strSiteId = @"0";
    }
    [params setObject:strSiteId forKey:@"siteid"];
    [params setObject:strprogramid forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:PriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                lblTesting.text = [dict safeObjectForKey:@"Instruction"];
                
                NSMutableParagraphStyle *style =  [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
                style.alignment = NSTextAlignmentCenter;
                style.firstLineHeadIndent = 10.0f;
                style.headIndent = 10.0f;
                style.tailIndent = -10.0f;
                
                NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:lblTesting.text attributes:@{ NSParagraphStyleAttributeName : style}];
                lblTesting.attributedText = attrText;
            }
        }else{
            lblTesting.text = @"";
        }
        
        [tblDrivesList reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)selectStudentListAtIndex:(NSInteger)index andSelectCell:(NSString *)strSelectedCell
{
    StudentList *objStudent = [arrStudentList objectAtIndex:index];
    
    NSString *strSFirstName = [NSString stringWithFormat:@"%@",objStudent.SFirstName];
    NSString *strStuentID = [NSString stringWithFormat:@"%@",objStudent.StudentID];
    
    if ([strSelectedCell isEqualToString:@"Yes"]) {
        [arrSelectStudentName addObject:strSFirstName];
        [arrSelectStudentID addObject:strStuentID];
    }else{
        [arrSelectStudentName removeObject:strSFirstName];
        [arrSelectStudentID removeObject:strStuentID];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
