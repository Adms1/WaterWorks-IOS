//
//  DivesSessionsCell.m
//  WaterWorks
//
//  Created by Darshan on 07/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DivesSessionsCell.h"

@implementation DivesSessionsCell

@synthesize btnselect;
@synthesize delegate;
@synthesize index;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    viewBack.layer.borderColor = [UIColor grayColor].CGColor;
    viewBack.layer.borderWidth = 0.5f;
}

-(void)setSwimCampsDataList:(DrivesTurns*)objSwimCamps
{
    _lblSessionType.text = objSwimCamps.Description;
    lblStartDate.text = [NSString stringWithFormat:@"Start Date:%@",objSwimCamps.startdate];
    _lblEndDate.text = [NSString stringWithFormat:@"End Date:%@",objSwimCamps.enddate];
    lblUnitPrice.text = [NSString stringWithFormat:@"UnitPrice:$%.02f",[objSwimCamps.unitprice floatValue]];
}

-(void)setLessonPriceDataList:(DrivesTurns*)objStudants
{
    lblParticipant.text = objStudants.FullName;
    lblSession.text = objStudants.tbid;
    lblStartDate.text = objStudants.startdate;
    lblUnitPrice.text = objStudants.unitprice;
    lblStartTime.text = objStudants.Time;
    lblSite.attributedText = [self getAttributedString:[NSString stringWithFormat:@"Site: %@",objStudants.sitename] :@"Site:"];
    lblDescription.attributedText = [self getAttributedString:[NSString stringWithFormat:@"Description: %@",objStudants.sessionname] :@"Description:"];
    lblRemark.attributedText = [self getAttributedString:[NSString stringWithFormat:@"Remark: %@",objStudants.Remark] :@"Remark:"];
    if ([objStudants.alreadyshopped isEqualToString:@"1"]) {
        [btnselect setHidden:YES];
    }
}

-(NSMutableAttributedString *)getAttributedString:(NSString *)str :(NSString *)subStr
{
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithString:str];
    NSRange range = [str rangeOfString:subStr options:NSCaseInsensitiveSearch];
    [text addAttribute:NSFontAttributeName
                 value:FONT_Bold(12)
                 range:range];
    return text;
}

-(void)setAddToCartDataList:(AddCart*)objAddCart
{
    lblParticipant.text = objAddCart.StudentName;
    lblSession.text = objAddCart.Sess;
    lblStartDate.text = objAddCart.Date;
    _lbl.hidden = YES;
    lblUnitPrice.text = objAddCart.Price;
    lblStartTime.text = objAddCart.Time;
    lblSite.attributedText = [self getAttributedString:[NSString stringWithFormat:@"Site: %@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SiteName"]] :@"Site:"];
    lblDescription.attributedText = [self getAttributedString:[NSString stringWithFormat:@"Description: %@",objAddCart.Description] :@"Description:"];
    lblRemark.text = @"";
}

-(void)setAddToCartSwimCapsList:(NSDictionary *)dic
{
    lblDescription.text = [NSString stringWithFormat:@"Description:%@",dic[@"Description"]];
    lblStartDate.text = [NSString stringWithFormat:@"Start Date:%@",dic[@"StartDate"]];
    _lblEndDate.text = [NSString stringWithFormat:@"End Date:%@",dic[@"EndDate"]];
    lblUnitPrice.text = [NSString stringWithFormat:@"Price:$%@",dic[@"Cost"]];
    lblSession.text = [NSString stringWithFormat:@"Session #:%@",dic[@"SessionID"]];
    _lblType.text = [NSString stringWithFormat:@"Early DropOff:%@",dic[@"Type"]];
    if ([dic[@"Type"] isEqualToString:@"Yes"]) {
        [_lblType setTextColor:[UIColor colorWithRed:(68.0/255.0) green:(157.0/255.0) blue:(64.0/255.0) alpha:1.0]];
    }else{
        [_lblType setTextColor:[UIColor blackColor]];
    }
}

-(void)setExtraSwimCapsList:(NSDictionary *)dic
{
    _lblSum.text = [NSString stringWithFormat:@"$%@",dic[@"SumValue"]];
    _lblEDOF.text = [NSString stringWithFormat:@"$%@",dic[@"DropOffValue"]];
    _lblRegisterDis.text = [NSString stringWithFormat:@"%@",dic[@"Discount"]];
    _lblSubTotal.text = [NSString stringWithFormat:@"$%@",dic[@"SubTotalValue"]];
}

- (IBAction)onClickSelectBtn:(id)sender {
    
    if ([btnselect isSelected]) {
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:index andSelectCell:@"No"];
        }
        btnselect.selected = NO;
    }else{
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:index andSelectCell:@"Yes"];
        }
        btnselect.selected = YES;
    }
}

- (IBAction)onClickSelectionBtn:(UIButton *)sender {
    
    if ([sender isSelected]) {
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:sender.tag andSelectCell:@"No"];
        }
        sender.selected = NO;
    }else{
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:sender.tag andSelectCell:@"Yes"];
        }
        sender.selected = YES;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
