//
//  DivesSessionsCell.h
//  WaterWorks
//
//  Created by Darshan on 07/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentList.h"
#import "DrivesTurns.h"
#import "AddCart.h"

@protocol SelectStudentSessionsDelegate <NSObject>

@optional
-(void)selectStudentListAtIndex:(NSInteger)index andSelectCell:(NSString *)strSelectedCell;

@end

@interface DivesSessionsCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
    
    //---cell - 1
    IBOutlet UILabel *lblParticipant;
    IBOutlet UILabel *lblSession;
    IBOutlet UILabel *lblStartDate;
    IBOutlet UILabel *lblSite;
    IBOutlet UILabel *lblRemark;
    IBOutlet UILabel *lblDescription;
    IBOutlet UILabel *lblStartTime;
    IBOutlet UILabel *lblUnitPrice;
}

@property (assign, nonatomic) id <SelectStudentSessionsDelegate> delegate;

@property (nonatomic , strong) IBOutlet UIButton *btnselect;
@property (nonatomic , strong) IBOutlet UILabel *lbl;


//Integer
@property (nonatomic) int index;

-(void)setLessonPriceDataList:(DrivesTurns*)objStudants;
-(void)setAddToCartDataList:(AddCart*)objAddCart;
-(void)setSwimCampsDataList:(DrivesTurns*)objSwimCamps;
-(void)setAddToCartSwimCapsList:(NSDictionary *)dic;
-(void)setExtraSwimCapsList:(NSDictionary *)dic;

//---cell - 2
@property (nonatomic , strong) IBOutlet UILabel *lblSessionType;
@property (nonatomic , strong) IBOutlet UILabel *lblEndDate;
@property (nonatomic , strong) IBOutlet UIButton *btnAdd;
@property (nonatomic , strong) IBOutlet UIButton *btnEdO;

//---cell - 3
@property (nonatomic , strong) IBOutlet UILabel *lblType;

//---cell - 4
@property (nonatomic , strong) IBOutlet UILabel *lblSum;
@property (nonatomic , strong) IBOutlet UILabel *lblEDOF;
@property (nonatomic , strong) IBOutlet UILabel *lblRegisterDis;
@property (nonatomic , strong) IBOutlet UILabel *lblSubTotal;

@end
