//
//  DivesSummaryViewController.h
//  WaterWorks
//
//  Created by Darshan on 07/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DivesSessionsCell.h"
#import "DrivesTurns.h"
#import "MyCartViewController.h"

@interface DivesSummaryViewController : UIViewController<SelectStudentSessionsDelegate>

{
    IBOutlet UITableView *tblSessionList;
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter1;
    IBOutlet UIView *viewFooter2;
    IBOutlet UIView *viewBack;
    
    IBOutlet UILabel *lblTotalChildrenReg;
    IBOutlet UILabel *lblTotalSessionsEnter;
    IBOutlet UILabel *lblTotalSessionsPrice;
    IBOutlet UILabel *lblMultiSession;
    IBOutlet UILabel *lblOutStandingBalance;
    IBOutlet UILabel *lblStudentDiscount;
    IBOutlet UILabel *lblHeader;
    IBOutlet UIButton *btnHome;
    
    NSMutableArray *arrStudentSessionList;
    NSMutableArray *arrSelectSession;
    IBOutlet NSLayoutConstraint *Space;
}

@property (nonatomic , strong) NSMutableArray *arrStudentID;
@property (nonatomic , strong) NSMutableArray *arrStuSessID;
@property (nonatomic , strong) NSMutableArray *arrStuEOID;
@property (nonatomic , strong) NSString *strprogramid;
@property (nonatomic , strong) NSString *strTitle;

@end
