//
//  DrivesSessionsViewController.h
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DivesSessionsCell.h"
#import "DrivesTurns.h"

@interface DrivesSessionsViewController : UIViewController<SelectStudentSessionsDelegate>

{
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    IBOutlet UITableView *tblSessionsList;
    IBOutlet UILabel *lblHeader;
    IBOutlet UIButton *btnHome;
    
    NSMutableArray *arrDivesSelect;
    NSMutableArray *arrSelectStudentIds;
    NSMutableArray *arrSelectEarlyDropOffID;
    NSMutableArray *arrSelectSessionID;
    NSMutableDictionary *dicSelectIds;
    NSMutableDictionary *dicSelectSIds;
    NSMutableDictionary *dicSelectEDIds;
    
}

@property (nonatomic , strong) NSMutableArray *arrStudentName;
@property (nonatomic , strong) NSMutableArray *arrStudentID;
@property (nonatomic , strong) NSString *strprogramid;
@property (nonatomic , strong) NSString *strTitle;

@end
