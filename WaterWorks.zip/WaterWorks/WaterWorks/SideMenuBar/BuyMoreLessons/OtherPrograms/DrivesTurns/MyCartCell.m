//
//  MyCartCell.m
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MyCartCell.h"

#define GET_RANGE(c, a, b) ((c >= a) && (c <= b))
@implementation MyCartCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setListOfCartData1:(ListMyCart*)objListCart
{
    if ([objListCart.DeleteEblDble isEqualToString:@"0"]) {
        [_btnDelete setHidden:YES];
    }
    
    lblPrivate.text = [NSString stringWithFormat:@"%@ Lessons",objListCart.Item];
    if ([objListCart.Qty integerValue] >= [objListCart.Package integerValue])
    {
        lblPackage.text = [NSString stringWithFormat:@"%@ Lesson Package",objListCart.Qty];
    }
    else
    {
        lblPackage.text = [NSString stringWithFormat:@"%@ Lesson Package",objListCart.Package];
    }
    lblPrice.text = objListCart.Subtotal;
}
-(void)setListOfCartData2:(ListMyCart*)objListCart
{
    if ([objListCart.DeleteEblDble isEqualToString:@"0"]) {
        [_btnDelete setHidden:YES];
    }
    
    lblEntryDate.text = objListCart.ItemTypeName;
    if (GET_RANGE([objListCart.ItemTypeID integerValue], 33, 38))
    {
        lblEntryDate.text = objListCart.Item;
        lblStudentName.text = [NSString stringWithFormat:@"Student: %@",objListCart.StudentName];
        lblLocation.text = [NSString stringWithFormat:@"Location: %@",objListCart.Location];
    }
    else if ([objListCart.ItemTypeID integerValue] == 10) // Swim Camp
    {
        lblEntryDate.text = [NSString stringWithFormat:@"Date : %@ %@",[[objListCart.Item componentsSeparatedByString:@":"] lastObject],objListCart.Type];
        lblStudentName.text = [NSString stringWithFormat:@"Student: %@",objListCart.StudentName];
        lblLocation.text = [NSString stringWithFormat:@"Location: %@",objListCart.Location];
    }
    else if ([objListCart.ItemTypeID integerValue] == 13) // S.Camp
    {
        lblEntryDate.text = objListCart.Type;
        if ([lblEntryDate.text containsString:@"% Off"]) {
            lblStudentName.text = [NSString stringWithFormat:@"Student: %@",objListCart.StudentName];
            lblLocation.text = [NSString stringWithFormat:@"Location: %@",objListCart.Location];
        }else{
            lblLocation.text = @"";
            lblStudentName.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
            lblStudentName.textColor = [UIColor colorWithRed:(142.0/255.0) green:(142.0/255.0) blue:(142.0/255.0) alpha:1.0];
        }
    }
    else if ([objListCart.ItemTypeID integerValue] == 7 || [objListCart.ItemTypeID integerValue] == 8) // Monthly Lap Swim & Family Swim Night
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@ %@",objListCart.Item,[objListCart.Item containsString:@"Family Swim"] ? @"Night" : @""];
        lblStudentName.text = objListCart.Package;
        lblLocation.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
    }
    else if ([objListCart.ItemTypeID integerValue] == 4 || [objListCart.ItemTypeID integerValue] == 3) // Water Aerobics & Lap Swim
    {
        if ([objListCart.ItemTypeID integerValue] == 4) {
            lblEntryDate.text = objListCart.Item;
        }else{
            lblEntryDate.text = objListCart.ItemTypeName;
        }
        lblStudentName.text = [NSString stringWithFormat:@"Location: %@",objListCart.Location];
        lblLocation.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
    }
    else if ([objListCart.ItemTypeID integerValue] == 14) // Swim Comp
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@\n%@",objListCart.Item,objListCart.ItemTypeName];
        lblStudentName.text = [NSString stringWithFormat:@"Student: %@",objListCart.StudentName];
        lblLocation.text = [NSString stringWithFormat:@"Location: %@",objListCart.Location];
    }
    else if ([objListCart.ItemTypeID integerValue] == 40) // Thermal Suits
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@ %@",objListCart.Item,objListCart.ItemTypeName];
        NSArray *arr = [objListCart.Description componentsSeparatedByString:@","];
        if (arr.count > 1) {
            lblStudentName.text = [NSString stringWithFormat:@"Color: %@\nSize: %@",[[[arr objectAtIndex:1] componentsSeparatedByString:@":"] firstObject],[[[arr objectAtIndex:2] componentsSeparatedByString:@":"] firstObject]];
        }
        lblLocation.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
    }
    else if ([lblEntryDate.text containsString:@"Retail Product"])
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@ %@",objListCart.Item,objListCart.ItemTypeName];
        lblStudentName.text = [NSString stringWithFormat:@"%@ Lesson Package",objListCart.Package];
        lblLocation.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
    }
    else if ([objListCart.ItemTypeID integerValue] == 6) // Swim Team
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@ %@",objListCart.Item,objListCart.ItemTypeName];
        lblStudentName.text = [NSString stringWithFormat:@"%@ Lesson Package",objListCart.Package];
        lblLocation.text = [NSString stringWithFormat:@"Student: %@",objListCart.StudentName];
    }
    else
    {
        lblEntryDate.text = [NSString stringWithFormat:@"%@ %@",objListCart.Item,objListCart.ItemTypeName];
        lblStudentName.text = [NSString stringWithFormat:@"%@ Lesson Package",objListCart.Package];
        lblLocation.text = [NSString stringWithFormat:@"Qty: %@",objListCart.Qty];
    }
    lblPrice.text = objListCart.Subtotal;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
