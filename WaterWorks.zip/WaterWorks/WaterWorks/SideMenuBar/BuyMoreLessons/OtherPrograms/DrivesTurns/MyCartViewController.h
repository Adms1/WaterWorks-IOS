//
//  MyCartViewController.h
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCartViewController : UIViewController
{
    IBOutlet UITableView *tblMyCartList;
    IBOutlet UITextField *txtPromoCode;
    IBOutlet UILabel *lblSubTotal;
    IBOutlet UILabel *lblTotal;
    IBOutlet UIView *viewFooter;
    IBOutlet UIView *vf1,*vf2;
    IBOutlet UIButton *btnCart;
    IBOutlet UIButton *btnApply;
    IBOutlet UILabel *lblEmpty;
    
    IBOutlet UILabel *lblSalesTaxTitle;
    IBOutlet UILabel *lblSalesTax;

    IBOutlet UILabel *lblPromoTitle;
    IBOutlet UILabel *lblPromo;
    
    IBOutlet UILabel *lblTaxTitle;
    IBOutlet UILabel *lblTaxSum;
    
    IBOutlet UILabel *lblCreditNum;
    IBOutlet UIButton *btnHome;
    
    IBOutlet NSLayoutConstraint *s1,*s2;
    IBOutlet NSLayoutConstraint *t1,*t2;
    IBOutlet NSLayoutConstraint *p1,*p2;
}
@end
