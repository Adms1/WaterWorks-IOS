//
//  DrivesTurnCell.m
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DrivesTurnCell.h"

@implementation DrivesTurnCell

@synthesize delegate;
@synthesize index;
@synthesize lblTitle,btnselect;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    //viewBack.layer.borderColor = [UIColor lightGrayColor].CGColor;
    //viewBack.layer.borderWidth = 1.0f;
}

-(void)setPrivetLessonPriceDataList:(StudentList*)objStudants
{
    lblTitle.text = objStudants.SFirstName;
}
- (IBAction)onClickSelectBtn:(id)sender {
    
    if ([btnselect isSelected]) {
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:index andSelectCell:@"No"];
        }
        btnselect.selected = NO;
    }else{
        if (delegate &&[delegate respondsToSelector:@selector(selectStudentListAtIndex:andSelectCell:)]) {
            [delegate selectStudentListAtIndex:index andSelectCell:@"Yes"];
        }
        btnselect.selected = YES;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
