//
//  OtherViewController.h
//  WaterWorks
//
//  Created by Darshan on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WaterAerobcsViewController.h"
#import "LapSwimOptionsViewController.h"
#import "OtherCell.h"

@interface OtherViewController : UIViewController
{
    IBOutlet UITableView *tblOtherList;
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    NSMutableArray *arrOtherProgramList;
    
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnAddToCart;
    
}
@end
