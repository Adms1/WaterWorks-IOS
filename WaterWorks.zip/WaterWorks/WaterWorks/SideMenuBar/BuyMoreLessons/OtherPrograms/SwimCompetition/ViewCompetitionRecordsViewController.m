//
//  ViewCompetitionRecordsViewController.m
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ViewCompetitionRecordsViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "SwimScheduleCell.h"
#import "NIDropDown.h"
#import "CustomTabbar.h"

@interface ViewCompetitionRecordsViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSArray *arrViewRecords, *arrSwimMeetList, *arrEventName, *arrSites;
    NSString *strStrokeID, *strAgeId, *strSiteId;
}
@end

@implementation ViewCompetitionRecordsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    strStrokeID = strAgeId = strSiteId = @"0";
    
    tblViewRecords.estimatedRowHeight = 30.0f;
    tblViewRecords.rowHeight = UITableViewAutomaticDimension;
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewDidLayoutSubviews
{
    [self.view layoutIfNeeded];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
    
    [super viewDidLayoutSubviews];
    
    tblViewRecords.tableHeaderView = tblHeaderView;
    
    if (tblViewRecords.subviews.count == 2)
    {
        for (UIView *v in tblHeaderView.subviews)
        {
            if ([v isKindOfClass:[UIButton class]] && v.tag != 0)
            {
                ((UIButton *)v).imageEdgeInsets = UIEdgeInsetsMake(0, tblHeaderView.frame.size.width - 20 - 16, 0, 0);
                UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(v.frame.origin.x, v.frame.origin.y, tblHeaderView.frame.size.width - 20 - 16, v.frame.size.height)];
                btn.tag = v.tag;
                [tblViewRecords addSubview:btn];
                [btn addTarget:self action:@selector(btnSelectClicked:) forControlEvents:UIControlEventTouchUpInside];
            }
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
    
    [self Get_SiteListForFamilyPoolRecords];
}

-(void)Get_SiteListForFamilyPoolRecords
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Get_SiteListForFamilyPoolRecords_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrSites = [responseObject valueForKey:@"EmailPref"];
        }
        else
        {
            [((UIButton *)[tblHeaderView viewWithTag:1])        setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [((UIButton *)[tblHeaderView viewWithTag:1])        setEnabled:NO];
        }
        
        [self GetAgeGroupListForSwimMeet];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)GetAgeGroupListForSwimMeet
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             };
    
    [manager POST:GetAgeGroupListForSwimMeet_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrSwimMeetList = [responseObject valueForKey:@"AgeList"];
        }
        else
        {
            [((UIButton *)[tblHeaderView viewWithTag:2])        setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [((UIButton *)[tblHeaderView viewWithTag:2])        setEnabled:NO];
        }
        
        [self GetStudentEvents];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)GetStudentEvents
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"studentid":@"0",
                             };
    
    [manager POST:GetStudentEvents_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrEventName = [responseObject valueForKey:@"EventList"];
        }
        else
        {
            [((UIButton *)[tblHeaderView viewWithTag:3])        setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [((UIButton *)[tblHeaderView viewWithTag:3])        setEnabled:NO];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_GetPoolRecords:(NSString *)str_ageId :(NSString *)str_strokeId :(NSString *)str_siteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"agegroupid":str_ageId,
                             @"strokeid":str_strokeId,
                             @"siteid":str_siteId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_GetPoolRecords_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        arrViewRecords = [[NSArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrViewRecords = [responseObject valueForKey:@"EmailPref"];
            
            if (arrViewRecords.count == 0) {
                [CommonClass showToastMsg:NoRecrods];
            }
        }
        
        [tblViewRecords reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)btnSelectClicked:(UIButton *)sender
{
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    if (sender.tag == 1)
    {
        if (arrSites.count > 0) {
            [arr insertObject:@"-Select Location to Filter-" atIndex:0];
            [arr addObjectsFromArray:[arrSites valueForKey:@"SiteName"]];
        }
    }
    else if (sender.tag == 2)
    {
        if (arrSwimMeetList.count > 0) {
            [arr insertObject:@"-Select Age to Filter-" atIndex:0];
            [arr addObjectsFromArray:[arrSwimMeetList valueForKey:@"AgeGroup"]];
        }
    }
    else
    {
        if (arrEventName.count > 0) {
            [arr insertObject:@"-Select Stroke to Filter-" atIndex:0];
            [arr addObjectsFromArray:[arrEventName valueForKey:@"EventName"]];
        }
    }
    
    if(dropDown == nil) {
        CGFloat f = 250;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.tag = 1000;
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}
- (void)select:(UIButton *)sender :(NSInteger) idx
{
    ((UIButton *)[tblHeaderView viewWithTag:sender.tag]).titleLabel.text = sender.titleLabel.text;
    [sender setTitle:@"" forState:0];
    
    if (sender.tag == 1 && idx > 0)
    {
        strSiteId = [[arrSites valueForKey:@"SiteID"] objectAtIndex:idx-1];
    }
    else if (sender.tag == 2 && idx > 0)
    {
        strAgeId = [[arrSwimMeetList valueForKey:@"AgeGroupID"] objectAtIndex:idx-1];
    }
    else if (sender.tag == 3 && idx > 0)
    {
        strStrokeID = [[arrEventName valueForKey:@"EventID"] objectAtIndex:idx-1];
    }
    else if (sender.tag == 1 && idx == 0)
    {
        strSiteId = @"0";
    }
    else if (sender.tag == 2 && idx == 0)
    {
        strAgeId = @"0";
    }
    else
    {
        strStrokeID = @"0";
    }
    
    if ([strSiteId integerValue] == 0 && [strAgeId integerValue] == 0 && [strStrokeID integerValue] == 0)
    {
        [self clearFilter];
    }
    else
    {
        [self SwimCmpt_GetPoolRecords:strAgeId :strStrokeID :strSiteId];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

-(IBAction)btnClearFilter:(UIButton *)sender
{
    [self clearFilter];
}

-(void)clearFilter
{
    strAgeId = strStrokeID = strSiteId = @"0";
    
    arrViewRecords = [[NSArray alloc]init];
    [tblViewRecords reloadData];
    
    ((UIButton *)[tblHeaderView viewWithTag:1]).titleLabel.text = @"-Select Location to Filter-";;
    ((UIButton *)[tblHeaderView viewWithTag:2]).titleLabel.text = @"-Select Age to Filter-";;
    ((UIButton *)[tblHeaderView viewWithTag:3]).titleLabel.text = @"-Select Stroke to Filter-";
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return ((NSArray *)[arrViewRecords valueForKey:@"Events"]).count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ((NSArray *)[[arrViewRecords valueForKey:@"Events"] objectAtIndex:section]).count+1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblViewRecords.frame.size.width, 50)];
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 20, tblViewRecords.frame.size.width, 30)];
    lblSection.backgroundColor = [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0];
    lblSection.textColor = [UIColor blackColor];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [lblSection setText:[NSString stringWithFormat:@"  %@",[[arrViewRecords valueForKey:@"EventDescription"] objectAtIndex:section]]];
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    SwimScheduleCell *cell = (SwimScheduleCell *)[tableView dequeueReusableCellWithIdentifier:@"SwimScheduleCell2"];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SwimScheduleCell" owner:self options:nil];
        
        if (indexPath.row == 0)
        {
            cell = [nib objectAtIndex:4];
        }
        else
        {
            cell = [nib objectAtIndex:5];
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.layer.borderColor = [[UIColor grayColor]CGColor];
    cell.layer.borderWidth = 0.5f;
    
    if (indexPath.row > 0)
    {
        NSArray *array = [[[arrViewRecords valueForKey:@"Events"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row-1];
        cell.lblDate.text = [array valueForKey:@"EventDate"];
        cell.lblSwimmer.text = [array valueForKey:@"Swimmer"];
        cell.lblAge.text = [NSString stringWithFormat:@"%@",[array valueForKey:@"Age"]];
        cell.lblTime.text = [array valueForKey:@"MeetTime"];
    }
    return cell;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
