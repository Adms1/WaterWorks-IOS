//
//  RegisterViewController.h
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "FamilySwimCell.h"
#import "SelectLocationViewController.h"

@interface RegisterViewController : UIViewController<LocationDelegate>

{
    IBOutlet UITableView *tblSwimComprtitionList;
    
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    IBOutlet UIButton *btnSiteLocation;
    IBOutlet UIButton *btnHome;
    
    IBOutlet UILabel *lblInstruction;
    IBOutlet UILabel *lblMemberNonMember;
    IBOutlet UILabel *lblFees;
}

@property (nonatomic , strong) NSString *strSwimCopatitionProgramID;
@end
