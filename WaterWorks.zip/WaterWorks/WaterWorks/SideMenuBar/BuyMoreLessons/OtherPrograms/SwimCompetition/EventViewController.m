//
//  EventViewController.m
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "EventViewController.h"
#import "AppDelegate.h"
#import "EventCell.h"
#import "CommonClass.h"
#import "PreferenceViewController.h"
#import "CustomTabbar.h"

@interface EventViewController ()<CommonDelegate>
{
    NSInteger previousTag;
    NSString *studentName;
    NSArray *arrEvents;
    NSMutableArray *arrtemp ,*arrTempIndex;
    NSMutableDictionary *dicTempIndex;
    UIView *vStripe;
    UIButton *btnTemp;
}
@end

@implementation EventViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblEventList.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    SHARED_APPDELEGATE.dicTemp = [[NSMutableDictionary alloc]init];
    dicTempIndex = [[NSMutableDictionary alloc]init];
    arrtemp = [[NSMutableArray alloc]init];
    arrTempIndex = [[NSMutableArray alloc]init];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksEvents :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
    }
}

-(void)DynamicAddStudents
{
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:tblEventList :self];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
    [self SwimCmpt_Register_SwimMeetStep2FillData:[_arrStudentIds objectAtIndex:0]];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    if ([SHARED_APPDELEGATE.dicTemp valueForKey:[NSString stringWithFormat:@"Event_%@",studentName]] != nil)
    {
        arrtemp = [SHARED_APPDELEGATE.dicTemp valueForKey:[NSString stringWithFormat:@"Event_%@",studentName]];
        arrTempIndex = [dicTempIndex valueForKey:[NSString stringWithFormat:@"Index_%@",studentName]];
    }
    else
    {
        arrtemp = [[NSMutableArray alloc]init];
        arrTempIndex = [[NSMutableArray alloc]init];
    }
    
    arrEvents = [[NSArray alloc]init];
    [tblEventList reloadData];
    
    [self SwimCmpt_Register_SwimMeetStep2FillData:[_arrStudentIds objectAtIndex:sender.tag]];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        tblEventList.transform = CGAffineTransformMakeTranslation(tblEventList.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblEventList.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        tblEventList.transform = CGAffineTransformMakeTranslation(-tblEventList.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblEventList.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
}

-(void)SwimCmpt_Register_SwimMeetStep2FillData:(NSString *)childId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"ChildListArry":childId,
                             @"MeetdatetimeText":[[NSUserDefaults standardUserDefaults]valueForKey:@"MeetDate_Display"],
                             @"MeetdatetimeValue":[[NSUserDefaults standardUserDefaults]valueForKey:@"DateValue"],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:SwimCmpt_Register_SwimMeetStep2FillData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //NSLog(@"RESPONSE %@",responseObject);
        
        arrEvents = [[NSArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr = [responseObject safeObjectForKey:@"SwimMeetCheck2"];
            if (arr.count > 0) {
                arrEvents = [[arr valueForKey:@"EvantDetails"] objectAtIndex:0];
            }
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        [tblEventList reloadData];
        
        [tblEventList setContentOffset:CGPointZero animated:YES];
        [tblEventList scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat height = (self.view.frame.size.width * 55) / 320;
    return height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrEvents.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"EventCell";
    
    EventCell *cell = (EventCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"EventCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dic = [arrEvents objectAtIndex:indexPath.row];
    
    cell.lblEventName.text = [NSString stringWithFormat:@"%@ - %@",[dic valueForKey:@"StrokeType"],[dic valueForKey:@"Distance"]] ;
    cell.lblAge.text = [NSString stringWithFormat:@"Age: %@  Event #%@",[dic valueForKey:@"AgeGroup"],[dic valueForKey:@"Event"]] ;
    if ([dic[@"ControlType"] isEqualToString:@"TextBox"])
    {
        [cell.btnSelect setHidden:YES];
        [cell.lblRegister setHidden:NO];
    }
    else
    {
        cell.btnSelect.tag = indexPath.row;
        [cell.btnSelect addTarget:self action:@selector(btnSelect:) forControlEvents:UIControlEventTouchUpInside];
        
        if (arrTempIndex.count > 0 && [arrTempIndex containsObject:[NSNumber numberWithInteger:indexPath.row]])
        {
            [cell.btnSelect setSelected:YES];
            cell.btnSelect.superview.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
        }
        else
        {
            [cell.btnSelect setSelected:NO];
            cell.btnSelect.superview.backgroundColor = [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0];
        }}
    return  cell;
}

-(void)btnSelect:(UIButton *)sender
{
    [scroll_header viewWithTag:([SHARED_APPDELEGATE.arrStudentName indexOfObject:studentName]+1)*100].layer.borderColor = [[UIColor clearColor]CGColor];
    
    sender.selected = !sender.selected;
    NSDictionary *dic = [arrEvents objectAtIndex:sender.tag];
    if (sender.selected)
    {
        [arrtemp addObject:dic];
        [arrTempIndex addObject:[NSNumber numberWithInteger:sender.tag]];
        sender.superview.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
    }
    else
    {
        [arrtemp removeObject:dic];
        [arrTempIndex removeObject:[NSNumber numberWithInteger:sender.tag]];
        sender.superview.backgroundColor = [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0];
    }
    
    if (arrtemp.count > 0) {
        [SHARED_APPDELEGATE.dicTemp setObject:arrtemp forKey:[NSString stringWithFormat:@"Event_%@",studentName]];
        [dicTempIndex setObject:arrTempIndex forKey:[NSString stringWithFormat:@"Index_%@",studentName]];
    }
    else
    {
        [SHARED_APPDELEGATE.dicTemp removeObjectForKey:[NSString stringWithFormat:@"Event_%@",studentName]];
        [dicTempIndex removeObjectForKey:[NSString stringWithFormat:@"Index_%@",studentName]];
    }
    NSLog(@"%@",SHARED_APPDELEGATE.dicTemp);
}

- (IBAction)onClickNextBtn:(id)sender
{
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        if (![[SHARED_APPDELEGATE.dicTemp allKeys] containsObject:[NSString stringWithFormat:@"Event_%@",[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]]])
        {
            if (btnTemp == nil) {
                btnTemp = ((UIButton *)[scroll_header viewWithTag:i]);
            }
            [scroll_header viewWithTag:(i+1)*100].layer.borderColor = [[UIColor redColor]CGColor];
            [scroll_header viewWithTag:(i+1)*100].layer.borderWidth = 1.0f;
        }
    }
    
    if ([SHARED_APPDELEGATE.dicTemp allKeys].count == _arrStudentIds.count) {
        PreferenceViewController *pvc = [[PreferenceViewController alloc]initWithNibName:@"PreferenceViewController" bundle:nil];
        pvc.arrStudentIds = _arrStudentIds;
        [[self navigationController]pushViewController:pvc animated:YES];
    }else{
        [self btnSelectStudent:btnTemp];
        [CommonClass showToastMsg:OneEventSelection];
        
        btnTemp = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
