//
//  MonthPopup.m
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "MonthPopup.h"
#import "MonthCell.h"

@interface MonthPopup ()
{
    NSMutableArray *arrSelectedMonth;
    NSMutableArray *arrSelectedMonthId;
    NSMutableArray *arrSelectedIndex;
}
@end

@implementation MonthPopup

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrSelectedMonth = [[NSMutableArray alloc]init];
    arrSelectedMonthId = [[NSMutableArray alloc]init];
    arrSelectedIndex = [[NSMutableArray alloc]init];
    
    tblMonthList.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_arrMonthList count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"MonthCell";
    
    MonthCell *cell = (MonthCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MonthCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.btnMonth setTitle:[[_arrMonthList objectAtIndex:indexPath.row]valueForKey:@"MonthName"] forState:0];
    [cell.btnMonth addTarget:self action:@selector(btnSelection:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnMonth.tag = indexPath.row;
    
    if ([_arrSelectMonth containsObject:cell.btnMonth.titleLabel.text])
    {
        cell.btnMonth.selected = YES;
        arrSelectedMonth = [_arrSelectMonth mutableCopy];
        if (![arrSelectedIndex containsObject:[NSNumber numberWithInteger:indexPath.row]]) {
            [arrSelectedIndex addObject:[NSNumber numberWithInteger:indexPath.row]];
            [arrSelectedMonthId addObject:[[_arrMonthList objectAtIndex:indexPath.row]valueForKey:@"MonthID"]];
        }
    }
    else
    {
        cell.btnMonth.selected = NO;
    }
    return cell;
}

-(void)btnSelection:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if ([_arrSelectMonth containsObject:sender.titleLabel.text])
    {
        [arrSelectedMonth removeObject:sender.titleLabel.text];
        [arrSelectedIndex removeObject:[NSNumber numberWithInteger:sender.tag]];
        [arrSelectedMonthId removeObject:[[_arrMonthList objectAtIndex:sender.tag]valueForKey:@"MonthID"]];
    }
    else
    {
        [arrSelectedMonth addObject:sender.titleLabel.text];
        [arrSelectedIndex addObject:[NSNumber numberWithInteger:sender.tag]];
        [arrSelectedMonthId addObject:[[_arrMonthList objectAtIndex:sender.tag]valueForKey:@"MonthID"]];
    }
    _arrSelectMonth = arrSelectedMonth;
}

-(IBAction)btnDone:(UIButton *)sender
{
    NSArray* sortedMonth = [arrSelectedMonth sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSNumber* index1 = arrSelectedIndex[[arrSelectedMonth indexOfObjectIdenticalTo:obj1]];
        NSNumber* index2 = arrSelectedIndex[[arrSelectedMonth indexOfObjectIdenticalTo:obj2]];
        
        NSComparisonResult result = [index1 compare:index2];
        return result;
    }];
    
    NSArray* sortedMonthId = [arrSelectedMonthId sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSNumber* index1 = arrSelectedIndex[[arrSelectedMonthId indexOfObjectIdenticalTo:obj1]];
        NSNumber* index2 = arrSelectedIndex[[arrSelectedMonthId indexOfObjectIdenticalTo:obj2]];
        
        NSComparisonResult result = [index1 compare:index2];
        return result;
    }];
    
    [self.m_delegate Click:[sortedMonth mutableCopy] :[sortedMonthId mutableCopy]];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}


@end
