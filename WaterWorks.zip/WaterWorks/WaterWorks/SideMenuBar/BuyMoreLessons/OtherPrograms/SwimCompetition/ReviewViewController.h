//
//  ReviewViewController.h
//  WaterWorks
//
//  Created by Ankit on 04/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReviewViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UITableView *tblReviewList;
    IBOutlet UIView *viewFooter;
    IBOutlet UILabel *lblHeader;
    IBOutlet UIButton *btnHome;
    IBOutlet UIView *viewFlash;
}
@property(nonatomic,retain)NSArray *arrStudentIds;
@end
