//
//  SwimScheduleCell.h
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SwimScheduleCell : UITableViewCell
//---cell - 1
@property(nonatomic,retain)IBOutlet UILabel *lbleventNumber;
@property(nonatomic,retain)IBOutlet UILabel *lblstrokeDescription;

//---cell - 2
@property(nonatomic,retain)IBOutlet UILabel *lblGender;
@property(nonatomic,retain)IBOutlet UILabel *lblAge;

//---cell - 3
@property(nonatomic,retain)IBOutlet UILabel *lblDate;
@property(nonatomic,retain)IBOutlet UILabel *lblSwimmer;
@property(nonatomic,retain)IBOutlet UILabel *lblTime;

//---cell - 4
@property(nonatomic,retain)IBOutlet UILabel *lblEvent;
@property(nonatomic,retain)IBOutlet UILabel *lblPlacement;

//---cell - 5
@property(nonatomic,retain)IBOutlet UILabel *lblPlace;
@end
