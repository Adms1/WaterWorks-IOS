//
//  UpComingMeetViewController.h
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpComingMeetViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UILabel *lblSiteName, *lblMeetDate, *lblAddress, *lblChilds, *lblHeader, *lblMiddle, *lblBottom;
    IBOutlet UIButton *btnCheckIn, *btnResults, *btnSchedule, *btnRecord;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,assign)NSInteger indexValue;
@end
