//
//  CheckInViewController.m
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "UpcomingCheckInViewController.h"
#import "CustomTabbar.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "CheckInData.h"
#import "CheckInCell.h"

@interface UpcomingCheckInViewController ()<CheckCellDelegate,CommonDelegate>
{
    NSMutableArray *arrCheckIn;
    NSMutableDictionary *dic;
    NSMutableArray *arrIndex;
}
@end

@implementation UpcomingCheckInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblCheckIn.estimatedRowHeight = 172.0f;
    tblCheckIn.rowHeight = UITableViewAutomaticDimension;
    
    [self getCheckInData];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    if (SHARED_APPDELEGATE.isFromPrograms)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    else if (SHARED_APPDELEGATE.isFromSwim)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
    }
    else
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
    }
}


-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :@[@"Upcoming Meet",@"Register",@"Trophy Room"] :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)getCheckInData
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             };
    
    arrIndex = [[NSMutableArray alloc]init];
    arrCheckIn = [[NSMutableArray alloc]init];
    dic = [[NSMutableDictionary alloc]init];
    
    [manager POST:SwimCmpt_Get_check_in_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"CheckIn %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrFinalArray = [responseObject safeObjectForKey:@"SwimComp_CheckIN"];
            
            if ([arrFinalArray count] > 0)
            {
                int i = 0;
                for (NSDictionary *dict in arrFinalArray)
                {
                    CheckInData *checkIn = [[CheckInData alloc] init];
                    
                    checkIn.Time1 = [dict safeObjectForKey:@"Time1"];
                    checkIn.fullname = [dict safeObjectForKey:@"fullname"];
                    checkIn.listtbid = [dict safeObjectForKey:@"listtbid"];
                    checkIn.wu_checkin = [dict safeObjectForKey:@"wu_checkin"];
                    checkIn.wu_description = [dict safeObjectForKey:@"wu_description"];
                    checkIn.wu_eventnumber = [dict safeObjectForKey:@"wu_eventnumber"];
                    checkIn.wu_groupdescription = [dict safeObjectForKey:@"wu_groupdescription"];
                    checkIn.wu_preference1 = [dict safeObjectForKey:@"wu_preference1"];
                    checkIn.wu_preference2 = [dict safeObjectForKey:@"wu_preference2"];
                    checkIn.wu_strokedescription = [dict safeObjectForKey:@"wu_strokedescription"];
                    checkIn.wu_studentid = [dict safeObjectForKey:@"wu_studentid"];
                    checkIn.wu_swimmeetid = [dict safeObjectForKey:@"wu_swimmeetid"];
                    
                    NSString *pref1, *pref2;
                    if ([checkIn.wu_preference1 isEqualToString:@"2"]) {
                        pref1 = @"Yes";
                    }else{
                        pref1 = @"No";
                    }
                    
                    if ([checkIn.wu_preference2 isEqualToString:@"0"]) {
                        pref2 = @"Yes";
                    }else{
                        pref2 = @"No";
                    }
                    
                    [dic setObject:[NSString stringWithFormat:@"%@:%@:%@:%@:%@:%@:%@",[checkIn.wu_checkin isEqualToString:@"1"] ? @"True" : @"False" , checkIn.listtbid,checkIn.fullname,pref1,pref2,checkIn.wu_studentid,checkIn.wu_swimmeetid] forKey:[NSNumber numberWithInteger:i]];
                    
                    [arrCheckIn addObject:checkIn];
                    i++;
                }
            }
            else
            {
                [lblCheckIn setText:CheckInMsg];
                [btnCheckIn setHidden:YES];
            }
            [tblCheckIn reloadData];
        }
        else
        {
            [lblCheckIn setText:CheckInMsg];
            [btnCheckIn setHidden:YES];
            [CommonClass showToastMsg:[[[responseObject valueForKey:@"SwimComp_CheckIN"] valueForKey:@"Msg"] firstObject]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrCheckIn.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    CheckInCell *cell = (CheckInCell *)[tblCheckIn dequeueReusableCellWithIdentifier:@"CheckInCell" forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.c_delegate = self;
    CheckInData *data = [arrCheckIn objectAtIndex:indexPath.row];
    [cell getCheckInData:data :arrCheckIn.count :indexPath.row];
    
    if ([data.wu_checkin isEqualToString:@"1"]) {
        if (![arrIndex containsObject:[NSNumber numberWithInteger:indexPath.row]]) {
            [arrIndex addObject:[NSNumber numberWithInteger:indexPath.row]];
        }
    }
    
    if ([arrIndex containsObject:[NSNumber numberWithInteger:indexPath.row]])
    {
        [cell.btnCheck setSelected:YES];
    }
    return cell;
}
-(void)ChangePref1Pref2Value:(NSString *)str :(NSString *)str1 :(NSString *)str2 :(NSInteger)index
{
    CheckInData *data = [arrCheckIn objectAtIndex:index];
    if ([str isEqualToString:@"True"]) {
        if (![arrIndex containsObject:[NSNumber numberWithInteger:index]]) {
            [arrIndex addObject:[NSNumber numberWithInteger:index]];
        }
    }else{
        [arrIndex removeObject:[NSNumber numberWithInteger:index]];
    }
    
    [dic setObject:[NSString stringWithFormat:@"%@:%@:%@:%@:%@:%@:%@",str, data.listtbid,data.fullname,str1,str2,data.wu_studentid,data.wu_swimmeetid] forKey:[NSNumber numberWithInteger:index]];
}

-(IBAction)btnCheckInClicked:(UIButton *)sender
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    __block NSString *CheckInList = @"";
    [dic enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        CheckInList = [CheckInList stringByAppendingString:[NSString stringWithFormat:@"%@,",obj]];
    }];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"CheckInListArray":[CheckInList
                                                  substringToIndex:[CheckInList length]-1]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_Insert_checkinProceed_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"CheckIn %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [[self navigationController]popViewControllerAnimated:YES];
            
            [SHARED_APPDELEGATE hideLoadingView];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
