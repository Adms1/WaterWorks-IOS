//
//  ViewCompetitionScheduleViewController.m
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ViewCompetitionScheduleViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "SwimScheduleCell.h"
#import "CustomTabbar.h"

@interface ViewCompetitionScheduleViewController ()<CommonDelegate>
{
    NSString *strEstimateTime;
    NSArray *arrChildSchedule, *arrIndividuleMedly_Butterfly;
    NSMutableArray *arrEventnum;
}
@end

@implementation ViewCompetitionScheduleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

-(void)viewDidLayoutSubviews
{
    [self.view layoutIfNeeded];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}
-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
    
    [self SwimCmptSchedule_EstimatedDurationForEvent];
}

-(void)SwimCmptSchedule_EstimatedDurationForEvent
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"swimmeetid":_strSwimId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmptSchedule_EstimatedDurationForEven_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if (((NSArray *)[[responseObject valueForKey:@"EmailPref"] valueForKey:@"EstimatedTime"]).count > 0)
            {
                strEstimateTime = [[[[responseObject valueForKey:@"EmailPref"] valueForKey:@"IsUpcomingEvents"]objectAtIndex:0] isEqual:@0] ? @"" : [[[responseObject valueForKey:@"EmailPref"] valueForKey:@"EstimatedTime"]objectAtIndex:0];
            }
            [self SwimCmpt_EventListOfStudentByMeet];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_EventListOfStudentByMeet
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"swimmeetid":_strSwimId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    arrEventnum = [[NSMutableArray alloc]init];
    
    [manager POST:SwimCmpt_EventListOfStudentByMeet_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrChildSchedule = [responseObject valueForKey:@"EmailPref"];
            
            [self SwimCmpt_AllEventList];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_AllEventList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"swimmeetid":_strSwimId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_AllEventList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrIndividuleMedly_Butterfly = [responseObject valueForKey:@"EmailPref"];
        }
        
        [tblViewSchedule reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrChildSchedule.count > 0 ? arrChildSchedule.count + 6 : 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 0;
    }else if (section > 0 && section <= arrChildSchedule.count){
        return arrChildSchedule.count > 0 ? ((NSArray *)[[arrChildSchedule objectAtIndex:section-1]valueForKey:@"Events"]).count+1: 0;
    }else{
        return arrIndividuleMedly_Butterfly.count > 0 ? ((NSArray *)[[arrIndividuleMedly_Butterfly objectAtIndex:section-arrChildSchedule.count-1] valueForKey:@"Events"]).count+1 : 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 50;
    }else if (section == arrChildSchedule.count+1){
        return 60;
    }else{
        return 30;
    }
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(5, 0, tblViewSchedule.frame.size.width - 10, tableView.tableHeaderView.frame.size.height)];
    headerView.backgroundColor = [UIColor clearColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(section == arrChildSchedule.count+1 ? 0 : 5, section == arrChildSchedule.count+1 ? 5 : 0, tblViewSchedule.frame.size.width, section == 0 ? 25 : 30)];
    lblSection.backgroundColor = section == arrChildSchedule.count+1 ? [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0] : [UIColor clearColor];
    lblSection.textColor = [UIColor blackColor];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    
    if (section == 0 || section == arrChildSchedule.count+1)
    {
        [lblSection setText:section == 0 ? @"Competition Schedule" : @"  All Events"];
        
        //---
        UILabel *lblsubSection = [[UILabel alloc]initWithFrame:CGRectMake(5, section == 0 ? 25 : 35, tblViewSchedule.frame.size.width, 25)];
        lblsubSection.backgroundColor = [UIColor clearColor];
        lblsubSection.textColor = section == arrChildSchedule.count+1 ? [UIColor colorWithRed:(0.0/255.0) green:(60.0/255.0) blue:(111.0/255.0) alpha:1.0] : [UIColor blackColor];
        lblsubSection.font = section == 0 ? FONT_OpenSans(13) : FONT_Bold(13);
        lblsubSection.textAlignment = NSTextAlignmentLeft;
        [lblsubSection setText:section == 0 ? [NSString stringWithFormat:@"Estimated Duration: %@",strEstimateTime] : [NSString stringWithFormat:@"%@ %@",[[arrIndividuleMedly_Butterfly objectAtIndex:section-arrChildSchedule.count-1] valueForKey:@"StartTime"],[[arrIndividuleMedly_Butterfly objectAtIndex:section-arrChildSchedule.count-1] valueForKey:@"EventDescription"]]];
        [headerView addSubview:lblsubSection];
        
    }
    else if (section <= arrChildSchedule.count)
    {
        headerView.backgroundColor = [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0];
        [lblSection setText:arrChildSchedule.count > 0 ? [[arrChildSchedule objectAtIndex:section-1] valueForKey:@"StudentName"] : @""];
    }
    else
    {
        lblSection.textColor = [UIColor colorWithRed:(0.0/255.0) green:(60.0/255.0) blue:(111.0/255.0) alpha:1.0];
        [lblSection setText:[NSString stringWithFormat:@"%@ %@",[[arrIndividuleMedly_Butterfly objectAtIndex:section-arrChildSchedule.count-1] valueForKey:@"StartTime"],[[arrIndividuleMedly_Butterfly objectAtIndex:section-arrChildSchedule.count-1] valueForKey:@"EventDescription"]] ];
    }
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if (indexPath.section <= arrChildSchedule.count)
    {
        SwimScheduleCell *cell = (SwimScheduleCell *)[tableView dequeueReusableCellWithIdentifier:@"SwimScheduleCell"];
        cell = nil;
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SwimScheduleCell" owner:self options:nil];
            
            if (indexPath.row == 0)
            {
                cell = [nib objectAtIndex:0];
            }
            else
            {
                cell = [nib objectAtIndex:1];
            }
            
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.layer.borderColor = [[UIColor lightGrayColor]CGColor];
        cell.layer.borderWidth = 0.5f;
        if (indexPath.row > 0)
        {
            NSDictionary *dic = [[[arrChildSchedule objectAtIndex:indexPath.section-1] valueForKey:@"Events"]objectAtIndex:indexPath.row-1];
            cell.lbleventNumber.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EventNumber"]];
            cell.lblstrokeDescription.text = [NSString stringWithFormat:@"%@ - %@",[dic valueForKey:@"Description"],[dic valueForKey:@"StrockDescription"]];
            
            NSString *str = [[[[arrChildSchedule valueForKey:@"Events"] valueForKey:@"EventNumber"] objectAtIndex:indexPath.section-1]objectAtIndex:indexPath.row-1];
            if (![arrEventnum containsObject:[NSString stringWithFormat:@"%@",str]]) {
                [arrEventnum addObject:str];
            }
        }
        return cell;
    }
    else
    {
        SwimScheduleCell *cell = (SwimScheduleCell *)[tableView dequeueReusableCellWithIdentifier:@"SwimScheduleCell1"];
        cell = nil;
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SwimScheduleCell" owner:self options:nil];
            
            if (indexPath.row == 0)
            {
                cell = [nib objectAtIndex:2];
            }
            else
            {
                cell = [nib objectAtIndex:3];
            }
        }
        cell.layer.borderColor = [[UIColor lightGrayColor]CGColor];
        cell.layer.borderWidth = 0.5f;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.row > 0)
        {
            NSDictionary *dic = [[[arrIndividuleMedly_Butterfly objectAtIndex:indexPath.section-arrChildSchedule.count-1] valueForKey:@"Events"]objectAtIndex:indexPath.row-1];
            cell.lbleventNumber.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EventNumber"]];
            cell.lblAge.text = [dic valueForKey:@"Age"];
            cell.lblGender.text = [dic valueForKey:@"Gender"];
            cell.lblstrokeDescription.text = [dic valueForKey:@"StrokeDesc"];
            
            if ([arrEventnum containsObject:[NSNumber numberWithInteger:[[dic valueForKey:@"EventNumber"] integerValue]]])
            {
                cell.contentView.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
            }
        }
        return cell;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
