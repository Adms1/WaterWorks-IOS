//
//  PreferenceViewController.m
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PreferenceViewController.h"
#import "AppDelegate.h"
#import "AcknowledgementViewController.h"
#import "CustomTabbar.h"
#import "CommonClass.h"

@interface PreferenceViewController ()<CommonDelegate>
{
    UIView *vStripe;
    NSInteger previousTag;
    NSString *studentName;
    NSMutableDictionary *dic;
    UIButton *btnTemp;
}
@end

@implementation PreferenceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    dic = [[NSMutableDictionary alloc]init];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksPreferences :self :btnHome :nil :YES :self];
}

-(void)DynamicAddStudents
{
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:viewPreference :self];
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
    [l1 setText:[NSString stringWithFormat:@"Where should %@ start the race?",[[studentName componentsSeparatedByString:@" "] firstObject]]];
    [l2 setText:[NSString stringWithFormat:@"Should %@ swim next to the wall in an end lane?",[[studentName componentsSeparatedByString:@" "] firstObject]]];
    
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        viewPreference.transform = CGAffineTransformMakeTranslation(viewPreference.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            viewPreference.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        viewPreference.transform = CGAffineTransformMakeTranslation(-viewPreference.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            viewPreference.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    [self UpdatePreferenceView];
}

-(void)UpdatePreferenceView
{
    [l1 setText:[NSString stringWithFormat:@"Where should %@ start the race?",[[studentName componentsSeparatedByString:@" "] firstObject]]];
    [l2 setText:[NSString stringWithFormat:@"Should %@ swim next to the wall in an end lane?",[[studentName componentsSeparatedByString:@" "] firstObject]]];
    
    for (int  i = 1; i <= 2; i++)
    {
        for (UIView *v in [viewPreference viewWithTag:i*10].subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
            }
        }
    }
    
    for (NSString *key in dic)
    {
        if ([[[key componentsSeparatedByString:@"_"]lastObject] isEqualToString:studentName])
        {
            for (UIView *v in [viewPreference viewWithTag:[[[key componentsSeparatedByString:@"_"]firstObject] integerValue]].subviews)
            {
                if ([v isKindOfClass:[UIButton class]])
                {
                    if (v.tag == [[dic valueForKey:key]integerValue])
                    {
                        [((UIButton *)v)setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
                    }
                }
            }
        }
    }
}

-(IBAction)btnClicked:(UIButton *)sender
{
    [scroll_header viewWithTag:([SHARED_APPDELEGATE.arrStudentName indexOfObject:studentName]+1)*100].layer.borderColor = [[UIColor clearColor]CGColor];
    
    [self Reset:sender.superview];
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
    [dic setValue:[NSNumber numberWithInteger:sender.tag] forKey:[NSString stringWithFormat:@"%ld_%@",sender.superview.tag,studentName]];
}

-(void)Reset:(UIView *)v
{
    for (UIView *view in v.subviews) {
        if ([view isKindOfClass:[UIButton class]])
        {
            [((UIButton *)view)setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
        }
    }
}

- (IBAction)onClickNextBtn:(id)sender
{
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        for (int j = 1; j < 3; j++)
        {
            if (![[dic allKeys] containsObject:[NSString stringWithFormat:@"%d_%@",j*10,[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]]])
            {
                if (btnTemp == nil) {
                    btnTemp = ((UIButton *)[scroll_header viewWithTag:i]);
                }
                [scroll_header viewWithTag:(i+1)*100].layer.borderColor = [[UIColor redColor]CGColor];
                [scroll_header viewWithTag:(i+1)*100].layer.borderWidth = 1.0f;
            }
        }
    }
    
    if ([dic allKeys].count == SHARED_APPDELEGATE.arrStudentName.count*2)
    {
        AcknowledgementViewController *avc = [[AcknowledgementViewController alloc]initWithNibName:@"AcknowledgementViewController" bundle:nil];
        avc.arrStudentIds = _arrStudentIds;
        [[self navigationController]pushViewController:avc animated:YES];
    }
    else
    {
        [self btnSelectStudent:btnTemp];
        [CommonClass showToastMsg:SwimmerRaceBegin];
        btnTemp = nil;
    }
}
@end
