//
//  UpComingMeetViewController.m
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UpComingMeetViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "ViewCompetitionScheduleViewController.h"
#import "ViewCompetitionRecordsViewController.h"
#import "CustomTabbar.h"
#import "UpcomingCheckInViewController.h"
#import "ViewCompetitionResults.h"

@interface UpComingMeetViewController ()<CommonDelegate>
{
    NSArray *arr;
}
@end

@implementation UpComingMeetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _indexValue = [[[NSUserDefaults standardUserDefaults]valueForKey:@"CheckMeet"]integerValue];
    for (UIView *v in scroll_main.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            if (((UIButton *)v) != btnCheckIn) {
                v.layer.borderColor = [[UIColor grayColor]CGColor];
                v.layer.borderWidth = 0.5f;
            }
            
            if ((v.tag == 0 || v.tag == 1) && _indexValue == 2)
            {
                [[scroll_main viewWithTag:v.tag+10]setHidden:NO];
            }
            else if ((v.tag == 0 || v.tag == 1 || v.tag == 2) && _indexValue == 0)
            {
                [[scroll_main viewWithTag:v.tag+10]setHidden:NO];
            }
            else if (v.tag == 1 && _indexValue == 1)
            {
                [[scroll_main viewWithTag:v.tag+10]setHidden:NO];
            }
        }
    }
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    if (SHARED_APPDELEGATE.isFromPrograms)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    else if (SHARED_APPDELEGATE.isFromSwim)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
    }
    else
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
    }
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}
-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
    
    //[self SwimCmpt_CheckStudentMeetExist];
    [self SwimCmpt_Get_NextSwimCmpRegis];
}

-(void)SwimCmpt_CheckStudentMeetExist
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_CheckStudentMeetExist_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_Get_NextSwimCmpRegis
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_Get_NextSwimCmpRegis_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckinFlg"]isEqual:@0])
            {
                [[scroll_main viewWithTag:10]setHidden:NO];
                [btnCheckIn setTitle:@"You are Checked In" forState:0];
                lblMiddle.text = @"";
            }
            else if ([[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckinFlg"]isEqual:@1])
            {
                [btnCheckIn setTitle:@"Check In Now" forState:0];
                lblMiddle.text = @"Please Check In now.\n We look forward to seeing you there!";
            }
            else
            {
                [btnCheckIn setTitle:@"Check In" forState:0];
            }
            
            if ([[[[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"flgMeet"] componentsSeparatedByString:@"|"] firstObject]isEqualToString:@"0"])
            {
                lblHeader.text = @"You are not currently registered for any future swim competitions.";
                //                lblMiddle.text = @"You will be able to Check In on the day of the meet\n We look forward to seeing you there!";
                lblMiddle.text = @"";
            }
            else if ([[[[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"flgMeet"] componentsSeparatedByString:@"|"] firstObject]isEqualToString:@"1"])
            {
                lblHeader.text = @"You have a Swim Competition today!";
            }
            else
            {
                lblHeader.text = @"Your next Swim Competition is:";
                if ([[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckinFlg"]isEqual:@0])
                {
                    [btnCheckIn setTitle:@"Check In" forState:0];
                    lblMiddle.text = @"You will be able to Check In on the day of the meet\nWe look forward to seeing you there!";
                }
                else if ([[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckinFlg"]isEqual:@1])
                {
                    [btnCheckIn setTitle:@"Check In Now" forState:0];
                    lblMiddle.text = @"Please Check In now.\n We look forward to seeing you there!";
                }
            }
            
            if ([[[[[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"flgMeet"] componentsSeparatedByString:@"|"] lastObject]isEqualToString:@"1"])
            {
                [[scroll_main viewWithTag:11]setHidden:YES];
                [[scroll_main viewWithTag:11]setTag:13];
                
            }
            
            arr = [[responseObject valueForKey:@"EmailPref"]objectAtIndex:0];
            lblSiteName.text = [arr valueForKey:@"sitename"];
            lblAddress.text = [NSString stringWithFormat:@"%@\n%@ %@ %@", [arr valueForKey:@"Address"],[arr valueForKey:@"sitename"],[arr valueForKey:@"State"],[arr valueForKey:@"ZipCode"]];
            
            lblMeetDate.text = [arr valueForKey:@"MeetDate"];
            
            NSArray *array = [arr valueForKey:@"Students"];
            int  i = 0;
            lblChilds.text = @"";
            
            NSMutableAttributedString *combineString = [[NSMutableAttributedString alloc]init];
            for (NSString *str in [array valueForKey:@"StudentName"])
            {
                lblChilds.text = [NSString stringWithFormat:@"\n%@ is registered for %@ Events!",str,[[array valueForKey:@"MeetCount"] objectAtIndex:i]];
                
                NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc] initWithString:lblChilds.text];
                [mutableString addAttribute:NSFontAttributeName value:FONT_Bold(13) range:[lblChilds.text rangeOfString:str]];
                [mutableString addAttribute:NSFontAttributeName value:FONT_Bold(13) range:[lblChilds.text rangeOfString:[[[array valueForKey:@"MeetCount"] objectAtIndex:i] stringValue]]];
                
                if (i == 0) {
                    combineString = [mutableString mutableCopy];
                }else{
                    [combineString appendAttributedString:mutableString];
                }
                i++;
            }
            lblChilds.attributedText = combineString;
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnClicked:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UpcomingCheckInViewController *upcvc = [storyBoard instantiateViewControllerWithIdentifier:@"UpcomingCheckInViewController"];
        [[self navigationController]pushViewController:upcvc animated:YES];
    }
    else if (sender.tag == 1)
    {
        ViewCompetitionResults *vcr = [[ViewCompetitionResults alloc]initWithNibName:@"ViewCompetitionResults" bundle:nil];
        vcr.strSwimId = [arr valueForKey:@"swimmeetid"];
        [[self navigationController]pushViewController:vcr animated:YES];
    }
    else if (sender.tag == 2)
    {
        ViewCompetitionScheduleViewController *vcsvc = [[ViewCompetitionScheduleViewController alloc]initWithNibName:@"ViewCompetitionScheduleViewController" bundle:nil];
        vcsvc.strSwimId = [arr valueForKey:@"swimmeetid"];
        [[self navigationController]pushViewController:vcsvc animated:YES];
    }
    else if (sender.tag == 3)
    {
        ViewCompetitionRecordsViewController *vcrvc = [[ViewCompetitionRecordsViewController alloc]initWithNibName:@"ViewCompetitionRecordsViewController" bundle:nil];
        vcrvc.strSwimId = [arr valueForKey:@"swimmeetid"];
        [[self navigationController]pushViewController:vcrvc animated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
