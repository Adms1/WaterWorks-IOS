//
//  ViewCompetitionResults.h
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCompetitionResults : UIViewController
{
    IBOutlet UITableView *tblViewResults;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,retain)NSString *strSwimId;
@end
