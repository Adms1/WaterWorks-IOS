//
//  CheckInData.m
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CheckInData.h"

@implementation CheckInData
@synthesize fullname;
@synthesize wu_checkin;
@synthesize wu_studentid;
@synthesize wu_swimmeetid;
@synthesize wu_description;
@synthesize wu_eventnumber;
@synthesize wu_preference1;
@synthesize wu_preference2;
@synthesize wu_groupdescription;
@synthesize wu_strokedescription;
@synthesize description;
@synthesize Time1;
@synthesize listtbid;
@end
