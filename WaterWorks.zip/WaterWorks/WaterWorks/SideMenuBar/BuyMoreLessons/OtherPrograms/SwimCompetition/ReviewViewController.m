//
//  EventViewController.m
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ReviewViewController.h"
#import "AppDelegate.h"
#import "EventCell.h"
#import "CommonClass.h"
#import "PreferenceViewController.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"

@interface ReviewViewController ()<CommonDelegate>
{
    NSInteger previousTag;
    NSString *studentName ,*member;
    NSString *ChkChildListStp1, *ChkChilsWiseDtlStp2;
    UIView *vStripe;
}
@end

@implementation ReviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [lblHeader setText:[[[NSUserDefaults standardUserDefaults] valueForKey:@"HeaderData"] stringByReplacingOccurrencesOfString:@"|" withString:@"\n"]];
    tblReviewList.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    [self performSelector: NSSelectorFromString([NSString stringWithFormat:@"func%d",arc4random()%5])];
    
    double delayInSeconds = 2.5;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [viewFlash setHidden:YES];
        
        tblReviewList.transform = CGAffineTransformMakeTranslation(-tblReviewList.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblReviewList.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
    });
}

/*-(void)randomAnimation:(int)count
 {
 switch (count) {
 case 0:
 [self func1];
 break;
 
 case 1:
 [self func2];
 break;
 
 case 2:
 [self func3];
 break;
 
 case 3:
 [self func4];
 break;
 
 case 4:
 [self func5];
 break;
 
 default:
 [self randomAnimation:arc4random()%5];
 break;
 }
 }*/

-(void)func0
{
    viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(viewFlash.subviews[0].frame.size.width, 0);
    [UIView animateWithDuration:1.5 animations:^{
        viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, 0);
    }];
}

-(void)func1
{
    viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(-viewFlash.subviews[0].frame.size.width, 0);
    [UIView animateWithDuration:1.5 animations:^{
        viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, 0);
    }];
}

-(void)func2
{
    viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, self.view.frame.size.height);
    [UIView animateWithDuration:1.5 animations:^{
        viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, 0);
    }];
}

-(void)func3
{
    viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, -self.view.frame.size.height);
    [UIView animateWithDuration:1.5 animations:^{
        viewFlash.subviews[0].transform = CGAffineTransformMakeTranslation(0, 0);
    }];
}

-(void)func4
{
    viewFlash.subviews[0].alpha = 0.0f;
    viewFlash.subviews[0].transform = CGAffineTransformMakeScale(0, 0);
    [UIView animateWithDuration:1.5 animations:^{
        viewFlash.subviews[0].transform = CGAffineTransformMakeScale(1, 1);
        viewFlash.subviews[0].alpha = 1.0f;
    }];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:@"Review" :self :btnHome :nil :YES :self];
    
    ChkChildListStp1 = [[NSString alloc]init];
    ChkChilsWiseDtlStp2 = [[NSString alloc]init];
    
    [self SwimCmpt_Register_SwimMeetStep5_EventCalc];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (studentName == nil) {
        [self DynamicAddStudents];
    }
}

-(void)DynamicAddStudents
{
    vStripe = [CommonClass dynamicAddChild:scroll_header scrollToview:tblReviewList :self];
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:0];
}

-(void)btnSelectStudent:(UIButton *)sender
{
    [UIView animateWithDuration:0.3 animations:^{
        
        CGSize stringsize = [[sender titleForState:UIControlStateNormal] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((sender.frame.size.width/2) - (stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20)/2 + sender.frame.origin.x, vStripe.frame.origin.y, stringsize.width + 20 > sender.frame.size.width ? sender.frame.size.width : stringsize.width + 20, vStripe.frame.size.height)];
    }];
    
    if (previousTag > sender.tag)
    {
        // R-L
        tblReviewList.transform = CGAffineTransformMakeTranslation(tblReviewList.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblReviewList.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x + width, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x - width, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    else
    {
        // L-R
        tblReviewList.transform = CGAffineTransformMakeTranslation(-tblReviewList.frame.size.width, 0);
        [UIView animateWithDuration:0.5 animations:^{
            tblReviewList.transform = CGAffineTransformMakeTranslation(0, 0);
        }];
        
        CGFloat width = vStripe.frame.size.width;
        [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, 0, vStripe.frame.size.height)];
        [UIView animateWithDuration:.8 animations:^{
            [vStripe setFrame:CGRectMake(vStripe.frame.origin.x, vStripe.frame.origin.y, width, vStripe.frame.size.height)];
        }];
    }
    
    previousTag = sender.tag;
    
    for (UIView *v in scroll_header.subviews)
    {
        if([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v) setTitleColor:Top_Color forState:0];
        }
    }
    [sender setTitleColor:botomColor forState:0];
    
    /*
     */
    
    studentName = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:sender.tag];
    [tblReviewList reloadData];
    
    [tblReviewList setContentOffset:CGPointZero animated:YES];
    [tblReviewList scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
}


#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat height = (self.view.frame.size.width * 140) / 320;
    return height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return ((NSArray *)[SHARED_APPDELEGATE.dicTemp valueForKey:[NSString stringWithFormat:@"Event_%@",studentName]]).count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"EventCell";
    
    EventCell *cell = (EventCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"EventCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    NSDictionary *dic = [[SHARED_APPDELEGATE.dicTemp valueForKey:[NSString stringWithFormat:@"Event_%@",studentName]] objectAtIndex:indexPath.row];
    
    cell.lblEventName.text = [NSString stringWithFormat:@"%@ - %@",[dic valueForKey:@"StrokeType"],[dic valueForKey:@"Distance"]] ;
    cell.lblAge.text = [NSString stringWithFormat:@"Age: %@  Event #%@",[dic valueForKey:@"AgeGroup"],[dic valueForKey:@"Event"]] ;
    [cell.btnSelect setHidden:YES];
    
    return  cell;
}
- (IBAction)onClickConfirmPayBtn:(UIButton *)sender
{
    if (sender.tag == 10)
    {
        [CustomAnimation SlideUp:[viewFooter viewWithTag:20] :0.3];
        [viewFooter.subviews makeObjectsPerformSelector:@selector(setHidden:)];
        [[viewFooter viewWithTag:20]setHidden:NO];
    }
    else
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
        {
            [self AddToCart];
        }else{
            
            [CommonClass setGetBasketID:^(BOOL success) {
                if (success)
                {
                    [self AddToCart];
                }
            }];
        }
    }
    [tblReviewList reloadData];
}

-(void)AddToCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSString *strMember = member;
    member = @"";
    for (int i = 0; i < _arrStudentIds.count; i++)
    {
        member = [member stringByAppendingFormat:@"%@|%@,",strMember,[_arrStudentIds objectAtIndex:i]];
    }
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"basketid":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             @"SiteID":[[NSUserDefaults standardUserDefaults]objectForKey:SITEID],
                             @"FirstName1":@"",
                             @"LastName1":@"",
                             @"RdbMeet1":@"0",
                             @"RdbComp1":@"0",
                             
                             @"FirstName2":@"",
                             @"LastName2":@"",
                             @"RdbMeet2":@"0",
                             @"RdbComp2":@"0",
                             
                             @"FirstName3":@"",
                             @"LastName3":@"",
                             @"RdbMeet3":@"0",
                             @"RdbComp3":@"0",
                             
                             @"FirstName4":@"",
                             @"LastName4":@"",
                             @"RdbMeet4":@"0",
                             @"RdbComp4":@"0",
                             
                             @"FirstName5":@"",
                             @"LastName5":@"",
                             @"RdbMeet5":@"0",
                             @"RdbComp5":@"0",
                             
                             @"FirstName6":@"",
                             @"LastName6":@"",
                             @"RdbMeet6":@"0",
                             @"RdbComp6":@"0",
                             
                             @"FirstName7":@"",
                             @"LastName7":@"",
                             @"RdbMeet7":@"0",
                             @"RdbComp7":@"0",
                             
                             @"FirstName8":@"",
                             @"LastName8":@"",
                             @"RdbMeet8":@"0",
                             @"RdbComp8":@"0",
                             
                             @"FirstName9":@"",
                             @"LastName9":@"",
                             @"RdbMeet9":@"0",
                             @"RdbComp9":@"0",
                             
                             @"FirstName10":@"",
                             @"LastName10":@"",
                             @"RdbMeet10":@"0",
                             @"RdbComp10":@"0",
                             
                             @"RdbChildLstStp3_1":@"",
                             @"RdbChildLstStp3_2":@"",
                             
                             @"MeetdatetimeValue":[[NSUserDefaults standardUserDefaults]valueForKey:@"DateValue"],
                             @"ChkChildListStp1":[ChkChildListStp1 substringToIndex:[ChkChildListStp1 length]-1],
                             @"swimmeetid":@"0",
                             @"flag":@"0",
                             @"SelectedEventDataStep2":[ChkChilsWiseDtlStp2 substringToIndex:[ChkChilsWiseDtlStp2 length]-1],
                             @"NoofVolunteersvalue":@"0",
                             @"member":[member substringToIndex:[member length]-1],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:SwimCmpt_Register_SwimMeetAddToCart_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)SwimCmpt_Register_SwimMeetStep5_EventCalc
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    int event_count = 0;
    for (int i = 0; i < SHARED_APPDELEGATE.arrStudentName.count; i++)
    {
        ChkChildListStp1 = [ChkChildListStp1 stringByAppendingFormat:@"%@:%@,",[_arrStudentIds objectAtIndex:i],[SHARED_APPDELEGATE.arrStudentName objectAtIndex:i]];
        
        NSString *sname = [SHARED_APPDELEGATE.arrStudentName objectAtIndex:i];
        for (NSDictionary *dic in ((NSArray *)[SHARED_APPDELEGATE.dicTemp valueForKey:[NSString stringWithFormat:@"Event_%@",sname]]))
        {
            NSString *str = [NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@",[dic valueForKey:@"Event"],[dic valueForKey:@"AgeGroup"],[[[dic valueForKey:@"Distance"] componentsSeparatedByString:@" "] firstObject],[dic valueForKey:@"StrokeType"],[_arrStudentIds objectAtIndex:i],[dic valueForKey:@"tdid"]];
            ChkChilsWiseDtlStp2 = [ChkChilsWiseDtlStp2 stringByAppendingFormat:@"%@,",str];
            event_count++;
        }
    }
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"ChkChildListStp1":[ChkChildListStp1 substringToIndex:ChkChildListStp1.length-1],
                             @"ChkChilsWiseDtlStp2":[ChkChilsWiseDtlStp2 substringToIndex:ChkChilsWiseDtlStp2.length-1],
                             @"MeetdatetimeValue":[[NSUserDefaults standardUserDefaults]valueForKey:@"DateValue"],
                             @"EventCounter":[NSNumber numberWithInt:event_count]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager GET:SwimCmpt_Register_SwimMeetStep5_EventCalc_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            member = [[[responseObject valueForKey:@"SwimMeetCheck5_EventCalc"]valueForKey:@"wwmember"]firstObject];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
