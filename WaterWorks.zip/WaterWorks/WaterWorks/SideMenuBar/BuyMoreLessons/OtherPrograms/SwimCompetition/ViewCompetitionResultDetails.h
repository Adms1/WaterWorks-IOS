//
//  ViewCompetitionResultDetails.h
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCompetitionResultDetails : UIViewController
{
    IBOutlet UITableView *tblViewResultData;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,retain)NSString *strSwimId;
@property(nonatomic,retain)NSString *strEventNumber;
@property(nonatomic,retain)NSString *strEventName;
@property(nonatomic,retain)NSString *strStudentId;
@end
