//
//  ViewCompetitionResults.m
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ViewCompetitionResults.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "CustomTabbar.h"
#import "SwimScheduleCell.h"
#import "ViewCompetitionResultDetails.h"

@interface ViewCompetitionResults ()<CommonDelegate>
{
    NSArray *arrStudents;
    NSMutableDictionary *arrStudentResults;
}
@end

@implementation ViewCompetitionResults
int count = 0;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblViewResults.estimatedRowHeight = 30.0f;
    tblViewResults.rowHeight = UITableViewAutomaticDimension;
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
    
    count = 0;
    [self SwimCmpt_AllEventList_MeetOverTime];
}

-(void)SwimCmpt_AllEventList_MeetOverTime
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"swimmeetid":_strSwimId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    arrStudentResults = [[NSMutableDictionary alloc]init];
    
    [manager POST:SwimCmpt_AllEventList_MeetOverTime_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [((UILabel *)self.view.subviews[self.view.subviews.count-2])setText:[[[responseObject valueForKey:@"EventTime"] valueForKey:@"header"] objectAtIndex:0]];
            
            //             && [[[[responseObject valueForKey:@"EventTime"] valueForKey:@"header"] objectAtIndex:0]isEqualToString:@""]
            if ([[[[responseObject valueForKey:@"EventTime"] valueForKey:@"RemainingTimeFlag"] objectAtIndex:0]isEqual:@1])
            {
                [self SwimCmpt_Get_NextSwimCmpRegis];
            }
            else
            {
                [CommonClass showToastMsg:ResultUpdate];
                [SHARED_APPDELEGATE hideLoadingView];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_Get_NextSwimCmpRegis
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             };
    
    arrStudentResults = [[NSMutableDictionary alloc]init];
    
    [manager POST:SwimCmpt_Get_NextSwimCmpRegis_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrStudents = [[[responseObject valueForKey:@"EmailPref"] valueForKey:@"Students"] objectAtIndex:0];
        }
        [self SwimCmpt_AllGetEventResultForStudent:[[arrStudents valueForKey:@"StudentID"] objectAtIndex:count] :[[arrStudents valueForKey:@"StudentName"] objectAtIndex:count]];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)SwimCmpt_AllGetEventResultForStudent:(NSString *)strStudentId :(NSString *)strStudentName
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"studentid":strStudentId,
                             @"swimmeetid":_strSwimId
                             };
    
    [manager POST:SwimCmpt_AllGetEventResultForStudent_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [arrStudentResults setObject:[responseObject valueForKey:@"EmailPref"] forKey:strStudentName];
            
            if (count < arrStudents.count)
            {
                [self SwimCmpt_AllGetEventResultForStudent:[[arrStudents valueForKey:@"StudentID"] objectAtIndex:count] :[[arrStudents valueForKey:@"StudentName"] objectAtIndex:count]];
            }else{
                [tblViewResults reloadData];
                [SHARED_APPDELEGATE hideLoadingView];
            }
            count++;
        }
        
        [tblViewResults reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrStudents.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *strKey = [[arrStudents valueForKey:@"StudentName"] objectAtIndex:section];
    return ((NSArray *)[arrStudentResults valueForKey:strKey]).count+1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 60;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblViewResults.frame.size.width, 60)];
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 20, tblViewResults.frame.size.width, 40)];
    lblSection.backgroundColor = [UIColor colorWithRed:(239.0/255.0) green:(239.0/255.0) blue:(239.0/255.0) alpha:1.0];
    lblSection.textColor = [UIColor blackColor];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [lblSection setText:[NSString stringWithFormat:@"  %@",[[arrStudents valueForKey:@"StudentName"] objectAtIndex:section]]];
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    SwimScheduleCell *cell = (SwimScheduleCell *)[tableView dequeueReusableCellWithIdentifier:@"SwimScheduleCell3"];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SwimScheduleCell" owner:self options:nil];
        
        if (indexPath.row == 0)
        {
            cell = [nib objectAtIndex:6];
        }
        else
        {
            cell = [nib objectAtIndex:7];
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.layer.borderColor = [[UIColor grayColor]CGColor];
    cell.layer.borderWidth = 0.5f;
    
    if (indexPath.row > 0)
    {
        NSString *strKey = [[arrStudents valueForKey:@"StudentName"] objectAtIndex:indexPath.section];
        NSDictionary *dictionary = [[arrStudentResults valueForKey:strKey] objectAtIndex:indexPath.row-1];
        cell.lblEvent.text = [NSString stringWithFormat:@"Event #%@\n%@ - %@",[dictionary valueForKey:@"EventNumber"],[dictionary valueForKey:@"Distance"],[dictionary valueForKey:@"strokedescription"]];
        cell.lblPlacement.text = [NSString stringWithFormat:@"%@",[dictionary valueForKey:@"placeno"]];
        cell.lblTime.text = [NSString stringWithFormat:@"%@  %@",[dictionary valueForKey:@"MeetTime"],[dictionary valueForKey:@"TimeImprovement"]];
        
        NSString *subString = [dictionary valueForKey:@"TimeImprovement"];
        
        NSMutableAttributedString *text =
        [[NSMutableAttributedString alloc]
         initWithString:cell.lblTime.text];
        
        NSRange range = [cell.lblTime.text rangeOfString:[dictionary valueForKey:@"TimeImprovement"] options:NSCaseInsensitiveSearch];
        [text addAttribute:NSForegroundColorAttributeName
                     value:[subString containsString:@"-"] ? [UIColor colorWithRed:(122.0/255.0) green:(175.0/255.0) blue:(94.0/255.0) alpha:1.0] : [subString containsString:@"+"] ? [UIColor redColor] : [UIColor blackColor]
                     range:range];
        [cell.lblTime setAttributedText: text];
    }
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strKey = [[arrStudents valueForKey:@"StudentName"] objectAtIndex:indexPath.section];
    NSDictionary *dictionary = [[arrStudentResults valueForKey:strKey] objectAtIndex:indexPath.row-1];
    
    ViewCompetitionResultDetails *vcrd = [[ViewCompetitionResultDetails alloc]initWithNibName:@"ViewCompetitionResultDetails" bundle:nil];
    vcrd.strSwimId = _strSwimId;
    vcrd.strEventNumber = [dictionary valueForKey:@"EventNumber"];
    vcrd.strEventName = [NSString stringWithFormat:@"Event #%@ : %@ - %@",[dictionary valueForKey:@"EventNumber"],[dictionary valueForKey:@"Distance"],[dictionary valueForKey:@"strokedescription"]];
    vcrd.strStudentId = [[arrStudents valueForKey:@"StudentID"] objectAtIndex:indexPath.section];
    [[self navigationController]pushViewController:vcrd animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
