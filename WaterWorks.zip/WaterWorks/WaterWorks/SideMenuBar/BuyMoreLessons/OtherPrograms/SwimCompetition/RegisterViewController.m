//
//  RegisterViewController.m
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RegisterViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "Location.h"
#import "ParticipatesViewController.h"
#import "CustomTabbar.h"
#import "NIDropDown.h"

@interface RegisterViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NSMutableArray *arrLocationList, *arrPrice ,*arrEventDetails;
    NSString *selectedMeetDate, *selectAddress;
    NIDropDown *dropDown;
    UIButton *btn;
}
@end

@implementation RegisterViewController
int extra = 0;

@synthesize strSwimCopatitionProgramID;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getProgramInstruction];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :1 :0];
    [self.view insertSubview:ct atIndex:0];
    
    btnSiteLocation.imageEdgeInsets = UIEdgeInsetsMake(0, self.view.frame.size.width - 18 - 25, 0, 0);
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
}
-(void)popViewController
{
    if (SHARED_APPDELEGATE.isFromPrograms)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    else if (SHARED_APPDELEGATE.isFromSwim)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
    }
    else
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
    }
}


-(void)getProgramInstruction
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strSwimCopatitionProgramID forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:programInstruction_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:[[dict safeObjectForKey:@"Instruction"] stringByReplacingOccurrencesOfString:@"!" withString:@""]];
                NSRange selectedRange = NSMakeRange(0, [[[dict safeObjectForKey:@"Instruction"] componentsSeparatedByString:@"\n"] firstObject].length);
                [string addAttribute:NSFontAttributeName
                               value:FONT_Bold(14)
                               range:selectedRange];
                lblInstruction.attributedText = string;
                
                btn = [[UIButton alloc]initWithFrame:CGRectOffset(btnSiteLocation.frame, 0, 50)];
                [btn addTarget:self action:@selector(onClickSwimCompatitionBtn:) forControlEvents:UIControlEventTouchUpInside];
                [self.view addSubview:btn];
                
                [self setLocationDataList];
            }
        }else{
            [self setLocationDataList];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)setLocationDataList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:Get_SwimcompetitionsSite_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrLocationList = [[NSMutableArray alloc] init];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"Sites"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"SiteName"];
                    objLocation.siteid = [dict valueForKey:@"SiteID"];
                    
                    [arrLocationList addObject:objLocation];
                }
                
                if (arrLocation.count == 1)
                {
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    
                    [btnSiteLocation setTitle:strTitle forState:UIControlStateNormal];
                    
                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                    
                    [userDefault setObject:strLocationID forKey:SITEID];
                    
                    [self Get_SiteDetailsBySiteID:strLocationID];
                    [self Get_ProgramsPriceInfo:strLocationID];
                }
            }
        }else{
            
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)Get_SiteDetailsBySiteID:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"SiteID":strSiteId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:Get_SiteDetailsBySiteID_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"Sites"];
            
            if ([arrLocation count] > 0) {
                
                selectAddress = [[arrLocation valueForKey:@"Address1"] objectAtIndex:0];
            }
        }else{
            
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)Get_ProgramsPriceInfo:(NSString *)siteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"siteid":siteId,
                             @"programid":strSwimCopatitionProgramID
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:PriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrInstruction = [[responseObject safeObjectForKey:@"Instruction"] objectAtIndex:0];
            
            if ([arrInstruction count] > 0) {
                
                lblMemberNonMember.text = [arrInstruction valueForKey:@"Instruction"];
                lblMemberNonMember.text = [lblMemberNonMember.text stringByReplacingOccurrencesOfString:@"    " withString:@" "];
                lblFees.text = @"Fees";
                if (viewHeader.frame.size.height <= 170) {
                    extra = -([self getDynamicHeightOflbl:lblMemberNonMember.text].height + 10);
                }else{
                    extra = 0;
                }
                
                NSMutableParagraphStyle *style =  [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
                style.alignment = NSTextAlignmentJustified;
                style.firstLineHeadIndent = 10.0f;
                style.headIndent = 10.0f;
                style.tailIndent = -10.0f;
                
                NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:lblMemberNonMember.text attributes:@{ NSParagraphStyleAttributeName : style}];
                lblMemberNonMember.attributedText = attrText;
            }
        }else{
            if (viewHeader.frame.size.height > 170) {
                extra = ([self getDynamicHeightOflbl:lblMemberNonMember.text].height + 10);
            }else{
                extra = 0;
            }
            lblFees.text = lblMemberNonMember.text = @"";
        }
        
        [tblSwimComprtitionList reloadData];
        [self SwimCmpt_Register_SwimMeetDateBySite:siteId];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)SwimCmpt_Register_SwimMeetDateBySite:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"SiteID":strSiteId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:SwimCmpt_Register_SwimMeetDateBySite_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrEventDetails = [responseObject safeObjectForKey:@"SwimMeetDateBySite"];
        }
        
        if (extra != 0) {
            [CustomAnimation SlideUp:lblFees :0.5];
            [CustomAnimation SlideUp:lblMemberNonMember :0.5];
        }
        [tblSwimComprtitionList reloadData];
        extra = 0;
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return viewHeader.frame.size.height - extra;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat height = (self.view.frame.size.width * 55) / 320;
    return height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrEventDetails.count > 0 ? arrEventDetails.count+1 : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"FamilySwimCell";
    
    FamilySwimCell *cell = (FamilySwimCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"FamilySwimCell" owner:self options:nil];
        if(indexPath.row == 0)
        {
            cell = [nib objectAtIndex:1];
        }
        else
        {
            cell = [nib objectAtIndex:2];
        }
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if (indexPath.row > 0)
    {
        cell.lblEventDate.text = [[arrEventDetails objectAtIndex:indexPath.row-1] valueForKey:@"MeetDate"];
        cell.lblStartTime.text = [[arrEventDetails objectAtIndex:indexPath.row-1] valueForKey:@"StartTime"];
        cell.btnSelect.tag = indexPath.row-1;
        [cell.btnSelect addTarget:self action:@selector(btnSelect:) forControlEvents:UIControlEventTouchUpInside];
        
        if ([selectedMeetDate isEqualToString:[[[[arrEventDetails objectAtIndex:indexPath.row-1] valueForKey:@"DateValue"] componentsSeparatedByString:@" "] firstObject]])
        {
            [cell.btnSelect setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
        }
    }
    return  cell;
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    btn.frame = CGRectMake(btn.frame.origin.x, btnSiteLocation.frame.origin.y - tblSwimComprtitionList.contentOffset.y + 50, btn.frame.size.width, btn.frame.size.height);
}
-(void)btnSelect:(UIButton *)sender
{
    for (FamilySwimCell *cell in tblSwimComprtitionList.visibleCells)
    {
        [cell.btnSelect setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
    }
    selectedMeetDate = [[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"DateValue"];
    
    [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@|%@|%@ Facility|%@,%@",[[[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"DateText"] componentsSeparatedByString:@"-"] firstObject],[[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"StartTime"] stringByReplacingOccurrencesOfString:@" " withString:@":00 "],[[[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"DateText"] componentsSeparatedByString:@" "] lastObject],selectAddress,[[[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"DateText"] componentsSeparatedByString:@" "] lastObject]] forKey:@"HeaderData"];
    
    [[NSUserDefaults standardUserDefaults]setValue:[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"DateValue"] forKey:@"DateValue"];
    [[NSUserDefaults standardUserDefaults]setValue:[[arrEventDetails objectAtIndex:sender.tag] valueForKey:@"MeetDate_Display"] forKey:@"MeetDate_Display"];
    
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
}
- (IBAction)onClickSwimCompatitionBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSiteLocation :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn;
{
    [self Get_SiteDetailsBySiteID:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx]];
    [self Get_ProgramsPriceInfo:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx]];
}

- (IBAction)onClickRegisterBtn:(id)sender
{
    if (selectedMeetDate != nil)
    {
        ParticipatesViewController *pvc = [[ParticipatesViewController alloc]initWithNibName:@"ParticipatesViewController" bundle:nil];
        pvc.strMeetDate = selectedMeetDate;
        [[self navigationController]pushViewController:pvc animated:YES];
    }
    else
    {
        [CommonClass showToastMsg:SelectEvent];
    }
}
-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType{
    
    [btnSiteLocation setTitle:strType forState:UIControlStateNormal];
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:strID forKey:SITEID];
    
    [self Get_SiteDetailsBySiteID:strID];
    [self Get_ProgramsPriceInfo:strID];
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_OpenSans(13) }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.view.frame.size.width - 40, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize Size = rect.size;
    return Size;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
