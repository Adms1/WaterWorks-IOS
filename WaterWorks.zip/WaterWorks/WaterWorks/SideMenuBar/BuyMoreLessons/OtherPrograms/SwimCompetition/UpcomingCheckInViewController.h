//
//  CheckInViewController.h
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpcomingCheckInViewController : UIViewController
{
    IBOutlet UIButton *btnHome, *btnCheckIn;
    IBOutlet UITableView *tblCheckIn;
    IBOutlet UILabel *lblCheckIn;
}
@end
