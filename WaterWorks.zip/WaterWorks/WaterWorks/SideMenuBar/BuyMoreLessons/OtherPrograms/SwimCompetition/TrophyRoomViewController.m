//
//  TrophyRoomViewController.m
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TrophyRoomViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "TrophiesData.h"
#import "CustomTabbar.h"

@interface TrophyRoomViewController ()<CommonDelegate>
{
    NSArray *studentArray;
    NSMutableArray *arrRibbon;
}
@end

@implementation TrophyRoomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    arrRibbon = [[NSMutableArray alloc]init];
    
    [manager POST:MyAcnt_Get_ProgressRpt_List_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            studentArray = [responseObject valueForKey:@"ProgresRptList"];
            
            [self GetRibbonCount:0];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :2 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
}

-(void)GetRibbonCount:(int)i
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             @"studentid":[[studentArray objectAtIndex:i]valueForKey:@"Studentid"]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:GetStudentRibbonCount_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *array = [responseObject safeObjectForKey:@"RibbonCount"];
            
            for (NSDictionary *dic in array)
            {
                TrophiesData *trophies = [[TrophiesData alloc]init];
                trophies.participation = dic[@"participation"];
                trophies.timeimprovement = dic[@"timeimprovement"];
                trophies.totalribbons = dic[@"totalribbons"];
                
                [arrRibbon addObject:trophies];
            }
            
            if(i < studentArray.count - 1)
            {
                int x = i+1;
                [self GetRibbonCount:x];
            }
            else
            {
                [tblTrophyRoomList reloadData];
                [SHARED_APPDELEGATE hideLoadingView];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)popViewController
{
    if (SHARED_APPDELEGATE.isFromPrograms)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    else if (SHARED_APPDELEGATE.isFromSwim)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
    }
    else
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
    }
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 185.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return studentArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"TrophyRoomCell";
    
    TrophyRoomCell *cell = (TrophyRoomCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TrophyRoomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    TrophiesData *trophies = [arrRibbon objectAtIndex:indexPath.row];
    [cell setTrophiesData:trophies :[studentArray objectAtIndex:indexPath.row]];
    return  cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    //
    //    PrivateLesson *objPrivate = [arrPraivateLesson objectAtIndex:indexPath.row];
    //
    //    //    NSString *strSelect = [arrBusCategory objectAtIndex:indexPath.row];
    //
    //    [tblPrivateLessonsList deselectRowAtIndexPath:indexPath animated:YES];
    //
    //    if (cell.accessoryType == UITableViewCellAccessoryNone) {
    //        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    //        [arrselected addObject:objCategory.category_name];
    //        [arrBusCategoryID addObject:objCategory.catID];
    //    }else {
    //        cell.accessoryType = UITableViewCellAccessoryNone;
    //        [arrselected removeObject:objCategory.category_name];
    //        [arrBusCategoryID removeObject:objCategory.catID];
    //    }
    //
    //    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
