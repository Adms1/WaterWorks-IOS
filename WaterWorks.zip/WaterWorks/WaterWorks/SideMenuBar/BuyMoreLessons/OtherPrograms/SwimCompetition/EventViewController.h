//
//  EventViewController.h
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UITableView *tblEventList;
    IBOutlet UIView *viewFooter;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,retain)NSArray *arrStudentIds;
@end
