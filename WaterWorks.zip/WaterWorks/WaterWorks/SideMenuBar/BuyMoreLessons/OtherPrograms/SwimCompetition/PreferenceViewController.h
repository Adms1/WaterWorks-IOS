//
//  PreferenceViewController.h
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreferenceViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_header;
    IBOutlet UIView *viewPreference;
    IBOutlet UIButton *btnHome;
    IBOutlet UILabel *l1,*l2;
}
@property(nonatomic,retain)NSArray *arrStudentIds;
@end
