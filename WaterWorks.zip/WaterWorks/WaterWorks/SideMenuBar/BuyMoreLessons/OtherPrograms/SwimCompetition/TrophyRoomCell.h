//
//  TrophyRoomCell.h
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TrophiesData.h"

@interface TrophyRoomCell : UITableViewCell
{
    IBOutlet UILabel *lblSname, *lblParticipate, *lblTI, *lblTotal;
}
-(void)setTrophiesData:(TrophiesData *)trophiesData :(NSDictionary *)dic;
@end
