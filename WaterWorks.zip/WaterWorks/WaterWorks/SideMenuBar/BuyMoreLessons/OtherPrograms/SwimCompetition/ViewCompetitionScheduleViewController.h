//
//  ViewCompetitionScheduleViewController.h
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewCompetitionScheduleViewController : UIViewController
{
    IBOutlet UITableView *tblViewSchedule;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,retain)NSString *strSwimId;
@end
