//
//  TrophyRoomCell.m
//  WaterWorks
//
//  Created by Darshan on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TrophyRoomCell.h"

@implementation TrophyRoomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setTrophiesData:(TrophiesData *)trophiesData :(NSDictionary *)dic
{
    [lblSname setText:[NSString stringWithFormat:@"%@ %@",dic[@"SFirstName"],dic[@"SLastName"]]];
    [lblParticipate setText:[NSString stringWithFormat:@"%@",trophiesData.participation]];
    [lblTI setText:[NSString stringWithFormat:@"%@",trophiesData.timeimprovement]];
    [lblTotal setText:[NSString stringWithFormat:@"%@",trophiesData.totalribbons]];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
