//
//  ViewCompetitionResultDetails.m
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ViewCompetitionResultDetails.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "SwimScheduleCell.h"
#import "CustomTabbar.h"

@interface ViewCompetitionResultDetails ()<CommonDelegate>
{
    NSArray *arrResultData;
}
@end

@implementation ViewCompetitionResultDetails

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblViewResultData.estimatedRowHeight = 30.0f;
    tblViewResultData.rowHeight = UITableViewAutomaticDimension;
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :SHARED_APPDELEGATE.items :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSwimCompetitionRegistration :self :btnHome :nil :YES :self];
    
    [self SwimCmpt_AllMeetResultForEvent];
}

-(void)SwimCmpt_AllMeetResultForEvent
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"eventnumber":_strEventNumber,
                             @"swimmeetid":_strSwimId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:SwimCmpt_AllMeetResultForEvent_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrResultData = [responseObject safeObjectForKey:@"EmailPref"];
        }
        [tblViewResultData reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrResultData.count+1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblViewResultData.frame.size.width, 20)];
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, tblViewResultData.frame.size.width, 20)];
    lblSection.textColor = [UIColor blackColor];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [lblSection setText:@"Event Details"];
    [headerView addSubview:lblSection];
    
    UILabel *lblSubSection = [[UILabel alloc]initWithFrame:CGRectMake(0, 22, tblViewResultData.frame.size.width, 20)];
    lblSubSection.textColor = [UIColor blackColor];
    lblSubSection.font = FONT_Semibold(14);
    lblSubSection.textAlignment = NSTextAlignmentLeft;
    [lblSubSection setText:_strEventName];
    [headerView addSubview:lblSubSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    SwimScheduleCell *cell = (SwimScheduleCell *)[tableView dequeueReusableCellWithIdentifier:@"SwimScheduleCell4"];
    cell = nil;
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SwimScheduleCell" owner:self options:nil];
        
        if (indexPath.row == 0)
        {
            cell = [nib objectAtIndex:8];
        }
        else
        {
            cell = [nib objectAtIndex:9];
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.layer.borderColor = [[UIColor grayColor]CGColor];
    cell.layer.borderWidth = 0.5f;
    
    if (indexPath.row > 0)
    {
        NSArray *array = [arrResultData objectAtIndex:indexPath.row-1];
        cell.lblPlace.text = [NSString stringWithFormat:@"%@",[array valueForKey:@"placeno"]];
        cell.lblSwimmer.text = [array valueForKey:@"Swimmer"];
        cell.lblAge.text = [NSString stringWithFormat:@"%@",[array valueForKey:@"Age"]];
        cell.lblTime.text = [NSString stringWithFormat:@"%@  %@",[array valueForKey:@"MeetTime"],[array valueForKey:@"TimeImprovement"]];
        
        NSString *subString = [array valueForKey:@"TimeImprovement"];
        
        NSMutableAttributedString *text =
        [[NSMutableAttributedString alloc]
         initWithString:cell.lblTime.text];
        
        NSRange range = [cell.lblTime.text rangeOfString:[array valueForKey:@"TimeImprovement"] options:NSCaseInsensitiveSearch];
        [text addAttribute:NSForegroundColorAttributeName
                     value:[subString containsString:@"-"] ? [UIColor colorWithRed:(122.0/255.0) green:(175.0/255.0) blue:(94.0/255.0) alpha:1.0] : [subString containsString:@"+"] ? [UIColor redColor] : [UIColor blackColor]
                     range:range];
        [cell.lblTime setAttributedText: text];
        
        if ([[[arrResultData objectAtIndex:indexPath.row-1] valueForKey:@"StudentID"] isEqual:_strStudentId]) {
            cell.contentView.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
        }
    }
    return cell;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
