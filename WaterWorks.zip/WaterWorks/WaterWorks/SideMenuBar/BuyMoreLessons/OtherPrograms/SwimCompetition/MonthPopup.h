//
//  MonthPopup.h
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MonthPopupDelegate <NSObject>
-(void)Click:(NSMutableArray *)MonthArray :(NSMutableArray *)arrMonthId;
@end
@interface MonthPopup : UIViewController
{
    IBOutlet UITableView *tblMonthList;
}
@property (nonatomic , strong) NSArray *arrMonthList;
@property (nonatomic , strong) NSArray *arrSelectMonth;
@property(nonatomic,retain)id <MonthPopupDelegate> m_delegate;
@end
