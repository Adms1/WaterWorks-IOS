//
//  CheckInData.h
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckInData : NSObject
@property (nonatomic , strong) NSString *fullname;
@property (nonatomic , strong) NSString *wu_preference1;
@property (nonatomic , strong) NSString *wu_studentid;
@property (nonatomic , strong) NSString *wu_swimmeetid;
@property (nonatomic , strong) NSString *wu_preference2;
@property (nonatomic , strong) NSString *wu_eventnumber;
@property (nonatomic , strong) NSString *wu_groupdescription;
@property (nonatomic , strong) NSString *wu_description;
@property (nonatomic , strong) NSString *wu_strokedescription;
@property (nonatomic , strong) NSString *Time1;
@property (nonatomic , strong) NSString *wu_checkin;
@property (nonatomic , strong) NSString *listtbid;
@end
