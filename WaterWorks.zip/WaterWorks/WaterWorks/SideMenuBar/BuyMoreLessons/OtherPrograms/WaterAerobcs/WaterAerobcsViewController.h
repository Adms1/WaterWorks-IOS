//
//  WaterAerobcsViewController.h
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SessionPopUpViewController.h"
#import "SelectLocationViewController.h"
#import "AFNetworking.h"

@interface WaterAerobcsViewController : UIViewController<popUpSessionsDelegate,LocationDelegate>

{
    IBOutlet UILabel *lblWarning;
    IBOutlet UILabel *lblTesting;
    IBOutlet UITextView *txtInstruction;
    IBOutlet UILabel *lblTotal;
    
    IBOutlet UIButton *btnSelectLocation;
    IBOutlet UIButton *btnSessions;
    IBOutlet UIButton *btnHome;
}

@property (nonatomic , strong) NSString *strWaterProgramID;

@end
