//
//  WaterAerobcsViewController.m
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "WaterAerobcsViewController.h"
#import "CommonClass.h"
#import "Location.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "NIDropDown.h"

@interface WaterAerobcsViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NSString *strSiteID, *strAerobicsQnt;
    NSMutableArray *arrLocationList;
    NIDropDown *dropDown;
}
@end


@implementation WaterAerobcsViewController

@synthesize strWaterProgramID;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strWaterProgramID forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:programInstruction_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                txtInstruction.text = [dict safeObjectForKey:@"Instruction"];
                [txtInstruction setTextContainerInset:UIEdgeInsetsMake(0, 0, 0, 0)];
                [self setLocationDataList];
            }
        }else{
            [self setLocationDataList];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
    lblTesting.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    lblTesting.layer.borderWidth = 0.5f;
    
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [btnSelectLocation setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectLocation.frame.size.width - 20, 0, 0)];
    [btnSessions setImageEdgeInsets:UIEdgeInsetsMake(0, btnSessions.frame.size.width - 20, 0, 0)];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterAerobics :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setLocationDataList
{
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        if (flag) {
            arrLocationList = [[NSMutableArray alloc] init];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"SiteList"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"sitename"];
                    objLocation.siteid = [dict valueForKey:@"siteid"];
                    objLocation.Lafitness = [dict valueForKey:@"Lafitness"];
                    objLocation.Address1 = [dict valueForKey:@"Address1"];
                    objLocation.Address2 = [dict valueForKey:@"Address2"];
                    objLocation.City = [dict valueForKey:@"City"];
                    objLocation.State = [dict valueForKey:@"State"];
                    objLocation.ZipCode = [dict valueForKey:@"ZipCode"];
                    objLocation.Phone = [dict valueForKey:@"Phone"];
                    
                    [arrLocationList addObject:objLocation];
                }
                
                if ([arrLocationList count] == 1) {
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    NSString *strLAfit = [NSString stringWithFormat:@"%@",objLocation.Lafitness];
                    
                    [btnSelectLocation setTitle:strTitle forState:UIControlStateNormal];
                    
                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                    
                    [userDefault setObject:strLocationID forKey:SITEID];
                    [userDefault setObject:strLAfit forKey:LAFITNESS];
                    
                    strSiteID = strLocationID;
                    [self Get_ProgramsPriceInfo:strLocationID];
                }
            }
        }
    }];
}

-(void)Get_ProgramsPriceInfo:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"programid":strWaterProgramID,
                             @"siteid":strSiteId,
                             };
    
    [manager POST:Get_ProgramsPriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            lblTesting.text = [[[responseObject valueForKey:@"Instruction"]valueForKey:@"Instruction"] objectAtIndex:0];
        }else{
            lblTesting.text = @"";
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSelectLocation :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    strSiteID = [[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx];
    [self Get_ProgramsPriceInfo:strSiteID];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    NSString *str = [NSString stringWithFormat:@"%ld",(long)idx];
    
    if ([str isEqualToString:@"0"]) {
        lblWarning.text = @"Please select the number of water aerobics classes you would like to purchase.";
    }else{
        lblWarning.text = @"";
    }
    
    [btnSessions setTitle:str forState:UIControlStateNormal];
    
    strAerobicsQnt = str;
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    int Session = [str intValue];
    
    float cost = 0;
    if (Session <= 9){
        cost = Session * 12;
    }else{
        if (Session < 15){
            cost = Session * 10.80;
        }else{
            if (Session <= 17){
                cost = Session * 10;
            }else{
                if (Session == 18){
                    cost = 172;
                }else{
                    if (Session == 19){
                        cost = 175;
                    }else{
                        if (Session > 19){
                            cost = 9 * Session;
                        }
                    }
                }
            }
        }
    }
    
    lblTotal.text = [NSString stringWithFormat:@"Total : $ %.02f",cost];
}

-(void)rel{
    dropDown = nil;
}

- (IBAction)onClickSelectSessionsBtn:(id)sender {
    //    SessionPopUpViewController *viewSessionPopUp = [[SessionPopUpViewController alloc] initWithNibName:@"SessionPopUpViewController" bundle:nil];
    //    viewSessionPopUp.sessionsDelegate = self;
    //    [self presentPopupViewController:viewSessionPopUp animationType:MJPopupViewAnimationFade];
    
    if(dropDown == nil) {
        CGFloat f = 300;
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        for (int i = 0; i < 100; i++) {
            [arr addObject:[NSNumber numberWithInt:i]];
        }
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}


-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType{
    
    [btnSelectLocation setTitle:strType forState:UIControlStateNormal];
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:strID forKey:SITEID];
    [userDefault setObject:stFitNess forKey:LAFITNESS];
    
    strSiteID = strID;
    [self Get_ProgramsPriceInfo:strID];
}

-(void)selectSessionsAtIndex:(NSString *)strSessions
{
    NSLog(@"strSessions>>> %@",strSessions);
    
    if ([strSessions isEqualToString:@"0"]) {
        lblWarning.text = @"Please select the number of water aerobics classes you would like to purchase.";
    }else{
        lblWarning.text = @"";
    }
    
    [btnSessions setTitle:strSessions forState:UIControlStateNormal];
    
    strAerobicsQnt = strSessions;
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    int Session = [strSessions intValue];
    
    float cost = 0;
    if (Session <= 9){
        cost = Session * 12;
    }else{
        if (Session < 15){
            cost = Session * 10.80;
        }else{
            if (Session <= 17){
                cost = Session * 10;
            }else{
                if (Session == 18){
                    cost = 172;
                }else{
                    if (Session == 19){
                        cost = 175;
                    }else{
                        if (Session > 19){
                            cost = 9 * Session;
                        }
                    }
                }
            }
        }
    }
    
    lblTotal.text = [NSString stringWithFormat:@"Total : $ %.02f",cost];
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickSelectSubmitBtn:(id)sender {
    
    if (strSiteID == nil)
    {
        [CommonClass showToastMsg:SiteSelection];
    }
    else if (strAerobicsQnt == nil || [strAerobicsQnt isEqualToString:@"0"])
    {
        lblWarning.text = WAClassSelection;
    }
    else
    {
        lblWarning.text = @"";
        if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
        {
            [self AddtoCart];
        }
        else{
            
            [CommonClass setGetBasketID:^(BOOL success) {
                if (success)
                {
                    [self AddtoCart];
                }
            }];
        }
    }
}
-(void)AddtoCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    NSString *strFamilyID = [[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID];
    
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    [params setObject:strFamilyID forKey:@"FamilyID"];
    [params setObject:strBasketID forKey:@"BasketID"];
    [params setObject:strSiteID forKey:@"SiteID"];
    [params setObject:strAerobicsQnt forKey:@"AerobicsQnt"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:MakePurchase_AddWaterArobics_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
