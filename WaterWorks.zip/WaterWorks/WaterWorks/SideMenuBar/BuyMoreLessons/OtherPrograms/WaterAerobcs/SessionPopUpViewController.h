//
//  SessionPopUpViewController.h
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol popUpSessionsDelegate <NSObject>

-(void)selectSessionsAtIndex:(NSString *)strSessions;

@end

@interface SessionPopUpViewController : UIViewController

{
    IBOutlet UITableView *tblSessionsList;
    
    NSMutableArray *arrSessionList;
}

@property (assign, nonatomic) id <popUpSessionsDelegate> sessionsDelegate;

@end
