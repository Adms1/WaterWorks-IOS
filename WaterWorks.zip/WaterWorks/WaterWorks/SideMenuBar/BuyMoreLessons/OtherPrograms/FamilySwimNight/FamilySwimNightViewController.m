//
//  FamilySwimNightViewController.m
//  WaterWorks
//
//  Created by Darshan on 30/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "FamilySwimNightViewController.h"
#import "CommonClass.h"
#import "Location.h"
#import "AppDelegate.h"
#import "FamilySwimCell.h"
#import "FamilySwimRegisterViewController.h"
#import "CustomTabbar.h"
#import "NIDropDown.h"

@interface FamilySwimNightViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
}
@end

@implementation FamilySwimNightViewController

@synthesize strProgramID;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strProgramID forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:programInstruction_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                txtInstruction.text = [dict safeObjectForKey:@"Instruction"];
                [txtInstruction setTextContainerInset:UIEdgeInsetsMake(0, 0, 0, 0)];
                [self setLocationDataList];
            }
        }else{
            [self setLocationDataList];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
    _lblTesting.layer.borderWidth = 0.5f;
    _lblTesting.layer.borderColor = [UIColor grayColor].CGColor;
    
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    btnLocation.imageEdgeInsets = UIEdgeInsetsMake(0, btnLocation.frame.size.width - 18, 0, 0);
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksFamilySwimNight :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnLocation :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx] forKey:SITEID];
    
    [self PriceInfo:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx]];
    [self setFamilySwimList:[[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx]];
}

-(void)setLocationDataList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:FamilySwimSite_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrLocationList = [[NSMutableArray alloc] init];
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"Sites"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"SiteName"];
                    objLocation.siteid = [dict valueForKey:@"SiteID"];
                    
                    [arrLocationList addObject:objLocation];
                }
                
                if (arrLocation.count == 1)
                {
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    
                    [btnLocation setTitle:strTitle forState:UIControlStateNormal];
                    
                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                    
                    [userDefault setObject:strLocationID forKey:SITEID];
                    
                    [self setFamilySwimList:strLocationID];
                }
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType{
    
    [btnLocation setTitle:strType forState:UIControlStateNormal];
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:strID forKey:SITEID];
    //[userDefault setObject:stFitNess forKey:LAFITNESS];
    
    [self PriceInfo:strID];
    [self setFamilySwimList:strID];
}

-(void)PriceInfo:(NSString *)strId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"siteid":strId,
                             @"programid":strProgramID
                             };
    
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:PriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
        
        if ([arrInstruction count] > 0) {
            
            NSDictionary *dict = [arrInstruction firstObject];
            _lblTesting.text = [dict safeObjectForKey:@"Instruction"];
        }else{
            _lblTesting.text = @"";
        }
        
        NSMutableParagraphStyle *style =  [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        style.alignment = NSTextAlignmentCenter;
        style.firstLineHeadIndent = 10.0f;
        style.headIndent = 10.0f;
        style.tailIndent = -10.0f;
        
        NSAttributedString *attrText = [[NSAttributedString alloc] initWithString:_lblTesting.text attributes:@{ NSParagraphStyleAttributeName : style}];
        _lblTesting.attributedText = attrText;
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)setFamilySwimList:(NSString *)strId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]valueForKey:FAMILYID],
                             @"siteid":strId,
                             };
    
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:MakePurchase_FamilySwimDate_SiteIDWise_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        arrSwimList = [[NSMutableArray alloc] init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrSwimList = [responseObject valueForKey:@"FinalArray"];
            
        }
        [tblSwim reloadData];
        tblHeight.constant = tblSwim.contentSize.height;
        [scroll_main setContentSize:CGSizeMake(scroll_main.frame.size.width, tblSwim.frame.origin.y + tblSwim.contentSize.height)];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrSwimList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblSwim.frame.size.width, 30)];
    headerView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, tblSwim.frame.size.width, 20)];
    lblSection.backgroundColor = [UIColor clearColor];
    lblSection.textColor = [UIColor blackColor];
    [lblSection setText:@"Event Dates"];
    lblSection.font = FONT_Bold(14);
    lblSection.textAlignment = NSTextAlignmentLeft;
    [headerView addSubview:lblSection];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70.0f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    FamilySwimCell *fsCell = (FamilySwimCell *)[tableView dequeueReusableCellWithIdentifier:@"FamilySwimCell"];
    
    if (fsCell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"FamilySwimCell" owner:self options:nil];
        fsCell = [nib objectAtIndex:0];
    }
    fsCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    fsCell.lblSwimDate.text = [[arrSwimList objectAtIndex:indexPath.row]valueForKey:@"SwimDate_Front"];
    fsCell.lblTheme.text = [[arrSwimList objectAtIndex:indexPath.row]valueForKey:@"Theme"];
    fsCell.btnRegister.tag = indexPath.row;
    [fsCell.btnRegister addTarget:self action:@selector(btnRegisterClicked:) forControlEvents:UIControlEventTouchUpInside];
    return fsCell;
}

-(void)btnRegisterClicked:(UIButton *)sender
{
    FamilySwimRegisterViewController *fsrvc = [[FamilySwimRegisterViewController alloc]initWithNibName:@"FamilySwimRegisterViewController" bundle:nil];
    fsrvc.strSwimDate = [[arrSwimList objectAtIndex:sender.tag]valueForKey:@"SwimDateSiteID"];
    [[self navigationController]pushViewController:fsrvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
