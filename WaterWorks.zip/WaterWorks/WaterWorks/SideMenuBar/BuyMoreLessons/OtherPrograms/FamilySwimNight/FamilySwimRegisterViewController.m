//
//  FamilySwimRegisterViewController.m
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "FamilySwimRegisterViewController.h"
#import "NIDropDown.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"

@interface FamilySwimRegisterViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSString *strKids, *strAdults;
}
@end

@implementation FamilySwimRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    strAdults = strKids = @"";
    
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:@"Register" :self :btnHome :nil :YES :self];

    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] == nil)
    {
        [CommonClass setGetBasketID:^(BOOL success) {
        }];
    }
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    for (UIView *v in scroll_main.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            ((UIButton *)v).imageEdgeInsets = UIEdgeInsetsMake(0, scroll_main.frame.size.width - 20 - 20, 0, 0);
        }
    }
}

-(void)MakePurchase_CostDetail_SwimDateWise:(NSString *)str_kids :(NSString *)str_adults :(BOOL)flag :(NSString *)web_url
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]valueForKey:FAMILYID],
                             @"Kids":str_kids,
                             @"Adults":str_adults,
                             @"SiteID":[[NSUserDefaults standardUserDefaults]valueForKey:SITEID],
                             @"SwimDate":_strSwimDate,
                             @"BasketID":[[NSUserDefaults standardUserDefaults]valueForKey:BASKETID]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:web_url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if (!flag) {
                
                lblWarning.text = [[[responseObject valueForKey:@"FinalArray"] objectAtIndex:0]valueForKey:@"Warning"];
                lblTotalAmount.text = [NSString stringWithFormat:@"Total                                           %@",[[[responseObject valueForKey:@"FinalArray"] valueForKey:@"FamSwimCost"] objectAtIndex:0]];
            }else{
                [self AddToCart];
            }
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnSelectClicked:(UIButton *)sender
{
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    for (int i = 1; i <= sender.tag; i++)
    {
        [arr addObject:[NSNumber numberWithInt:i]];
    }
    if (sender.tag == 4) {
        [arr insertObject:[NSNumber numberWithInt:0] atIndex:0];
    }
    
    if(dropDown == nil) {
        CGFloat f = 100;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}
- (void)select:(UIButton *)sender :(NSInteger) idx
{
    if (sender.tag == 2)
    {
        strAdults = sender.titleLabel.text;
    }
    else
    {
        strKids = sender.titleLabel.text;
    }
    if ([strAdults isEqualToString:@""])
    {
        //[KSToastView ks_showToast:@"Please Select Kids value" duration:2.0f];
    }
    else if ([strKids isEqualToString:@""])
    {
        [CommonClass showToastMsg:KidValue];
    }
    else
        [self MakePurchase_CostDetail_SwimDateWise:strKids :strAdults :false :MakePurchase_CostDetail_SwimDateWise_Url];
}
- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

-(IBAction)btnConfirmPayClicked:(UIButton *)sender
{
    if (![strKids isEqualToString:@""] && ![strAdults isEqualToString:@""] && [lblWarning.text isEqualToString:@""])
    {
        [self MakePurchase_CostDetail_SwimDateWise:strKids :strAdults :true :MakePurchase_SubmitSwimData_Url];
    }
}

-(void)AddToCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID],
                             @"Basketid":[[NSUserDefaults standardUserDefaults]objectForKey:BASKETID],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager GET:FillDateMyCart_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
