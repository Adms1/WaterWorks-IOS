//
//  FamilySwimCell.h
//  WaterWorks
//
//  Created by Darshan on 30/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FamilySwimCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
}
//---cell - 1
@property (nonatomic , strong)IBOutlet UILabel *lblSwimDate;
@property (nonatomic , strong)IBOutlet UILabel *lblTheme;
@property (nonatomic , strong)IBOutlet UIButton *btnRegister;

//---cell - 2
@property (nonatomic , strong)IBOutlet UILabel *lblEventDate;
@property (nonatomic , strong)IBOutlet UILabel *lblStartTime;
@property (nonatomic , strong)IBOutlet UIButton *btnSelect;
@end
