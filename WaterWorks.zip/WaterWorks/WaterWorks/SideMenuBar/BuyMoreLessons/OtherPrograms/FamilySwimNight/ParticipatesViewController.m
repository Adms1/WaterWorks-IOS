//
//  ParticipatesViewController.m
//  WaterWorks
//
//  Created by Ankit on 29/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ParticipatesViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "DrivesTurnCell.h"
#import "EventViewController.h"
#import "CustomTabbar.h"

@interface ParticipatesViewController ()<CommonDelegate>
{
    NSArray *arrStudentList;
    NSMutableArray *arrStudent, *arrStudentId;
}
@end

@implementation ParticipatesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self SwimComp_StuList_FamilyWise];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksParticipants :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)SwimComp_StuList_FamilyWise
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"FamilyID":[[NSUserDefaults standardUserDefaults]valueForKey:FAMILYID],
                             @"meetdate":[[_strMeetDate componentsSeparatedByString:@" "]firstObject]
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    arrStudent = [[NSMutableArray alloc]init];
    arrStudentId = [[NSMutableArray alloc]init];
    
    [manager POST:SwimComp_StuList_FamilyWise_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrStudentList = [responseObject safeObjectForKey:@"FinalArray"];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        [tblStudentList reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)SwimCmpt_Register_SwimMeetStep1Check
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"MeetdatetimeValue":_strMeetDate
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:SwimCmpt_Register_SwimMeetStep1Check_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([[[[responseObject safeObjectForKey:@"SwimMeetDateStep1check"]valueForKey:@"Msg1_Hours"] objectAtIndex:0]isEqual:[NSNull null]])
            {
                EventViewController *evc = [[EventViewController alloc]initWithNibName:@"EventViewController" bundle:nil];
                evc.arrStudentIds = arrStudentId;
                [[self navigationController]pushViewController:evc animated:YES];
            }
            else
            {
                [CommonClass showToastMsg:[[[responseObject valueForKey:@"SwimMeetDateStep1check"] valueForKey:@"Msg1_Hours"] objectAtIndex:0]];
            }
        }
        else{
            EventViewController *evc = [[EventViewController alloc]initWithNibName:@"EventViewController" bundle:nil];
            evc.arrStudentIds = arrStudentId;
            [[self navigationController]pushViewController:evc animated:YES];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        [tblStudentList reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    //CGSize expectedLabelSize = [((UILabel *)viewHeader.subviews[0]).text sizeWithFont:((UILabel *)viewHeader.subviews[0]).font constrainedToSize:CGSizeMake(((UILabel *)viewHeader.subviews[0]).frame.size.width, CGFLOAT_MAX) lineBreakMode:NSLineBreakByWordWrapping]; // deprecated
    
    CGRect expectedLabelSize = [((UILabel *)viewHeader.subviews[0]).text boundingRectWithSize:CGSizeMake(((UILabel *)viewHeader.subviews[0]).frame.size.width, CGFLOAT_MAX)  options:NSStringDrawingUsesLineFragmentOrigin| NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:((UILabel *)viewHeader.subviews[0]).font} context:nil];
    
    return expectedLabelSize.size.height + 40;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    CGFloat height = (self.view.frame.size.width * 55) / 320;
    return height;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrStudentList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"DrivesTurnCell";
    
    DrivesTurnCell *cell = (DrivesTurnCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DrivesTurnCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.lblTitle.text = [[arrStudentList objectAtIndex:indexPath.row] valueForKey:@"StudentName"];
    cell.btnselect.tag = indexPath.row;
    [cell.btnselect addTarget:self action:@selector(btnSelect:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([arrStudent containsObject:cell.lblTitle.text]) {
        [cell.btnselect setSelected:YES];
    }
    return  cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [CustomAnimation SlideUp:cell :0.3];
}

-(void)btnSelect:(UIButton *)sender
{
    //sender.selected = !sender.selected;
    NSString *str = [[arrStudentList objectAtIndex:sender.tag] valueForKey:@"StudentName"];
    NSString *str1 = [[arrStudentList objectAtIndex:sender.tag] valueForKey:@"StudentID"];
    
    if ([arrStudent containsObject:str]) {
        [arrStudent removeObject:str];
        [arrStudentId removeObject:str1];
    }else{
        [arrStudent addObject:str];
        [arrStudentId addObject:str1];
    }
}

- (IBAction)onClickNextBtn:(id)sender
{
    SHARED_APPDELEGATE.arrStudentName = arrStudent;
    if (arrStudentId.count > 0) {
        [self SwimCmpt_Register_SwimMeetStep1Check];
    }else{
        [CommonClass showToastMsg:OneStudentSelection];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
