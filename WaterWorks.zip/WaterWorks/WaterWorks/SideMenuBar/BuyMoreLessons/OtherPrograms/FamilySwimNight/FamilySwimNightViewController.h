//
//  FamilySwimNightViewController.h
//  WaterWorks
//
//  Created by Darshan on 30/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "SelectLocationViewController.h"

@interface FamilySwimNightViewController : UIViewController<LocationDelegate>
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UITableView *tblSwim;
    IBOutlet UITextView *txtInstruction;
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnLocation;
    
    NSMutableArray *arrLocationList;
    NSMutableArray *arrSwimList;
    IBOutlet NSLayoutConstraint *tblHeight;
}

@property (nonatomic , strong) NSString *strProgramID;
@property (nonatomic , strong)IBOutlet UILabel *lblTesting;
@end
