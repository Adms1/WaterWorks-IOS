//
//  FamilySwimRegisterViewController.h
//  WaterWorks
//
//  Created by Ankit on 28/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FamilySwimRegisterViewController : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UILabel *lblTotalAmount, *lblWarning;
    IBOutlet UIButton *btnHome;
}
@property(nonatomic,retain)NSString *strSwimDate;
@end
