//
//  OtherViewController.m
//  WaterWorks
//
//  Created by Darshan on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "OtherViewController.h"
#import "CommonClass.h"
#import "FamilySwimNightViewController.h"
#import "DrivesTurnsViewController.h"
#import "AppDelegate.h"
#import "SwimTeamViewController.h"
#import "MyCartViewController.h"
#import "CustomTabbar.h"
#import "UpComingMeetViewController.h"
#import "RegisterViewController.h"

@interface OtherViewController ()<CommonDelegate>

@end

@implementation OtherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    [params setObject:strToken forKey:@"Token"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:showHiden_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceHideShow %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrLesson = [responseObject safeObjectForKey:@"FinalArray"];
            
            arrOtherProgramList = [[NSMutableArray alloc] init];
            
            for (NSDictionary *dict in arrLesson) {
                //
                if ([[dict safeObjectForKey:@"SwimCompFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Swim Competition" titleValue:[dict safeObjectForKey:@"SwimCompFlag"] andProgramID:@"1"]];
                }
                
                if ([[dict safeObjectForKey:@"FamilySwimFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Family Swim Night" titleValue:[dict safeObjectForKey:@"FamilySwimFlag"] andProgramID:@"2"]];
                }
                
                if ([[dict safeObjectForKey:@"SwimTeamFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Swim Teams" titleValue:[dict safeObjectForKey:@"SwimTeamFlag"] andProgramID:@"3"]];
                }
                
                if ([[dict safeObjectForKey:@"SwimCampFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Swim Camps" titleValue:[dict safeObjectForKey:@"SwimCampFlag"] andProgramID:@"4"]];
                }
                
                if ([[dict safeObjectForKey:@"GirlScoutFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Girl Scout Swim Programs" titleValue:[dict safeObjectForKey:@"GirlScoutFlag"] andProgramID:@"10"]];
                }
                
                if ([[dict safeObjectForKey:@"DivesTurnsFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Dives and Turns Clinic" titleValue:[dict safeObjectForKey:@"DivesTurnsFlag"] andProgramID:@"5"]];
                }
                
                if ([[dict safeObjectForKey:@"LifeGuardFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Jr. Guard Prep" titleValue:[dict safeObjectForKey:@"LifeGuardFlag"] andProgramID:@"6"]];
                }
                
                if ([[dict safeObjectForKey:@"MeritBadgeFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Lifesaving/Swimming Merit Badges" titleValue:[dict safeObjectForKey:@"MeritBadgeFlag"] andProgramID:@"7"]];
                }
                
                if ([[dict safeObjectForKey:@"ActivityBadgeFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Aquanaut/Swimming Activity Badges" titleValue:[dict safeObjectForKey:@"ActivityBadgeFlag"] andProgramID:@"8"]];
                }
                
                if ([[dict safeObjectForKey:@"WaterPoloFlag"] isEqualToString:@"1"]) {
                    [arrOtherProgramList addObject:[self getShowDictionaryWithTitle:@"Water Polo Conditioning" titleValue:[dict safeObjectForKey:@"WaterPoloFlag"] andProgramID:@"9"]];
                }
            }
            [tblOtherList reloadData];
        }else{
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"Msg"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
    for (UIView *v in viewFooter.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            v.layer.shadowColor = [[UIColor lightGrayColor] CGColor];
            v.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
            v.layer.shadowOpacity = 1.0f;
            v.layer.shadowRadius = 1.0f;
        }
    }
}

-(NSMutableDictionary *)getShowDictionaryWithTitle:(NSString *)title titleValue:(NSString *)strValue andProgramID:(NSString *)strProgramID
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:title forKey:@"title"];
    [dict setObject:strValue forKey:@"TitleValue"];
    [dict setObject:strProgramID forKey:@"ProgramID"];
    return dict;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :2 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnAddToCart :YES :self];
}

-(void)popViewController
{
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:0] animated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return viewHeader.frame.size.height;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return  viewFooter.frame.size.height;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return viewFooter;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrOtherProgramList count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  50.0f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"OtherCell";
    
    OtherCell *cell = (OtherCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OtherCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    [cell setShowOtherListData:[arrOtherProgramList objectAtIndex:indexPath.row]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherCell *cell = (OtherCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    NSString *strSwimValue = [[arrOtherProgramList objectAtIndex:indexPath.row] valueForKey:@"ProgramID"];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if ([strSwimValue isEqualToString:@"1"]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        NSDictionary *params = @{
                                 @"Token":[userDefault objectForKey:TOKEN],
                                 };
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [manager POST:SwimCmpt_CheckStudentMeetExist_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"RESPONSE  %@",responseObject);
            
            NSNumber *idx;
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                idx = [[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckMeet"];
                
                if ([idx isEqual:@1])
                {
                    SHARED_APPDELEGATE.items = @[@"Today's Meet", @"Register",@"Trophy Room"];
                }
                else
                {
                    SHARED_APPDELEGATE.items = @[@"Upcoming Meet", @"Register",@"Trophy Room"];
                }
                
                [[NSUserDefaults standardUserDefaults]setInteger:[idx integerValue] forKey:@"CheckMeet"];
                if (![idx isEqual:@0])
                {
                    UpComingMeetViewController *viewUpcoming = [[UpComingMeetViewController alloc] initWithNibName:@"UpComingMeetViewController" bundle:nil];
                    [self.navigationController pushViewController:viewUpcoming animated:YES];
                }
                else
                {
                    RegisterViewController *viewRegister = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:nil];
                    viewRegister.strSwimCopatitionProgramID = @"1";
                    [self.navigationController pushViewController:viewRegister animated:YES];
                }
            }
            
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
        
    }
    else if ([strSwimValue isEqualToString:@"2"]) {
        FamilySwimNightViewController *viewFamily = [[FamilySwimNightViewController alloc] initWithNibName:@"FamilySwimNightViewController" bundle:nil];
        viewFamily.strProgramID = strSwimValue;
        [userDefault removeObjectForKey:WATERPOLO];
        [userDefault removeObjectForKey:GUARDPREP];
        [userDefault removeObjectForKey:ACTIVITYBADGES];
        [userDefault removeObjectForKey:LIFESAVING];
        [self.navigationController pushViewController:viewFamily animated:YES];
    }
    else if ([strSwimValue isEqualToString:@"3"]) {
        SwimTeamViewController *swimTeam = [[SwimTeamViewController alloc] initWithNibName:@"SwimTeamViewController" bundle:nil];
        swimTeam.programId = strSwimValue;
        [self.navigationController pushViewController:swimTeam animated:YES];
    }
    else
    {
        DrivesTurnsViewController *viewDrivesTurns = [[DrivesTurnsViewController alloc] initWithNibName:@"DrivesTurnsViewController" bundle:nil];
        viewDrivesTurns.strprogramid = strSwimValue;
        viewDrivesTurns.strTitle = cell.lblTitle.text;
        [self.navigationController pushViewController:viewDrivesTurns animated:YES];
        
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (IBAction)onClickLapSwimBtn:(id)sender {
    
    LapSwimOptionsViewController *viewLap = [[LapSwimOptionsViewController alloc] initWithNibName:@"LapSwimOptionsViewController" bundle:nil];
    [self.navigationController pushViewController:viewLap animated:YES];
}

- (IBAction)onClickWaterAerobcsBtn:(id)sender {
    
    WaterAerobcsViewController *viewWater = [[WaterAerobcsViewController alloc] initWithNibName:@"WaterAerobcsViewController" bundle:nil];
    viewWater.strWaterProgramID = @"12";
    [self.navigationController pushViewController:viewWater animated:YES];
}


- (IBAction)onClickOtherProgramsBtn:(id)sender {
    
    OtherViewController *viewOther = [[OtherViewController alloc] initWithNibName:@"OtherViewController" bundle:nil];
    [self.navigationController pushViewController:viewOther animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
