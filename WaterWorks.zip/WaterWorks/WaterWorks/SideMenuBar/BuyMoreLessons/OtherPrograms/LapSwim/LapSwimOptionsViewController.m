//
//  LapSwimOptionsViewController.m
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LapSwimOptionsViewController.h"
#import "LapSwimPackageViewController.h"
#import "LapSwimPassViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface LapSwimOptionsViewController ()<CommonDelegate>

@end

@implementation LapSwimOptionsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    btnLapPackage.layer.borderWidth = 1.0f;
    btnLapPackage.layer.borderColor = LapSwimColor.CGColor;
    
    btnMonthlyPass.layer.borderWidth = 1.0f;
    btnMonthlyPass.layer.borderColor = LapSwimColor.CGColor;
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksLapSwims :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onClickLapSwimPackageBtn:(id)sender {
    
    LapSwimPackageViewController *viewLapSwim = [[LapSwimPackageViewController alloc] initWithNibName:@"LapSwimPackageViewController" bundle:nil];
    viewLapSwim.strLapSwimProgramID = @"11";
    [self.navigationController pushViewController:viewLapSwim animated:YES];
}

- (IBAction)onClickMonthlyLapSwimPassBtn:(id)sender {
    LapSwimPassViewController *viewLapSwim = [[LapSwimPassViewController alloc] initWithNibName:@"LapSwimPassViewController" bundle:nil];
    [self.navigationController pushViewController:viewLapSwim animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
