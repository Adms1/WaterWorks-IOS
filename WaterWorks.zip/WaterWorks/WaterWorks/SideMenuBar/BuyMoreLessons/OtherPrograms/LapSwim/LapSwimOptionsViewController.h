//
//  LapSwimOptionsViewController.h
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LapSwimOptionsViewController : UIViewController

{
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnLapPackage;
    IBOutlet UIButton *btnMonthlyPass;
}
@end
