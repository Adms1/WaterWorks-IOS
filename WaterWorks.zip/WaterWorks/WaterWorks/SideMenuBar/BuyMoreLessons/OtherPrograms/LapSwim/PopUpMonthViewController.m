//
//  PopUpMonthViewController.m
//  WaterWorks
//
//  Created by Darshan on 04/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PopUpMonthViewController.h"

@interface PopUpMonthViewController ()

@end

@implementation PopUpMonthViewController

@synthesize strMonthType;
@synthesize delegate;
@synthesize index;
@synthesize arrMonthList;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if ([strMonthType isEqualToString:@"NumberMonth"]) {
        arrMonthList = [[NSMutableArray alloc] init];
        [arrMonthList addObject:[self getShowDictionaryWithTitle:@"Please Choose" titleValue:@"0"]];
        [arrMonthList addObject:[self getShowDictionaryWithTitle:@"1 Month" titleValue:@"1"]];
        [arrMonthList addObject:[self getShowDictionaryWithTitle:@"3 Months" titleValue:@"2"]];
        [arrMonthList addObject:[self getShowDictionaryWithTitle:@"6 Months" titleValue:@"3"]];
        [arrMonthList addObject:[self getShowDictionaryWithTitle:@"12 Months" titleValue:@"4"]];
    }
}

-(NSMutableDictionary *)getShowDictionaryWithTitle:(NSString *)title titleValue:(NSString *)strValue
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:title forKey:@"title"];
    [dict setObject:strValue forKey:@"TitleValue"];
    return dict;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrMonthList count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdenti = @"Event1";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdenti];
    }
    if ([strMonthType isEqualToString:@"NumberMonth"])
    {
        cell.textLabel.text = [NSString stringWithFormat:@"%@",[[arrMonthList valueForKey:@"title"]objectAtIndex:indexPath.row]];
    }
    else
    {
        cell.textLabel.text = [[arrMonthList valueForKey:@"MonthName"] objectAtIndex:indexPath.row];
    }
    
    return  cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strMonthID,*strMonth;
    if ([strMonthType isEqualToString:@"NumberMonth"])
    {
        strMonthID = [[arrMonthList valueForKey:@"TitleValue"]objectAtIndex:indexPath.row];
        strMonth = [[arrMonthList valueForKey:@"title"]objectAtIndex:indexPath.row];
    }
    else
    {
        strMonthID = [[arrMonthList valueForKey:@"MonthId"]objectAtIndex:indexPath.row];
        strMonth = [[arrMonthList valueForKey:@"MonthName"]objectAtIndex:indexPath.row];
    }
    if (delegate &&[delegate respondsToSelector:@selector(selectMonthsPopUp:andMonthIndex:andType:)]) {
        [delegate selectMonthsPopUp:strMonth andMonthIndex:strMonthID andType:strMonthType];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
