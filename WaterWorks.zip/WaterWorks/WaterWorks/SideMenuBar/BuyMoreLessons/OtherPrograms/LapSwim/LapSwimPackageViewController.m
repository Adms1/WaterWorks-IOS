//
//  LapSwimPackageViewController.m
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LapSwimPackageViewController.h"
#import "CommonClass.h"
#import "Location.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#import "NIDropDown.h"

@interface LapSwimPackageViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NSString *strSiteID, *strLapSwimQnt;
    NSMutableArray *arrLocationList;
    NIDropDown *dropDown;
}
@end

@implementation LapSwimPackageViewController

@synthesize strLapSwimProgramID;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strLapSwimProgramID forKey:@"programid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:programInstruction_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSMutableArray *arrInstruction = [responseObject safeObjectForKey:@"Instruction"];
            
            if ([arrInstruction count] > 0) {
                
                NSDictionary *dict = [arrInstruction firstObject];
                txtInstruction.text = [dict safeObjectForKey:@"Instruction"];
                [txtInstruction setTextContainerInset:UIEdgeInsetsMake(0, 0, 0, 0)];
                [self setLocationDataList];
            }
        }else{
            [self setLocationDataList];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [btnSelectLocation setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectLocation.frame.size.width - 20, 0, 0)];
    [btnSessions setImageEdgeInsets:UIEdgeInsetsMake(0, btnSessions.frame.size.width - 20, 0, 0)];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksLapSwims :self :btnHome :nil :YES :self];
}

-(void)Get_RegLapSwimPriceBySite:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"siteid":strSiteId,
                             @"programid":strLapSwimProgramID,
                             };
    
    //    Get_RegLapSwimPriceBySite_Url
    [manager POST:PriceInfo_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
//            NSDictionary *dic = [[responseObject valueForKey:@"EmailPref"]objectAtIndex:0];
//            lblCost.text = [NSString stringWithFormat:@"%@\nOR\n%@",[dic valueForKey:@"PerSession1"],[dic valueForKey:@"PerSession2"]];
            
            NSDictionary *dic = [[responseObject valueForKey:@"Instruction"]objectAtIndex:0];
            lblCost.text = [dic valueForKey:@"Instruction"];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setLocationDataList
{
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        if (flag) {
            arrLocationList = [[NSMutableArray alloc] init];
            
            NSMutableArray *arrLocation = [responseObject safeObjectForKey:@"SiteList"];
            
            if ([arrLocation count] > 0) {
                
                for (NSDictionary *dict in arrLocation) {
                    
                    Location *objLocation = [[Location alloc] init];
                    
                    objLocation.sitename = [dict valueForKey:@"sitename"];
                    objLocation.siteid = [dict valueForKey:@"siteid"];
                    objLocation.Lafitness = [dict valueForKey:@"Lafitness"];
                    objLocation.Address1 = [dict valueForKey:@"Address1"];
                    objLocation.Address2 = [dict valueForKey:@"Address2"];
                    objLocation.City = [dict valueForKey:@"City"];
                    objLocation.State = [dict valueForKey:@"State"];
                    objLocation.ZipCode = [dict valueForKey:@"ZipCode"];
                    objLocation.Phone = [dict valueForKey:@"Phone"];
                    
                    [arrLocationList addObject:objLocation];
                }
                if ([arrLocationList count] == 1) {
                    
                    Location *objLocation = [arrLocationList objectAtIndex:0];
                    
                    NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation.sitename];
                    NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation.siteid];
                    NSString *strLAfit = [NSString stringWithFormat:@"%@",objLocation.Lafitness];
                    
                    [btnSelectLocation setTitle:strTitle forState:UIControlStateNormal];
                    
                    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                    
                    [userDefault setObject:strLocationID forKey:SITEID];
                    [userDefault setObject:strLAfit forKey:LAFITNESS];
                    
                    strSiteID = strLocationID;
                    
                    [self Get_RegLapSwimPriceBySite:strSiteID];
                }
            }
        }
    }];
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSelectLocation :sender :self];
    }
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    strSiteID = [[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx];
    [self Get_RegLapSwimPriceBySite:strSiteID];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    strLapSwimQnt = [NSString stringWithFormat:@"%ld",(long)idx];
}

- (IBAction)onClickSelectSessionsBtn:(id)sender {
    //    SessionPopUpViewController *viewSessionPopUp = [[SessionPopUpViewController alloc] initWithNibName:@"SessionPopUpViewController" bundle:nil];
    //    viewSessionPopUp.sessionsDelegate = self;
    //    [self presentPopupViewController:viewSessionPopUp animationType:MJPopupViewAnimationFade];
    
    if(dropDown == nil) {
        CGFloat f = 300;
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        for (int i = 0; i < 100; i++) {
            [arr addObject:[NSNumber numberWithInt:i]];
        }
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

-(void)rel{
    dropDown = nil;
}

-(void)selectSessionsAtIndex:(NSString *)strSessions
{
    NSLog(@"strSessions>>> %@",strSessions);
    
    strLapSwimQnt = strSessions;
    [btnSessions setTitle:strSessions forState:UIControlStateNormal];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType;{
    
    [btnSelectLocation setTitle:strType forState:UIControlStateNormal];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    strSiteID = strID;
    [self Get_RegLapSwimPriceBySite:strID];
}
- (IBAction)onClickSelectSubmitBtn:(id)sender {
    
    lblWarning.text = @"";
    if (strLapSwimQnt == nil || [strLapSwimQnt isEqualToString:@"0"])
    {
        [CommonClass showToastMsg:SessionSelection];
    }
    else if (strSiteID == nil)
    {
        [CommonClass showToastMsg:SiteSelection];
    }
    else
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
        {
            [self AddtoCart];
        }
        else{
            [CommonClass setGetBasketID:^(BOOL success) {
                if (success) {
                    [self AddtoCart];
                }
            }];
        }
    }
}
-(void)AddtoCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    NSString *strFamilyID = [[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID];
    
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    [params setObject:strFamilyID forKey:@"FamilyID"];
    [params setObject:strBasketID forKey:@"BasketID"];
    [params setObject:strSiteID forKey:@"SiteID"];
    [params setObject:strLapSwimQnt forKey:@"LapSwimQnt"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:MakePurchase_AddLapSwim_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
