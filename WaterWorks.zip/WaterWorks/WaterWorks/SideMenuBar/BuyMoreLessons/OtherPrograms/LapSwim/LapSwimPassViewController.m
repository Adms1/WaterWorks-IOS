//
//  LapSwimPassViewController.m
//  WaterWorks
//
//  Created by D2D Websolution on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LapSwimPassViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "MyCartViewController.h"
#include <math.h>
#import "NIDropDown.h"

@interface LapSwimPassViewController ()<NIDropDownDelegate,CommonDelegate>
{
    NSMutableArray *arrLocationList, *arrCost, *arrMonth;
    NSArray *arrHeader;
    NSString *strSiteID;
    NIDropDown *dropDown;
}
@end

@implementation LapSwimPassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //    viewCost.layer.cornerRadius = 4.0f;
    viewCost.layer.borderWidth = 1.0f;
    viewCost.layer.borderColor = [UIColor blackColor].CGColor;
    
    [self MakePurchase_LapSwimMonthList];
    
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        if (flag) {
            
            arrLocationList = [responseObject safeObjectForKey:@"SiteList"];
            
            if (arrLocationList.count == 1)
            {
                NSDictionary *objLocation = [arrLocationList objectAtIndex:0];
                NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation[@"sitename"]];
                NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation[@"siteid"]];
                
                [btnSelectLocation setTitle:strTitle forState:UIControlStateNormal];
                
                NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                
                [userDefault setObject:strLocationID forKey:SITEID];
                
                strSiteID = strLocationID;
                [self monthlySwimDic:strLocationID];
            }
        }
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksLapSwims :self :btnHome :nil :YES :self];
}

-(void)MakePurchase_LapSwimMonthList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:MakePurchase_LapSwimMonthList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrMonth = [responseObject safeObjectForKey:@"PhoneList"] ;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)monthlySwimDic:(NSString *)strSiteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    [params setObject:strSiteId forKey:@"siteid"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:monthlySwimDic_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"False"]) {
            
            arrCost = [responseObject safeObjectForKey:@"EmailPref"];
            [self AddCostView];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)viewWillLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    [btnSelectMonth setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectMonth.frame.size.width - 30, 0, 0)];
    [btnSelectStartMonth setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectStartMonth.frame.size.width - 30, 0, 0)];
    [btnSelectLocation setImageEdgeInsets:UIEdgeInsetsMake(0, btnSelectLocation.frame.size.width - 30, 0, 0)];
    
    if (viewCost.subviews.count == 0) {
        
        arrHeader = @[@"Number of Months",@"Regular Price",@"Discounted Price",@"Senior Disc. Price"];
        
        [viewCost layoutIfNeeded];
        [self AddCostView];
    }
}
-(void)AddCostView
{
    [viewCost.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    CGFloat width = viewCost.frame.size.width/4;
    CGFloat height = viewCost.frame.size.height/5;
    
    for (int i = 0; i < 4; i++)
    {
        float cnt = (i+1) * height;
        UIView *subview = [[UIView alloc]initWithFrame:CGRectMake(i*width, 0, width, viewCost.frame.size.height)];
        subview.backgroundColor = [UIColor clearColor];
        [viewCost addSubview:subview];
        
        UIView *HstripeView = [[UIView alloc]initWithFrame:CGRectMake(i*width, 0, 1, viewCost.frame.size.height)];
        HstripeView.backgroundColor = [UIColor blackColor];
        [viewCost addSubview:HstripeView];
        
        UIView *VstripeView = [[UIView alloc]initWithFrame:CGRectMake(0, (i+1) == 1 ? cnt+10 : ((i+1)*(height-2))+10, viewCost.frame.size.width, 1)];
        VstripeView.backgroundColor = [UIColor blackColor];
        [viewCost addSubview:VstripeView];
        
        for (int j = 0; j < 5; j++)
        {
            float cnt = j * height;
            UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(0, j == 1 ?cnt+10 : j == 0 ? cnt:(j*(height-2))+10, subview.frame.size.width, j == 0 ? height + 10 : height-2)];
            lbl.numberOfLines = 0;
            lbl.lineBreakMode = NSLineBreakByWordWrapping;
            
            if (j == 0)
            {
                lbl.text = [arrHeader objectAtIndex:i];
            }
            else if(i == 0 && j != 0)
            {
                int formula = 3 * pow(2, j-2);
                lbl.text = [[NSNumber numberWithInt:(j-1 == 0) ? 1 : formula]stringValue];
            }
            else
            {
                if (arrCost.count > 0) {
                    int formula = 3 * pow(2, j-2);
                    lbl.text = [[arrCost objectAtIndex:0] valueForKey:[NSString stringWithFormat:@"%dMonth%@",(j-1 == 0) ? 1 : formula,[[arrHeader objectAtIndex:i]substringToIndex:3]]];
                }
                else{
                    lbl.text = @"-";
                }
            }
            lbl.font = FONT_OpenSans(12);
            lbl.textAlignment = NSTextAlignmentCenter;
            lbl.textColor = [UIColor blackColor];
            lbl.tag = j;
            [subview addSubview:lbl];
        }
    }
}

- (IBAction)onClickSelectNumberOfMonthBtn:(id)sender {
    
    //    PopUpMonthViewController *viewSessionPopUp = [[PopUpMonthViewController alloc] initWithNibName:@"PopUpMonthViewController" bundle:nil];
    //    viewSessionPopUp.delegate = self;
    //    viewSessionPopUp.strMonthType = @"NumberMonth";
    //    [self presentPopupViewController:viewSessionPopUp animationType:MJPopupViewAnimationFade];
    
    if(dropDown == nil) {
        CGFloat f = 300;
        NSArray *arr = @[@"Please Choose",@"1 Month",@"3 Months",@"6 Months",@"12 Months"];
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickStartMonthBtn:(id)sender {
    
    //    PopUpMonthViewController *viewSessionPopUp = [[PopUpMonthViewController alloc] initWithNibName:@"PopUpMonthViewController" bundle:nil];
    //    viewSessionPopUp.delegate = self;
    //    viewSessionPopUp.strMonthType = @"NumberMonthList";
    //    viewSessionPopUp.arrMonthList = arrMonth;
    //    [self presentPopupViewController:viewSessionPopUp animationType:MJPopupViewAnimationFade];
    
    if(dropDown == nil) {
        CGFloat f = 300;
        NSArray *arr = [arrMonth valueForKey:@"MonthName"];
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickSelectLocationBtn:(id)sender {
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnSelectLocation :sender :self];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    strSiteID = [[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx];
    [self monthlySwimDic:strSiteID];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

-(void)selectLocationIDPopUp:(NSString *)strID laFitness:(NSString *)stFitNess andReturnType:(NSString *)strType;{
    
    [btnSelectLocation setTitle:strType forState:UIControlStateNormal];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    strSiteID = strID;
    [self monthlySwimDic:strID];
}

-(void)selectMonthsPopUp:(NSString *)strMonth andMonthIndex:(NSString *)strIndex andType:(NSString *)strType
{
    if ([strType isEqualToString:@"NumberMonth"]) {
        [btnSelectMonth setTitle:strMonth forState:UIControlStateNormal];
    }else{
        [btnSelectStartMonth setTitle:strMonth forState:UIControlStateNormal];
    }
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickSubmitBtn:(id)sender
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:BASKETID] != nil)
    {
        if (strSiteID == nil)
        {
            [CommonClass showToastMsg:SiteSelection];
        }
        else if ([btnSelectMonth.titleLabel.text isEqualToString:@"Please Choose"])
        {
            [CommonClass showToastMsg:NumberOfMonths];
        }
        else if ([btnSelectStartMonth.titleLabel.text isEqualToString:@"Please Choose"])
        {
            [CommonClass showToastMsg:StartingMonth];
        }
        else
        {
            [self AddtoCart];
        }
    }
    else
    {
        [CommonClass setGetBasketID:^(BOOL success) {
            if (success)
            {
                if (strSiteID == nil)
                {
                    [CommonClass showToastMsg:SiteSelection];
                }
                else if ([btnSelectMonth.titleLabel.text isEqualToString:@"Please Choose"])
                {
                    [CommonClass showToastMsg:NumberOfMonths];
                }
                else if ([btnSelectStartMonth.titleLabel.text isEqualToString:@"Please Choose"])
                {
                    [CommonClass showToastMsg:StartingMonth];
                }
                else
                {
                    [self AddtoCart];
                }
            }
        }];
    }
}

-(void)AddtoCart
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *strBasketID = [[NSUserDefaults standardUserDefaults]objectForKey:BASKETID];
    
    NSString *strFamilyID = [[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID];
    
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    [params setObject:strFamilyID forKey:@"FamilyID"];
    [params setObject:strBasketID forKey:@"BasketID"];
    [params setObject:strSiteID forKey:@"SiteID"];
    [params setObject:[[btnSelectMonth.titleLabel.text componentsSeparatedByString:@" "] firstObject] forKey:@"MonthlyNumber"];
    [params setObject:[[arrMonth valueForKey:@"MonthId"] objectAtIndex:[[arrMonth valueForKey:@"MonthName"] indexOfObject:btnSelectStartMonth.titleLabel.text]] forKey:@"StartMonth"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:MakePurchase_AddDiscountLapSwim_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
            [[self navigationController]pushViewController:mcvc animated:YES];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
