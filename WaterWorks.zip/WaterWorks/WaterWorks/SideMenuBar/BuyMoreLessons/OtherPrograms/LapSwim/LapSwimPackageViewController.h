//
//  LapSwimPackageViewController.h
//  WaterWorks
//
//  Created by Darshan on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectLocationViewController.h"
#import "SessionPopUpViewController.h"

@interface LapSwimPackageViewController : UIViewController<popUpSessionsDelegate,LocationDelegate>

{
    IBOutlet UITextView *txtInstruction;
    IBOutlet UIButton *btnSelectLocation;
    IBOutlet UIButton *btnSessions;
    IBOutlet UILabel *lblCost;
    IBOutlet UILabel *lblWarning;
    IBOutlet UIButton *btnHome;
}

@property (nonatomic , strong) NSString *strLapSwimProgramID;
@end
