//
//  PopUpMonthViewController.h
//  WaterWorks
//
//  Created by Darshan on 04/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol MonthPopUpDelegate <NSObject>

-(void)selectMonthsPopUp:(NSString *)strMonth andMonthIndex:(NSString *)strIndex andType:(NSString *)strType;

@end

@interface PopUpMonthViewController : UIViewController

{
    IBOutlet UITableView *tblMonthList;
    
}

//Delegate
@property (assign, nonatomic) id <MonthPopUpDelegate> delegate;

@property (nonatomic) int index;

@property (nonatomic , strong) NSString *strMonthType;
@property (nonatomic , strong) NSMutableArray *arrMonthList;


@end
