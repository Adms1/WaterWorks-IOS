//
//  LapSwimPassViewController.h
//  WaterWorks
//
//  Created by D2D Websolution on 29/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopUpMonthViewController.h"
#import "SelectLocationViewController.h"

@interface LapSwimPassViewController : UIViewController<MonthPopUpDelegate,LocationDelegate>
{
    IBOutlet UIButton *btnSelectMonth;
    IBOutlet UIButton *btnSelectStartMonth;
    IBOutlet UIButton *btnSelectLocation;
    IBOutlet UIView *viewCost;
    IBOutlet UIButton *btnHome;
}
@end
