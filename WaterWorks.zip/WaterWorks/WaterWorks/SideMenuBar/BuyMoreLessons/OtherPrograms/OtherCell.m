//
//  OtherCell.m
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "OtherCell.h"

@implementation OtherCell
@synthesize lblTitle;

- (void)awakeFromNib {
    [super awakeFromNib];
    
    viewBack.layer.shadowColor = [[UIColor lightGrayColor] CGColor];
    viewBack.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
    viewBack.layer.shadowOpacity = 1.0f;
    viewBack.layer.shadowRadius = 1.0f;
}

-(void)setShowOtherListData:(NSDictionary *)dictParam
{
    if ([[dictParam objectForKey:@"title"] isEqualToString:@"Girl Scout Swim Programs"])
    {
        lblTitle.text = @"Girls Scout Program";
    }
    else if ([[dictParam objectForKey:@"title"] isEqualToString:@"Jr. Guard Prep"])
    {
        lblTitle.text = @"Junior Lifeguard Prep Courses";
    }
    else if ([[dictParam objectForKey:@"title"] isEqualToString:@"Dives and Turns Clinic"])
    {
        lblTitle.text = @"Dives & Turns Clinics";
    }
    else if ([[dictParam objectForKey:@"title"] isEqualToString:@"Water Polo Conditioning"])
    {
        lblTitle.text = @"Water Polo Clinics";
    }
    else
    {
        lblTitle.text = [dictParam objectForKey:@"title"];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
