//
//  AddRemoveLocation.m
//  WaterWorks
//
//  Created by Ankit on 17/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "AddRemoveLocation.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface AddRemoveLocation ()<CommonDelegate>
{
    NSString *googleMapKey;
}
@end

@implementation AddRemoveLocation

- (void)viewDidLoad {
    [super viewDidLoad];
    googleMapKey = @"AIzaSyDHQzQyCWN_OjTnScZvWfbWmnaBplA7a1k";
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksAddLocation :self :btnHome :nil :YES :self];
    
    [btnLocation setTitle:_btnStatus forState:0];
    [btnPhonoNo setTitle:[_arrLocation valueForKey:@"Phone"] forState:0];
    NSString *str = [NSString stringWithFormat:@"%@\n%@, %@ %@",[_arrLocation valueForKey:@"Address1"],[_arrLocation valueForKey:@"City"],[_arrLocation valueForKey:@"State"],[_arrLocation valueForKey:@"ZipCode"]];
    [lblAddress setText:str];
    [self GetLatLon:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@&key=%@",str,googleMapKey] :str];
}

-(void)GetLatLon:(NSString *)strRequest :(NSString *)strAddress
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager GET:[strRequest stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSArray *arr = [[[responseObject valueForKey:@"results"]valueForKey:@"geometry"] valueForKey:@"location"];
        
        if(arr.count == 0) {
            [self GetLatLon:[NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?address=%@",strAddress] :strAddress];
            return;
        }
        
        double lat = [[((NSArray *)[arr valueForKey:@"lat"]) firstObject]doubleValue];
        double lng = [[((NSArray *)[arr valueForKey:@"lng"]) firstObject]doubleValue];
        
        //Place a single pin
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(lat, lng);
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        [annotation setTitle:strAddress];
        
        MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
        region.center.latitude = lat ;
        region.center.longitude = lng;
        region.span.longitudeDelta = 0.15f;
        region.span.latitudeDelta = 0.15f;
        [mapView setRegion:region animated:YES];
        
        [mapView addAnnotation:annotation];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)AddRemoveLocation:(NSString *)web_url :(NSString *)siteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"siteid":siteId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:web_url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([web_url isEqualToString:Get_InsertSiteFromFamily_Url])
            {
                [CommonClass showToastMsg:LocationAdd];
                [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:self.navigationController.viewControllers.count-3] animated:YES];
            }
            else
            {
                [CommonClass showToastMsg:LocationRemove];
                [self.navigationController popViewControllerAnimated:YES];
            }
            
        }else{
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[[responseObject valueForKey:@"ChangePass"] valueForKey:@"Msg"] delegate:self];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (IBAction)onClickPhoneNoBtn:(UIButton *)sender
{
    NSString *phNo = sender.titleLabel.text;
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",phNo]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
        [[UIApplication sharedApplication] openURL:phoneUrl];
    }
    else
    {
        [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Call facility is not available!!!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
    }
}

- (IBAction)onClickAddRemoveLocationBtn:(UIButton *)sender
{
    if ([sender.titleLabel.text isEqualToString:@"Add Location"])
    {
        [self AddRemoveLocation:Get_InsertSiteFromFamily_Url :[_arrLocation valueForKey:@"SiteID"]];
    }
    else
    {
        if (_arrLocationCount > 1)
        {
            [self AddRemoveLocation:Get_RemoveSiteFromFamily_Url :[_arrLocation valueForKey:@"siteid"]];
        }
        else
        {
            [CommonClass showToastMsg:LocationAvailability];
        }
    }
}
-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
