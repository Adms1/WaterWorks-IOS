//
//  ProgressReportDetails.h
//  WaterWorks
//
//  Created by Ankit on 20/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProgressReportDetails : UIViewController
{
    IBOutlet UIScrollView *scroll_main;
    IBOutlet UITableView *tblLevels;
    IBOutlet UITableView *tblSkills;
    IBOutlet UIButton *btnHome;
    IBOutlet UIView *progressView;
    IBOutlet UIView *levelView;
    
    IBOutlet UILabel *lbl_studentName;
    IBOutlet UILabel *lbl_level;
    IBOutlet UILabel *lbl_level_per;
    IBOutlet UILabel *lbl_level_skills;
    
    IBOutlet UILabel *lbl_achievedSkills;
    IBOutlet UIButton *btnViewAllLevels;
    IBOutlet NSLayoutConstraint *tblHeight;
    IBOutlet NSLayoutConstraint *tblSkillHeight;
}
@property(nonatomic,retain)NSArray *studentArray;
@end
