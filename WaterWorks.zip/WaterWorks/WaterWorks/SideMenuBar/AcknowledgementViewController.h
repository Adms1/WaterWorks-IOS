//
//  AcknowledgementViewController.h
//  WaterWorks
//
//  Created by Ankit on 30/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AcknowledgementViewController : UIViewController
{
    IBOutlet UIButton *btnNext, *btnHome;
    IBOutlet UIScrollView *scrollView;
}
@property(nonatomic,retain)NSArray *arrStudentIds;
@end
