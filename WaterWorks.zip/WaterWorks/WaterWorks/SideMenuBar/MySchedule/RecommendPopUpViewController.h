//
//  RecommendPopUpViewController.h
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol popUpRemoveClassesDelegate <NSObject>

-(void)selectRemoveClassTime;

@end

@interface RecommendPopUpViewController : UIViewController

@property (assign, nonatomic) id <popUpRemoveClassesDelegate> removeDelegate;

@end
