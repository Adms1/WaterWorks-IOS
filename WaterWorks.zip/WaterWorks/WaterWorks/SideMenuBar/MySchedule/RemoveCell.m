//
//  RemoveCell.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RemoveCell.h"

@implementation RemoveCell

@synthesize timeDelegate;
@synthesize indexs;
@synthesize btnCheckMark;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    asyImg.layer.cornerRadius = asyImg.frame.size.width/2;
}

- (IBAction)onCheckMarkBtn:(id)sender {
    
    /*
    if([btnCheckMark isSelected]){
        [btnCheckMark setSelected:NO];
    }else{
        [btnCheckMark setSelected:YES];
    }
    if (timeDelegate &&[timeDelegate respondsToSelector:@selector(selectRemoveCellAtIndex:)]) {
        [timeDelegate selectRemoveCellAtIndex:index];
    } */
    
}

-(void)setRemoveDateTimeDataList:(RemoveDateTime*)objRemove
{
    if(objRemove.isSelected){
        [btnCheckMark setSelected:YES];
        self.viewBack.backgroundColor = sectionSelectColor;

    }else{
        [btnCheckMark setSelected:NO];
        self.viewBack.backgroundColor = sectionUnSelectColor;
    }
    
    NSString *strTitle = [NSString stringWithFormat:@"%@ - %@",[objRemove valueForKey:@"StudentName"],[objRemove valueForKey:@"wu_lessonname"]];
    NSString *strDateTime = [NSString stringWithFormat:@"%@ %@",[objRemove valueForKey:@"wu_Day"],[objRemove valueForKey:@"FormateTime"]];
    
    lblTitle.text = strTitle;
    lblDate.text = strDateTime;
    lblInstructor.text = [objRemove valueForKey:@"InstructorName"];
    
    [btnDate setTitle:[objRemove valueForKey:@"RemoveFrom"] forState:UIControlStateNormal];
    
    NSString *imageName;
    
    if ([objRemove valueForKey:@"wu_photo"] == nil || [[objRemove valueForKey:@"wu_photo"] isEqualToString:@""]) {
        asyImg.image = [UIImage imageNamed:@"DemoLogo"];
    }else{
        NSString *strUrl = [NSString stringWithFormat:@"%@",[objRemove valueForKey:@"wu_photo"]];
        NSString *escapedString = [strUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        imageName = [NSString stringWithFormat:@"%@",escapedString];
        //[imgInstructor loadImageFromStringforUserimg:imageName];
//        [asyImg loadImageWithURl:escapedString andPlaceholderName:nil];
        [asyImg loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
    }

    
    /*dispatch_async(dispatch_get_global_queue(0,0), ^{
        
        NSString *strUrl = [NSString stringWithFormat:@"%@",[objRemove valueForKey:@"wu_photo"]];
        NSString *escapedString = [strUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:escapedString]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            // WARNING: is the cell still using the same data by this point??
            asyImg.image = [UIImage imageWithData: data];
        });
    });*/

}

- (IBAction)onClickChangeDateBtn:(id)sender {
    
    if (timeDelegate &&[timeDelegate respondsToSelector:@selector(scheduleSetDateAtIndex:)]) {
        [timeDelegate scheduleSetDateAtIndex:indexs];
    }
//    DatePickerViewController *viewDatePicker  = [[DatePickerViewController alloc]initWithNibName:@"DatePickerViewController" bundle:nil];
//    viewDatePicker.datePickerDelegate = self;
//    [(UIViewController *)timeDelegate presentPopupViewController:viewDatePicker animationType:MJPopupViewAnimationFade];
}

//-(void)selectDateIntoDatePicker:(NSString *)strDate andCellIndex:(int)index{
//    
//    NSLog(@"strDate %@",strDate);
//    
//    if(strDate.length > 0){
//        [btnDate setTitle:strDate forState:UIControlStateNormal];
////        NSArray *arrDate = [strDate componentsSeparatedByString:@"/"];
////        NSString *newupdateDate =[arrDate componentsJoinedByString:@"|"];
//        if (timeDelegate &&[timeDelegate respondsToSelector:@selector(selectDateAtIndex:andDate:)]) {
//            [timeDelegate selectDateAtIndex:indexs andDate:strDate];
//        }
//    }
//    [(UIViewController *)timeDelegate dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
