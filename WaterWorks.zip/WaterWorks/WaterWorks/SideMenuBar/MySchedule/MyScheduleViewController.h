//
//  MyScheduleViewController.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScheduleCell.h"

@interface MyScheduleViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,lessonScheduleDelegate>
{
    IBOutlet UILabel *lblRemoveDayTime;
    
    IBOutlet UIButton *btnSelectedLesson;
    IBOutlet UIButton *btnHome;
    
    IBOutlet UIView *viewHeader;
    IBOutlet UITableView *tblSchedule;
    
    NSMutableArray *arrSchedule;
    
    NSString *strLastDate;
}


@end
