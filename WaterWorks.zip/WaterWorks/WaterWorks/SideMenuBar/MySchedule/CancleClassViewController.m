//
//  CancleClassViewController.m
//  WaterWorks
//
//  Created by ADMS on 02/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CancleClassViewController.h"

@interface CancleClassViewController ()

@end

@implementation CancleClassViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(IBAction)btnOk:(id)sender
{
    if (_CancelClassDelegate && [_CancelClassDelegate respondsToSelector:@selector(CancelClassPopup:)]) {
        [_CancelClassDelegate CancelClassPopup:self];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
