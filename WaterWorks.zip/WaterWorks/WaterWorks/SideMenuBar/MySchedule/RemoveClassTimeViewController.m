//
//  RemoveClassTimeViewController.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RemoveClassTimeViewController.h"
#import "RemoveDateTime.h"
#import "CommonClass.h"
#import "ClassTimeRemoveViewController.h"
#import "AppDelegate.h"
#import "MDDatePickerDialog.h"

@interface RemoveClassTimeViewController ()<MDDatePickerDialogDelegate,CommonDelegate>
{
    int Index;
    NSString *strRequestedEndDate;
}
@property(nonatomic) NSDateFormatter *dateFormatter;
@property(nonatomic) MDDatePickerDialog *datePicker;
@end

@implementation RemoveClassTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _dateFormatter = [[NSDateFormatter alloc] init];
    
    selectedSection = -1;
    
    tblRemoveTimeList.HVTableViewDataSource = self;
    tblRemoveTimeList.HVTableViewDelegate = self;
    
    UIBarButtonItem *barBtnhome = [[UIBarButtonItem alloc] initWithCustomView:btnHome];
    self.navigationItem.rightBarButtonItems = @[barBtnhome];
    
    tblRemoveTimeList.tableFooterView = viewFooter;
    [self getRemoveLessonsListing];
    
    arrSelected= [[NSMutableArray alloc]init];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksRemoveTime :self :btnHome :nil :YES :self];
}

-(void)getRemoveLessonsListing
{
    arrRemoveList = [[NSMutableArray alloc] init];
    arrRemoveListSelect = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:strToken forKey:@"Token"];
    [params setObject:[userDefault objectForKey:FAMILYID] forKey:@"FamilyID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:removeLessons_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrAfterLogin count] > 0) {
                
                for (NSDictionary *dict in arrAfterLogin) {
                    
                    RemoveDateTime *objRemoveDate = [[RemoveDateTime alloc] init];
                    
                    objRemoveDate.FormateTime = [dict safeObjectForKey:@"FormateTime"];
                    objRemoveDate.InstructorName = [dict safeObjectForKey:@"InstructorName"];
                    objRemoveDate.ReleaseID = [dict objectForKey:@"ReleaseID"];
                    objRemoveDate.RemoveFrom = [dict objectForKey:@"RemoveFrom"];
                    objRemoveDate.StudentName = [dict safeObjectForKey:@"StudentName"];
                    objRemoveDate.wu_Day = [dict safeObjectForKey:@"wu_Day"];
                    objRemoveDate.wu_lessonname = [dict objectForKey:@"wu_lessonname"];
                    objRemoveDate.wu_photo = [dict objectForKey:@"wu_photo"];
                    objRemoveDate.wu_sttimehr = [dict objectForKey:@"wu_sttimehr"];
                    objRemoveDate.wu_sttimemin = [dict objectForKey:@"wu_sttimemin"];
                    
                    [arrRemoveList addObject:objRemoveDate];
                }
                [tblRemoveTimeList reloadData];
            }
        }else{
            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            NSDictionary *dict = [arrAfterLogin firstObject];
            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark -
#pragma mark - TableView Delegate Method

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return  viewFooter.frame.size.height;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return viewFooter;
//}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrRemoveList count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath isExpanded:(BOOL)isexpanded
{
    //you can define different heights for each cell. (then you probably have to calculate the height or e.g. read pre-calculated heights from an array
    
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:indexPath.row];
    
    if(objRemoveDate.isSelected){
        return 188;
    }else{
        
        if (isexpanded){
            return 188;
        }
    }
    return 76.0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath isExpanded:(BOOL)isExpanded
{
    static NSString *simpleTableIdenti = @"RemoveCell";
    
    RemoveCell *cell = (RemoveCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RemoveCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.timeDelegate = self;
    cell.indexs = (int)indexPath.row;
    
    
    /*
     if([arrRemoveListSelect containsObject:arrRemoveList]) {
     cell.accessoryType = UITableViewCellAccessoryCheckmark;
     }
     else {
     cell.accessoryType = UITableViewCellAccessoryNone;
     } */
    
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:indexPath.row];
    [cell setRemoveDateTimeDataList:objRemoveDate];
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView expandCell:(UITableViewCell *)cell withIndexPath:(NSIndexPath *)indexPath
{
    //    UILabel *detailLabel = (UILabel *)[cell viewWithTag:3];
    //    UIButton *purchaseButton = (UIButton *)[cell viewWithTag:10];
    //    purchaseButton.alpha = 0;
    //    purchaseButton.hidden = NO;
    
    RemoveCell *cell1 = (RemoveCell *)cell;
    cell1.viewBack.backgroundColor = sectionSelectColor;
    cell1.btnCheckMark.selected = YES;
    
    RemoveCell *cell2 = [tableView cellForRowAtIndexPath:indexPath];
    
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:indexPath.row];
    
    [tblRemoveTimeList deselectRowAtIndexPath:indexPath animated:YES];
    
    if (cell2.accessoryType == UITableViewCellAccessoryNone) {
        //        cell2.accessoryType = UITableViewCellAccessoryCheckmark;
        [arrRemoveListSelect addObject:objRemoveDate.ReleaseID];
    }
    
    cell2.img.hidden = NO;
    objRemoveDate.isSelected = YES;
    [arrRemoveList replaceObjectAtIndex:indexPath.row withObject:objRemoveDate];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [UIView animateWithDuration:.5 animations:^{
        //        detailLabel.text = @"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
        //        purchaseButton.alpha = 1;
        [cell.contentView viewWithTag:7].transform = CGAffineTransformMakeRotation(3.14);
    }];
}

//perform your collapse stuff (may include animation) for cell here. It will be called when the user touches an expanded cell so it gets collapsed or the table is in the expandOnlyOneCell satate and the user touches another item, So the last expanded item has to collapse
-(void)tableView:(UITableView *)tableView collapseCell:(UITableViewCell *)cell withIndexPath:(NSIndexPath *)indexPath
{
    //    UILabel *detailLabel = (UILabel *)[cell viewWithTag:3];
    //    UIButton *purchaseButton = (UIButton *)[cell viewWithTag:10];
    
    
    //RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:indexPath.row];
    
    RemoveCell *cell1 = (RemoveCell *)cell;
    cell1.viewBack.backgroundColor = sectionUnSelectColor;
    cell1.btnCheckMark.selected = NO;
    
    RemoveCell *cell2 = [tableView cellForRowAtIndexPath:indexPath];
    
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:indexPath.row];
    
    [tblRemoveTimeList deselectRowAtIndexPath:indexPath animated:YES];
    
    //NSString *strDate = [NSString stringWithFormat:@"%@",objRemoveDate.wu_Day];
    
    cell2.accessoryType = UITableViewCellAccessoryNone;
    [arrRemoveListSelect removeObject:objRemoveDate.ReleaseID];
    
    cell2.img.hidden = YES;
    objRemoveDate.isSelected = NO;
    [arrRemoveList replaceObjectAtIndex:indexPath.row withObject:objRemoveDate];
    
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [UIView animateWithDuration:.5 animations:^{
        //        detailLabel.text = @"Lorem ipsum dolor sit amet";
        //        purchaseButton.alpha = 0;
        [cell.contentView viewWithTag:7].transform = CGAffineTransformMakeRotation(-3.14);
    } completion:^(BOOL finished) {
        //        purchaseButton.hidden = YES;
    }];
}

-(void)selectRemoveCellAtIndex:(int)index
{
    
    //    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:index];
    //
    //    if (index) {
    //
    //    }
    
}
-(void)selectDateAtIndex:(int)index andDate:(NSString *)strNewDate1
{
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:index];
    
    NSString *strReleaseID = [NSString stringWithFormat:@"%@",objRemoveDate.ReleaseID];
    
    NSArray *arrDate = [strNewDate1 componentsSeparatedByString:@"|"];
    NSString *newupdateDate =[arrDate componentsJoinedByString:@"/"];
    
    objRemoveDate.RemoveFrom = newupdateDate;
    
    if (objRemoveDate.isDateUpdate) {
        
        NSArray *arrList = [strReleaseID componentsSeparatedByString:@"|"];
        NSMutableArray *arrIds =[[NSMutableArray alloc]initWithArray:arrList];
        if([arrIds count] >=3){
            [arrIds removeLastObject];
            [arrIds removeLastObject];
            [arrIds removeLastObject];
            
            NSString *newUpdatedStrign = [arrIds componentsJoinedByString:@"|"];
            newUpdatedStrign = [NSString stringWithFormat:@"%@|%@",newUpdatedStrign , strNewDate1];
            
            objRemoveDate.ReleaseID = newUpdatedStrign;
            objRemoveDate.isDateUpdate = YES;
            
            [arrRemoveList replaceObjectAtIndex:index withObject:objRemoveDate];
            [tblRemoveTimeList reloadData];
        }
    }else{
        
        NSString *newUpdatedStrign = [NSString stringWithFormat:@"%@|%@",strReleaseID , strNewDate1];
        
        objRemoveDate.ReleaseID = newUpdatedStrign;
        objRemoveDate.isDateUpdate = YES;
        
        [arrRemoveList replaceObjectAtIndex:index withObject:objRemoveDate];
        [tblRemoveTimeList reloadData];
    }
}

-(void)scheduleSetDateAtIndex:(int)index {
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    RemoveDateTime *objRemoveDate = [arrRemoveList objectAtIndex:index];
    _datePicker.selectedDate = [_dateFormatter dateFromString:objRemoveDate.RemoveFrom];
    Index = index;
    _datePicker.minimumDate = [NSDate date];
    [_datePicker show];
    
}
- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    _dateFormatter.dateFormat = @"MM/dd/yyyy";
    [self selectDateAtIndex:Index andDate:[_dateFormatter stringFromDate:date]];
}

-(void)selectRemoveScheduleDateAtIndex:(int)index{
    
}

-(void)selectScheduleReleaseClasses:(NSString *)strType andCellIndex:(int)index{
    
    NSString *removeIdList = @"";
    
    if ([strType isEqualToString:@"Cancel"]) {
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
        return;
    }else{
        //        NSString *strRemoveClasses = [arrRemoveListSelect componentsJoinedByString:@","];
        
        for(RemoveDateTime *objRm in arrRemoveList){
            
            if(objRm.isSelected){
                
                NSLog(@"DATE %@", objRm);
                
                if(objRm.isDateUpdate){
                    if(removeIdList.length > 0){
                        removeIdList = [NSString stringWithFormat:@"%@,%@", removeIdList , objRm.ReleaseID];
                        strRequestedEndDate = [NSString stringWithFormat:@"%@,%@",strRequestedEndDate, objRm.ReleaseID];
                    }else{
                        removeIdList = [NSString stringWithFormat:@"%@",  objRm.ReleaseID];
                        strRequestedEndDate = [NSString stringWithFormat:@"%@", objRm.ReleaseID];
                    }
                }
                else
                {
                    //                    NSArray *arrDate = [objRm.RemoveFrom componentsSeparatedByString:@"/"];
                    //                    NSString *newupdateDate =[arrDate componentsJoinedByString:@"|"];
                    
                    if (removeIdList.length > 0)
                    {
                        removeIdList = [NSString stringWithFormat:@"%@,%@", removeIdList, [NSString stringWithFormat:@"%@|%@" , objRm.ReleaseID,objRm.RemoveFrom] ];
                        strRequestedEndDate = [NSString stringWithFormat:@"%@,%@",strRequestedEndDate, objRm.ReleaseID];
                    }
                    else
                    {
                        removeIdList = [NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@|%@" , objRm.ReleaseID,objRm.RemoveFrom]];
                        strRequestedEndDate = [NSString stringWithFormat:@"%@", objRm.ReleaseID];
                    }
                }
            }
        }
    }
    
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:removeIdList forKey:REMOVECLASS];
    
    [params setObject:strToken forKey:@"Token"];
    [params setObject:[userDefault objectForKey:FAMILYID] forKey:@"FamilyID"];
    [params setObject:removeIdList forKey:@"RemoveClass"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:removeClasses_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        NSString *strScheduleID = @"";
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            NSMutableArray *arrReleaseClass = [responseObject safeObjectForKey:@"FinalArray"];
            
            NSString *strAllSelect = [NSString stringWithFormat:@"%@",[responseObject safeObjectForKey:@"AllSelect"]];
            [userDefault setObject:strAllSelect forKey:ALLSELECT];
            
            if ([strAllSelect isEqualToString:@"1"]) {
                [userDefault setObject:[responseObject safeObjectForKey:@"EndDt"] forKey:ALLEndDT];
                [userDefault setObject:[responseObject safeObjectForKey:@"ID"] forKey:ALLSCHEDULEID];
            }else{
                for (NSDictionary *dict in arrReleaseClass) {
                    
                    if (strScheduleID.length > 0) {
                        strScheduleID = [NSString stringWithFormat:@"%@,%@", strScheduleID,[dict valueForKey:@"ScheduleID"]];
                    }else{
                        strScheduleID = [NSString stringWithFormat:@"%@",[dict valueForKey:@"ScheduleID"]];
                    }
                }
                [userDefault setObject:strScheduleID forKey:SCHEDULEID];
            }
            [tblRemoveTimeList reloadData];
            
            [self getReleaseClassNewLesson];
        }else{
            /*NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
             NSDictionary *dict = [arrAfterLogin firstObject];
             [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];*/
            [CommonClass showToastMsg:ReleaseSchedule];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getReleaseClassNewLesson
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *strRemoveClass = [[NSUserDefaults standardUserDefaults]objectForKey:REMOVECLASS];
    NSString *strScheduleID = [[NSUserDefaults standardUserDefaults]objectForKey:SCHEDULEID];
    NSString *strAllSelect = [[NSUserDefaults standardUserDefaults]objectForKey:ALLSELECT];
    NSString *strAllScheduleID  = [[NSUserDefaults standardUserDefaults]objectForKey:ALLSCHEDULEID];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if ([strAllSelect isEqualToString:@"1"]) {
        [params setObject:strAllScheduleID forKey:@"ScheduleIDs"];
    }else{
        [params setObject:strScheduleID forKey:@"ScheduleIDs"];
    }
    
    [params setObject:strToken forKey:@"Token"];
    [params setObject:[userDefault objectForKey:FAMILYID] forKey:@"FamilyID"];
    [params setObject:strRemoveClass forKey:@"RemoveClass"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:releaseNew_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceUpCommingLesson %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            if ([strAllSelect isEqualToString:@"0"]) {
                [self popViewController];
            }else{
                ClassTimeRemoveViewController *viewschedule =[[ClassTimeRemoveViewController alloc]initWithNibName:@"ClassTimeRemoveViewController" bundle:nil];
                viewschedule.strRequestedEndDate =         strRequestedEndDate;
                
                [self.navigationController pushViewController:viewschedule animated:YES];
            }
        }else{
            //            NSMutableArray *arrAfterLogin = [responseObject safeObjectForKey:@"FinalArray"];
            //            NSDictionary *dict = [arrAfterLogin firstObject];
            //            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
/*
 - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if(indexPath.section == selectedSection){
 //        UnitTestCell *cell = (UnitTestCell *)[self tableView:tblUnitTest cellForRowAtIndexPath:indexPath];
 //        return [cell getUnitTestCellHeight];
 return 116;
 }else{
 return 0;
 }
 }
 
 -(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
 {
 return 50;
 }
 */

/*
 - (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
 {
 CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
 RemoveSectionView *viewFit = [[RemoveSectionView alloc] initWithFrame:rect];
 
 viewFit.testDelegate = self;
 viewFit.index = (int)section;
 
 if(section == selectedSection){
 [viewFit setSelectedColor:sectionUnSelectColor];
 }else{
 [viewFit setNormalColor];
 }
 
 //    NSDictionary *dictData =[arrUnitTest objectAtIndex:section];
 //    [viewFit setSectionData:[dictData objectForKey:@"TestName"]];
 
 return viewFit;
 } */


//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//
//    return 1;
//}

/*
 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if(indexPath.section != selectedSection){
 
 static NSString *simpleTableIdenti = @"UnitTest1";
 
 UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
 
 if (cell == nil) {
 cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdenti];
 }
 
 return  cell;
 }else{
 static NSString *simpleTableIdenti = @"RemoveCell";
 
 RemoveCell *cell = (RemoveCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
 if (cell == nil)
 {
 NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RemoveCell" owner:self options:nil];
 cell = [nib objectAtIndex:0];
 }
 cell.selectionStyle  = UITableViewCellSelectionStyleNone;
 cell.timeDelegate = self;
 cell.index = (int)indexPath.row;
 
 cell.textLabel.text = @"";
 return cell;
 }
 return nil;
 } */

/*- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
 {
 
 } */

-(void)selectRemoveTimeClassAtIndex:(int)index
{
    NSLog(@"%d",index);
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    [tblRemoveTimeList reloadData];
}

-(void)setUnitTestDateAtindex:(int)index
{
    
}


- (IBAction)onClickReleaseClassBtn:(id)sender {
    
    NSLog(@"%lu",(unsigned long)[arrRemoveListSelect count]);
    NSLog(@"%lu",(unsigned long)[arrRemoveList count]);
    
    NSInteger selectCount = [arrRemoveListSelect count];
    
    if ([arrRemoveListSelect count] > 0) {
        ReleaseClassViewController *viewReleaseClass = [[ReleaseClassViewController alloc] initWithNibName:@"ReleaseClassViewController" bundle:nil];
        viewReleaseClass.releaseDelegate = self;
        viewReleaseClass.arrCount = selectCount;
        [self presentPopupViewController:viewReleaseClass animationType:MJPopupViewAnimationFade];
    }
    
    /*if ([arrRemoveListSelect count] == [arrRemoveList count]) {
     ReleaseClassViewController *viewReleaseClass = [[ReleaseClassViewController alloc] initWithNibName:@"ReleaseClassViewController" bundle:nil];
     viewReleaseClass.releaseDelegate = self;
     [self presentPopupViewController:viewReleaseClass animationType:MJPopupViewAnimationFade];
     }else if ([arrRemoveList count] > [arrRemoveListSelect count]){
     ReleaseClassViewController *viewReleaseClass = [[ReleaseClassViewController alloc] initWithNibName:@"ReleaseClassViewController" bundle:nil];
     viewReleaseClass.releaseDelegate = self;
     [self presentPopupViewController:viewReleaseClass animationType:MJPopupViewAnimationFade];
     }*/
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
