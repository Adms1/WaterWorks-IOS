//
//  LessonCancelViewController.m
//  WaterWorks
//
//  Created by Ankit on 27/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "LessonCancelViewController.h"

@interface LessonCancelViewController ()

@end

@implementation LessonCancelViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    lbl_title.text = _strTitle;
    [btnCancel setTitle:[[_btnTitle componentsSeparatedByString:@"|"] firstObject] forState:0];
    [btnDonotCancel setTitle:[[_btnTitle componentsSeparatedByString:@"|"] lastObject] forState:0];
    
    if (_flag)
    {
        NSString *substr = @"We are unable to issue a makeup lesson";
        
        NSMutableAttributedString *text =
        [[NSMutableAttributedString alloc]
         initWithAttributedString: lbl_msg.attributedText];
        
        NSRange range = [lbl_msg.text rangeOfString:substr options:NSCaseInsensitiveSearch];
        [text addAttribute:NSForegroundColorAttributeName
                     value:[UIColor redColor]
                     range:range];
        [lbl_msg setAttributedText: text];
    }
    else
    {
        lbl_msg.text = _strMsg;
    }
}
- (IBAction)onClickCancelLesson:(UIButton *)sender
{
    if (_LessonCancelDelegate && [_LessonCancelDelegate respondsToSelector:@selector(selectRemoveLesson::::)]) {
        [_LessonCancelDelegate selectRemoveLesson:_selectedidx :sender.tag :self :_Value];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
