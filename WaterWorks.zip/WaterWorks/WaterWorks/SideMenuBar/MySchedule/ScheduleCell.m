//
//  ScheduleCell.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ScheduleCell.h"


@implementation ScheduleCell
@synthesize delegate;
@synthesize index;
@synthesize lblday,lblDate,lblMonth,imgtopLine;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
    
}

-(void)setScheduleData:(NSDictionary *)dict lastDate:(NSString *)lastDate
{
    NSString *curDate = [dict objectForKey:@"Date"];
    
    NSArray *arrDate  = [curDate componentsSeparatedByString:@"/"];
    if([arrDate count] > 1){
        lblDate.text = [arrDate objectAtIndex:1];
    }
    NSString *strDay =[dict objectForKey:@"Day"];
    if(strDay.length > 2){
        lblday.text = [strDay substringToIndex:3];
    }
    
    lblMonth.text = [self getMonthFromDate:[arrDate.firstObject intValue]];
    
    //lblDate.text = curDate;
    
    NSString *strLesson = [NSString stringWithFormat:@"%@" , [dict objectForKey:@"wu_lessoncount"]];
    if([strLesson isEqualToString:@""] || [[dict objectForKey:@"Counts"] isEqualToString:@"Unpaid"])
    {
        if( [[dict objectForKey:@"Counts"] isEqualToString:@"Unpaid"])
        {
            lblLesson.text = [NSString stringWithFormat:@"UNPAID - %@",[dict objectForKey:@"LessonType"]];
            NSString *scheduletitle = [NSString stringWithFormat:@"%@ - %@" , [dict objectForKey:@"Schedule Date"], [dict objectForKey:@"StudentName"]];
            lblTimeName.text = scheduletitle;
        }
        else
        {
            lblTimeName.text = [NSString stringWithFormat:@"%@" , [dict objectForKey:@"Student"]];
            lblLesson.text = @"No Lesson Today";
            lblLesson.textColor = [UIColor redColor];
        }
        [_btnCheckMark setHidden:YES];
    }
    else
    {
        if ([((NSString *)dict[@"Comments"]) containsString:@"Makeup Used"])
        {
            lblLesson.text = [strLesson stringByReplacingOccurrencesOfString:@"Lesson 0 of 0" withString:@"Makeup Lessons"];
        }
        else
        {
            lblLesson.text = strLesson;
        }
        NSString *scheduletitle = [NSString stringWithFormat:@"%@ - %@" , [dict objectForKey:@"Schedule Date"], [dict objectForKey:@"StudentName"]];
        lblTimeName.text = scheduletitle;
    }
    
    if([curDate isEqualToString:lastDate]){
        lblDate.hidden = YES;
        lblday.hidden = YES;
        lblMonth.hidden= YES;
        imgtopLine.hidden = YES;
        
    }else{
        imgtopLine.hidden = NO;
        lblDate.hidden = NO;
        lblday.hidden = NO;
        lblMonth.hidden= NO;
    }
    
    NSString *intructor =[dict objectForKey:@"Instructor"];
    
    NSLog(@"intructor %@", intructor);
    if(intructor.length > 0){
        viewsingle.hidden = NO;
        lblInstructor.text = intructor;
    }else{
        viewsingle.hidden = YES;
        lblInstructor.text = @"Instructor";
    }
    
    NSString *imageName;
    
    if ([dict objectForKey:@"wu_photo"] == nil || [[dict objectForKey:@"wu_photo"] isEqualToString:@""]) {
        imgInstructor.image = [UIImage imageNamed:@"AppLogo"];
    }else{
        NSString *strUrl = [NSString stringWithFormat:@"%@%@",Image_Url,[[dict objectForKey:@"wu_photo"] substringFromIndex:1]];
        imageName = [NSString stringWithFormat:@"%@",strUrl];
        //[imgInstructor loadImageFromStringforUserimg:imageName];
        //        [imgInstructor loadImageWithURl:strUrl andPlaceholderName:nil];
        NSLog(@"%@",dict);
        NSLog(@"%@",imageName);
        [imgInstructor loadImageWithURl:strUrl andPlaceHolderImage:[UIImage imageNamed:@"AppLogo"]];
    }
    
    /*
     NSString *imageName1;
     
     if ([dict objectForKey:@"wu_photo"] == nil || [[dict objectForKey:@"wu_photo"] isEqualToString:@""]) {
     imgInstructor.image = [UIImage imageNamed:@"DemoLogo"];
     }else{
     NSString *strUrl = [NSString stringWithFormat:@"http://office.waterworksswimonline.com/newcode%@",[[dict objectForKey:@"wu_photo"] substringFromIndex:1]];
     imageName1 = [NSString stringWithFormat:@"%@",strUrl];
     [imgInstructor loadImageFromStringforUserimg:imageName1];
     } */
}

-(NSString *)getMonthFromDate:(int)monthNumber
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    NSString *returnDate = [[df monthSymbols] objectAtIndex:(monthNumber-1)];
    return [returnDate substringToIndex:3];
}

- (IBAction)onClickCheckMarkBtn:(UIButton *)sender {
    
    if([_btnCheckMark isSelected]){
        [_backgroundview setBackgroundColor:sectionUnSelectColor];
        [_btnCheckMark setSelected:NO];
    }else{
        [_backgroundview setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
        [_btnCheckMark setSelected:YES];
    }
    
    if (delegate &&[delegate respondsToSelector:@selector(setScheduleLessonIndex::)]) {
        [delegate setScheduleLessonIndex:index :sender.tag];
    }
}
@end
