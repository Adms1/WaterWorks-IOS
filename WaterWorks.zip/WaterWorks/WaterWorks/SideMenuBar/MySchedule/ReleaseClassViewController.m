//
//  ReleaseClassViewController.m
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
// selected class remove seccussfully

#import "ReleaseClassViewController.h"

@interface ReleaseClassViewController ()

@end

@implementation ReleaseClassViewController

@synthesize releaseDelegate;
@synthesize dateIndex;
@synthesize arrCount;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSString *strTitle = [NSString stringWithFormat:@"Are you sure you want to release %ld selected lesson time?",(long)arrCount];
    
    lblTitle.text = [NSString stringWithFormat:@"%@",strTitle];
    
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithAttributedString: lblTitle.attributedText];
    
    NSRange range = [lblTitle.text rangeOfString:[NSString stringWithFormat:@"%ld",(long)arrCount] options:NSCaseInsensitiveSearch];
    [text addAttribute:NSForegroundColorAttributeName
                 value:[UIColor redColor]
                 range:range];
    [lblTitle setAttributedText: text];
}

- (IBAction)onClickCancelBtn:(id)sender {
    if (releaseDelegate &&[releaseDelegate respondsToSelector:@selector(selectScheduleReleaseClasses:andCellIndex:)]) {
        [releaseDelegate selectScheduleReleaseClasses:@"Cancel" andCellIndex:dateIndex];
    }
}

- (IBAction)onClickOklBtn:(id)sender {
    
    if (releaseDelegate &&[releaseDelegate respondsToSelector:@selector(selectScheduleReleaseClasses:andCellIndex:)]) {
        [releaseDelegate selectScheduleReleaseClasses:@"Ok" andCellIndex:dateIndex];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
