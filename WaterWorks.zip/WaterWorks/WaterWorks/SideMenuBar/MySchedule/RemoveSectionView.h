//
//  RemoveSectionView.h
//  WaterWorks
//
//  Created by Darshan on 25/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+NibLoading.h"
#import "AsyImage.h"

@protocol UnitTestDelegate <NSObject>

-(void)setUnitTestDateAtindex:(int)index;
-(void)selectRemoveTimeClassAtIndex:(int)index;

@end

@interface RemoveSectionView : UIView

{
    IBOutlet UIView *viewBack;
    
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblInstructor;
    
    IBOutlet UIButton *btnCheck;
    
    IBOutlet AsyImage *imgInstructor;
}


//Delegate
@property (strong , nonatomic) id<UnitTestDelegate> testDelegate;

//Integer
@property (nonatomic)int index;

@property (nonatomic , strong) IBOutlet UIView *viewBack;

-(void)setNormalColor;
-(void)setSelectedColor:(UIColor *)color;

@end
