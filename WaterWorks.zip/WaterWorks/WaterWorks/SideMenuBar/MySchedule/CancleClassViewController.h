//
//  CancleClassViewController.h
//  WaterWorks
//
//  Created by ADMS on 02/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CancleClassViewController;

@protocol CancleClassViewControllerDelegate <NSObject>
-(void)CancelClassPopup:(CancleClassViewController *)ccvc;
@end

@interface CancleClassViewController : UIViewController
@property (assign, nonatomic) id <CancleClassViewControllerDelegate> CancelClassDelegate;

@end
