//
//  PopupView.m
//  WaterWorks
//
//  Created by Ankit on 10/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PopupView.h"

@interface PopupView ()

@end

@implementation PopupView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [lblHeader setText:_strTitleText];
    [lblMsg setText:_strMsgText];
    if ([_strBtnText isEqualToString:@"Yes"]) {
        [btnCancel setTitle:@"No" forState:0];
    }
    [btnContinue setTitle:_strBtnText forState:0];
    
    if ([_strTitleText isEqualToString:@"Alert"]) {
        [lblHeader setTextColor:[UIColor redColor]];
    }else{
        [lblHeader setTextColor:[UIColor blackColor]];
    }
    
    if (_check) {
        [btnContinue setEnabled:YES];
        [btnContinue setBackgroundColor:Top_Color];
        
    }else{
        [btnContinue setEnabled:NO];
        [btnContinue setBackgroundColor:sectionUnSelectColor];
    }
}
-(IBAction)btnContinueGoBack:(UIButton *)sender
{
    if (_p_delegate && [_p_delegate respondsToSelector:@selector(Continue_GoBack:::)]) {
        [_p_delegate Continue_GoBack:self :sender :sender.tag];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
