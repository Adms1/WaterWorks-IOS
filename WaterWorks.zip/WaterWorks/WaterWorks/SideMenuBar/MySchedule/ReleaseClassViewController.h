//
//  ReleaseClassViewController.h
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol popUpReleaseClassesDelegate <NSObject>

-(void)selectScheduleReleaseClasses:(NSString *)strType andCellIndex:(int)index;

@end

@interface ReleaseClassViewController : UIViewController

{
    IBOutlet UILabel *lblTitle;
}

@property (nonatomic) NSInteger arrCount;

@property (assign, nonatomic) id <popUpReleaseClassesDelegate> releaseDelegate;

//Integer
@property (nonatomic) int dateIndex;

@end
