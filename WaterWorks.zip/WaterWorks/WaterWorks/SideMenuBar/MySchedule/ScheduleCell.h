//
//  ScheduleCell.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyImage.h"

@protocol lessonScheduleDelegate <NSObject>

-(void)setScheduleLessonIndex:(int)index :(NSInteger)selectedindex;

@end

@interface ScheduleCell : UITableViewCell

{
    IBOutlet UILabel *lblTimeName;
    
    IBOutlet UILabel *lblInstructor;
    
    IBOutlet UILabel *lblLesson;
    
    //IBOutlet UILabel *lblDate;
    
    IBOutlet UIView *viewsingle;
    
    IBOutlet AsyImage *imgInstructor;
    IBOutlet AsyImage *imgInstructor1;
}
@property(nonatomic,retain)IBOutlet UIView *backgroundview;
@property(nonatomic,retain)IBOutlet UIButton *btnCheckMark;
@property(nonatomic,retain)IBOutlet UIButton *btntransperant;
@property(nonatomic,retain)IBOutlet UILabel *lblDate;
@property(nonatomic,retain)IBOutlet UILabel *lblday;
@property(nonatomic,retain)IBOutlet UILabel *lblMonth;
@property(nonatomic,retain)IBOutlet UIImageView *imgtopLine;


-(void)setScheduleData:(NSDictionary *)dict lastDate:(NSString *)lastDate;

//Delegate
@property (nonatomic , strong) id<lessonScheduleDelegate> delegate;

//Integer
@property (nonatomic) int index;

@end
