//
//  MyScheduleViewController.m
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MyScheduleViewController.h"
#import "AFNetworking.h"
#import "AppDelegate.h"
#import "RemoveClassTimeViewController.h"
#import "CommonClass.h"
#import "LessonCancelViewController.h"
#import "CancleClassViewController.h"

@interface MyScheduleViewController ()<LessonCancelViewControllerDelegate,CommonDelegate,CancleClassViewControllerDelegate>
{
    NSMutableArray *selectedIndexs,*selectedCancelIds;
    NSString *selectedHiddenValue;
    BOOL flag,Makeup;
}
@end

@implementation MyScheduleViewController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer* gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(setRemoveDayNadTime:)];
    [lblRemoveDayTime setUserInteractionEnabled:YES];
    [lblRemoveDayTime addGestureRecognizer:gesture];
    
    //    [self getAllSchedule];
    //    tblSchedule.tableHeaderView = viewHeader;
    
    UIBarButtonItem *barBtnhome = [[UIBarButtonItem alloc] initWithCustomView:btnHome];
    self.navigationItem.rightBarButtonItems = @[barBtnhome];
    
    [btnSelectedLesson setBackgroundColor:[UIColor colorWithRed:(228.0/255.0) green:(156.0/255.0) blue:(151.0/255.0) alpha:1.0]];
    btnSelectedLesson.enabled = NO;
    
    selectedIndexs = [[NSMutableArray alloc]init];
    selectedCancelIds = [[NSMutableArray alloc]init];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSchedule :self :btnHome :nil :YES :self];
    [self getAllSchedule];
}

#pragma mark - Api Calling

-(void)getAllSchedule
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault objectForKey:FAMILYID] forKey:@"familyid"];
    [params setObject:[userDefault objectForKey:TOKEN] forKey:@"Token"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    arrSchedule = [[NSMutableArray alloc]init];
    
    [manager POST:schedular_List_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arrFinalArray =[responseObject objectForKey:@"FinalArray"];
            [arrSchedule addObjectsFromArray:arrFinalArray];
            
            /*
             NSDictionary *dict = [[responseObject objectForKey:@"Student"] firstObject];
             if(dict != nil){
             NSString *studentCount = [dict objectForKey:@"StudentCount"];
             int intValue =[studentCount intValue];
             if(intValue == 0){
             
             FirstTimeViewController *viewFirstTime;
             if (isIpad) {
             viewFirstTime = [[FirstTimeViewController alloc] initWithNibName:@"FirstTimeViewControllerIpad" bundle:nil];
             }else{
             viewFirstTime = [[FirstTimeViewController alloc] initWithNibName:@"FirstTimeViewController" bundle:nil];
             }
             [self.navigationController pushViewController:viewFirstTime animated:YES];
             }
             } */
            
        }else{
            
            NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"FinalArray"];
            NSDictionary *dict = [arrLogin firstObject];
            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
        }
        
        [tblSchedule reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        //        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
        [self getAllSchedule];
    }];
}

#pragma mark - Tableview Datasource & Delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 76.0f;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [arrSchedule count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"ScheduleCell";
    
    ScheduleCell *cell = (ScheduleCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ScheduleCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    cell.delegate = self;
    cell.index = (int)indexPath.row;
    
    if(indexPath.row > 0){
        NSDictionary *dic = [arrSchedule objectAtIndex:indexPath.row - 1];
        strLastDate =[dic objectForKey:@"Date"];
    }
    
    NSDictionary *dict =[arrSchedule objectAtIndex:indexPath.row];
    [cell setScheduleData:dict lastDate:strLastDate];
    
    if (indexPath.row == 0)
    {
        [cell.lblMonth setHidden:NO];
        [cell.lblDate setHidden:NO];
        [cell.lblday setHidden:NO];
        [cell.imgtopLine setHidden:NO];
    }
    
    if([[[arrSchedule objectAtIndex:indexPath.row]valueForKey:@"CancelID"] isEqualToString:@"0"])
    {
        [cell.btnCheckMark setHidden:YES];
        [cell.btntransperant setHidden:NO];
        [cell.btntransperant setUserInteractionEnabled:YES];
    }
    else
    {
        if ([[[arrSchedule objectAtIndex:indexPath.row] valueForKey:@"wu_lessoncount"]isEqualToString:@""])
        {
            [cell.btnCheckMark setHidden:YES];
            if (([[[arrSchedule objectAtIndex:indexPath.row] valueForKey:@"Counts"]isEqualToString:@"Unpaid"]))
            {
                [cell.btntransperant setHidden:YES];
                [cell.btntransperant setUserInteractionEnabled:NO];
            }
        }
        else
        {
            if (([[[arrSchedule objectAtIndex:indexPath.row] valueForKey:@"Counts"]isEqualToString:@"Unpaid"]))
            {
                [cell.btntransperant setHidden:YES];
                [cell.btntransperant setUserInteractionEnabled:NO];
            }
            else
            {
                [cell.btnCheckMark setHidden:NO];
                [cell.btntransperant setHidden:YES];
                [cell.btntransperant setUserInteractionEnabled:NO];
            }
        }
    }
    
    cell.btnCheckMark.tag = indexPath.row;
    
    //NSLog(@"%@",dict);
    //---------------------
    if (![selectedIndexs containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]])
    {
        [cell.btnCheckMark setSelected:NO];
        [cell.backgroundview setBackgroundColor:sectionUnSelectColor];
    }
    else
    {
        [cell.btnCheckMark setSelected:YES];
        [cell.backgroundview setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(153.0/255.0) blue:(51.0/255.0) alpha:1.0]];
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
     SalonShopView *viewSalonShop = [[SalonShopView alloc] initWithNibName:@"SalonShopView" bundle:nil];
     viewSalonShop.strSalonTitle = [arrSalonList objectAtIndex:indexPath.row];
     [self.navigationController pushViewController:viewSalonShop animated:YES];
     */
    
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

#pragma mark - Actions

- (void)setRemoveDayNadTime:(UITapGestureRecognizer *)tapGesture {
    NSLog(@"Press label");
    
    RemoveClassTimeViewController *viewRemove = [[RemoveClassTimeViewController alloc] initWithNibName:@"RemoveClassTimeViewController" bundle:nil];
    [self.navigationController pushViewController:viewRemove animated:YES];
}

-(void)setScheduleLessonIndex:(int)index :(NSInteger)selectedindex{
    
    NSString *value = @"-1";
    if ([[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"HiddenFeildValue"]isEqualToString:@"0"] || [[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"HiddenFeildValue"]isEqualToString:@"1"])
    {
        value = @"0";
    }
    else if ([[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"HiddenFeildValue"]isEqualToString:@"2"] || [[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"HiddenFeildValue"]isEqualToString:@"3"])
    {
        value = @"4";
    }
    
    else if ([[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"HiddenFeildValue"]isEqualToString:@"4"])
    {
        value = @"6";
    }
    
    if (![selectedIndexs containsObject:[NSString stringWithFormat:@"%ld",(long)selectedindex]])
    {
        [selectedCancelIds addObject:[NSString stringWithFormat:@"%@|%@",[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"CancelID"],value]];
        [selectedIndexs addObject:[NSString stringWithFormat:@"%ld",(long)selectedindex]];
        
        if ([[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"Comments"]isEqualToString:@"Makeup Used"])
        {
            Makeup = YES;
        }
    }
    else
    {
        [selectedCancelIds removeObject:[NSString stringWithFormat:@"%@|%@",[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"CancelID"],value]];
        [selectedIndexs removeObject:[NSString stringWithFormat:@"%ld",(long)selectedindex]];
        
        if ([[[arrSchedule objectAtIndex:selectedindex] valueForKey:@"Comments"]isEqualToString:@"Makeup Used"])
        {
            Makeup = NO;
        }
    }
    
    //------------
    
    if (selectedIndexs.count > 0)
    {
        [btnSelectedLesson setBackgroundColor:[UIColor colorWithRed:(255.0/255.0) green:(0.0/255.0) blue:(0.0/255.0) alpha:1.0]];
        btnSelectedLesson.enabled = YES;
    }
    else
    {
        [btnSelectedLesson setBackgroundColor:[UIColor colorWithRed:(228.0/255.0) green:(156.0/255.0) blue:(151.0/255.0) alpha:1.0]];
        btnSelectedLesson.enabled = NO;
    }
    
    if (!([value isEqualToString:@"0"] || [value isEqualToString:@"-1"]))
    {
        flag = NO;
        LessonCancelViewController *lcvc = [[LessonCancelViewController alloc] initWithNibName:@"LessonCancelViewController" bundle:nil];
        lcvc.Value = value;
        lcvc.strTitle = @"Cancel lesson(No Make-up)";
        lcvc.btnTitle = @"CANCEL LESSON|DO NOT CANCEL";
        lcvc.selectedidx = selectedindex;
        lcvc.LessonCancelDelegate = self;
        lcvc.flag = YES;
        [lcvc.view setFrame:CGRectMake(lcvc.view.frame.origin.x, lcvc.view.frame.origin.y, self.view.frame.size.width - 40, lcvc.view.frame.size.height)];
        [self presentPopupViewController:lcvc animationType:MJPopupViewAnimationFade];
    }
    
}
-(void)selectRemoveLesson:(NSInteger)selectedIndex :(NSInteger)idx :(LessonCancelViewController *)lcvc :(NSString *)valueStr
{
    [lcvc.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    
    if (idx == 1)
    {
        if (flag)
        {
            selectedCancelIds = (NSMutableArray *)[selectedCancelIds sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                NSNumber* index1 = selectedIndexs[[selectedCancelIds indexOfObjectIdenticalTo:obj1]];
                NSNumber* index2 = selectedIndexs[[selectedCancelIds indexOfObjectIdenticalTo:obj2]];
                
                NSComparisonResult result = [index1 compare:index2];
                return result;
            }];
            
            selectedCancelIds = selectedCancelIds.mutableCopy;
            [self cancelSelectedLessions:[selectedCancelIds objectAtIndex:0]];
        }
        else
        {
            [selectedIndexs removeAllObjects];
            [selectedCancelIds removeAllObjects];
            [selectedCancelIds addObject:[NSString stringWithFormat:@"%@|%@",[[arrSchedule objectAtIndex:selectedIndex] valueForKey:@"CancelID"],valueStr]];
            [selectedIndexs addObject:[NSString stringWithFormat:@"%ld",(long)selectedIndex]];
            [self cancelSelectedLessions:[selectedCancelIds objectAtIndex:0]];
        }
    }
}

-(void)CancelClassPopup:(CancleClassViewController *)ccvc
{
    [ccvc.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    [self getAllSchedule];
}

- (IBAction)onClickCancelScheduleLessonBtn:(id)sender
{
    flag = YES;
    LessonCancelViewController *lcvc = [[LessonCancelViewController alloc] initWithNibName:@"LessonCancelViewController" bundle:nil];
    lcvc.strTitle = @"Cancel lesson";
    if (Makeup)
    {
        lcvc.btnTitle = @"Continue|Go Back";
        lcvc.strMsg   = MakeupLessonMsg;
    }
    else
    {
        lcvc.btnTitle = @"OK|Go Back";
        lcvc.strMsg   = [NSString stringWithFormat:@"Are you sure you want to cancel %ld selected %@ ?",(long)selectedCancelIds.count,selectedCancelIds.count == 1 ? @"Class" : @"Classes"];
    }
    lcvc.LessonCancelDelegate = self;
    [lcvc.view setFrame:CGRectMake(lcvc.view.frame.origin.x, lcvc.view.frame.origin.y, self.view.frame.size.width - 40, lcvc.view.frame.size.height)];
    [self presentPopupViewController:lcvc animationType:MJPopupViewAnimationFade];
}

-(void)cancelSelectedLessions:(NSString *)cancel_id
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"CancelClass":cancel_id,
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"FamilyID":[userDefault objectForKey:FAMILYID]
                             };
    
    NSLog(@"Params %@",params);
    
    [manager POST:Cancel_Class_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"SCHEDULE RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([[responseObject safeObjectForKey:@"continues"]boolValue] == 1)
            {
                if (selectedCancelIds.count == 1) {
                    selectedCancelIds = [NSMutableArray new];
                    selectedIndexs = [NSMutableArray new];
                }
                else {
                    [selectedCancelIds removeObjectAtIndex:0];
                    [selectedIndexs removeObjectAtIndex:0];
                }
                
                if (selectedCancelIds.count > 0)
                {
                    [self cancelSelectedLessions:[selectedCancelIds objectAtIndex:0]];
                }
                else if(selectedCancelIds.count == 0)
                {
                    [btnSelectedLesson setBackgroundColor:[UIColor colorWithRed:(228.0/255.0) green:(156.0/255.0) blue:(151.0/255.0) alpha:1.0]];
                    btnSelectedLesson.enabled = NO;
                    [self getAllSchedule];
                }
            }
            else
            {
                CancleClassViewController *ccvc = [[CancleClassViewController alloc] initWithNibName:@"CancleClassViewController" bundle:nil];
                ccvc.CancelClassDelegate = self;
                [ccvc.view setFrame:CGRectMake(ccvc.view.frame.origin.x, ccvc.view.frame.origin.y, self.view.frame.size.width - 40, ccvc.view.frame.size.height)];
                [self presentPopupViewController:ccvc animationType:MJPopupViewAnimationFade];
                [SHARED_APPDELEGATE hideLoadingView];
            }
            
        }else{
            
            NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"FinalArray"];
            NSDictionary *dict = [arrLogin firstObject];
            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
            [SHARED_APPDELEGATE hideLoadingView];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error.description);
    }];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
