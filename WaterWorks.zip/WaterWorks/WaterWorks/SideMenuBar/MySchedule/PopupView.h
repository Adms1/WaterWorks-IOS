//
//  PopupView.h
//  WaterWorks
//
//  Created by Ankit on 10/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PopupView;

@protocol PopupViewDelegate <NSObject>
-(void)Continue_GoBack:(PopupView *)popup :(UIButton *)sender :(NSInteger)tag;
@end
@interface PopupView : UIViewController
{
    IBOutlet UIButton *btnContinue;
    IBOutlet UIButton *btnCancel;
    IBOutlet UILabel *lblMsg;
    IBOutlet UILabel *lblHeader;
}
@property (assign, nonatomic) id <PopupViewDelegate> p_delegate;
@property (nonatomic, assign)BOOL check;
@property (nonatomic, assign)NSString *strBtnText;
@property (nonatomic, assign)NSString *strMsgText;
@property (nonatomic, assign)NSString *strTitleText;
@end
