//
//  RemoveCell.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RemoveDateTime.h"
#import "AsyImage.h"

@protocol RemoveTimeDelegate <NSObject>

-(void)selectRemoveCellAtIndex:(int)index;
-(void)selectDateAtIndex:(int)index andDate:(NSString *)strNewDate;
-(void)scheduleSetDateAtIndex:(int)index;

@end

@interface RemoveCell : UITableViewCell

{
    IBOutlet UILabel *lblTitle;
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblInstructor;
    
    IBOutlet AsyImage *asyImg;
    
    IBOutlet UIButton *btnDate;
}

@property (nonatomic , strong) IBOutlet UIView *viewBack;

@property (assign, nonatomic) id <RemoveTimeDelegate> timeDelegate;

@property (nonatomic , strong) IBOutlet UIButton *btnCheckMark;
//Integer
@property (nonatomic) int indexs;

@property (nonatomic , strong) IBOutlet UIImageView *img;

-(void)setRemoveDateTimeDataList:(RemoveDateTime*)objRemove;


@end
