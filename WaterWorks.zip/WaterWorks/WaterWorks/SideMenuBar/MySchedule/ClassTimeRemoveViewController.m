//
//  ClassTimeRemoveViewController.m
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ClassTimeRemoveViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "MDDatePickerDialog.h"
#import "MyScheduleViewController.h"

@interface ClassTimeRemoveViewController ()<MDDatePickerDialogDelegate,CommonDelegate>
@property(nonatomic) NSDateFormatter *dateFormatter;
@property(nonatomic) MDDatePickerDialog *datePicker;
@end

@implementation ClassTimeRemoveViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dateFormatter = [[NSDateFormatter alloc] init];
    
    btnDate.layer.borderColor = [UIColor grayColor].CGColor;
    btnDate.layer.borderWidth = 1.0f;
    
    txvView.layer.borderWidth = 1.0f;
    txvView.layer.borderColor = [UIColor grayColor].CGColor;
    txvView.layer.cornerRadius = 4.0f;
    
    txvAnyThingView.layer.borderWidth = 1.0f;
    txvAnyThingView.layer.borderColor = [UIColor grayColor].CGColor;
    txvAnyThingView.layer.cornerRadius = 4.0f;
    
    txvThinkingView.layer.borderWidth = 1.0f;
    txvThinkingView.layer.borderColor = [UIColor grayColor].CGColor;
    txvThinkingView.layer.cornerRadius = 4.0f;
    
    [txvListRession  setFont: FONT_OpenSans(12)];
    txvListRession.backgroundColor = [UIColor whiteColor];
    txvListRession.text = PleaseReason;
    [txvListRession setTextColor:[UIColor grayColor]];
    
    [txvAnyThing  setFont: FONT_OpenSans(12)];
    txvAnyThing.backgroundColor = [UIColor whiteColor];
    txvAnyThing.text = IsAnyThingDo;
    [txvAnyThing setTextColor:[UIColor grayColor]];
    
    constHeightReleaseView.constant = 95.0f;
    constHeightThinkingView.constant = 0.0f;
    constHeightAnyThingView.constant = 0.0f;
    constHeighRecommendView.constant = 0.0f;
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksRemoveTime :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - TEXT VIEW DELEGATE

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    CGPoint point;
    if (textView == txvListRession) {
        if ([txvListRession.text isEqualToString:PleaseReason]) {
            txvListRession.text = @"";
            [txvListRession setTextColor:[UIColor blackColor]];
        }
    }
    if (textView == txvAnyThing) {
        if ([txvAnyThing.text isEqualToString:IsAnyThingDo]) {
            txvAnyThing.text = @"";
            [txvAnyThing setTextColor:[UIColor blackColor]];
        }
        point = CGPointMake(0,txvAnyThing.frame.origin.y);
    }
    [scrollV setContentOffset:point animated:YES];
}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    if (txvListRession.text.length == 0) {
        [txvListRession setFont:FONT_OpenSans(12)];
        txvListRession.text = PleaseReason;
        [txvListRession setTextColor:[UIColor grayColor]];
    }
    if (txvAnyThing.text.length == 0) {
        [txvAnyThing setFont:FONT_OpenSans(12)];
        txvAnyThing.text = IsAnyThingDo;
        [txvAnyThing setTextColor:[UIColor grayColor]];
    }
    [scrollV setContentOffset:CGPointMake(0, 0) animated:YES];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        [scrollV setContentOffset:CGPointMake(0,0) animated:YES];
        return NO;
    }
    return YES;
}

- (IBAction)onClickRemoveClassesYes:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:NO];
    
    NSArray *array = @[ReleaseView,ThinkingView,AnyThingView,RecommendView];
    
    for (UIView *view in array)
    {
        for (UIView *v in view.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v)setSelected:NO];
            }
        }
    }
    
    txvListRession.text = PleaseReason;
    [txvListRession setTextColor:[UIColor grayColor]];
    txvAnyThing.text = IsAnyThingDo;
    [txvAnyThing setTextColor:[UIColor grayColor]];
    
    constHeightReleaseView.constant = 95.0f;
    constHeightReleaseView.constant = 95.0f;
    constHeightThinkingView.constant = 0.0f;
    constHeightAnyThingView.constant = 0.0f;
    constHeighRecommendView.constant = 0.0f;
    
    [btnReleaseScheduleYes setSelected:YES];
    [btnReleaseScheduleNo setSelected:NO];
    
}

- (IBAction)onClickRemoveClassesNo:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];
    
    [btnReleaseScheduleYes setSelected:NO];
    [btnReleaseScheduleNo setSelected:YES];
    
    RecommendPopUpViewController *viewRecommend = [[RecommendPopUpViewController alloc] initWithNibName:@"RecommendPopUpViewController" bundle:nil];
    viewRecommend.removeDelegate = self;
    [self presentPopupViewController:viewRecommend animationType:MJPopupViewAnimationFade];
}

-(void)selectRemoveClassTime
{
    constHeightReleaseView.constant = 175.0f;
    constHeightThinkingView.constant = 75.0f;
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickThinkingAboutYes:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];

    for (UIView *v in RecommendView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    
    [btnCommingBackThink setSelected:NO];
    [btnCommingBackYes setSelected:YES];
    [btnCommingBackNo setSelected:NO];
    
    constHeightThinkingView.constant = 105.0f;
    constHeightAnyThingView.constant = 0.0f;
    constHeighRecommendView.constant = 85.0f;
    
}

- (IBAction)onClickThinkingAboutNo:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];

    for (UIView *v in AnyThingView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    for (UIView *v in ThinkingView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    
    [btnCommingBackThink setSelected:NO];
    [btnCommingBackYes setSelected:NO];
    [btnCommingBackNo setSelected:YES];
    
    constHeightAnyThingView.constant = constHeightThinkingView.constant = 75.0f;
    constHeighRecommendView.constant = 0.0f;
    
}

- (IBAction)onClickThinkingAbout:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];

    for (UIView *v in AnyThingView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    [btnCommingBackThink setSelected:YES];
    [btnCommingBackYes setSelected:NO];
    [btnCommingBackNo setSelected:NO];
    constHeightAnyThingView.constant = 75.0f;
    constHeighRecommendView.constant = 0.0f;
}

- (IBAction)onClickDateSelect:(id)sender {
    
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    _datePicker.selectedDate = [NSDate date];
    _datePicker.minimumDate = [NSDate date];
    [_datePicker show];
    
}
- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    _dateFormatter.dateFormat = @"MM/dd/yyyy";
    [btnDate setTitle:[_dateFormatter stringFromDate:date] forState:UIControlStateNormal];
}

- (IBAction)onClickAnyThinngYes:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];

    for (UIView *v in AnyThingView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    for (UIView *v in RecommendView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    
    [btnAnyThingYes setSelected:YES];
    [btnAnyThingNo setSelected:NO];
    
    constHeightAnyThingView.constant = 165.0f;
    constHeighRecommendView.constant = 85.0f;
    
}

- (IBAction)onClickAnyThinngNo:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:YES];

    for (UIView *v in AnyThingView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setSelected:NO];
        }
    }
    
    
    [btnAnyThingYes setSelected:NO];
    [btnAnyThingNo setSelected:YES];
    
    constHeightAnyThingView.constant = 75.0f;
    constHeighRecommendView.constant = 75.0f;
    
}

- (IBAction)onClickRecommendYes:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:NO];
    
    [btnRecommendYes setSelected:YES];
    [btnRecommendNo setSelected:NO];
    [btnRecommendThink setSelected:NO];
}

- (IBAction)onClickRecommendNo:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:NO];
    
    [btnRecommendYes setSelected:NO];
    [btnRecommendNo setSelected:YES];
    [btnRecommendThink setSelected:NO];
}

- (IBAction)onClickRecommendThink:(id)sender {
    [self resign];
    
    [btnReleaseTime setHidden:NO];
    
    [btnRecommendThink setSelected:YES];
    [btnRecommendYes setSelected:NO];
    [btnRecommendNo setSelected:NO];
}

- (IBAction)onClickRemoveClassTime:(id)sender {
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strToken = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    //NSString *strEndDt = [[NSUserDefaults standardUserDefaults]objectForKey:ALLEndDT];
    NSString *strFamilyID = [[NSUserDefaults standardUserDefaults]objectForKey:FAMILYID];
    NSString *strScheduleID = [[NSUserDefaults standardUserDefaults]objectForKey:ALLSCHEDULEID];
    
    [params setObject:strToken forKey:@"Token"];
    [params setObject:@"" forKey:@"SwitchTime"];
    [params setObject:@"" forKey:@"StopLessonReason"];
    [params setObject:@"" forKey:@"ComeBackThink"];
    [params setObject:@"" forKey:@"ReturnDate"];
    [params setObject:@"" forKey:@"RecommendTofriend"];
    [params setObject:strFamilyID forKey:@"FamilyID"];
    [params setObject:@"" forKey:@"Reconsider"];
    
    //    NSArray *arr = [strEndDt componentsSeparatedByString:@","];
    NSArray *array = [_strRequestedEndDate componentsSeparatedByString:@","];
    
    NSString *strReleaseDate = @"";
    for (int  i = 0 ; i < array.count ; i++)
    {
        strReleaseDate = [NSString stringWithFormat:@"%@,%@",strReleaseDate,[NSString stringWithFormat:@"1|%@",[array objectAtIndex:i]]];
    }
    [params setObject:[strReleaseDate substringFromIndex:1] forKey:@"RequestedEndDate"];
    [params setObject:strScheduleID forKey:@"RequestedID"];
    
    if ([btnReleaseScheduleYes isSelected] == YES) {
        [params setObject:@"yes" forKey:@"SwitchTime"];
    }else{
        [params setObject:@"no" forKey:@"SwitchTime"];
    }
    
    if ([txvListRession.text isEqualToString:PleaseReason]) {
        [params setObject:@"" forKey:@"StopLessonReason"];
    }else{
        [params setObject:txvListRession.text forKey:@"StopLessonReason"];
    }
    
    if ([btnCommingBackYes isSelected] == YES) {
        [params setObject:@"yes" forKey:@"ComeBackThink"];
        [params setObject:btnDate.titleLabel.text forKey:@"ReturnDate"];
    }
    if ([btnCommingBackNo isSelected] == YES) {
        [params setObject:@"no" forKey:@"ComeBackThink"];
        [params setObject:@"" forKey:@"ReturnDate"];
    }
    if ([btnCommingBackThink isSelected] == YES) {
        [params setObject:@"thinking about it" forKey:@"ComeBackThink"];
        [params setObject:@"" forKey:@"ReturnDate"];
    }
    
    //    if ([btnAnyThingYes isSelected] == YES) {
    //        [params setObject:@"yes" forKey:@"Reconsider"];
    //    }
    //    if ([btnAnyThingNo isSelected] == YES) {
    //        [params setObject:@"no" forKey:@"Reconsider"];
    //    }
    
    if ([txvAnyThing.text isEqualToString:IsAnyThingDo]) {
        [params setObject:@"" forKey:@"ReconsiderReason"];
    }else{
        [params setObject:txvAnyThing.text forKey:@"ReconsiderReason"];
    }
    
    if ([btnRecommendYes isSelected] == YES) {
        [params setObject:@"yes" forKey:@"RecommendTofriend"];
    }
    if ([btnAnyThingNo isSelected] == YES) {
        [params setObject:@"no" forKey:@"RecommendTofriend"];
    }
    if ([btnRecommendThink isSelected] == YES) {
        [params setObject:@"thinking about it" forKey:@"RecommendTofriend"];
    }
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:RemoveLesson_Request_ReleaseAllClass_Survey_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RemoveClassTime %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [CommonClass showToastMsg:ReleaseClass];
            for (UIViewController*vc in [self.navigationController viewControllers])
            {
                if ([vc isKindOfClass: [MyScheduleViewController class]])
                {
                    [self.navigationController popToViewController:vc animated:YES];
                    return;
                }
            }
            
        }else{
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)resign
{
    [txvListRession resignFirstResponder];
    [txvAnyThing resignFirstResponder];
    [txvChoosing resignFirstResponder];
    [scrollV setContentOffset:CGPointMake(0,0) animated:YES];
    [scrollV setContentInset:UIEdgeInsetsZero];
    [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
