//
//  RemoveSectionView.m
//  WaterWorks
//
//  Created by Darshan on 25/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RemoveSectionView.h"
#import "AppDelegate.h"

@implementation RemoveSectionView

AppDelegate *appDelegateUnitTest;

@synthesize testDelegate;
@synthesize index;
@synthesize viewBack;

-(id) initWithFrame:(CGRect)frame
{
    if(self == [super initWithFrame:frame])
    {
        appDelegateUnitTest = (AppDelegate *)[UIApplication sharedApplication].delegate;
        self = (RemoveSectionView *)[RemoveSectionView loadInstanceFromNib:self];
        
        UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dateSingleTap:)];
        [viewBack addGestureRecognizer:singleFingerTap];
    }
    return self;
}

-(void)setSelectedColor:(UIColor *)color
{
    viewBack.backgroundColor = sectionSelectColor;
}

-(void)setNormalColor
{
    viewBack.backgroundColor = sectionUnSelectColor;
}

- (IBAction)onClickCheckMarkBtn:(id)sender {
    
    if([btnCheck isSelected]){
        [btnCheck setSelected:NO];
    }else{
        [btnCheck setSelected:YES];
    }
    if (testDelegate &&[testDelegate respondsToSelector:@selector(selectRemoveTimeClassAtIndex:)]) {
        [testDelegate selectRemoveTimeClassAtIndex:index];
    }
}

- (void)dateSingleTap:(UITapGestureRecognizer *)recognizer {
    
    if (testDelegate && [testDelegate respondsToSelector:@selector(setUnitTestDateAtindex:)]) {
        [testDelegate setUnitTestDateAtindex:index];
    }
}

@end
