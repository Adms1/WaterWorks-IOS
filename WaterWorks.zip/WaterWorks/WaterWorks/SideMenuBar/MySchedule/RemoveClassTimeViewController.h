//
//  RemoveClassTimeViewController.h
//  WaterWorks
//
//  Created by D2D Websolution on 23/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RemoveSectionView.h"
#import "HVTableView.h"
#import "ReleaseClassViewController.h"
#import "RemoveCell.h"

@interface RemoveClassTimeViewController : UIViewController<RemoveTimeDelegate,UnitTestDelegate,HVTableViewDelegate, HVTableViewDataSource,popUpReleaseClassesDelegate>

{
    IBOutlet UIView *viewFooter;
    
    IBOutlet HVTableView *tblRemoveTimeList;
    
    IBOutlet UIButton *btnHome;
    
    int selectedSection;
    
    NSMutableArray *arrRemoveList;
    NSMutableArray *arrRemoveListSelect;
    
    NSMutableArray *arrSelected;
    
    
    NSString *strNewDate;
}

@end
