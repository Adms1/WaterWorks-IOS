//
//  RecommendPopUpViewController.m
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RecommendPopUpViewController.h"

@interface RecommendPopUpViewController ()

@end

@implementation RecommendPopUpViewController

@synthesize removeDelegate;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction)onClickCloseBtn:(id)sender {
    
    if (removeDelegate && [removeDelegate respondsToSelector:@selector(selectRemoveClassTime)]) {
        [removeDelegate selectRemoveClassTime];
    }
}

- (IBAction)onClickGoItBtn:(id)sender {
    
    if (removeDelegate && [removeDelegate respondsToSelector:@selector(selectRemoveClassTime)]) {
        [removeDelegate selectRemoveClassTime];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
