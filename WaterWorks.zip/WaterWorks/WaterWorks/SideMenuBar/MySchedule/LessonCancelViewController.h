//
//  LessonCancelViewController.h
//  WaterWorks
//
//  Created by Ankit on 27/02/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LessonCancelViewController;

@protocol LessonCancelViewControllerDelegate <NSObject>
-(void)selectRemoveLesson:(NSInteger)selectedIndex :(NSInteger)idx :(LessonCancelViewController *)lcvc :(NSString *)valueStr;
@end

@interface LessonCancelViewController : UIViewController
{
    IBOutlet UILabel *lbl_title, *lbl_msg;
    IBOutlet UIButton *btnCancel, *btnDonotCancel;
}

@property(nonatomic,assign)BOOL flag;
@property(nonatomic,assign)NSInteger selectedidx;
@property(nonatomic,assign)NSString *strTitle;
@property(nonatomic,assign)NSString *btnTitle;
@property(nonatomic,assign)NSString *strMsg;
@property(nonatomic,assign)NSString *Value;
@property (assign, nonatomic) id <LessonCancelViewControllerDelegate> LessonCancelDelegate;
@end
