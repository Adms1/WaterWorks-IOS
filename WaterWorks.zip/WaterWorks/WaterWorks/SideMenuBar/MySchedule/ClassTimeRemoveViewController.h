//
//  ClassTimeRemoveViewController.h
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecommendPopUpViewController.h"

@interface ClassTimeRemoveViewController : UIViewController<popUpRemoveClassesDelegate>

{
    IBOutlet UIScrollView *scrollV;
    
    IBOutlet UIButton *btnReleaseTime;

    IBOutlet UIButton *btnReleaseScheduleYes;
    IBOutlet UIButton *btnReleaseScheduleNo;
    
    IBOutlet UIButton *btnCommingBackYes;
    IBOutlet UIButton *btnCommingBackNo;
    IBOutlet UIButton *btnCommingBackThink;
    
    IBOutlet UIButton *btnAnyThingYes;
    IBOutlet UIButton *btnAnyThingNo;
    
    IBOutlet UIButton *btnRecommendYes;
    IBOutlet UIButton *btnRecommendNo;
    IBOutlet UIButton *btnRecommendThink;
    
    IBOutlet UIButton *btnDate;
    IBOutlet UIButton *btnHome;
    
    IBOutlet NSLayoutConstraint *constHeightReleaseView;
    IBOutlet NSLayoutConstraint *constHeightThinkingView;
    IBOutlet NSLayoutConstraint *constHeightAnyThingView;
    IBOutlet NSLayoutConstraint *constHeighRecommendView;
    
    IBOutlet UIView *ReleaseView;
    IBOutlet UIView *ThinkingView;
    IBOutlet UIView *AnyThingView;
    IBOutlet UIView *RecommendView;
    
    IBOutlet UIView *txvView;
    IBOutlet UIView *txvThinkingView;
    IBOutlet UIView *txvAnyThingView;
    
    IBOutlet UILabel *lblTitle;
    
    IBOutlet UITextView *txvListRession;
    IBOutlet UITextView *txvAnyThing;
    IBOutlet UITextView *txvChoosing;
}
@property(nonatomic,retain)NSString *strRequestedEndDate;
@end
