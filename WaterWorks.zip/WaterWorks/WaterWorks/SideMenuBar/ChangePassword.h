//
//  ChangePassword.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InputText.h"

@interface ChangePassword : UIViewController
{
    IBOutlet InputText *txtCpwd,*txtNpwd,*txtCNpwd;
    IBOutlet UIButton *btnHome;
}
@end
