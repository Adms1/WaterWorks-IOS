


//
//  ChangeLocation.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ChangeLocation.h"
#import "MyAccountCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "AddRemoveLocation.h"
#import "NIDropDown.h"

@interface ChangeLocation ()<UIPopoverPresentationControllerDelegate,CommonDelegate,NIDropDownDelegate>
{
    NSMutableArray *arrSites, *arr_Region;
    NIDropDown *dropDown;
}
@end

@implementation ChangeLocation

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblChangelocation.estimatedRowHeight = 40.0;
    tblChangelocation.rowHeight = UITableViewAutomaticDimension;
    
    btnRegion.layer.borderColor = [[UIColor blackColor]CGColor];
    btnRegion.layer.borderWidth = 0.5f;
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksAddLocation :self :btnHome :nil :YES :self];
    [self getRegionList];
}

-(void)getRegionList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    arrSites = [[NSMutableArray alloc]init];
    
    [manager POST:Get_RegionList_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            NSArray *arr =[responseObject objectForKey:@"Sites"];
            [arrSites addObjectsFromArray:arr];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
    }];
}

-(void)Get_SiteListByRegion:(NSString *)strRegionId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"RegionID":strRegionId
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Get_SiteListByRegion_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        arr_Region = [[NSMutableArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arr_Region = [responseObject valueForKey:@"Sites"];
        }
        
        [tblChangelocation reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}


#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_Region.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblChangelocation dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.bgView.layer.borderColor = [[UIColor blackColor]CGColor];
    maCell.bgView.layer.borderWidth = 0.5f;
    maCell.btnAdd.tag = indexPath.row;
    [maCell.btnAdd addTarget:self action:@selector(btnAdd:) forControlEvents:UIControlEventTouchUpInside];
    
    maCell.lbl_name.text = [NSString stringWithFormat:@"%@・%@・%@, %@",[[arr_Region objectAtIndex:indexPath.row] valueForKey:@"SiteName"],[[arr_Region objectAtIndex:indexPath.row] valueForKey:@"Address1"],[[arr_Region objectAtIndex:indexPath.row] valueForKey:@"City"],[[arr_Region objectAtIndex:indexPath.row] valueForKey:@"State"]];
    
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithAttributedString: maCell.lbl_name.attributedText];
    
    NSRange range = [maCell.lbl_name.text rangeOfString:[[arr_Region objectAtIndex:indexPath.row] valueForKey:@"SiteName"] options:NSCaseInsensitiveSearch];
    [text addAttribute:NSFontAttributeName
                 value:FONT_Bold(13)
                 range:range];
    [maCell.lbl_name setAttributedText: text];
    
    return maCell;
}

-(void)btnAdd:(UIButton *)sender
{
    AddRemoveLocation *arl = [self.storyboard instantiateViewControllerWithIdentifier:@"AddRemoveLocation"];
    arl.arrLocation = [arr_Region objectAtIndex:sender.tag];
    arl.btnStatus = @"Add Location";
    [[self navigationController]pushViewController:arl animated:YES];
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

- (IBAction)onClickChangeRegionBtn:(UIButton *)sender
{
    if(dropDown == nil) {
        CGFloat f = 300;
        NSArray *arr = [arrSites valueForKey:@"RegionName"];
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    [self Get_SiteListByRegion:[[arrSites valueForKey:@"RegionID"]objectAtIndex:idx]];
}
@end
