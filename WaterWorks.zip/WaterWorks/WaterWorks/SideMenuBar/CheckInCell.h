//
//  CheckInCell.h
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckInData.h"
#import "NIDropDown.h"

@protocol CheckCellDelegate <NSObject>
-(void)ChangePref1Pref2Value:(NSString *)str :(NSString *)str1 :(NSString *)str2 :(NSInteger)index;
@end

@interface CheckInCell : UITableViewCell<NIDropDownDelegate>
{
    IBOutlet UIView *bgView;
    IBOutlet UILabel *lblChild, *lblEvent, *lblDistance, *lblStroke, *lblAge;
    IBOutlet UIButton *btnDivingBlock, *btnEndLane;
    NIDropDown *dropDown;
}
-(void)getCheckInData:(CheckInData *)checkIn :(NSInteger)count :(NSInteger)index;
@property(nonatomic,retain)UIButton *btnCheck;
@property(nonatomic,retain)id<CheckCellDelegate>c_delegate;
@end
