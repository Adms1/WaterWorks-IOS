
//
//  CheckInCell.m
//  WaterWorks
//
//  Created by Ankit on 27/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CheckInCell.h"

@implementation CheckInCell
int cnt;

- (void)awakeFromNib {
    [super awakeFromNib];
    
    bgView.layer.borderColor = [Top_Color CGColor];
    bgView.layer.borderWidth = 0.5f;
    
    btnDivingBlock.layer.borderColor = [Top_Color CGColor];
    btnDivingBlock.layer.borderWidth = 0.5f;
    
    btnEndLane.layer.borderColor = [Top_Color CGColor];
    btnEndLane.layer.borderWidth = 0.5f;
    
}
-(void)getCheckInData:(CheckInData *)checkIn :(NSInteger)count :(NSInteger)index
{
    cnt = (int)count;
    [btnDivingBlock setTag:index];
    [_btnCheck setTag:index];
    [btnEndLane setTag:index+count];
    
    lblChild.text = [NSString stringWithFormat:@"Child: %@",checkIn.fullname];
    lblEvent.text = [NSString stringWithFormat:@"Event: %@",checkIn.wu_eventnumber];
    lblDistance.text = [NSString stringWithFormat:@"Distance: %@",checkIn.wu_description];
    lblStroke.text = [NSString stringWithFormat:@"Stroke: %@",checkIn.wu_strokedescription];
    lblAge.text = [NSString stringWithFormat:@"Age Group: %@",checkIn.wu_groupdescription];
    if ([checkIn.wu_checkin isEqualToString:@"1"]) {
        [_btnCheck setSelected:YES];
    }else{
        [_btnCheck setSelected:NO];
    }
    
    if ([checkIn.wu_preference1 isEqualToString:@"2"]) {
        [btnDivingBlock setTitle:@"YES" forState:0];
    }else{
        [btnDivingBlock setTitle:@"NO" forState:0];
    }
    
    if ([checkIn.wu_preference2 isEqualToString:@"0"]) {
        [btnEndLane setTitle:@"YES" forState:0];
    }else{
        [btnEndLane setTitle:@"NO" forState:0];
    }
    
    [btnDivingBlock setImageEdgeInsets:UIEdgeInsetsMake(0, btnDivingBlock.frame.size.width - 60, 0, 0)];
    [btnEndLane setImageEdgeInsets:UIEdgeInsetsMake(0, btnEndLane.frame.size.width - 60, 0, 0)];
    
    [btnDivingBlock setTitleEdgeInsets:UIEdgeInsetsMake(0, -btnDivingBlock.frame.size.width + 10, 0, 0)];
    [btnEndLane setTitleEdgeInsets:UIEdgeInsetsMake(0, -btnEndLane.frame.size.width + 10, 0, 0)];
}
-(IBAction)Check:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [self.c_delegate ChangePref1Pref2Value:_btnCheck.selected ? @"True":@"False" :btnDivingBlock.titleLabel.text :btnEndLane.titleLabel.text :sender.tag];
}
-(IBAction)DropDown:(UIButton *)sender
{
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"YES",@"NO"];
    if(dropDown == nil) {
        CGFloat f = 70;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :sender.tag >=cnt ? @"up" : @"down"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

- (void)select:(UIButton *)sender :(NSInteger) idx{
    
    [self.c_delegate ChangePref1Pref2Value:_btnCheck.selected ? @"True":@"False" :btnDivingBlock.titleLabel.text :btnEndLane.titleLabel.text :idx];
}

-(void)rel{
    dropDown = nil;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
