//
//  ViewPaymentHistory.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ViewPaymentHistory.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "AFNetworking.h"
#import "AFHTTPRequestOperationManager.h"
#import "MyAccountCell.h"
#import "MDDatePickerDialog.h"
#import "NIDropDown.h"

@interface ViewPaymentHistory ()<MDDatePickerDialogDelegate,NIDropDownDelegate,CommonDelegate>
{
    NSArray *arr_PaymentHistory,*arr_Sites,*arr_programType;
    NSMutableArray *arr_temp;
    NIDropDown *dropDown;
    CGSize size;
    NSString *str_StartDate,*str_EndDate,*str_SiteId,*str_ProgramType;
}
@property(nonatomic) MDDatePickerDialog *datePicker;
@property(nonatomic) NSDateFormatter *dateFormatter;
@end

@implementation ViewPaymentHistory

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dateFormatter = [[NSDateFormatter alloc] init];
    
    tblPaymentHistory.estimatedRowHeight = 250.0f;
    tblPaymentHistory.rowHeight = UITableViewAutomaticDimension;
    tblPaymentHistory.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    str_StartDate = str_EndDate = str_ProgramType = @"";
    str_SiteId = @"0";
    
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    
    [btnStartDate setImageEdgeInsets:UIEdgeInsetsMake(0, btnStartDate.frame.size.width - 20, 0, 0)];
    [btnEndDate setImageEdgeInsets:UIEdgeInsetsMake(0, btnEndDate.frame.size.width - 20, 0, 0)];
    [btnLocation setImageEdgeInsets:UIEdgeInsetsMake(0, (btnLocation.frame.size.width * 330) / 353, 0, 0)];
    [btnPTypes setImageEdgeInsets:UIEdgeInsetsMake(0, (btnPTypes.frame.size.width * 330) / 353, 0, 0)];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksPaymentHistory :self :btnHome :nil :YES :self];
    
    [self GetSiteNames];
    [self ViewPaymentHistory];
}
-(void)GetSiteNames
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Get_SiteListForFamilyPayments_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arr_Sites = [responseObject valueForKey:@"EmailPref"];
            
            if (arr_Sites.count == 1)
            {
                [btnLocation setTitle:[[arr_Sites valueForKey:@"SiteName"] objectAtIndex:0] forState:0];
                str_SiteId = [[arr_Sites valueForKey:@"SiteID"] objectAtIndex:0];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)ViewPaymentHistory
{
    [lblMsg setHidden:YES];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"siteid":str_SiteId,
                             @"ProgramType":str_ProgramType,
                             @"strEndDate":str_EndDate,
                             @"strStartDate":str_StartDate,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    arr_PaymentHistory = [[NSArray alloc]init];
    [manager POST:Get_GetPaymentHistoryOfFamily_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arr_PaymentHistory = [responseObject valueForKey:@"EmailPref"];
            
            arr_temp = [[NSMutableArray alloc]init];
            for (int i = 0; i < arr_PaymentHistory.count; i++)
            {
                [arr_temp addObject:[NSNumber numberWithBool:NO]];
            }
        }else{
            [lblMsg setHidden:NO];
        }
        
        tblHeight.constant = 1000000;
        [tblPaymentHistory reloadData];
        [tblPaymentHistory layoutIfNeeded];
        
        tblPaymentHistory.contentSize = [tblPaymentHistory sizeThatFits:CGSizeMake(CGRectGetWidth(tblPaymentHistory.bounds), CGFLOAT_MAX)];
        tblHeight.constant = tblPaymentHistory.contentSize.height;
        [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblHeight.constant + 375)];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arr_PaymentHistory.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*NSArray *arr = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"];
     NSMutableArray *temp = [[NSMutableArray alloc]init];
     
     if ([[arr_temp objectAtIndex:indexPath.row] isEqual:[NSNumber numberWithBool:YES]]) {
     
     for (int i = 0; i < arr.count; i++)
     {
     [temp addObject:[NSString stringWithFormat:@"%@:%@",[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemType"]objectAtIndex:i],[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemName"]objectAtIndex:i]]];
     }
     return 125.0 + [self getDynamicHeightOflbl:[temp componentsJoinedByString:@"\n"] :self.view.frame.size.width - 183].height;
     }
     
     NSString *str;
     if (arr.count == 1) {
     str = [NSString stringWithFormat:@"%@ %@",[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemType"]objectAtIndex:0],[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemName"]objectAtIndex:0]];
     }else{
     str = @"Show Line Items";
     }
     CGFloat height = [self getDynamicHeightOflbl:[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"sitename"] :self.view.frame.size.width - 163].height;
     return 110.0 + height + [self getDynamicHeightOflbl:str :self.view.frame.size.width - 183].height;*/
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblPaymentHistory dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.lbl_date.text = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"invoicedate"];
    maCell.lbl_siteName.text = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"sitename"];
    maCell.lbl_Invoice.text = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"TotalAmount"];
    maCell.lbl_Amount.text = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"AmountDue"];
    maCell.lbl_Payment.text = ([maCell.lbl_Invoice.text isEqualToString:@"0.00"] || [maCell.lbl_Amount.text isEqualToString:@"0.00"]) ? @"CREDITED" :[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"PaymentType"];
    
    NSArray *arr_des = [[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"];
    
    maCell.lbl_Description.tag = indexPath.row;
    if (arr_des.count == 1) {
        maCell.lbl_Description.text = [NSString stringWithFormat:@"%@ %@",[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemType"]objectAtIndex:0],[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemName"]objectAtIndex:0]];
        maCell.lbl_Description.textColor = [UIColor blackColor];
        maCell.lbl_Description.font = FONT_OpenSans(14);
        
    }else{
        maCell.lbl_Description.textColor = Top_Color;
        maCell.lbl_Description.font = FONT_Bold(14);
        maCell.lbl_Description.text = @"Show Line Items";
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(lblTap:)];
        [maCell.lbl_Description setUserInteractionEnabled:YES];
        [maCell.lbl_Description addGestureRecognizer:tap];
    }
    
    
    if ([[arr_temp objectAtIndex:indexPath.row] isEqual:[NSNumber numberWithBool:YES]]) {
        
        maCell.lbl_Description.textColor = [UIColor blackColor];
        maCell.lbl_Description.font = FONT_OpenSans(14);
        
        NSMutableArray *temp = [[NSMutableArray alloc]init];
        for (int i = 0; i < arr_des.count; i++)
        {
            [temp addObject:[NSString stringWithFormat:@"%@:%@",[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemType"]objectAtIndex:i],[[[[arr_PaymentHistory objectAtIndex:indexPath.row]valueForKey:@"Description"]valueForKey:@"ItemName"]objectAtIndex:i]]];
        }
        maCell.lbl_Description.text = [temp componentsJoinedByString:@"\n"];
        
    }
    
    return maCell;
}

-(void)lblTap:(UITapGestureRecognizer *)gesture
{
    [gesture.view layoutIfNeeded];
    size = gesture.view.frame.size;
    
    [arr_temp replaceObjectAtIndex:gesture.view.tag withObject:[NSNumber numberWithBool:YES]];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:gesture.view.tag inSection:0];
    NSArray *indexPaths = [[NSArray alloc] initWithObjects:indexPath, nil];
    
    [tblPaymentHistory beginUpdates];
    [tblPaymentHistory reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
    [tblPaymentHistory endUpdates];
    
    tblPaymentHistory.contentSize = [tblPaymentHistory sizeThatFits:CGSizeMake(CGRectGetWidth(tblPaymentHistory.bounds), CGFLOAT_MAX)];
    tblHeight.constant = tblPaymentHistory.contentSize.height;
    [scroll_main setContentSize:CGSizeMake(self.view.frame.size.width, tblHeight.constant + 375)];
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str :(CGFloat)width
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_Bold(14) }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){width, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize Size = rect.size;
    return Size;
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}
- (IBAction)onClickSelectDateBtn:(UIButton *)sender
{
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    _datePicker.selectedDate = [NSDate date];
    _datePicker.tag = sender.tag;
    [_datePicker show];
}

- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    _dateFormatter.dateFormat = @"MM/dd/yyyy";
    if (_datePicker.tag == 1)
    {
        [btnStartDate setTitle:[_dateFormatter stringFromDate:date] forState:0];
        str_StartDate = btnStartDate.titleLabel.text;
    }
    else
    {
        [btnEndDate setTitle:[_dateFormatter stringFromDate:date] forState:0];
        str_EndDate = btnEndDate.titleLabel.text;
    }
}

-(IBAction)btnSelectProgramType:(UIButton *)sender
{
    arr_programType = @[@"-All Types-",@"Lessons",@"Swim Team",@"Lap Swim",@"Water Aerobics",@"Birthday Party",@"Free Swim",@"Girls Scout Program",@"Dives and Turns Clinics",@"Swim Competition",@"Family Swim Nights",@"Scout Program",@"Jr. Life Guard Prep",@"Lifesaving/Swimming Merit Badges",@"Aquanaut/Swimming Activity Badges",@"Water Polo Conditioning",@"Retail Product"];
    
    [btnPTypes setSelected:YES];
    if(dropDown == nil) {
        CGFloat f = 250;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr_programType :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

-(IBAction)btnSelectLocation:(UIButton *)sender
{
    [btnLocation setSelected:YES];
    NSArray *array = [[NSArray alloc]initWithObjects:@"-All Locations-", nil];
    array = [array arrayByAddingObjectsFromArray:[arr_Sites valueForKey:@"SiteName"]];
    
    if (array.count > 2) {
        if(dropDown == nil) {
            CGFloat f = 150;
            dropDown = [[NIDropDown alloc]showDropDown:sender :&f :array :nil :@"down"];
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel];
        }
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender
{
    if(btnPTypes.selected == YES)
    {
        NSInteger idx = [arr_programType indexOfObject:btnPTypes.titleLabel.text];
        str_ProgramType = [btnPTypes.titleLabel.text isEqualToString:@"-All Types-"] ? @"" :[NSString stringWithFormat:@"%ld",(long)idx];
        [btnPTypes setSelected:NO];
    }
    else if(btnLocation.selected == YES)
    {
        NSInteger idx = [[arr_Sites valueForKey:@"SiteName"] indexOfObject:btnLocation.titleLabel.text];
        str_SiteId = [btnLocation.titleLabel.text isEqualToString:@"-All Locations-"] ? @"0" :[[arr_Sites valueForKey:@"SiteID"] objectAtIndex:idx];
        [btnLocation setSelected:NO];
    }
    [self rel];
}
-(void)rel{
    dropDown = nil;
}

-(IBAction)btnSelectFilter:(UIButton *)sender
{
    [self ViewPaymentHistory];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
