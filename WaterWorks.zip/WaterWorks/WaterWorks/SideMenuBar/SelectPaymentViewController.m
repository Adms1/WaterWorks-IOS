//
//  SelectPaymentViewController.m
//  WaterWorks
//
//  Created by Ankit on 22/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SelectPaymentViewController.h"
#import "AppDelegate.h"
#import "MakePaymentViewController.h"
#import "CustomTabbar.h"
#import "MyCartViewController.h"
#import "MyAccountCell.h"
#import "CommonClass.h"
#import "UpdateCardViewController.h"

@interface SelectPaymentViewController ()<CommonDelegate>
{
    NSMutableArray *arrCardDetails;
    NSString *strCard;
    NSString *currentDateMonth;
}
@end

@implementation SelectPaymentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblPayment.estimatedRowHeight = 50.0f;
    tblPayment.rowHeight = UITableViewAutomaticDimension;
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksMakePurchase :self :btnHome :btnCart :YES :self];
    
    [self CardDetail];
}

-(void)CardDetail
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                             @"Basketid":[[NSUserDefaults standardUserDefaults] valueForKey:BASKETID]
                             };
    
    [manager POST:Pay_DGetACHCardDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arrCardDetails = [responseObject valueForKey:@"ACHList"];
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"MM/yy"];
            currentDateMonth = [formatter stringFromDate:[NSDate date]];
        }
        
        [tblPayment reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)PaymentConfirm:(NSString *)strType :(NSString *)pmtid :(NSString *)strCardNumber
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"chkSaveCard":@"",
                             @"chkSaveACH":@"",
                             @"strCheckDtl":@"",
                             @"ShippingAddress":@"",
                             @"wu_recurring":@"0",
                             @"strCreditDtl":@"",
                             @"strType":strType,
                             @"RBPaymentType":@"",
                             @"pmtid":pmtid,
                             @"BasketID":[[NSUserDefaults standardUserDefaults]valueForKey:BASKETID],
                             @"chkagree":@"True",
                             @"strCard":strCardNumber,
                             @"ChkAddShippingAddress":@"False"
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Pay_ConformPaymnet_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if (![[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCheck"] objectAtIndex:0] isEqualToString:@""])
            {
                [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"PaymentCredit"];
                [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCheck"] objectAtIndex:0] forKey:@"PaymentCheck"];
            }
            else
            {
                [[NSUserDefaults standardUserDefaults]setValue:@"" forKey:@"PaymentCheck"];
                [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentCredit"] objectAtIndex:0] forKey:@"PaymentCredit"];
            }
            [[NSUserDefaults standardUserDefaults]setValue:strCard forKey:@"CreditCardNum"];
            [[NSUserDefaults standardUserDefaults]setValue:[[[responseObject valueForKey:@"ConformPayment"] valueForKey:@"PaymentBillingAddress"] objectAtIndex:0] forKey:@"AddressDetails"];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnSelectPaymentMethod:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        MakePaymentViewController *mpvc = [[MakePaymentViewController alloc]initWithNibName:@"MakePaymentViewController" bundle:nil];
        [self.navigationController pushViewController:mpvc animated:YES];
    }
    else
    {
        SHARED_APPDELEGATE.IsPlaceOrder = YES;
        arrCardDetails.count == 0 ? [CommonClass showToastMsg:PaymentMethodSelection] : strCard == nil ? [CommonClass showToastMsg:PaymentMethodSelection] : [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    CustomTabbar *ct = [[CustomTabbar alloc]initWithRect:self.view.bounds :ProgramTab :self :0 :0];
    [self.view insertSubview:ct atIndex:0];
}

-(void)popViewController
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickAddCartBtn:(id)sender
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyCartViewController *mcvc = [storyBoard instantiateViewControllerWithIdentifier:@"MyCartViewController"];
    [[self navigationController]pushViewController:mcvc animated:YES];
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return tblFooter.frame.size.height;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return tblFooter;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrCardDetails.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tblPayment dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    maCell.btn_check.tag = indexPath.row;
    [maCell.btn_check addTarget:self action:@selector(btnCheck:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([[[arrCardDetails valueForKey:@"wu_PayType"] objectAtIndex:indexPath.row] isEqualToString:@"Card"])
    {
        maCell.lbl_payment.text = [NSString stringWithFormat:@"%@  %@\n%@\nExpires %@",[[arrCardDetails valueForKey:@"wu_CardType"] objectAtIndex:indexPath.row],[[[arrCardDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:indexPath.row]substringFromIndex:7],[[arrCardDetails valueForKey:@"wu_ClientName"] objectAtIndex:indexPath.row],[[[[arrCardDetails valueForKey:@"wu_ExpDate"] objectAtIndex:indexPath.row] componentsSeparatedByString:@":"] lastObject]];
        
        if ([self CompareTwoDates:currentDateMonth :[[[[arrCardDetails valueForKey:@"wu_ExpDate"] objectAtIndex:indexPath.row] componentsSeparatedByString:@":"] lastObject]])
        {
            //Expire
            NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc]initWithString: maCell.lbl_payment.text];
            
            NSRange range = [maCell.lbl_payment.text rangeOfString:[NSString stringWithFormat:@"Expires %@",[[[[arrCardDetails valueForKey:@"wu_ExpDate"] objectAtIndex:indexPath.row] componentsSeparatedByString:@":"] lastObject]] options:NSCaseInsensitiveSearch];
            [attrStr addAttribute:NSForegroundColorAttributeName
                            value:[UIColor redColor]
                            range:range];
            maCell.lbl_payment.attributedText = attrStr;
            [maCell.btnEdit setHidden:NO];
            maCell.btnEdit.tag = indexPath.row;
            [maCell.btnEdit addTarget:self action:@selector(btnEditClicked:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    else
    {
        maCell.lbl_payment.text = [NSString stringWithFormat:@"Checking - %@\n%@",[[[arrCardDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:indexPath.row]substringFromIndex:5],[[arrCardDetails valueForKey:@"wu_BankName"] objectAtIndex:indexPath.row]];
    }
    
    return maCell;
}

-(void)btnEditClicked:(UIButton *)sender
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UpdateCardViewController *ucvc = [storyBoard instantiateViewControllerWithIdentifier:@"UpdateCardViewController"];
    ucvc.strPmtId = [[arrCardDetails valueForKey:@"wu_PmtID"] objectAtIndex:sender.tag];
    ucvc.strCustomerId = [[arrCardDetails valueForKey:@"wu_CustomerID"] objectAtIndex:sender.tag];
    [self.navigationController pushViewController:ucvc animated:YES];
}

-(BOOL)CompareTwoDates:(NSString *)strDate1 :(NSString *)strDate2
{
    NSDateFormatter *dateFormatter=[NSDateFormatter new];
    [dateFormatter setDateFormat:@"mm/yy"];
    NSDate *date1 = [dateFormatter dateFromString:strDate1];
    NSDate *date2 =[dateFormatter dateFromString:strDate2];
    
    if ([date1 compare:date2] == NSOrderedDescending) {
        //"date1 is later than date2
        return YES;
    } else if ([date1 compare:date2] == NSOrderedAscending) {
        //date1 is earlier than date2
        return NO;
    } else {
        //dates are the same
        return NO;
    }
}
-(void)btnCheck:(UIButton *)sender
{
    for (MyAccountCell *cell in tblPayment.visibleCells)
    {
        [cell.btn_check setImage:[UIImage imageNamed:@"CellUnCheck"] forState:0];
        if (sender != cell.btn_check) {
            cell.btn_check.selected = NO;
        }
    }
    sender.selected = !sender.selected;
    strCard = sender.selected ? [[[arrCardDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:sender.tag] substringFromIndex:[[[arrCardDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:sender.tag] length]-4] : @"";
    [[NSUserDefaults standardUserDefaults]setValue:[[arrCardDetails valueForKey:@"wu_CardType"] objectAtIndex:sender.tag] forKey:@"CardType"];
    [self PaymentConfirm:[[arrCardDetails valueForKey:@"wu_PayTypeID"] objectAtIndex:sender.tag]:[[arrCardDetails valueForKey:@"wu_PmtID"] objectAtIndex:sender.tag]:[[arrCardDetails valueForKey:@"wu_CardAccNumber"] objectAtIndex:sender.tag]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
