//
//  ScheduleMakeupViewController.h
//  WaterWorks
//
//  Created by Ankit on 07/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MDButton.h"

@interface ScheduleMakeupViewController : UIViewController
{
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnLocation;
    
    IBOutlet UIScrollView *scroll;
    IBOutlet UIWebView *webView;
    IBOutlet UITableView *tblSlist;
    
    IBOutlet UIButton *btn_sed_1,*btn_sed_2;
    
    IBOutlet UIView *noteView;
    IBOutlet UIButton *btnStartDate,*btnEndDate;
    IBOutlet MDButton *btnNext;
    
    IBOutlet UIView *lv,*v1,*v2,*v3;
    
    //Constrain
    IBOutlet NSLayoutConstraint *lViewHeight;
    IBOutlet NSLayoutConstraint *noteViewHeight;
    IBOutlet NSLayoutConstraint *tblHeight;
    
    IBOutlet NSLayoutConstraint *v1Height;
    IBOutlet NSLayoutConstraint *v2Height;
    IBOutlet NSLayoutConstraint *v3Height;
}
@end
