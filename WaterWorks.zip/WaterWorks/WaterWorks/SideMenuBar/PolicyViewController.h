//
//  PolicyViewController.h
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PolicyViewController : UIViewController
{
    IBOutlet UIButton *btnHome;
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *actView;
}
@property(nonatomic,assign)NSString *strType;
@end
