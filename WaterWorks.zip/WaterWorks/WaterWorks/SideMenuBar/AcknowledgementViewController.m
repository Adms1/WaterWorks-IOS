//
//  AcknowledgementViewController.m
//  WaterWorks
//
//  Created by Ankit on 30/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "AcknowledgementViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "ReviewViewController.h"
#import "CustomTabbar.h"

@interface AcknowledgementViewController ()<CommonDelegate>
{
    NSArray *arrMessage;
    int xi;
    CGSize lblSize,TotalSize;
}
@end

@implementation AcknowledgementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    xi = 0;
    [self SwimCmpt_Register_GetAck];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksAcknowledgements :self :btnHome :nil :YES :self];
}

-(void)SwimCmpt_Register_GetAck
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSString *str_meedId = [[[[NSUserDefaults standardUserDefaults]valueForKey:@"DateValue"] componentsSeparatedByString:@"|"]lastObject];
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                             @"meetid":str_meedId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"Params %@",params);
    
    [manager POST:SwimCmpt_Register_GetAck_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@" SCHEDULE RESPONSE  %@",responseObject);
        
        arrMessage = [[NSArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSArray *arr = [responseObject safeObjectForKey:@"SwimMeetCheck4"];
            if (arr.count > 0) {
                arrMessage = arr;
                [self AddAcknowledgement];
            }
        }else{
            [self.view.subviews[1] setHidden:NO];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)AddAcknowledgement
{
    xi++;
    if (xi <= arrMessage.count)
    {
        lblSize = [self getDynamicHeightOflbl:[[arrMessage objectAtIndex:xi-1]valueForKey:@"messageText"]];
        UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, TotalSize.height, self.view.frame.size.width - 60, lblSize.height)];
        lbl.textColor = [UIColor darkGrayColor];
        lbl.font = FONT_OpenSans(14);
        lbl.text = [[arrMessage objectAtIndex:xi-1]valueForKey:@"messageText"];
        lbl.tag = xi*1000;
        lbl.numberOfLines = 0;
        lbl.lineBreakMode = NSLineBreakByWordWrapping;
        [scrollView addSubview:lbl];
        
        TotalSize.height += lblSize.height + 50;
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, TotalSize.height - 35, 120, 25)];
        [btn setTitle:@"I understand" forState:0];
        [btn setTitleColor:[UIColor darkGrayColor] forState:0];
        [btn.titleLabel setFont:FONT_OpenSans(14)];
        [btn setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:0];
        [btn setImage:[UIImage imageNamed:@"CheckInstructor"] forState:UIControlStateSelected];
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        btn.tag = xi*100;
        [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [scrollView addSubview:btn];
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,  TotalSize.height + 30)];
        
        [CustomAnimation SlideUp:lbl :0.3];
    }
    else
    {
        btnNext.frame = CGRectMake(15, TotalSize.height + 30, self.view.frame.size.width - 30, 40);
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,  TotalSize.height + 100)];
        [btnNext setHidden:NO];
        
        [CustomAnimation SlideUp:btnNext :0.3];
    }
    [scrollView scrollRectToVisible:CGRectMake(scrollView.contentSize.width - 1,scrollView.contentSize.height - 1, 1, 1) animated:YES];
}

-(void)btnClicked:(UIButton *)sender
{
    sender.selected = !sender.selected;
    if (sender.selected) {
        [self AddAcknowledgement];
    }else{
        int x = xi - ((int)sender.tag)/100;
        for (int i = 0; i < x; i++)
        {
            [[scrollView viewWithTag:xi*100]removeFromSuperview];
            [[scrollView viewWithTag:xi*1000]removeFromSuperview];
            xi--;
            TotalSize.height = [scrollView viewWithTag:xi*1000].frame.origin.y + [scrollView viewWithTag:xi*1000].frame.size.height + 50;
            [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,  TotalSize.height + 30)];
            [scrollView scrollRectToVisible:CGRectMake(scrollView.contentSize.width - 1,scrollView.contentSize.height - 1, 1, 1) animated:YES];
            [btnNext setHidden:YES];
        }
    }
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_OpenSans(14) }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.view.frame.size.width - 60, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize Size = rect.size;
    return Size;
}

-(IBAction)btnNext:(id)sender
{
    ReviewViewController *rvc = [[ReviewViewController alloc]initWithNibName:@"ReviewViewController" bundle:nil];
    rvc.arrStudentIds = _arrStudentIds;
    [[self navigationController]pushViewController:rvc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
