//
//  FirstTimeViewController.h
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NIDropDown.h"
#import "MDDatePickerDialog.h"
#import "AppDelegate.h"
#import "MDButton.h"

@interface FirstTimeViewController : UIViewController<NIDropDownDelegate,MDDatePickerDialogDelegate>

{
    IBOutlet UIScrollView *scroll;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIView *viewCondition;
    IBOutlet NSLayoutConstraint *viewHeight;
    
    IBOutlet UITextField *txtFirstName;
    IBOutlet UITextField *txtLastName;
    IBOutlet UIButton *btnDateOfBirth;
    IBOutlet UIButton *btnMale;
    IBOutlet UIButton *btnFirstAny;
    IBOutlet UIButton *btnSecondAny;
    IBOutlet UITextField *txtCondtion;

    IBOutlet MDButton *btnNext;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnYes;
    IBOutlet UIButton *btnNo;
    
    NIDropDown *dropDown;
    
//    IBOutlet UIDatePicker *pickerHomeWorkDate;
    NSDate *selectedDate;
    
    NSString *strBirthdate;
    
}
@property(nonatomic) NSString *strNew;
@property(nonatomic) NSDateFormatter *dateFormatter;
@property(nonatomic) MDDatePickerDialog *datePicker;
@end
