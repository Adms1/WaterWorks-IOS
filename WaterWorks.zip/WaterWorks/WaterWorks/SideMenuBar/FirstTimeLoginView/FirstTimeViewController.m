//
//  FirstTimeViewController.m
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "FirstTimeViewController.h"
#import "QuestionViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface FirstTimeViewController ()<CommonDelegate>
{
    BOOL flag;
}
@end

@implementation FirstTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dateFormatter = [[NSDateFormatter alloc] init];
    
    txtFirstName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtFirstName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtFirstName.leftViewMode = UITextFieldViewModeAlways;
    txtFirstName.rightViewMode = UITextFieldViewModeAlways;
    txtFirstName.layer.borderWidth = 1.0f;
    txtFirstName.layer.borderColor = RegisterTextColor.CGColor;
    
    txtLastName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtLastName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtLastName.leftViewMode = UITextFieldViewModeAlways;
    txtLastName.rightViewMode = UITextFieldViewModeAlways;
    txtLastName.layer.borderWidth = 1.0f;
    txtLastName.layer.borderColor = RegisterTextColor.CGColor;
    
    btnMale.layer.borderWidth = 1.0f;
    btnMale.layer.borderColor = RegisterTextColor.CGColor;
    
    btnDateOfBirth.layer.borderWidth = 1.0f;
    btnDateOfBirth.layer.borderColor = RegisterTextColor.CGColor;
    
    btnFirstAny.layer.borderWidth = 1.0f;
    btnFirstAny.layer.borderColor = RegisterTextColor.CGColor;
    
    btnSecondAny.layer.borderWidth = 1.0f;
    btnSecondAny.layer.borderColor = RegisterTextColor.CGColor;
    
    txtCondtion.layer.borderWidth = 1.0f;
    txtCondtion.layer.borderColor = RegisterTextColor.CGColor;
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *lname = [userDefault objectForKey:WU_LASTNAME];
    if(lname != nil){
        txtLastName.text = lname;
    }
    
    for (UIView *v in [scroll subviews])
    {
        if([v isKindOfClass:[UILabel class]])
        {
            if(((UILabel *)v).tag != 1)
            {
                NSMutableAttributedString *text =
                [[NSMutableAttributedString alloc]
                 initWithAttributedString: ((UILabel *)v).attributedText];
                NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 2] options:NSCaseInsensitiveSearch];
                [text addAttribute:NSForegroundColorAttributeName
                             value:[UIColor redColor]
                             range:range];
                [((UILabel *)v) setAttributedText:text];
            }
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationRegisterChild :self :btnHome :nil :YES :self];
}

-(void)viewDidAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO];
}

-(void)popViewController
{
    if ([_strNew isEqualToString:@"Register New"]) {
        [[self navigationController]popViewControllerAnimated:YES];
    }else
        [SHARED_APPDELEGATE setLoginViewController];
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtFirstName) {
        point = CGPointMake(0, 0);
    }else if(textField == txtLastName){
        point = CGPointMake(0, 0);
    }else if(textField == txtCondtion){
        point = CGPointMake(0, viewCondition.frame.origin.y - viewCondition.frame.size.height);
    }
    [scroll setContentOffset:point animated:YES];
}

- (IBAction)onClickYesNoBtn:(UIButton *)sender
{
    flag = YES;
    [btnYes setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
    [btnNo setImage:[UIImage imageNamed:@"UnCheckCircle"] forState:0];
    
    [sender setImage:[UIImage imageNamed:@"SelectedSchedule"] forState:0];
    
    if (sender.tag == 0)
    {
        viewHeight.constant = 0.0f;
        [viewCondition setHidden:YES];
    }
    else
    {
        viewHeight.constant = 90.0f;
        [viewCondition setHidden:NO];
    }
    
    [btnNext layoutIfNeeded];
    [scroll layoutIfNeeded];
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width,btnNext.frame.origin.y + btnNext.frame.size.height + 20)];
    [scroll scrollRectToVisible:CGRectMake(scroll.contentSize.width - 1,scroll.contentSize.height - 1, 1, 1) animated:YES];
}
- (IBAction)onClickMaleBtn:(id)sender {
    
    [self Resign];
    btnMale.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"Male",@"Female"];
    if(dropDown == nil) {
        CGFloat f = 74;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
    [btnMale setTitleColor:[UIColor blackColor] forState:0];
}

- (IBAction)onClickFirstAnyBtn:(id)sender {
    
    [self Resign];
    btnFirstAny.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"No Preference",@"Male",@"Female"];
    if(dropDown == nil) {
        CGFloat f = 118;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
    [btnFirstAny setTitleColor:[UIColor blackColor] forState:0];
}

- (IBAction)onClickSecondAnyBtn:(id)sender {
    
    [self Resign];
    btnSecondAny.selected = YES;
    NSArray * arr = [[NSArray alloc] init];
    arr = @[@"No Preference",@"Firm",@"Gentle"];
    if(dropDown == nil) {
        CGFloat f = 118;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"up"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
    [btnSecondAny setTitleColor:[UIColor blackColor] forState:0];
}

-(BOOL)UpdateChildValidate
{
    NSString *strFirstName  = [CommonClass trimString:txtFirstName.text];
    NSString *strLastName = [CommonClass trimString:txtLastName.text];
    
    if ([strFirstName length] == 0) {
        [txtFirstName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideFirstName delegate:self];
        return NO;
    }
    if ([strLastName length] == 0) {
        [txtLastName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideLastName delegate:self];
        return NO;
    }
    if ([btnDateOfBirth.titleLabel.text isEqualToString:@" "]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideDateOfBirth delegate:self];
        return NO;
    }
    if ([btnMale.titleLabel.text isEqualToString:@"-Select Type-"]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideGender delegate:self];
        return NO;
    }
    if ([btnFirstAny.titleLabel.text isEqualToString:@"-Select Type-"]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePIG delegate:self];
        return NO;
    }
    if ([btnSecondAny.titleLabel.text isEqualToString:@"-Select Type-"]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePITS delegate:self];
        return NO;
    }
    if(!flag)
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideCondition delegate:self];
        return NO;
    }
    if(viewHeight.constant > 0)
    {
        if ([txtCondtion.text length] == 0) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideMCondition delegate:self];
            return NO;
        }
        return YES;
    }
    return  YES;
}

- (IBAction)onClickNextBtn:(id)sender {
    
    if ([self UpdateChildValidate]) {
        
        QuestionViewController *viewRegisterChild;
        
        if (isIpad) {
            viewRegisterChild = [[QuestionViewController alloc] initWithNibName:@"QuestionViewController" bundle:nil];
        }else{
            viewRegisterChild = [[QuestionViewController alloc] initWithNibName:@"QuestionViewController" bundle:nil];
        }
        viewRegisterChild.type = @"Register";
        viewRegisterChild.strMedical = txtCondtion.text;
        [self.navigationController pushViewController:viewRegisterChild animated:YES];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        [userDefault setObject:txtFirstName.text forKey:UD_REGISTER_F_NAME];
        [userDefault setObject:txtLastName.text forKey:UD_REGISTER_L_NAME];
        [userDefault setObject:btnDateOfBirth.titleLabel.text forKey:UD_REGISTER_B_DATE];
        
        [userDefault setObject:[NSString stringWithFormat:@"%@|%@|%@",btnMale.titleLabel.text,btnFirstAny.titleLabel.text,btnSecondAny.titleLabel.text] forKey:@"SDATA"];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if (btnMale.selected == YES) {
        btnMale.selected = NO;
        [userDefault setObject:btnMale.titleLabel.text forKey:UD_REGISTER_GENDER];
    }else if (btnFirstAny.selected == YES){
        btnFirstAny.selected = NO;
        [userDefault setObject:btnFirstAny.titleLabel.text forKey:UD_REGISTER_INSTRU_1];
    }else if (btnSecondAny.selected == YES){
        btnSecondAny.selected = NO;
        [userDefault setObject:btnSecondAny.titleLabel.text forKey:UD_REGISTER_INSTRU_2];
    }
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

/*- (IBAction)onClickPickDate:(UIDatePicker *)datePicker {
 
 NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
 [dateFormatter setDateFormat:@"MM/dd/yyyy"];
 NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
 
 selectedDate = datePicker.date;
 
 NSLog(@"%@",strDate);
 strBirthdate = strDate;
 [btnDateOfBirth setTitle:strDate forState:UIControlStateNormal];
 }*/

- (IBAction)btnSelectDate:(UIButton *)sender {
    [self Resign];
    if (!_datePicker) {
        MDDatePickerDialog *datePicker = [[MDDatePickerDialog alloc] init];
        _datePicker = datePicker;
        _datePicker.delegate = self;
    }
    _datePicker.selectedDate = [NSDate date];
    _datePicker.maximumDate = [NSDate date];
    _datePicker.tag = sender.tag;
    [_datePicker show];
}

- (void)datePickerDialogDidSelectDate:(NSDate *)date {
    _dateFormatter.dateFormat = @"MMM dd,yyyy";
    [btnDateOfBirth setTitle:[_dateFormatter stringFromDate:date] forState:UIControlStateNormal];
}

-(void)Resign
{
    [txtFirstName resignFirstResponder];
    [txtLastName resignFirstResponder];
    [txtCondtion resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
