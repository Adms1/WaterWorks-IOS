//
//  QuestionViewController.h
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol QuestionDelegate <NSObject>
-(void)UpdateStudentQuestionLevel:(NSString *)levelNum;
@end
@interface QuestionViewController : UIViewController

{
    IBOutlet UIScrollView *scroll;
    
    IBOutlet UIView *Qv1;
    IBOutlet UIView *Qv2;
    IBOutlet UIView *Qv3;
    IBOutlet UIView *Qv4;
    IBOutlet UIView *Qv5;
    IBOutlet UIView *Qv6;
    IBOutlet UIView *CLview;
    
    IBOutlet UILabel *lblQuq1;
    IBOutlet UILabel *lblQuq2;
    IBOutlet UILabel *lblQuq3;
    IBOutlet UILabel *lblQuq4;
    IBOutlet UILabel *lblQuq5;
    IBOutlet UILabel *lblQuq6;
    
    IBOutlet UILabel *lbl_level;
    IBOutlet NSLayoutConstraint *topSpace;
    
    IBOutlet UIButton *btnHome;
    IBOutlet UIView *TypeView;
    IBOutlet NSLayoutConstraint *TypeViewHeight;
    
    IBOutlet NSLayoutConstraint *Qv1Height;
    IBOutlet NSLayoutConstraint *Qv2Height;
    IBOutlet NSLayoutConstraint *Qv3Height;
    IBOutlet NSLayoutConstraint *Qv4Height;
    IBOutlet NSLayoutConstraint *Qv5Height;
    IBOutlet NSLayoutConstraint *Qv6Height;
}
@property(nonatomic,retain)NSString *type;
@property(nonatomic,retain)NSString *strMedical;
@property(nonatomic,retain)id<QuestionDelegate>q_delegate;
@end
