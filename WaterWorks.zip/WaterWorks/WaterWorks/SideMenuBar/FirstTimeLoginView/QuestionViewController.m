//
//  QuestionViewController.m
//  WaterWorks
//
//  Created by Darshan on 20/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "QuestionViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "ManageStudent.h"

@interface QuestionViewController ()<CommonDelegate>
{
    NSString *queCount,*Level;
    NSDictionary *dic;
    NSString *age;
    NSMutableArray *LessonIds,*LessonSelectedIds;
    BOOL startOver;
}
@end

@implementation QuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    queCount = @"1";
    LessonSelectedIds = [[NSMutableArray alloc]init];
    NSArray *lbls = [[NSArray alloc] initWithObjects:lblQuq1,lblQuq2, lblQuq3, lblQuq4, lblQuq5, lblQuq6, nil];
    
    for(int i = 0 ; i < lbls.count ; i++)
    {
        [self ChangelblColor:[NSString stringWithFormat:@"Question #%d",i+1] :((UILabel *)[lbls objectAtIndex:i])];
    }
    
    for (UIView *v in scroll.subviews)
    {
        if ([v isKindOfClass:[UIView class]])
        {
            for (UIView *v1 in v.subviews)
            {
                if ([v1 isKindOfClass:[UIButton class]] && v1.tag !=
                    1)
                {
                    v1.layer.borderColor = [[UIColor lightGrayColor]CGColor];
                    v1.layer.borderWidth = 1.0f;
                    
                    v1.layer.shadowColor = [[UIColor grayColor] CGColor];
                    v1.layer.shadowOffset = CGSizeMake(0.0f,2.0f);
                    v1.layer.shadowOpacity = 1.0f;
                    v1.layer.shadowRadius = 1.0f;
                }
            }
        }
    }
    
    dic = @{
            @"2a":@"Is your child able to swim backstroke across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of the pool and without assistance?",
            @"2b":@"Can your child swim or kick half way across the pool (12.5 yards) without assistance by using side breathing or rolling from thier stomach to their back?",
            @"3a":@"Does your child know how to swim legal Breakstroke without any flutter kicks across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of pool and without assistance?",
            @"3b":@"Can your child swim freestyle (the crawl) with 2 unassisted rollover breaths?",
            @"4yes":@"Does your child know how to swim legal Butterfly without any flutter kicks across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of pool and without assistance?",
            @"4no":@"Can your child keep their face and ears entirely in the water for 5 seconds?",
            };
    
    age = [CommonClass CalculateAge:[[NSUserDefaults standardUserDefaults] valueForKey:UD_REGISTER_B_DATE]];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationRegisterChild :self :btnHome :nil :YES :self];
}

#pragma mark - WEBSERVCIE CALLING

-(void)AgeCalculation:(NSString *)level
{
    Level = level;
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"age":[age substringToIndex:[age length] - 1],
                             @"Level":level,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Age_Calculation_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([_type isEqualToString:@"Register"]) {
                [self addDynamicInstructorButton:(NSArray *)[responseObject valueForKey:@"FinalArray"]];
            }else{
                [self.q_delegate UpdateStudentQuestionLevel:Level];
                [[self navigationController]popViewControllerAnimated:YES];
            }
            
        }else{
            if (![_type isEqualToString:@"Register"]) {
                [self.q_delegate UpdateStudentQuestionLevel:Level];
                [[self navigationController]popViewControllerAnimated:YES];
            }else{
                [self ScrollReset];
            }
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)RegisterChild
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"lessonlist":LessonSelectedIds.count > 0 ? [LessonSelectedIds componentsJoinedByString:@","] : @"",
                             @"Description":@"",
                             @"ChildStrongWilledValue":@"",
                             @"ChildSensitiveValue":@"",
                             @"ChildOutGoingValue":@"",
                             @"ChildStrongWilled":@"",
                             @"ChildSensitive":@"",
                             @"ChildOutGoing":@"",
                             @"chk1":@"false",
                             @"chk2":@"false",
                             @"chk3":@"false",
                             @"Swimgoals":@"",
                             @"levels":Level,
                             @"FName":[userDefault objectForKey:UD_REGISTER_F_NAME],
                             @"LName":[userDefault objectForKey:UD_REGISTER_L_NAME],
                             @"Dob":[userDefault objectForKey:UD_REGISTER_B_DATE],
                             @"Age":[age substringToIndex:[age length] - 1],
                             @"Gender":[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] firstObject],
                             @"InstructorNature":[[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] lastObject] isEqualToString:@"No Preference"] ? @"Any" : [[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] lastObject],
                             @"InstructorGender":[[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] objectAtIndex:1] isEqualToString:@"No Preference"] ? @"Any" : [[[[userDefault objectForKey:@"SDATA"] componentsSeparatedByString:@"|"] objectAtIndex:1] uppercaseString],
                             @"strYesNo1":@"",
                             @"strYesNo2":@"",
                             @"strallergiesmedical":_strMedical,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Register_Child_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"LAFitness"]boolValue])
            {
                if([age integerValue] < 3)
                {
                    [[[UIAlertView alloc]initWithTitle:@"WaterWorks" message:@"This facility is currently accepting students 3 years old and older. Please contact our office staff with any questions, or to locate your nearest facility accepting students younger than 3 years old." delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
                }
                else
                {
                    [self pushViewController];
                }
            }
            else
            {
                [self pushViewController];
            }
        }
        else
        {
            [CommonClass showToastMsg:[[[responseObject valueForKey:@"AddChildCount"]valueForKey:@"Msg"] firstObject]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self pushViewController];
}

-(void)pushViewController
{
    for (UIViewController*vc in [self.navigationController viewControllers])
    {
        if ([vc isKindOfClass: [ManageStudent class]])
        {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:2] animated:YES];
            return;
        }
    }
    
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ManageStudent *ms = [storyBoard instantiateViewControllerWithIdentifier:@"ManageStudent"];
    [[self navigationController]pushViewController:ms animated:YES];
}

#pragma mark - ACTIONS

-(void)ChangelblColor:(NSString *)substr :(UILabel *)lbl
{
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithAttributedString: lbl.attributedText];
    
    NSRange range = [lbl.text rangeOfString:substr options:NSCaseInsensitiveSearch];
    [text addAttribute:NSFontAttributeName
                 value:FONT_Bold(14)
                 range:range];
    [text addAttribute:NSForegroundColorAttributeName
                 value:[UIColor blackColor]
                 range:NSMakeRange(0, lbl.text.length)];
    [lbl setAttributedText: text];
}

-(void)CompleteLevel:(NSString *)level_no :(UIView *)view
{
    [lbl_level setText:[NSString stringWithFormat:@"Level %@ - ",level_no]];
    [CLview setHidden:NO];
    
    topSpace.constant = view.frame.origin.y + view.frame.size.height - 60.0f;
    [self AgeCalculation:level_no];
    
}

-(void)changeQuestion_showView:(UIView *)v :(int)cnt :(NSString *)ans hideView:(UIView *)hv :(NSLayoutConstraint *)constrain
{
    [((UILabel *)hv.subviews[1]) setText:[NSString stringWithFormat:@"Your answered : %@",ans]];;
    [((UILabel *)hv.subviews[0]) setTextColor:[UIColor lightGrayColor]];
    
    [self ChangelblColor:ans :((UILabel *)hv.subviews[1])];
    [self ChangeTextColor:[NSString stringWithFormat:@"Question #%d",cnt]: ((UILabel *)hv.subviews[0])];
    
    /*
     *---------------------------
     */
    
    CGSize expectedLabelSize = [((UILabel *)v.subviews[0]).text sizeWithFont:((UILabel *)v.subviews[0]).font constrainedToSize:CGSizeMake(v.frame.size.width - 30, CGFLOAT_MAX) lineBreakMode:NSLineBreakByWordWrapping]; // deprecated
    
    //CGRect expectedLabelSize = [((UILabel *)v.subviews[0]).text boundingRectWithSize:CGSizeMake(v.frame.size.width - 30, CGFLOAT_MAX)  options:NSStringDrawingUsesLineFragmentOrigin| NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:((UILabel *)v.subviews[0]).font} context:nil];

    CGFloat height = expectedLabelSize.height;
    
    if (v != nil)
    {
        [v setHidden:NO];
        //        if (startOver) {
        //            [v removeConstraint:[v.constraints lastObject]];
        //        }else{
        //            [v removeConstraint:[v.constraints firstObject]];
        //        }
        //        NSLayoutConstraint *HeightConstrain = [NSLayoutConstraint constraintWithItem:v attribute:NSLayoutAttributeHeight                               relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:height + 45];
        //        [v addConstraint:HeightConstrain];
        //        [v setNeedsUpdateConstraints];
        //        [v updateConstraintsIfNeeded];
        //        [v updateConstraints];
        //        [v setNeedsLayout];
        //        [v layoutIfNeeded];
        //        [v layoutSubviews];
        constrain.constant = height + 42;
    }
    
    /*
     *---------------------------
     */
    
    for (UIView *v in hv.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [v setHidden:YES];
        }
    }
    
    [scroll layoutIfNeeded];
    [scroll setContentSize:CGSizeMake(scroll.frame.size.width,v.frame.origin.y + v.frame.size.height + 20)];
    [scroll scrollRectToVisible:CGRectMake(scroll.contentSize.width - 1,scroll.contentSize.height - 1, 1, 1) animated:YES];
}

-(void)ChangeTextColor:(NSString *)substr :(UILabel *)lbl
{
    NSMutableAttributedString *text =
    [[NSMutableAttributedString alloc]
     initWithAttributedString: lbl.attributedText];
    
    NSRange range = [lbl.text rangeOfString:substr options:NSCaseInsensitiveSearch];
    NSRange range1 = [lbl.text rangeOfString:[NSString stringWithFormat:@"%@",[[[lbl.text componentsSeparatedByString:@"#"] lastObject] substringFromIndex:1]] options:NSCaseInsensitiveSearch];
    [text addAttribute:NSFontAttributeName
                 value:FONT_Bold(14)
                 range:range];
    [text addAttribute:NSForegroundColorAttributeName
                 value:[UIColor blackColor]
                 range:range];
    [text addAttribute:NSForegroundColorAttributeName
                 value:[UIColor lightGrayColor]
                 range:range1];
    [lbl setAttributedText: text];
}

-(void)addDynamicInstructorButton:(NSArray *)arr
{
    LessonIds = [arr mutableCopy];
    TypeViewHeight.constant = (arr.count * 35);
    
    for (UIView *v in TypeView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [v removeFromSuperview];
        }
    }
    
    for (int i = 0 ; i < arr.count ; i++)
    {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(6, i * 35, TypeView.frame.size.width - 12, 30)];
        [btn setTitle:[[arr objectAtIndex:i] valueForKey:@"LessionName"] forState:0];
        btn.backgroundColor = [UIColor clearColor];
        btn.titleLabel.font = FONT_OpenSans(14);
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"CheckInstructor"] forState:UIControlStateSelected];
        [btn setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:0];
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
        btn.tag = i;
        btn.selected = NO;
        [btn addTarget:self action:@selector(selectUnselectInstructor:) forControlEvents:UIControlEventTouchUpInside];
        [TypeView addSubview:btn];
        [LessonSelectedIds addObject:@""];
    }
    
    [self ScrollReset];
}

-(void)selectUnselectInstructor:(UIButton *)sender
{
    NSLog(@"%ld",(long)sender.tag);
    
    BOOL flag = sender.selected ? NO : YES;
    sender.selected = flag;
    
    if(flag)
    {
        if(![LessonSelectedIds containsObject:[[LessonIds objectAtIndex:sender.tag]valueForKey:@"LessionID"]])
        {
            [LessonSelectedIds replaceObjectAtIndex:sender.tag withObject:[[LessonIds objectAtIndex:sender.tag]valueForKey:@"LessionID"]];
        }
    }
    else
    {
        NSInteger idx = [LessonSelectedIds indexOfObject:[[LessonIds objectAtIndex:sender.tag]valueForKey:@"LessionID"]];
        [LessonSelectedIds replaceObjectAtIndex:idx withObject:@""];
    }
}

-(void)ScrollReset
{
    if (startOver) {
        [CLview removeConstraint:[CLview.constraints lastObject]];
    }else{
        [CLview removeConstraint:[CLview.constraints firstObject]];
    }
    
    CGFloat height = CLview.subviews[4].frame.origin.y + 150 + TypeViewHeight.constant; //145 = btn(45) + space(20) + lable
    
    NSLayoutConstraint *HeightConstrain = [NSLayoutConstraint constraintWithItem:CLview attribute:NSLayoutAttributeHeight                               relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:height];
    [CLview addConstraint:HeightConstrain];
    [CLview layoutIfNeeded];
    [CLview updateConstraints];
    
    [scroll layoutIfNeeded];
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width, topSpace.constant + height)];
    [scroll scrollRectToVisible:CGRectMake(scroll.contentSize.width - 1,scroll.contentSize.height - 1, 1, 1) animated:YES];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Button Actions

- (IBAction)onClickYesBtn:(UIButton *)sender
{
    if ([queCount isEqualToString:@"1"]) {
        queCount = @"2a";
        [lblQuq2 setText:[NSString stringWithFormat:@"Question #2\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #2" :lblQuq2];
        [self changeQuestion_showView:Qv2 :1 :@"Yes" hideView:Qv1:Qv2Height];//167
        
    } else if ([queCount isEqualToString:@"2a"]) {
        queCount = @"3a";
        [lblQuq3 setText:[NSString stringWithFormat:@"Question #3\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #3" :lblQuq3];
        [self changeQuestion_showView:Qv3 :2 :@"Yes" hideView:Qv2:Qv3Height];//166
        
    } else if ([queCount isEqualToString:@"3a"]) {
        queCount = @"4yes";
        [lblQuq4 setText:[NSString stringWithFormat:@"Question #4\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #4" :lblQuq4];
        [self changeQuestion_showView:Qv4 :3 :@"Yes" hideView:Qv3:Qv4Height];//166
        
    } else if ([queCount isEqualToString:@"4yes"]) {
        queCount = @"5";
        [self changeQuestion_showView:Qv5 :4 :@"Yes" hideView:Qv4:Qv5Height];//126
        
    } else if ([queCount isEqualToString:@"5"]) {
        queCount = @"6";
        [self changeQuestion_showView:Qv6 :5 :@"Yes" hideView:Qv5:Qv6Height];//148
        
    } else if ([queCount isEqualToString:@"6"]) {
        [self changeQuestion_showView:nil :6 :@"Yes" hideView:Qv6:nil];
        [self CompleteLevel:@"11" :Qv6];
        
    } else if ([queCount isEqualToString:@"2b"]) {
        queCount = @"2b";
        [lblQuq2 setText:[NSString stringWithFormat:@"Question #2\n\n%@",[dic valueForKey:queCount]]];
        [self changeQuestion_showView:nil :2 :@"Yes" hideView:Qv2:nil];
        [self ChangelblColor:@"Question #2" :lblQuq2];
        [self CompleteLevel:@"4" :Qv2];
        
    } else if ([queCount isEqualToString:@"3b"]) {
        queCount = @"3b";
        [lblQuq3 setText:[NSString stringWithFormat:@"Question #3\n\n%@",[dic valueForKey:queCount]]];
        [self changeQuestion_showView:nil :3 :@"Yes" hideView:Qv3:nil];
        [self ChangelblColor:@"Question #3" :lblQuq3];
        [self CompleteLevel:@"3" :Qv3];
        
    } else if ([queCount isEqualToString:@"4no"]) {
        [self changeQuestion_showView:nil :4 :@"Yes" hideView:Qv4:nil];
        [self ChangelblColor:@"Question #4" :lblQuq4];
        [self CompleteLevel:@"2" :Qv4];
    }
}

- (IBAction)onClickNoSureBtn:(UIButton *)sender
{
    if ([queCount isEqualToString:@"1"]) {
        queCount = @"2b";
        [lblQuq2 setText:[NSString stringWithFormat:@"Question #2\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #2" :lblQuq2];
        [self changeQuestion_showView:Qv2 :1 :@"No" hideView:Qv1:Qv2Height];
        
    } else if ([queCount isEqualToString:@"2b"]) {
        queCount = @"3b";
        [lblQuq3 setText:[NSString stringWithFormat:@"Question #3\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #3" :lblQuq3];
        [self changeQuestion_showView:Qv3 :2 :@"No" hideView:Qv2:Qv3Height];
        
    } else if ([queCount isEqualToString:@"3b"]) {
        queCount = @"4no";
        [lblQuq4 setText:[NSString stringWithFormat:@"Question #4\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #4" :lblQuq4];
        [self changeQuestion_showView:Qv4 :3 :@"No" hideView:Qv3:Qv4Height];
        
    } else if ([queCount isEqualToString:@"4no"]) {
        [self changeQuestion_showView:nil :4 :@"No" hideView:Qv4:nil];
        [self CompleteLevel:@"1" :Qv4];
        
    } else if ([queCount isEqualToString:@"2a"]) {
        queCount = @"2a";
        [lblQuq2 setText:[NSString stringWithFormat:@"Question #2\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #2" :lblQuq2];
        [self changeQuestion_showView:nil :2 :@"No" hideView:Qv2:nil];
        [self CompleteLevel:@"5" :Qv2];
        
    } else if ([queCount isEqualToString:@"3a"]) {
        queCount = @"3a";
        [lblQuq3 setText:[NSString stringWithFormat:@"Question #3\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #3" :lblQuq3];
        [self changeQuestion_showView:nil :3 :@"No" hideView:Qv3:nil];
        [self CompleteLevel:@"7" :Qv3];
        
    } else if ([queCount isEqualToString:@"4yes"]) {
        queCount = @"4yes";
        [lblQuq4 setText:[NSString stringWithFormat:@"Question #4\n\n%@",[dic valueForKey:queCount]]];
        [self ChangelblColor:@"Question #4" :lblQuq4];
        [self changeQuestion_showView:nil :4 :@"No" hideView:Qv4:nil];
        [self CompleteLevel:@"8" :Qv4];
        
    } else if ([queCount isEqualToString:@"5"]) {
        [self changeQuestion_showView:nil :5 :@"No" hideView:Qv5:nil];
        [self CompleteLevel:@"9" :Qv5];
        
    } else if ([queCount isEqualToString:@"6"]) {
        [self changeQuestion_showView:nil :6 :@"No" hideView:Qv6:nil];
        [self CompleteLevel:@"10" :Qv6];
    }
}

- (IBAction)onClickStartOverBtn:(id)sender
{
    startOver = YES;
    queCount = @"1";
    for (UIView *v in scroll.subviews)
    {
        if (![v isKindOfClass:[UILabel class]] && v.tag != 100)
        {
            [v setHidden:YES];
            //            [v removeConstraint:[v.constraints lastObject]];
            //            NSLayoutConstraint *HeightConstrain = [NSLayoutConstraint constraintWithItem:v attribute:NSLayoutAttributeHeight                               relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:0.0];
            //            [v addConstraint:HeightConstrain];
            //            [v updateConstraints];
            
            for (UIView *v1 in v.subviews)
            {
                [v1 setHidden:NO];
            }
        }
        else
        {
            [v setHidden:NO];
            for (UIView *v1 in v.subviews)
            {
                [v1 setHidden:NO];
                [((UILabel *)v.subviews[1])setText:@""];
            }
        }
    }
    
    [self ChangelblColor:@"Question #1" :lblQuq1];
    topSpace.constant = 0.0;
    
    [scroll layoutIfNeeded];
    [scroll setContentSize:CGSizeMake(self.view.frame.size.width, self.view.frame.size.height)];
    [scroll scrollRectToVisible:CGRectMake(scroll.contentSize.width - 1,scroll.contentSize.height - 1, 1, 1) animated:YES];
}

- (IBAction)onClickNextBtn:(id)sender
{
    //    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"LAFitness"]boolValue])
    //    {
    //        if(age < 3)
    //        {
    //            [CommonClass showAlertWithTitle:@"WaterWorks" andMessage:@"This facility is currently accepting students 3 years old and older. Please contact our office staff with any questions, or to locate your nearest facility accepting students younger than 3 years old." delegate:self];
    //        }
    //        else
    //        {
    [self RegisterChild];
    //        }
    //    }
}

/*- (IBAction)onClickNoSureBtn:(id)sender {
 
 btnNotSure.selected = YES;
 
 if ([btnYes isSelected] == YES) {
 if (queCount == 2) {
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:5];
 }
 }else if (queCount == 3){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:7];
 }
 }else if (queCount == 4){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:8];
 }
 }else if (queCount == 5){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:9];
 }
 }else if (queCount == 6){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:10];
 }
 }
 [self popViewController];
 return;
 }
 
 queCount++;
 if (queCount == 2) {
 lblTitleQue1.text = @"Question #2";
 lblQuq1.text = @"Can your child swim or kick half way across the pool(12.5 yards) without assistance by using side breathing or rolling from their stomach to their back?";
 }else if (queCount == 3){
 lblTitleQue1.text = @"Question #3";
 lblQuq3.hidden = NO;
 lblQuq1.hidden = YES;
 lblQuq4.hidden = YES;
 }else if (queCount == 4){
 lblTitleQue1.text = @"Question #4";
 lblQuq3.hidden = YES;
 lblQuq1.hidden = YES;
 lblQuq4.hidden = NO;
 }else{
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:1];
 }
 
 [self popViewController];
 }
 }*/

/*- (IBAction)onClickYesBtn:(id)sender {
 
 btnYes.selected = YES;
 
 if ([btnNotSure isSelected] == YES) {
 
 if (queCount == 2) {
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:4];
 }
 }else if (queCount == 3){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:3];
 }
 }else if (queCount == 4){
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:2];
 }
 }
 [self popViewController];
 return;
 }
 
 queCount++;
 if (queCount == 2) {
 lblTitleQue1.text = @"Question #2";
 lblQuq1.text = @"Is your child able to swim backstroke across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of the pool and without assistance?";
 }else if (queCount == 3){
 lblTitleQue1.text = @"Question #3";
 lblQuq1.hidden = YES;
 lblQuq5.hidden = NO;
 lblQuq5.text = @" Does your child know how to swim legal Breaststroke without any flutter kicks across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of pool and without assistance?";
 }else if (queCount == 4){
 lblTitleQue1.text = @"Question #4";
 lblQuq5.text = @"Does your child know how to swim legal Butterfly without any flutter kicks across the length (25 yards) of the pool by themselves without touching the bottom of the pool, the side of the pool and without assistance?";
 }else if (queCount == 5){
 lblTitleQue1.text = @"Question #5";
 lblQuq4.hidden = NO;
 lblQuq5.hidden = YES;
 lblQuq4.text = @"Does your child swim or have swum on a competitive swim team?";
 }else if (queCount == 6){
 lblTitleQue1.text = @"Question #6";
 lblQuq4.hidden = YES;
 lblQuq6.hidden = NO;
 }else{
 
 if (queDelegate &&[queDelegate respondsToSelector:@selector(setQuestionLavel:)]) {
 [queDelegate setQuestionLavel:11];
 }
 
 [self popViewController];
 }
 }*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
