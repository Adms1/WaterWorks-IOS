//
//  LessonView.m
//  WaterWorks
//
//  Created by Ankit on 21/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "AddPayment.h"
#import "AppDelegate.h"
#import "NIDropDown.h"
#import "CommonClass.h"

@interface AddPayment ()<NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSArray *arr_state;
    UITextField *txtfld;
    NSMutableDictionary *dicPaymentDetails;
}
@end

@implementation AddPayment

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getStateName];
    [self addToolBar];
    
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //                                             selector:@selector(keyboardWillShown:)
    //                                                 name:UIKeyboardWillShowNotification object:nil];
    //
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //                                             selector:@selector(keyboardWillBeHidden:)
    //                                                 name:UIKeyboardWillHideNotification object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksPaymentAccount :self :btnHome :nil :YES :self];
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    [self textfield:cardView :keyboardtoolBar];
    [self textfield:bankView :keyboardtoolBar];
}

-(void)textfield:(UIView *)view :(UIToolbar *)toolBar
{
    for (UIView *v in view.subviews)
    {
        if ([v isKindOfClass:[UITextField class]])
        {
            if (((UITextField *)v).keyboardType == UIKeyboardTypeNumberPad)
            {
                ((UITextField *)v).inputAccessoryView = toolBar;
            }
            ((UITextField *)v).attributedPlaceholder = [[NSAttributedString alloc] initWithString:((UITextField *)v).placeholder attributes:@{NSForegroundColorAttributeName: [UIColor clearColor]}];
            v.backgroundColor = [UIColor clearColor];
            v.layer.borderColor = [[UIColor lightGrayColor]CGColor];
            v.layer.borderWidth = 0.5f;
            ((UITextField *)v).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
            ((UITextField *)v).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
            ((UITextField *)v).leftViewMode = UITextFieldViewModeAlways;
            ((UITextField *)v).rightViewMode = UITextFieldViewModeAlways;
        }
    }
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [btnPayment setImageEdgeInsets:UIEdgeInsetsMake(0, btnPayment.frame.size.width - 20, 0, 0)];
    NSArray *arr = @[self.view.subviews[0],cardView,bankView];
    for (UIView *view in arr)
    {
        for (UIView *v in view.subviews)
        {
            if ([v isKindOfClass:[UIButton class]])
            {
                [((UIButton *)v) setImageEdgeInsets:UIEdgeInsetsMake(0, v.frame.size.width - 25, 0, 0)];
            }
        }
    }
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}

-(void)getStateName
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager POST:Get_StateList_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        arr_state = [[responseObject valueForKey:@"StateList"]valueForKey:@"State"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(IBAction)btnAddCreditCardDetails:(UIButton *)sender
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params;
    NSString *Weburl, *successMsg;
    if (sender.tag == 100)
    {
        if ([self CheckAccountValidation:cardView])
        {
            params = @{
                       @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                       @"SiteID":@"0",
                       @"ddlctype":[dicPaymentDetails valueForKey:@"0"],
                       @"txtfname":[[((NSString *)[dicPaymentDetails valueForKey:@"Card Name"]) componentsSeparatedByString:@" "]firstObject],
                       @"txtlname":[[((NSString *)[dicPaymentDetails valueForKey:@"Card Name"]) componentsSeparatedByString:@" "]lastObject],
                       @"CardNo":[dicPaymentDetails valueForKey:@"Card Number"],
                       @"txtcvv":[dicPaymentDetails valueForKey:@"CVV"],
                       @"txtaddress1":[dicPaymentDetails valueForKey:@"Address line 1"],
                       @"txtaddress2":[dicPaymentDetails valueForKey:@"Address line 2"],
                       @"txtcity":[dicPaymentDetails valueForKey:@"City"],
                       @"ddlexp1":[dicPaymentDetails valueForKey:@"1"],
                       @"ddlexp2":[dicPaymentDetails valueForKey:@"2"],
                       @"txtstate":[dicPaymentDetails valueForKey:@"3"],
                       @"txtzipcode":[dicPaymentDetails valueForKey:@"Zipcode"],
                       };
            Weburl = AddCardDetailsBySite_Url;
            successMsg = @"Card Details Added Successfully.";
        }else
            return;
    }
    else
    {
        if ([self CheckAccountValidation:bankView])
        {
            params = @{
                       @"Token":[[NSUserDefaults standardUserDefaults]valueForKey:TOKEN],
                       @"SiteID":@"0",
                       @"txtnameofcheck":[dicPaymentDetails valueForKey:@"Name on Account"],
                       @"txtrouting":[dicPaymentDetails valueForKey:@"Routing Number"],
                       @"txtaccno":[dicPaymentDetails valueForKey:@"Account Number"],
                       @"txtbankname":[dicPaymentDetails valueForKey:@"Bank Name"],
                       @"ddlAccountType":[dicPaymentDetails valueForKey:@"10"],
                       @"chkaddressline1":[dicPaymentDetails valueForKey:@"Address line 1"],
                       @"chkaddressline2":[dicPaymentDetails valueForKey:@"Address line 2"],
                       @"chkcity":[dicPaymentDetails valueForKey:@"City"],
                       @"chkstate":[dicPaymentDetails valueForKey:@"3"],
                       @"chkzip":[dicPaymentDetails valueForKey:@"Zipcode"],
                       };
            Weburl = AddACHDetailsBySite_Url;
            successMsg = @"Bank Details Added Successfully.";
            
        }else
            return;
    }
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"%@",responseObject);
        
        [CommonClass showToastMsg:successMsg];
        
        [[self navigationController]popViewControllerAnimated:YES];
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = txtfld.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [txtfld.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [txtfld resignFirstResponder];
        [((UIScrollView *)self.view.subviews[0]) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)self.view.subviews[0]) setScrollIndicatorInsets:UIEdgeInsetsZero];
        if (bankVHeight.constant > 0) {
            [((UIScrollView *)self.view.subviews[0]) scrollRectToVisible:CGRectOffset(bankView.subviews.lastObject.frame, 0, 100) animated:YES];
        }else{
            [((UIScrollView *)self.view.subviews[0]) scrollRectToVisible:CGRectOffset(cardView.subviews.lastObject.frame, 0, 100) animated:YES];
        }
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [((UIScrollView *)self.view.subviews[0]) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)self.view.subviews[0]) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)self.view.subviews[0]) setContentOffset:CGPointZero animated:YES];
    if (bankVHeight.constant > 0) {
        [((UIScrollView *)self.view.subviews[0])
         scrollRectToVisible:CGRectOffset(bankView.subviews.lastObject.frame, 0, 100) animated:YES];
    }else{
        [((UIScrollView *)self.view.subviews[0])
         scrollRectToVisible:CGRectOffset(cardView.subviews.lastObject.frame, 0, 100) animated:YES];
    }
    [self.view endEditing:YES];
}


-(IBAction)btnSelectType:(UIButton *)sender
{
    if(dropDown == nil) {
        CGFloat f = 80;
        NSArray *arr = @[@"Credit or Debit Card",@"Bank Account"];
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    [((UIScrollView *)self.view.subviews[0]) setScrollEnabled:YES];
    if (idx == 0) {
        [bankView setHidden:YES];
        [cardView setHidden:NO];
        [((UIScrollView *)self.view.subviews[0])setContentSize:CGSizeMake(((UIScrollView *)self.view.subviews[0]).frame.size.width, cardView.subviews.lastObject.frame.origin.y + cardView.subviews.lastObject.frame.size.height + 30 + 106.0)];
    }else{
        [cardView setHidden:YES];
        [bankView setHidden:NO];
        [((UIScrollView *)self.view.subviews[0])setContentSize:CGSizeMake(((UIScrollView *)self.view.subviews[0]).frame.size.width, bankView.subviews.lastObject.frame.origin.y + bankView.subviews.lastObject.frame.size.height + 30 + 106.0)];
    }
}
-(void)rel{
    dropDown = nil;
}

-(IBAction)btnSelect_CardType_Month_year_State:(UIButton *)sender
{
    sender.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    [self.view endEditing:YES];
    
    if(dropDown == nil) {
        CGFloat f = 250;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        NSString *yearString = [formatter stringFromDate:[NSDate date]];
        
        NSMutableArray *arr = [[NSMutableArray alloc]init];
        for(int i = 1 ; i <= 12 ;i++)
        {
            if (sender.tag == 0)
            {
                arr = @[@"Visa",@"American Express",@"Master Card",@"Discover"].mutableCopy;
            }
            else if (sender.tag == 1)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",i]];
            }
            else if (sender.tag == 2)
            {
                [arr addObject:[NSString stringWithFormat:@"%d",[yearString intValue]+i-1]];
            }
            else if (sender.tag == 3)
            {
                [self doneClicked:nil];
                arr = [arr_state mutableCopy];
            }
            else
            {
                arr = @[@"Checking"].mutableCopy;
            }
        }
        
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :sender.tag == 3 ? @"up" : @"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (BOOL)CheckAccountValidation:(UIView *)view
{
    [((UIScrollView *)txtfld.superview.superview) setContentOffset:CGPointZero animated:YES];
    
    for (UIView *v in view.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            if ([((UIButton *)v).titleLabel.text isEqualToString:@"Please select card type"])
            {
                v.layer.borderColor = [[UIColor redColor]CGColor];
                v.layer.borderWidth = 1.0f;
            }
        }
        else if ([v isKindOfClass:[UITextField class]])
        {
            if(((UITextField *)v).text.length == 0)
            {
                if ((view == cardView && v.tag != 4)||(view == bankView && v.tag != 5))
                {
                    v.layer.borderColor = [[UIColor redColor]CGColor];
                    v.layer.borderWidth = 1.0f;
                }
            }
        }
    }
    
    dicPaymentDetails = [[NSMutableDictionary alloc]init];
    for (UIView *v in view.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            if ([((UIButton *)v).titleLabel.text isEqualToString:@"Please select card type"])
            {
                [self doneClicked:nil];
                [[[UIAlertView alloc]initWithTitle:@"" message:@"Please select card type" delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
                return NO;
            }
            [dicPaymentDetails setObject:((UIButton *)v).titleLabel.text forKey:[NSString stringWithFormat:@"%ld",(long)v.tag]];
        }
        else if ([v isKindOfClass:[UITextField class]])
        {
            if(((UITextField *)v).text.length == 0)
            {
                if ((view == cardView && v.tag != 4)||(view == bankView && v.tag != 5))
                {
                    [[[UIAlertView alloc]initWithTitle:@"" message:[NSString stringWithFormat:@"Please Enter %@",((UITextField *)v).placeholder] delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
                    [((UITextField *)v) becomeFirstResponder];
                    return NO;
                }
            }
            [dicPaymentDetails setObject:((UITextField *)v).text forKey:((UITextField *)v).placeholder];
        }
    }
    return YES;
}


#pragma mark - Keyboard

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)txtfld.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = txtfld.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = txtfld.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:txtfld.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [((UIScrollView *)txtfld.superview.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    if (bankVHeight.constant > 0) {
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:CGRectOffset(bankView.subviews.lastObject.frame, 0, 100) animated:YES];
    }else{
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:CGRectOffset(cardView.subviews.lastObject.frame, 0, 100) animated:YES];
    }
}

#pragma mark - UITextField Delegate

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    txtfld = textField;
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    txtfld = textField;
    [textField becomeFirstResponder];
    textField.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    
    CGFloat compareValue = txtfld.frame.origin.y + 100;
    if(compareValue > (isiPhone5 ? 200 : 250)) {
        [((UIScrollView *)textField.superview.superview) setContentOffset:CGPointMake(0, compareValue - (isiPhone5 ? 200 : 250)) animated:YES];
    }
    else {
        [((UIScrollView *)textField.superview.superview) setContentOffset:CGPointZero animated:YES];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    txtfld = textField;
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [((UIScrollView *)textField.superview.superview) setContentInset:UIEdgeInsetsZero];
        [((UIScrollView *)textField.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
        [((UIScrollView *)textField.superview.superview) setContentOffset:CGPointZero animated:YES];
        if (bankVHeight.constant > 0) {
            [((UIScrollView *)textField.superview.superview) scrollRectToVisible:CGRectOffset(bankView.subviews.lastObject.frame, 0, 100) animated:YES];
        }else{
            [((UIScrollView *)textField.superview.superview) scrollRectToVisible:CGRectOffset(cardView.subviews.lastObject.frame, 0, 100) animated:YES];
        }
        return YES;
    }
    return NO;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((textField.tag == 1 || textField.tag == 2) && range.location > 15 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if ((textField.tag == 6 || textField.tag == 7) && range.location > 5 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if (textField.tag == 3 && range.location > 8 && textField.keyboardType == UIKeyboardTypeNumberPad)
    {
        return NO;
    }
    else if (textField.tag == 2 && range.location > 3 && textField.superview == cardView)
    {
        return NO;
    }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
