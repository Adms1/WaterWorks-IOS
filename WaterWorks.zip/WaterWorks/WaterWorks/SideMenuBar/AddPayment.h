//
//  AddPayment.h
//  WaterWorks
//
//  Created by Ankit on 21/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddPayment : UIViewController
{
    IBOutlet UIButton *btnHome,*btnPayment;
    IBOutlet UIView *cardView,*bankView;
    IBOutlet NSLayoutConstraint *cardVHeight,*bankVHeight;
}
@end
