//
//  ProgressReportDetails.m
//  WaterWorks
//
//  Created by Ankit on 20/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ProgressReportDetails.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "MyAccountCell.h"
#import "LessonView.h"

@interface ProgressReportDetails ()<CommonDelegate>
{
    NSArray *arr_Levels_skills,*arr_Skills;
    NSMutableArray *arr_temp;
}
@end

@implementation ProgressReportDetails

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tblSkills.estimatedRowHeight = 0.0f;
    tblSkills.rowHeight = UITableViewAutomaticDimension;
    
    tblLevels.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    tblLevels.layer.borderWidth = 0.5f;
    
    tblLevels.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    [lbl_studentName setText:[NSString stringWithFormat:@"%@ %@",[_studentArray valueForKey:@"SFirstName"],[_studentArray valueForKey:@"SLastName"]]];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksProgressReport :self :btnHome :nil :YES :self];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    if (progressView.subviews.count==0) {
        [self getStudentLevel];
    }
}

-(void)getStudentLevel
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"studentid":[_studentArray valueForKey:@"Studentid"],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetStudentLevelProgress_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        [self getStudentSkills];
        
        [lbl_level setText:[NSString stringWithFormat:@"Level %@",[responseObject valueForKey:@"LevelName"]]];
        
        [lbl_level_per setText:[NSString stringWithFormat:@"%@%% Complete",[responseObject valueForKey:@"Percentage"]]];
        
        [self makeProgressView : [responseObject valueForKey:@"TotalSkills"] : [responseObject valueForKey:@"StudentSkills"]];
        
        [self makeLevelview :[responseObject valueForKey:@"LevelName"]];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentSkills
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"studentid":[_studentArray valueForKey:@"Studentid"],
                             };
    
    [manager POST:GetStudentRemainingLevelprereq_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [lbl_level_skills setText:[[[responseObject valueForKey:@"Skills"] valueForKey:@"Skills"] componentsJoinedByString:@"\n"]];
        }
        
        [self getLevels_Skills];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getLevels_Skills
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"studentid":[_studentArray valueForKey:@"Studentid"],
                             };
    
    arr_temp = [[NSMutableArray alloc]init];
    
    [manager POST:GetStudentLevelprereq_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arr_Skills = [responseObject valueForKey:@"Skills"];
        }
        else{
            lbl_achievedSkills.text = [responseObject valueForKey:@"Msg"];
        }
        
        [tblSkills reloadData];
        tblSkillHeight.constant = arr_Skills.count > 0 ? (tblSkills.contentSize.height) : 20;
        
        [self getStudentLevels_Skills];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentLevels_Skills
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"studentid":[_studentArray valueForKey:@"Studentid"],
                             };
    
    arr_temp = [[NSMutableArray alloc]init];
    
    [manager POST:GetStudentPreviousLevelprereq_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
                
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            arr_Levels_skills = [responseObject valueForKey:@"StudentSkills"];
            
            [arr_Levels_skills enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [arr_temp addObject:[NSNumber numberWithBool:NO]];
            }];
        }
        
        [tblLevels reloadData];
        
        if (arr_Levels_skills.count > 0) {
            
            tblLevels.contentSize = [tblLevels sizeThatFits:CGSizeMake(CGRectGetWidth(tblLevels.bounds), CGFLOAT_MAX)];
            tblHeight.constant = tblLevels.contentSize.height;
            CGFloat height = tblHeight.constant + tblLevels.frame.origin.y;
            if (height < btnViewAllLevels.frame.origin.y + btnViewAllLevels.frame.size.height) {
                height = btnViewAllLevels.frame.origin.y + btnViewAllLevels.frame.size.height;
            }
            
            [scroll_main setContentSize:CGSizeMake(scroll_main.frame.size.width, height)];
        }else{
            [scroll_main setContentSize:CGSizeMake(scroll_main.frame.size.width, tblLevels.frame.origin.y + tblHeight.constant + 20)];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)makeProgressView :(NSString *)totalSkills :(NSString *)StudentSkills
{
    CGFloat width = progressView.frame.size.width/[totalSkills intValue];
    int filled_count = [StudentSkills intValue];
    
    for (int i = 0; i < [totalSkills intValue]; i++)
    {
        UIView *v = [[UIView alloc]initWithFrame:CGRectMake(i * width, 0, width, progressView.frame.size.height)];
        v.layer.borderColor = [[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0] CGColor];
        v.layer.borderWidth = 0.5f;
        [progressView addSubview:v];
        
        if (i < filled_count) {
            [v setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
            v.layer.borderColor = [[UIColor whiteColor] CGColor];
            v.layer.borderWidth = 0.5f;
        }
    }
}

-(void)makeLevelview :(NSString *)level
{
    if ([level isEqualToString:@"P1"] || [level isEqualToString:@"P2"] || [level isEqualToString:@"P3"] ) {
        level = @"1";
    }
    
    for (int i = 12; i > 0; i--)
    {
        UILabel *l = [[UILabel alloc]initWithFrame:CGRectMake(0, (12-i) * 25, levelView.frame.size.width, 20)];
        //        l.backgroundColor = [UIColor clearColor];
        if (i < [level intValue])
        {
            [l setBackgroundColor:[UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0]];
        }
        l.layer.borderColor = [[UIColor lightGrayColor]CGColor];
        l.layer.borderWidth = 0.5f;
        [l setText:[NSString stringWithFormat:@"%d",i]];
        [l setTextAlignment:NSTextAlignmentCenter];
        [l setFont:FONT_OpenSans(10)];
        [l setTextColor:[UIColor blackColor]];
        l.tag = i;
        [levelView addSubview:l];
    }
}

#pragma mark - TABLEVIEW DATASOURCE & DELEGATE

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == tblLevels) {
        return arr_Levels_skills.count;
    }return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == tblLevels) {
        if ([[arr_temp objectAtIndex:section] isEqual:[NSNumber numberWithBool:YES]]) {
            return ((NSArray *)[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:section]).count;
        }else{
            return 0;
        }
    }else{
        return arr_Skills.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return tableView == tblLevels ? 30 : 0;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView == tblLevels)
    {
        UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tblLevels.frame.size.width, 30)];
        headerView.backgroundColor = [UIColor whiteColor];
        headerView.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        headerView.layer.borderWidth = 0.5f;
        
        UILabel *lblSection = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 100, 20)];
        lblSection.textColor = [UIColor blackColor];
        [lblSection setText:[NSString stringWithFormat:@"Level %@", [[arr_Levels_skills objectAtIndex:section] valueForKey:@"Level"]]];
        lblSection.font = FONT_Bold(12);
        lblSection.textAlignment = NSTextAlignmentLeft;
        [headerView addSubview:lblSection];
        
        UIButton *btnArrow = [[UIButton alloc]initWithFrame:CGRectMake(tblLevels.frame.size.width - 15, 5, 10, 20)];
        btnArrow.backgroundColor = [UIColor clearColor];
        [btnArrow setTitleColor:[UIColor blackColor] forState:0];
        [btnArrow setTitle:@">" forState:0];
        if ([[arr_temp objectAtIndex:section] isEqual:[NSNumber numberWithBool:NO]]) {
            [btnArrow setTransform: CGAffineTransformIdentity];
        }else{
            [btnArrow setTransform: CGAffineTransformMakeRotation(M_PI_2)];
        }
        btnArrow.titleLabel.font = FONT_Bold(13);
        [headerView addSubview:btnArrow];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        headerView.tag = section;
        [headerView setUserInteractionEnabled:YES];
        [headerView addGestureRecognizer:tap];
        
        return headerView;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str;
    if (tableView == tblLevels)
    {
        str = [CommonClass stringByStrippingHTML: [[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]valueForKey:@"SkillsData"]];
        return [self getDynamicHeightOflbl:str].height+5;
    }
    else
    {
        NSDictionary *dic = [arr_Skills objectAtIndex:indexPath.row];
        str = [CommonClass stringByStrippingHTML:[NSString stringWithFormat:@"%@ %@",dic[@"Skill No"],dic[@"Skills"]]];
        return [self getDynamicHeightOflbl:str].height;
    }
    //return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    MyAccountCell *maCell = (MyAccountCell *)[tableView dequeueReusableCellWithIdentifier:@"MyAccountCell" forIndexPath:indexPath];
    maCell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (tableView == tblLevels)
    {
        if (indexPath.row == 0)
        {
            maCell.lbl_ldate.text = [[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row] valueForKey:@"SkillDate"];
        }
        else
        {
            if (indexPath.row < [tblLevels numberOfRowsInSection:indexPath.section]-1)
            {
                if ([[[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row-1] valueForKey:@"SkillDate"] isEqualToString:[[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row] valueForKey:@"SkillDate"]])
                {
                    maCell.lbl_ldate.text = @"";
                }
                else
                {
                    maCell.lbl_ldate.text = [[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row] valueForKey:@"SkillDate"];
                    NSLog(@"%@",maCell.lbl_ldate.text);
                }
            }
        }
        maCell.lbl_skills.attributedText = [self stringHTML: [[[[arr_Levels_skills valueForKey:@"Skills"]objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]valueForKey:@"SkillsData"]];
        
    }
    else
    {
        NSDictionary *dic = [arr_Skills objectAtIndex:indexPath.row];
        maCell.lbl_ldate.text = dic[@"Date"];
        maCell.lbl_skills.text = [NSString stringWithFormat:@"%@ %@",dic[@"Skill No"],dic[@"Skills"]];
    }
    return maCell;
}

-(void)tap:(UITapGestureRecognizer *)gesture
{
    BOOL flag = [[arr_temp objectAtIndex:gesture.view.tag]boolValue];
    [arr_temp replaceObjectAtIndex:gesture.view.tag withObject:[NSNumber numberWithBool:!flag]];
    
    NSIndexSet *section = [NSIndexSet indexSetWithIndex:gesture.view.tag];
    [tblLevels beginUpdates];
    [tblLevels reloadSections:section withRowAnimation:UITableViewRowAnimationFade];
    [tblLevels endUpdates];
    
    tblLevels.contentSize = [tblLevels sizeThatFits:CGSizeMake(CGRectGetWidth(tblLevels.bounds), CGFLOAT_MAX)];
    NSLog(@"%f", tblLevels.contentSize.height);
    
    tblHeight.constant = tblLevels.contentSize.height;
    CGFloat height = tblHeight.constant + tblLevels.frame.origin.y;
    if (height < btnViewAllLevels.frame.origin.y + btnViewAllLevels.frame.size.height) {
        height = btnViewAllLevels.frame.origin.y + btnViewAllLevels.frame.size.height;
    }
    [scroll_main setContentSize:CGSizeMake(scroll_main.frame.size.width, height)];
}

-(CGSize )getDynamicHeightOflbl:(NSString *)str
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:str attributes:@ {NSFontAttributeName:FONT_OpenSans(12) }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.view.frame.size.width - 189, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize size = rect.size;
    return size;
}

-(void)popViewController
{
    [[self navigationController]popViewControllerAnimated:YES];
}
- (IBAction)onClickViewAllLevel:(id)sender {
    
    LessonView *lv = [self.storyboard instantiateViewControllerWithIdentifier:@"LessonView"];
    [[self navigationController]pushViewController:lv animated:YES];
}

-(NSAttributedString *)stringHTML :(NSString *)str
{
    NSAttributedString * attrStr = [[NSAttributedString alloc] initWithData:[str dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    NSRange range = (NSRange){0,[attrStr length]};
    NSMutableAttributedString *newString = [[NSMutableAttributedString alloc] initWithAttributedString:attrStr];
    [newString enumerateAttribute:NSFontAttributeName inRange:range options:NSAttributedStringEnumerationLongestEffectiveRangeNotRequired usingBlock:^(id value, NSRange range, BOOL *stop) {
        UIFont* currentFont = value;
        UIFont *replacementFont = nil;
        
        if ([currentFont.fontName rangeOfString:@"bold" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            replacementFont = FONT_Bold(12);
        } else {
            replacementFont = FONT_OpenSans(12);
        }
        [newString addAttribute:NSFontAttributeName value:replacementFont range:range];
    }];
    return newString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
