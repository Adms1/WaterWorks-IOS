//
//  HelpViewController.m
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "HelpViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "SelectLocationViewController.h"
#import "PolicyViewController.h"

@interface HelpViewController ()<LocationDelegate>

@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    subView.layer.borderColor = [UIColor blackColor].CGColor;
    subView.layer.borderWidth = 1.0f;
    
    [lblVersion setText:[NSString stringWithFormat:@"Client %@",AppVersion]];
}

- (void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksHelp_Support :self :btnHome :nil :NO :nil];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    viewHeight.constant = subView.subviews.lastObject.frame.origin.y + subView.subviews.lastObject.frame.size.height + 5;
    
    for (UIView *v in subView.subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            [((UIButton *)v)setImageEdgeInsets:UIEdgeInsetsMake(0, v.frame.size.width - 20, 0, 0)];
        }
    }
}
-(IBAction)btnClicked:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",Call]];
        
        if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
            [[UIApplication sharedApplication] openURL:phoneUrl];
        }
        else
        {
            [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Call facility is not available!!!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
        }
    }
    else if (sender.tag == 1)
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:Link]];
    }
    else
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        PolicyViewController *pvc = [storyBoard instantiateViewControllerWithIdentifier:@"PolicyViewController"];
        if (sender.tag == 2) {
            pvc.strType = @"Waterworks Privacy Policy";
        }else{
            pvc.strType = @"Waterworks Terms Of Use";
        }
        [[self navigationController]pushViewController:pvc animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
