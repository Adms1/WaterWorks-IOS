//
//  ReportViewController.m
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SendViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "SelectLocationViewController.h"
#import "NIDropDown.h"

@interface SendViewController ()<LocationDelegate,NIDropDownDelegate,CommonDelegate>
{
    NIDropDown *dropDown;
    NSMutableArray *arrLocationList;
    NSString *strSiteID, *strSiteName, *strDepId, *strDepName;
    NSArray *array;
    NSMutableDictionary *dic;
    BOOL check;
    UITextField *activeField;
}
@end

@implementation SendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UITextView class]] || [v isKindOfClass:[UITextField class]])
        {
            v.layer.borderColor = [UIColor lightGrayColor].CGColor;
            v.layer.borderWidth = 0.5f;
        }
        else if ([v isKindOfClass:[UILabel class]])
        {
            NSMutableAttributedString *text =
            [[NSMutableAttributedString alloc]
             initWithAttributedString: ((UILabel *)v).attributedText];
            NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 1] options:NSCaseInsensitiveSearch];
            [text addAttribute:NSForegroundColorAttributeName
                         value:[UIColor redColor]
                         range:range];
            [((UILabel *)v) setAttributedText:text];
        }
    }
    
    for (UIView *v in viewRequest.subviews)
    {
        if ([v isKindOfClass:[UITextField class]])
        {
            v.layer.borderColor = [UIColor lightGrayColor].CGColor;
            v.layer.borderWidth = 0.5f;
        }
    }
    
    array = @[@"Front Desk",@"Maintenance",@"Management",@"Accounting"];
    [[self.view.subviews[0] viewWithTag:200] setTitle:[array objectAtIndex:0] forState:UIControlStateNormal];
    strDepId = @"1";
    strDepName = [array objectAtIndex:0];
    
    [CommonClass getSiteByFamily:^(BOOL flag, NSDictionary *responseObject) {
        if (flag) {
            arrLocationList = [responseObject safeObjectForKey:@"SiteList"];
            
            if (arrLocationList.count == 1)
            {
                NSDictionary *objLocation = [arrLocationList objectAtIndex:0];
                NSString *strTitle = [NSString stringWithFormat:@"%@",objLocation[@"sitename"]];
                NSString *strLocationID = [NSString stringWithFormat:@"%@",objLocation[@"siteid"]];
                
                NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                
                [userDefault setObject:strLocationID forKey:SITEID];
                
                strSiteID = strLocationID;
                strSiteName = strTitle;
                
                [btnLocation setTitle:strSiteName forState:0];
                
            }
        }
    }];
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksSendMessage :self :btnHome :nil :YES :self];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UIButton class]] && v.tag != 1000)
        {
            [((UIButton *)v)setImageEdgeInsets:UIEdgeInsetsMake(0, v.frame.size.width - 25, 0, 0)];
        }
    }
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnCheck:(UIButton *)sender
{
    check = sender.selected = !sender.selected;
    [UIView animateWithDuration:0.5f animations:^{
        viewHeight.constant = sender.selected ? ([[viewRequest subviews]lastObject].frame.origin.y + [[viewRequest subviews]lastObject].frame.size.height) : 0;
        [self.view layoutIfNeeded];
        
    }completion:^(BOOL finished){
        [viewRequest setHidden:sender.selected ? NO : YES];
    }];
}

- (IBAction)onClickSelectLocationBtn:(UIButton *)sender {
    
    [self.view.subviews[0] viewWithTag:-2].layer.borderColor = [UIColor lightGrayColor].CGColor;
    [self.view.subviews[0] viewWithTag:-2].layer.borderWidth = 0.5f;
    
    if ([arrLocationList count] > 1) {
        [CommonClass setLocation:arrLocationList :btnLocation :sender :self];
    }
}
-(void)performAction:(NSInteger)idx :(UIButton *)btn
{
    strSiteID = [[arrLocationList valueForKey:@"siteid"] objectAtIndex:idx];
    strSiteName = [[arrLocationList valueForKey:@"sitename"] objectAtIndex:idx];
}

- (IBAction)onClickSelectDepartMentBtn:(UIButton *)sender
{
    if(dropDown == nil) {
        CGFloat f = 150;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :array :nil :@"down"];
        dropDown.tag = 1000;
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}
- (void)select:(UIButton *)sender :(NSInteger) idx
{
    strDepName = [array objectAtIndex:idx];
    strDepId = [NSString stringWithFormat:@"%lu",(unsigned long)idx+1];
}
-(void)rel{
    dropDown = nil;
}

-(IBAction)btnSendMessage:(UIButton *)sender
{
    if ([self Validation])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        NSDictionary *params = @{
                                 @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                                 @"problemDetails":[dic valueForKey:@"4"],
                                 @"DeptValue":strDepId,
                                 @"Sitename":strSiteName,
                                 @"callback":[dic valueForKey:@"6"] == nil ? @"" : [dic valueForKey:@"6"],
                                 @"Email":[dic valueForKey:@"2"],
                                 @"phone2":@"",
                                 @"sitevalue":strSiteID,
                                 @"DeptName":strDepName,
                                 @"lastname":[dic valueForKey:@"1"],
                                 @"subject":[dic valueForKey:@"3"],
                                 @"firstname":[dic valueForKey:@"1"],
                                 @"phone1":[dic valueForKey:@"5"] == nil ? @"" : [dic valueForKey:@"5"],
                                 };
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [manager POST:SendMail_ContactByFamily_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"RESPONSE %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                [CommonClass showToastMsg:MessageSent];
                
                [[self navigationController]popViewControllerAnimated:YES];
            }
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(BOOL)Validation
{
    BOOL flag = YES;
    [((UIScrollView *)self.view.subviews[0]) setContentOffset:CGPointZero animated:YES];
    
    dic = [[NSMutableDictionary alloc]init];
    if (strSiteID == nil)
    {
        [self.view.subviews[0] viewWithTag:-2].layer.borderColor = [UIColor redColor].CGColor;
        [self.view.subviews[0] viewWithTag:-2].layer.borderWidth = 1.f;
        flag = NO;
    }
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UITextView class]] || [v isKindOfClass:[UITextField class]])
        {
            [((UITextView *)v).text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            [((UITextField *)v).text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            
            if (([((UITextField *)v).text isEqualToString:@""] || [((UITextView *)v).text isEqualToString:@""]) && v.tag != -1 && v.tag != -2) {
                
                v.layer.borderColor = [UIColor redColor].CGColor;
                v.layer.borderWidth = 1.0f;
                flag = NO;
            }
            else if ((v.tag == 2 && ![CommonClass textIsValidEmailFormat:((UITextField *)v).text]))
            {
                v.layer.borderColor = [UIColor redColor].CGColor;
                v.layer.borderWidth = 1.0f;
                [CommonClass showToastMsg:InvalidEmail];
                return NO;
            }
            else
            {
                [dic setObject:((UITextField *)v).text forKey:[NSString stringWithFormat:@"%ld",(long)((UITextField *)v).tag]];
                [dic setObject:((UITextView *)v).text forKey:@"4"];
            }
        }
    }
    if (check)
    {
        for (UIView *v in viewRequest.subviews)
        {
            if ([v isKindOfClass:[UITextField class]])
            {
                if ([((UITextField *)v).text isEqualToString:@""])
                {
                    v.layer.borderColor = [UIColor redColor].CGColor;
                    v.layer.borderWidth = 1.0f;
                    flag = NO;
                }
                else
                {
                    [dic setObject:((UITextField *)v).text forKey:[NSString stringWithFormat:@"%ld",(long)((UITextField *)v).tag]];
                }
            }
        }
    }
    if (!flag) {
        [CommonClass showToastMsg:FieldValidation];
    }
    return flag;
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)activeField.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)activeField.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)activeField.superview.superview) scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [((UIScrollView *)activeField.superview.superview) setContentOffset:CGPointZero animated:YES];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    activeField = textField;
    if (activeField.keyboardType == UIKeyboardTypeNumberPad) {
        [self addToolBar];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.keyboardType == UIKeyboardTypeNumberPad) {
        return [CommonClass Textfield:textField :range];
    }return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [((UIScrollView *)textField.superview.superview) setContentOffset:CGPointZero animated:YES];
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - UITextView Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView;
{
    [((UIScrollView *)textView.superview)setContentOffset:CGPointMake(0, textView.frame.origin.y - textView.frame.size.height) animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    textView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        if (check) {
            [[viewRequest viewWithTag:5]becomeFirstResponder];
        }
    }
    return YES;
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    activeField.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = activeField.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [activeField.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [activeField.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self resignFirstResponder];
        [((UIScrollView *)activeField.superview.superview) setContentOffset:CGPointZero animated:YES];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [((UIScrollView *)activeField.superview.superview) setContentOffset:CGPointZero animated:YES];
    [activeField.superview endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
