//
//  HelpViewController.h
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface HelpViewController : MasterViewController
{
    IBOutlet UIButton *btnHome;
    IBOutlet UIView *subView;
    IBOutlet UILabel *lblVersion;
    IBOutlet NSLayoutConstraint *viewHeight;
}
@end
