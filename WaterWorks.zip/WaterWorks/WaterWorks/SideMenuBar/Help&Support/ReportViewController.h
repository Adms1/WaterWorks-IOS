//
//  ReportViewController.h
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReportViewController : UIViewController
{
    IBOutlet UIButton *btnHome;
}
@end
