//
//  ReportViewController.m
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "ReportViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface ReportViewController ()<CommonDelegate>
{
    UITextView *txtView;
    NSMutableDictionary *dic;
}
@end

@implementation ReportViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if (![v isKindOfClass:[UILabel class]])
        {
            v.layer.borderColor = [UIColor lightGrayColor].CGColor;
            v.layer.borderWidth = 0.5f;
        }
        else
        {
            if(v.tag == 1)
            {
                NSMutableAttributedString *text =
                [[NSMutableAttributedString alloc]
                 initWithAttributedString: ((UILabel *)v).attributedText];
                NSRange range = [((UILabel *)v).text rangeOfString:[((UILabel *)v).text substringFromIndex:[((UILabel *)v).text length] - 1] options:NSCaseInsensitiveSearch];
                [text addAttribute:NSForegroundColorAttributeName
                             value:[UIColor redColor]
                             range:range];
                [((UILabel *)v) setAttributedText:text];
            }
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [CommonClass setNavigationTitle:NavigationWaterWorksReportBug :self :btnHome :nil :YES :self];
}

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITextView Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView;
{
    [textView becomeFirstResponder];
    [((UIScrollView *)textView.superview)setContentOffset:CGPointMake(0, textView.frame.origin.y - textView.frame.size.height) animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    textView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    textView.layer.borderWidth = 0.5f;
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        if (textView.tag == 2) {
            [[self.view.subviews[0] viewWithTag:3]becomeFirstResponder];
        }else if(textView.tag == 3){
            [((UIScrollView *)textView.superview)setContentOffset:CGPointZero animated:YES];
        }
        return NO;
    }
    return YES;
}

-(IBAction)btnSendReport:(UIButton *)sender
{
    if ([self Validation])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        NSDictionary *params = @{
                                 @"Token":[[NSUserDefaults standardUserDefaults] valueForKey:TOKEN],
                                 @"subjectline":[dic valueForKey:@"1"],
                                 @"Type":@"2",
                                 @"Description":[dic valueForKey:@"2"],
                                 @"StepReproduce":[dic valueForKey:@"3"],
                                 };
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [manager POST:SendMail_Help_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"RESPONSE %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                [SHARED_APPDELEGATE hideLoadingView];
                
                [CommonClass showToastMsg:BugReportSent];
                
                [[self navigationController]popViewControllerAnimated:YES];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(BOOL)Validation
{
    BOOL flag = YES;
    [((UIScrollView *)self.view.subviews[0]) setContentOffset:CGPointZero animated:YES];
    dic = [[NSMutableDictionary alloc]init];
    for (UIView *v in self.view.subviews[0].subviews)
    {
        if ([v isKindOfClass:[UITextView class]] || [v isKindOfClass:[UITextField class]])
        {
            [((UITextView *)v).text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            [((UITextField *)v).text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            
            if ([((UITextView *)v).text isEqualToString:@""]||[((UITextField *)v).text isEqualToString:@""]) {
                
                v.layer.borderColor = [UIColor redColor].CGColor;
                v.layer.borderWidth = 1.0f;
                flag = NO;
            }
            else
            {
                [dic setObject:((UITextView *)v).text forKey:[NSString stringWithFormat:@"%ld",(long)((UITextView *)v).tag]];
                [dic setObject:((UITextField *)v).text forKey:@"1"];
            }
        }
    }
    if (!flag) {
        [CommonClass showToastMsg:FieldValidation];
    }
    return flag;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.layer.borderColor = [UIColor lightGrayColor].CGColor;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [[self.view.subviews[0] viewWithTag:2]becomeFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
