//
//  SendViewController.h
//  WaterWorks
//
//  Created by Ankit on 20/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendViewController : UIViewController
{
    IBOutlet UIView *viewRequest;
    IBOutlet UIButton *btnHome;
    IBOutlet NSLayoutConstraint *viewHeight;
    IBOutlet UIButton *btnLocation;
}
@end
