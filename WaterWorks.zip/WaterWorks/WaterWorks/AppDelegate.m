//
//  AppDelegate.m
//  WaterWorks
//
//  Created by Sweta Sheth on JANUARY - 2017
//  Copyright © 2016 Darshan. All rights reserved.

#import "AppDelegate.h"
#import "CommonClass.h"
#import "LoginViewController.h"
#import "SplaceScreen.h"
#import "MyScheduleViewController.h"
#import "SLViewController.h"
#import "BuyLessonsViewController.h"

@interface AppDelegate ()
{
    NSDateFormatter *dateFormatter;
}
@end

@implementation AppDelegate

@synthesize window;
@synthesize navigation;

+(AppDelegate*)sharedAppDelegate
{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [self setAppProperty];
    
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:REMEMBERME] isEqualToString:@"YES"]) {
        [self setSplaceViewController];
    }else{
        [self setLoginViewController];
    }
    return YES;
}




//- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
//{
//    if(self.restrictRotation)
//        return UIInterfaceOrientationMaskLandscape;
//    else
//        return UIInterfaceOrientationMaskAll;
//}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    NSLog(@"%d......%d",_min,_sec);
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    
    [[UIApplication sharedApplication] endBackgroundTask:UIBackgroundTaskInvalid];
    
    if ([[NSUserDefaults standardUserDefaults]valueForKey:@"StartTime"] != nil)
    {
        NSDateFormatter *dateFormatter1=[NSDateFormatter new];
        [dateFormatter1 setDateFormat:@"hh:mm:ss a"];
        
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"hh:mm:ss a"];
        NSDate *date1 = [df dateFromString:[[NSUserDefaults standardUserDefaults]valueForKey:@"StartTime"]];
        NSDate *date2 = [df dateFromString:[dateFormatter1 stringFromDate:[NSDate date]]];
        NSTimeInterval interval = [date2 timeIntervalSinceDate:date1];
        int diff = (int)interval;
        int min = 0;
        while (diff-60 > 0)
        {
            min++;
            diff = (int)diff-60;
        }
        NSLog(@"%d............%d",min,diff);
        _min = (int)_min - min;
        _sec = (int)_sec - diff;
    }
    
    dateFormatter = [NSDateFormatter new];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    NSLog(@"Saved Date....%@",[[NSUserDefaults standardUserDefaults]valueForKey:TODAY]);
    NSLog(@"Today's Date....%@",[dateFormatter stringFromDate:[NSDate date]]);
    
    if (![[[NSUserDefaults standardUserDefaults]valueForKey:TODAY]isEqualToString:[dateFormatter stringFromDate:[NSDate date]]] && [[NSUserDefaults standardUserDefaults]valueForKey:LOGCOUNT] != nil)
    {
        [self LoginAgain];
    }
}

-(void)LoginAgain
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[defaults valueForKey:WU_PRIMARYEMAIL] forKey:@"username"];
    [params setObject:[defaults valueForKey:WU_PASSWORD] forKey:@"password"];
    
    [manager POST:login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"LoginDtl"];
            
            if ([arrLogin count] > 0)
            {
                NSDictionary *dict = [arrLogin firstObject];
                [defaults setObject:[dict safeObjectForKey:@"Token"] forKey:TOKEN];
                [defaults setObject:[dateFormatter stringFromDate:[NSDate date]] forKey:TODAY];
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:BASKETID];
}

#pragma mark -
#pragma mark - LoginViewController Method

-(void)setSplaceViewController
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SplaceScreen *ss = [storyBoard instantiateViewControllerWithIdentifier:@"SplaceScreen"];
    navigation = [[UINavigationController alloc] initWithRootViewController:ss];
    [navigation setNavigationBarHidden:YES];
    window.rootViewController = navigation;
    
    [window makeKeyWindow];
    [window makeKeyAndVisible];
}

-(void)setLoginViewController
{
    LoginViewController *viewLogin = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    navigation = [[UINavigationController alloc] initWithRootViewController:viewLogin];
    window.rootViewController = navigation;
    
    [window makeKeyWindow];
    [window makeKeyAndVisible];
}

-(void)setHomeViewController
{
    HomeViewController *viewHome = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    navigation = [[UINavigationController alloc] initWithRootViewController:viewHome];
    [navigation setNavigationBarHidden:NO];
    window.rootViewController = navigation;
    
    [window makeKeyWindow];
    [window makeKeyAndVisible];
}

-(void)setScheduleViewController
{
    HomeViewController *viewHome = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    navigation = [[UINavigationController alloc] initWithRootViewController:viewHome];
    [navigation setNavigationBarHidden:NO];
    window.rootViewController = navigation;
    
    SLViewController *slvc = [[SLViewController alloc] initWithNibName:@"SLViewController" bundle:nil];
    [navigation pushViewController:slvc animated:YES];
}

-(void)setBuyLessonViewController
{
    HomeViewController *viewHome = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    navigation = [[UINavigationController alloc] initWithRootViewController:viewHome];
    [navigation setNavigationBarHidden:NO];
    window.rootViewController = navigation;
    
    BuyLessonsViewController *buyvc = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
    buyvc.strType = @"Buy";
    buyvc.FromComfirmSchedule = NO;
    SHARED_APPDELEGATE.isFromPrograms = SHARED_APPDELEGATE.isFromSwim = NO;
    [navigation pushViewController:buyvc animated:YES];
}

-(void)setMyScheduleViewController
{
    HomeViewController *viewHome = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:nil];
    navigation = [[UINavigationController alloc] initWithRootViewController:viewHome];
    [navigation setNavigationBarHidden:NO];
    window.rootViewController = navigation;
    
    MyScheduleViewController *msvc = [[MyScheduleViewController alloc] initWithNibName:@"MyScheduleViewController" bundle:nil];
    [navigation pushViewController:msvc animated:YES];
}

#pragma mark -
#pragma mark - TextField Padding Method

-(UIView*)getTextFieldLeftAndRightView
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(30, 0, 10, 10)];
    return paddingView;
}

#pragma mark -
#pragma mark - Loading View

-(void)showLoadingView
{
    if (loadView == nil)
    {
        loadView = [[UIView alloc] initWithFrame:self.window.frame];
        loadView.opaque = NO;
        loadView.backgroundColor = [UIColor clearColor];
        //loadView.alpha = 0.7f;
        
        viewBack = [[UIView alloc] initWithFrame:CGRectMake(80, 230, 160, 50)];
        viewBack.backgroundColor = [UIColor blackColor];
        viewBack.alpha = 0.7f;
        viewBack.layer.masksToBounds = NO;
        viewBack.layer.cornerRadius = 5;
        
        lblLoading = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, 110, 50)];
        lblLoading.backgroundColor = [UIColor clearColor];
        lblLoading.textAlignment = NSTextAlignmentCenter;
        lblLoading.text = @"Please Wait...";
        lblLoading.numberOfLines = 2;
        
        spinningWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5.0, 10.0, 30.0, 30.0)];
        spinningWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        lblLoading.textColor = [UIColor whiteColor];
        [spinningWheel startAnimating];
        [viewBack addSubview:spinningWheel];
        
        [viewBack addSubview:lblLoading];
        [loadView addSubview:viewBack];
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            
            float y = (loadView.frame.size.height/2 ) - (viewBack.frame.size.height/2);
            float x =(loadView.frame.size.width/2 ) - (viewBack.frame.size.width/2);
            viewBack.frame = CGRectMake(x , y, 160, 50);;
        }
        else{
            
            float y = (loadView.frame.size.height/2 ) - (viewBack.frame.size.height/2);
            float x =(loadView.frame.size.width/2 ) - (viewBack.frame.size.width/2);
            viewBack.frame = CGRectMake(x , y, 160, 50);;
        }
    }
    if(loadView.superview == nil)
        [self.window addSubview:loadView];
}

-(void) hideLoadingView
{
    [loadView removeFromSuperview];
    loadView=nil;
}

#pragma mark -
#pragma mark - Left NavigationTitle

-(UILabel *)getNavigationWithTitle:(NSString *)title fontSize:(int)size
{
    UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, SHARED_APPDELEGATE.window.frame.size.width, 35)];
    lblTitle.font = FONT_OpenSans(size);
    lblTitle.text = title;
    lblTitle.textAlignment = NSTextAlignmentLeft;
    lblTitle.textColor =[UIColor whiteColor];
    return lblTitle;
}

#pragma mark -
#pragma mark - Center NavigationTitle

-(UILabel *)getNavigationCenterWithTitle:(NSString *)title fontSize:(int)size
{
    UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, SHARED_APPDELEGATE.window.frame.size.width, 35)];
    lblTitle.font = FONT_OpenSans(size);
    lblTitle.text = title;
    lblTitle.textAlignment = NSTextAlignmentLeft;
    lblTitle.textColor =[UIColor whiteColor];
    return lblTitle;
}

-(UILabel *)getNavigationWithScheduleTitle:(NSString *)title fontSize:(int)size
{
    UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, SHARED_APPDELEGATE.window.frame.size.width, 35)];
    lblTitle.font = FONT_OpenSans(size);
    lblTitle.text = title;
    lblTitle.textAlignment = NSTextAlignmentLeft;
    lblTitle.textColor =[UIColor whiteColor];
    return lblTitle;
}
#pragma mark -
#pragma mark - NavigationBarColor

-(void)setAppProperty
{
    [[UIBarButtonItem appearance] setTintColor:[UIColor whiteColor]];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [[UINavigationBar appearance]setBackgroundImage:[self imageFromColor:navColor] forBarMetrics:UIBarMetricsDefault];
}

-(UIImage *)imageFromColor:(UIColor *)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
