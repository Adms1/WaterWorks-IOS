//
//  SplaceScreen.m
//  WaterWorks
//
//  Created by Ankit on 03/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SplaceScreen.h"
#import "LegalDocViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface SplaceScreen ()
{
    BOOL LegalDocFlag;
}
@end

@implementation SplaceScreen

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setNeedsStatusBarAppearanceUpdate];
    [self IsLAFitness_Check_Login];
}

-(void)IsLAFitness_Check_Login
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:IsLAFitness_Check_Login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"IsLaFitness"] :@"1"]) {
            
            [self LegDoc_Update_StudentDocStatus];
        }
        else{
            [SHARED_APPDELEGATE setHomeViewController];
            [SHARED_APPDELEGATE hideLoadingView];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Update_StudentDocStatus
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [manager POST:LegDoc_Update_StudentDocStatus_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self LegDoc_Check_LoginDoc];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Check_LoginDoc
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [manager POST:LegDoc_Check_LoginDoc_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            LegalDocFlag = YES;
        }
        
        if (LegalDocFlag)
        {
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            LegalDocViewController *ldvc = [storyBoard instantiateViewControllerWithIdentifier:@"LegalDocViewController"];
            [self.navigationController setNavigationBarHidden:YES];
            [self.navigationController pushViewController:ldvc animated:YES];
        }
        else
        {
            [SHARED_APPDELEGATE setHomeViewController];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
