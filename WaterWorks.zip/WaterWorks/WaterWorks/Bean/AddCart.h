//
//  AddCart.h
//  WaterWorks
//
//  Created by Darshan on 13/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddCart : NSObject

@property (nonatomic , strong) NSString *StudentID;
@property (nonatomic , strong) NSString *StudentName;
@property (nonatomic , strong) NSString *Line;
@property (nonatomic , strong) NSString *Sess;
@property (nonatomic , strong) NSString *Description;
@property (nonatomic , strong) NSString *Date;
@property (nonatomic , strong) NSString *Time;
@property (nonatomic , strong) NSString *Price;


@end
