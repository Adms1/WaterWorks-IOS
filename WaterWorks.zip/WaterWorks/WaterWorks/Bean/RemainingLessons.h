//
//  RemainingLessons.h
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RemainingLessons : NSObject

@property (nonatomic , strong) NSString *LessonType;
@property (nonatomic , strong) NSString *Count;

@end
