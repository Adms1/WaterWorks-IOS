//
//  UpComingClass.h
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UpComingClass : NSObject

@property (nonatomic , strong) NSString *StudentName;
@property (nonatomic , strong) NSString *Photo;
@property (nonatomic , strong) NSString *ScheduleDate;
@property (nonatomic , strong) NSString *Instructor;

@end
