//
//  ListMyCart.h
//  WaterWorks
//
//  Created by D2D Websolution on 14/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ListMyCart : NSObject

@property (nonatomic , strong) NSString *StudentName;
@property (nonatomic , strong) NSString *index;
@property (nonatomic , strong) NSString *ItemTypeID;
@property (nonatomic , strong) NSString *ItemTypeName;
@property (nonatomic , strong) NSString *Type;
@property (nonatomic , strong) NSString *Item;
@property (nonatomic , strong) NSString *Package;
@property (nonatomic , strong) NSString *Price;
@property (nonatomic , strong) NSString *Qty;
@property (nonatomic , strong) NSString *Tax;
@property (nonatomic , strong) NSString *Subtotal;
@property (nonatomic , strong) NSString *Delete;
@property (nonatomic , strong) NSString *Description;
@property (nonatomic , strong) NSString *Location;
@property (nonatomic , strong) NSString *Promocode;
@property (nonatomic , strong) NSString *DeleteEblDble;

@end
