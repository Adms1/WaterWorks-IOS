//
//  UpComingClass.m
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UpComingClass.h"

@implementation UpComingClass

@synthesize StudentName;
@synthesize Photo;
@synthesize ScheduleDate;
@synthesize Instructor;

@end
