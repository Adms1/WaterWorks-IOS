//
//  Location.m
//  WaterWorks
//
//  Created by D2D Websolution on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "Location.h"

@implementation Location

@synthesize sitename;
@synthesize siteid;
@synthesize Lafitness;
@synthesize Address1;
@synthesize Address2;
@synthesize City;
@synthesize State;
@synthesize ZipCode;
@synthesize Phone;

@end
