//
//  StudentList.m
//  WaterWorks
//
//  Created by D2D Websolution on 06/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "StudentList.h"

@implementation StudentList

@synthesize SFirstName;
@synthesize StudentID;

@end
