//
//  AddCart.m
//  WaterWorks
//
//  Created by Darshan on 13/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "AddCart.h"

@implementation AddCart

@synthesize StudentID;
@synthesize StudentName;
@synthesize Line;
@synthesize Sess;
@synthesize Description;
@synthesize Date;
@synthesize Time;
@synthesize Price;

@end
