//
//  Location.h
//  WaterWorks
//
//  Created by D2D Websolution on 27/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Location : UIView

@property (nonatomic , strong) NSString *sitename;
@property (nonatomic , strong) NSString *siteid;
@property (nonatomic , strong) NSString *Lafitness;
@property (nonatomic , strong) NSString *Address1;
@property (nonatomic , strong) NSString *Address2;
@property (nonatomic , strong) NSString *City;
@property (nonatomic , strong) NSString *State;
@property (nonatomic , strong) NSString *ZipCode;
@property (nonatomic , strong) NSString *Phone;

@end
