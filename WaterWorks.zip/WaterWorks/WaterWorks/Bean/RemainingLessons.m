//
//  RemainingLessons.m
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RemainingLessons.h"

@implementation RemainingLessons

@synthesize LessonType;
@synthesize Count;

@end
