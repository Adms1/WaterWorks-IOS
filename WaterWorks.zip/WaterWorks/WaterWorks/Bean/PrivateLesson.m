//
//  PrivateLesson.m
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PrivateLesson.h"

@implementation PrivateLesson

@synthesize Quantity;
@synthesize PackageID;
@synthesize Price;
@synthesize Popular;
@synthesize OrgPrice;
@synthesize Saving;
@synthesize isSelected;
@end
