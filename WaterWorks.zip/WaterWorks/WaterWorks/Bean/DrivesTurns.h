//
//  DrivesTurns.h
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DrivesTurns : NSObject

@property (nonatomic , strong) NSString *FullName;
@property (nonatomic , strong) NSString *Studentid;
@property (nonatomic , strong) NSString *tbid;
@property (nonatomic , strong) NSString *sessionname;
@property (nonatomic , strong) NSString *startdate;
@property (nonatomic , strong) NSString *enddate;
@property (nonatomic , strong) NSString *Time;
@property (nonatomic , strong) NSString *unitprice;
@property (nonatomic , strong) NSString *sitename;
@property (nonatomic , strong) NSString *alreadyshopped;
@property (nonatomic , strong) NSString *Remark;
@property (nonatomic , strong) NSString *Description;
@property (nonatomic , strong) NSString *EarlyDropOffID;
@property (nonatomic , strong) NSString *SessionID;

@end
