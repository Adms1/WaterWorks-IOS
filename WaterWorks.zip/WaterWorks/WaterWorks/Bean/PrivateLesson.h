//
//  PrivateLesson.h
//  SmileStream
//
//  Created by D2D Websolution on 28/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PrivateLesson : NSObject

@property (nonatomic , strong) NSString *Quantity;
@property (nonatomic , strong) NSString *PackageID;
@property (nonatomic , strong) NSString *Price;
@property (nonatomic , strong) NSString *Popular;
@property (nonatomic , strong) NSString *OrgPrice;
@property (nonatomic , strong) NSString *Saving;
@property (nonatomic) BOOL isSelected;

@end
