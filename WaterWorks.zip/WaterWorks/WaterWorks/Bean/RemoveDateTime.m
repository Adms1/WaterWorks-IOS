//
//  RemoveDateTime.m
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "RemoveDateTime.h"

@implementation RemoveDateTime

@synthesize FormateTime;
@synthesize InstructorName;
@synthesize ReleaseID;
@synthesize RemoveFrom;
@synthesize StudentName;
@synthesize wu_Day;
@synthesize wu_lessonname;
@synthesize wu_photo;
@synthesize wu_sttimehr;
@synthesize wu_sttimemin;
@synthesize isDateUpdate;
@synthesize isSelected;


@end
