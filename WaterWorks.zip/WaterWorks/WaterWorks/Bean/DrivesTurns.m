//
//  DrivesTurns.m
//  WaterWorks
//
//  Created by Darshan on 12/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DrivesTurns.h"

@implementation DrivesTurns

@synthesize FullName;
@synthesize Studentid;
@synthesize tbid;
@synthesize sessionname;
@synthesize startdate;
@synthesize enddate;
@synthesize Time;
@synthesize unitprice;
@synthesize sitename;
@synthesize alreadyshopped;
@synthesize Remark;
@synthesize Description;
@synthesize EarlyDropOffID;
@synthesize SessionID;

@end
