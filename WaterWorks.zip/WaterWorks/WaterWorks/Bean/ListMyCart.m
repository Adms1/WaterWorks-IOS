//
//  ListMyCart.m
//  WaterWorks
//
//  Created by D2D Websolution on 14/10/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ListMyCart.h"

@implementation ListMyCart

@synthesize StudentName;
@synthesize index;
@synthesize ItemTypeID;
@synthesize ItemTypeName;
@synthesize Type;
@synthesize Item;
@synthesize Package;
@synthesize Price;
@synthesize Qty;
@synthesize Tax;
@synthesize Subtotal;
@synthesize Delete;
@synthesize Description;
@synthesize Location;
@synthesize Promocode;
@synthesize DeleteEblDble;

@end
