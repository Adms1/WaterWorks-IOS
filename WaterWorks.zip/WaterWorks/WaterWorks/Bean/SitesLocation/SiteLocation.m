//
//  SiteLocation.m
//  WaterWorks
//
//  Created by Darshan on 16/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SiteLocation.h"

@implementation SiteLocation

@synthesize SiteID;
@synthesize SiteName;
@synthesize master;
@synthesize hearaboutlabel;
@synthesize hearaboutlabel1;
@synthesize hearaboutlabel2;
@synthesize secondary;
@synthesize child;

@end
