//
//  SiteLocation.h
//  WaterWorks
//
//  Created by Darshan on 16/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SiteLocation : NSObject

@property (nonatomic , strong) NSString *SiteID;
@property (nonatomic , strong) NSString *SiteName;
@property (nonatomic , strong) NSString *master;
@property (nonatomic , strong) NSString *hearaboutlabel;
@property (nonatomic , strong) NSString *hearaboutlabel1;
@property (nonatomic , strong) NSString *hearaboutlabel2;
@property (nonatomic , strong) NSString *secondary;
@property (nonatomic , strong) NSString *child;

@end
