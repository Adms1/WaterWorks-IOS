//
//  RemoveDateTime.h
//  WaterWorks
//
//  Created by Darshan on 26/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RemoveDateTime : NSObject

@property (nonatomic , strong) NSString *FormateTime;
@property (nonatomic , strong) NSString *InstructorName;
@property (nonatomic , strong) NSString *ReleaseID;
@property (nonatomic , strong) NSString *RemoveFrom;
@property (nonatomic , strong) NSString *StudentName;
@property (nonatomic , strong) NSString *wu_Day;
@property (nonatomic , strong) NSString *wu_lessonname;
@property (nonatomic , strong) NSString *wu_photo;
@property (nonatomic , strong) NSString *wu_sttimehr;
@property (nonatomic , strong) NSString *wu_sttimemin;
@property (nonatomic) BOOL isDateUpdate;
@property (nonatomic) BOOL isSelected;

@end
