//
//  MasterViewController.m
//  GTUPapers
//
//  Created by My Mac on 4/11/16.
//  Copyright (c) 2016 Darshan Jolapara. All rights reserved.
//

#import "MasterViewController.h"
#import "AppDelegate.h"
#import "MyScheduleViewController.h"
#import "LogoutPopup.h"
#import "MyAccountViewController.h"
#import "CommonClass.h"
#import "SLViewController.h"
#import "BuyLessonsViewController.h"
#import "UpComingMeetViewController.h"
#import "RegisterViewController.h"
#import "OtherViewController.h"
#import "HelpViewController.h"
#import "PastDuePopUp.h"

//#import "UIViewController+MFSideMenuAdditions.h"
//#import "MFSideMenu.h"

@interface MasterViewController ()<LogoutPopupDelegate,PastDueDelegate>

@end

@implementation MasterViewController



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return YES;
}

-(void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Header"]];
    
    [self setupMenuBarButtonItems];
    
    // Init custom right-side menu
    self.menuRight = [[VKSideMenu alloc] initWithSize:(SHARED_APPDELEGATE.window.frame.size.width) - 70 andDirection:VKSideMenuDirectionFromLeft];
    self.menuRight.dataSource       = self;
    self.menuRight.delegate         = self;
    self.menuRight.textColor        = [UIColor whiteColor];
    self.menuRight.enableOverlay    = NO;
    self.menuRight.hideOnSelection  = NO;
    self.menuRight.selectionColor   = nil;//[UIColor colorWithWhite:.0 alpha:.3];
    self.menuRight.iconsColor       = nil;
    [self.menuRight addSwipeGestureRecognition:self.view];
}

#pragma mark -
#pragma mark - UIBarButtonItems

- (void)setupMenuBarButtonItems {
    
    [self rightMenuBarButtonItem];
}

-(void)rightMenuBarButtonItem{
    
    UIButton *btnMenu = [UIButton buttonWithType:UIButtonTypeCustom];
    btnMenu.frame = CGRectMake(0, 0, 40, 40);
    [btnMenu setImage:[UIImage imageNamed:@"Menu"] forState:UIControlStateNormal];
    [btnMenu addTarget:self action:@selector(clickToggle) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:btnMenu];
    
}

-(void)backBarButtonItem
{
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.frame=CGRectMake(0, 0, 35, 35);
    [btnBack setImage:[UIImage imageNamed:@"back-arrow"] forState:UIControlStateNormal];
    [btnBack addTarget:self action:@selector(onClickBack) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:btnBack];
}

-(void)clickToggle
{
    [self.menuRight toggleMenu];
}

-(void)onClickBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - UIBarButtonItem Callbacks

- (void)backButtonPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)leftSideMenuButtonPressed:(id)sender {
    
}

- (void)rightSideMenuButtonPressed:(id)sender {
    
}


#pragma mark - VKSideMenuDataSource

-(NSInteger)numberOfSectionsInSideMenu:(VKSideMenu *)sideMenu
{
    return 1;
}

-(NSInteger)sideMenu:(VKSideMenu *)sideMenu numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

-(VKSideMenuItem *)sideMenu:(VKSideMenu *)sideMenu itemForRowAtIndexPath:(NSIndexPath *)indexPath
{
    VKSideMenuItem *item = [VKSideMenuItem new];
    switch (indexPath.row)
    {
        case 0:
            item.title = @"Home";
            break;
            
        case 1:
            item.title = @"My Account";
            break;
            
        case 2:
            item.title = @"View My Schedule";
            break;
            
        case 3:
            item.title = @"Make a Purchase";
            break;
            
        case 4:
            item.title = @"Scheduling";
            break;
            
        case 5:
            item.title = @"Swim Competition";
            break;
            
        case 6:
            item.title = @"Cancel a Lesson";
            break;
            
        case 7:
            item.title = @"Programs";
            break;
            
        case 8:
            item.title = @"Help & Support";
            break;
            
        case 9:
            item.title = @"LogOut";
            break;
            
        default:
            break;
    }
    return item;
}

#pragma mark - VKSideMenuDelegate

-(void)sideMenu:(VKSideMenu *)sideMenu didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"SideMenu didSelectRow: %@", indexPath);
    
    if (indexPath.row == 0) {
        [SHARED_APPDELEGATE setHomeViewController];
    }
    else if (indexPath.row == 1) {
        
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        MyAccountViewController *mavc = [storyBoard instantiateViewControllerWithIdentifier:@"MyAccountViewController"];
        [self.navigationController pushViewController:mavc animated:YES];
        
    }else if (indexPath.row == 2 || indexPath.row == 6) {
        MyScheduleViewController *viewschedule =[[MyScheduleViewController alloc]initWithNibName:@"MyScheduleViewController" bundle:nil];
        [self.navigationController pushViewController:viewschedule animated:YES];
    }else if (indexPath.row == 3) {
        BuyLessonsViewController *viewBuyLessons = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
        viewBuyLessons.FromComfirmSchedule = NO;
        viewBuyLessons.strType = @"Buy";
        [self.navigationController pushViewController:viewBuyLessons animated:YES];
        
    }else if (indexPath.row == 4) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        [manager POST:Schl_Page_Load_Url parameters:@{@"Token":[userDefault objectForKey:TOKEN],@"ScheduleType":@"0"} success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"%@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
            {
                [[NSUserDefaults standardUserDefaults]setValue:@"NoPastDue" forKey:PastDue];
                NSDictionary *dic = [[responseObject safeObjectForKey:@"LessonList"] objectAtIndex:0];
                
                if (![dic[@"pastdue"]isEqualToString:@"0"])
                {
                    PastDuePopUp *pdp = [[PastDuePopUp alloc] initWithNibName:@"PastDuePopUp" bundle:nil];
                    pdp.pd_delegate = self;
                    pdp.strMsg = dic[@"pastduemessage"];
                    [pdp.view setFrame:CGRectMake(pdp.view.frame.origin.x, pdp.view.frame.origin.y, self.view.frame.size.width - 40, pdp.view.frame.size.height)];
                    [self presentPopupViewController:pdp animationType:MJPopupViewAnimationFade];
                }
                else
                {
                    SLViewController *slvc =[[SLViewController alloc]initWithNibName:@"SLViewController" bundle:nil];
                    [self.navigationController pushViewController:slvc animated:YES];
                }
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
        }];
        
    }
    else if (indexPath.row == 5)
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        NSDictionary *params = @{
                                 @"Token":[userDefault objectForKey:TOKEN],
                                 };
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [manager POST:SwimCmpt_CheckStudentMeetExist_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"RESPONSE  %@",responseObject);
            
            NSNumber *idx;
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                idx = [[[responseObject valueForKey:@"EmailPref"]objectAtIndex:0]valueForKey:@"CheckMeet"];
                
                if ([idx isEqual:@1])
                {
                    SHARED_APPDELEGATE.items = @[@"Today's Meet", @"Register",@"Trophy Room"];
                }
                else
                {
                    SHARED_APPDELEGATE.items = @[@"Upcoming Meet", @"Register",@"Trophy Room"];
                }
                
                SHARED_APPDELEGATE.isFromPrograms = NO;
                SHARED_APPDELEGATE.isFromSwim = YES;
                
                [[NSUserDefaults standardUserDefaults]setInteger:[idx integerValue] forKey:@"CheckMeet"];
                if (![idx isEqual:@0])
                {
                    UpComingMeetViewController *viewUpcoming = [[UpComingMeetViewController alloc] initWithNibName:@"UpComingMeetViewController" bundle:nil];
                    [self.navigationController pushViewController:viewUpcoming animated:YES];
                }
                else
                {
                    RegisterViewController *viewRegister = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:nil];
                    viewRegister.strSwimCopatitionProgramID = @"1";
                    [self.navigationController pushViewController:viewRegister animated:YES];
                }
                
            }
            
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
    else if (indexPath.row == 7){
        
        OtherViewController *ovc = [[OtherViewController alloc] initWithNibName:@"OtherViewController" bundle:nil];
        SHARED_APPDELEGATE.isFromPrograms = YES;
        SHARED_APPDELEGATE.isFromSwim = NO;
        [self.navigationController pushViewController:ovc animated:YES];
    }
    else if (indexPath.row == 8){
        
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HelpViewController *hvc = [storyBoard instantiateViewControllerWithIdentifier:@"HelpViewController"];
        [self.navigationController pushViewController:hvc animated:YES];
    }
    else if (indexPath.row == 9){
        
        LogoutPopup *lp = [[LogoutPopup alloc] initWithNibName:@"LogoutPopup" bundle:nil];
        lp.ldelegate = self;
        [lp.view setFrame:CGRectMake(lp.view.frame.origin.x, lp.view.frame.origin.y, self.view.frame.size.width - 60, lp.view.frame.size.height)];
        [self presentPopupViewController:lp animationType:MJPopupViewAnimationFade];
    }
    [self.menuRight hide];
}

-(void)sideMenuDidShow:(VKSideMenu *)sideMenu
{
    NSLog(@" VKSideMenue did show");
}

-(void)sideMenuDidHide:(VKSideMenu *)sideMenu
{
    NSLog(@" VKSideMenue did Hide");
}

-(NSString *)sideMenu:(VKSideMenu *)sideMenu titleForHeaderInSection:(NSInteger)section
{
    return nil;
}

-(void)Logout:(NSInteger)selectedIndex :(LogoutPopup *)lcvc;
{
    if (selectedIndex == 1)
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:FAMILYID];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:TOKEN];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_FIRSTNAME];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_PRIMARYEMAIL];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_ACTIVE];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_LASTNAME];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_PHONE];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGCOUNT];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:REMEMBERME];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:BASKETID];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"StartTime"];
        
        [SHARED_APPDELEGATE setLoginViewController];
    }
    [lcvc.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)RemovePopup:(PastDuePopUp *)popup
{
    [popup.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
