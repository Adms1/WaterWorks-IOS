//
//  ForgotViewController.h
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"

@protocol popUpForgotDelegate <NSObject>

-(void)setDismissForgotPasswordView:(NSString *)strType;

@end

@interface ForgotViewController : UIViewController

{
    IBOutlet UITextField *txtEmailID;
}

@property (assign, nonatomic) id <popUpForgotDelegate> forgotDelegate;

@end
