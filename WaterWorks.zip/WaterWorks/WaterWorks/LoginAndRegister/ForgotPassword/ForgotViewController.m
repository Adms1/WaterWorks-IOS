//
//  ForgotViewController.m
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ForgotViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ForgotViewController ()

@end

@implementation ForgotViewController

@synthesize forgotDelegate;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    txtEmailID.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtEmailID.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtEmailID.leftViewMode = UITextFieldViewModeAlways;
    txtEmailID.rightViewMode = UITextFieldViewModeAlways;
    txtEmailID.layer.borderWidth = 1.0f;
    txtEmailID.layer.borderColor = TextFieldColor.CGColor;
    txtEmailID.layer.sublayerTransform = CATransform3DMakeTranslation(30, 0, 0);
}

#pragma mark -
#pragma mark - TextField Return Keyboard Method

-(void)hideallKeyBoard
{
    if([txtEmailID isFirstResponder]){
        [txtEmailID resignFirstResponder];
    }
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtEmailID) {
        point = CGPointMake(0, 0);
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

-(BOOL)forgotValidate
{
    NSString *strLoginUserName  = [CommonClass trimString:txtEmailID.text];
    
    if ([strLoginUserName length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        return NO;
    }
    if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:strLoginUserName]]){
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        return NO;
    }
    return  YES;
}

#pragma mark -
#pragma mark - Button Method

- (IBAction)onClickResetPasswordBtn:(id)sender {
    
    if ([self forgotValidate]) {
        if (forgotDelegate &&[forgotDelegate respondsToSelector:@selector(setDismissForgotPasswordView:)]) {
            [forgotDelegate setDismissForgotPasswordView:txtEmailID.text];
        }
    }
}

- (IBAction)onClickCloseBtn:(id)sender {
    if (forgotDelegate &&[forgotDelegate respondsToSelector:@selector(setDismissForgotPasswordView:)]) {
        [forgotDelegate setDismissForgotPasswordView:@"Close"];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
