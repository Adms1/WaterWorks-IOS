//
//  LoginViewController.m
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LoginViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "LegalDocViewController.h"
#import "FirstTimeViewController.h"

@interface LoginViewController ()
{
    BOOL LegalDocFlag;
}
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    txtUserName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtUserName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtUserName.leftViewMode = UITextFieldViewModeAlways;
    txtUserName.rightViewMode = UITextFieldViewModeAlways;
    txtUserName.layer.borderWidth = 1.0f;
    txtUserName.layer.borderColor = TextFieldColor.CGColor;
    txtUserName.layer.sublayerTransform = CATransform3DMakeTranslation(30, 0, 0);
    
    txtPassword.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPassword.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPassword.leftViewMode = UITextFieldViewModeAlways;
    txtPassword.rightViewMode = UITextFieldViewModeAlways;
    txtPassword.layer.borderWidth = 1.0f;
    txtPassword.layer.borderColor = TextFieldColor.CGColor;
    txtPassword.layer.sublayerTransform = CATransform3DMakeTranslation(30, 0, 0);
    
    [lblVersion setText:AppVersion];
    
    if([[NSUserDefaults standardUserDefaults]valueForKey:CHECK] != nil)
    {
        btnRemember.selected = YES;
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
}

-(void)getChildCount
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault objectForKey:FAMILYID] forKey:@"familyid"];
    
    NSLog(@"Params %@",params);
    
    [manager POST:getstudentChild_count_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceChildCount %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSDictionary *dict = [[responseObject objectForKey:@"Student"] firstObject];
            
            if(dict != nil)
            {
                NSString *studentCount = [dict objectForKey:@"StudentCount"];
                int intValue =[studentCount intValue];
                if(intValue == 0)
                {
                    FirstTimeViewController *viewFirstTime;
                    
                    viewFirstTime = [[FirstTimeViewController alloc] initWithNibName:@"FirstTimeViewController" bundle:nil];
                    
                    [self.navigationController pushViewController:viewFirstTime animated:YES];
                    [SHARED_APPDELEGATE hideLoadingView];
                }
                else
                {
                    [self IsLAFitness_Check_Login];
                }
            }
        }
        else
        {
            NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"LoginDtl"];
            NSDictionary *dict = [arrLogin firstObject];
            [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
            [SHARED_APPDELEGATE hideLoadingView];
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

-(void)IsLAFitness_Check_Login
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [manager POST:IsLAFitness_Check_Login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        [[NSUserDefaults standardUserDefaults]setBool:[[responseObject safeObjectForKey:@"IsLaFitness"] boolValue] forKey:@"LAFitness"];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"IsLaFitness"] :@"1"])
        {
            [self LegDoc_Update_StudentDocStatus];
        }
        else
        {
            [SHARED_APPDELEGATE setHomeViewController];
            [SHARED_APPDELEGATE hideLoadingView];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Update_StudentDocStatus
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [manager POST:LegDoc_Update_StudentDocStatus_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self LegDoc_Check_LoginDoc];
        }
        else
            [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Check_LoginDoc
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Check_LoginDoc_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            LegalDocFlag = YES;
        }
        
        if (LegalDocFlag)
        {
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            LegalDocViewController *ldvc = [storyBoard instantiateViewControllerWithIdentifier:@"LegalDocViewController"];
            [[self navigationController]setNavigationBarHidden:YES];
            [[self navigationController]pushViewController:ldvc animated:YES];
        }
        else
        {
            [SHARED_APPDELEGATE setHomeViewController];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TextField Return Keyboard Method

-(void)hideallKeyBoard
{
    if([txtUserName isFirstResponder]){
        [txtUserName resignFirstResponder];
    }
    if([txtPassword isFirstResponder]){
        [txtPassword resignFirstResponder];
    }
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtUserName) {
        point = CGPointMake(0, 0);
    }else if(textField == txtPassword){
        point = CGPointMake(0, 0);
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

-(BOOL)loginValidate
{
    NSString *strLoginUserName  = [CommonClass trimString:txtUserName.text];
    NSString *strLoginPassword  = [CommonClass trimString:txtPassword.text];
    
    if ([strLoginUserName length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        return NO;
    }
    if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:strLoginUserName]]){
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        return NO;
    }
    if ([strLoginPassword length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePassword delegate:self];
        return NO;
    }
    return  YES;
}

#pragma mark -
#pragma mark - Button Method

- (IBAction)onClickLoginBtn:(id)sender {
    
    if ([self loginValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:txtUserName.text forKey:@"username"];
        [params setObject:txtPassword.text forKey:@"password"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"Params %@",params);
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        [manager POST:login_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"LoginDtl"];
                
                if ([arrLogin count] > 0) {
                    
                    NSDictionary *dict = [arrLogin firstObject];
                    
                    if (btnRemember.isSelected == YES)
                    {
                        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:REMEMBERME];
                    }else{
                        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:REMEMBERME];
                    }
                    
                    [userDefault setObject:[dict safeObjectForKey:@"FamilyID"] forKey:FAMILYID];
                    [userDefault setObject:[dict safeObjectForKey:@"Token"] forKey:TOKEN];
                    [userDefault setObject:[dict safeObjectForKey:@"WU_FParent1_FirstName"] forKey:WU_FIRSTNAME];
                    [userDefault setObject:[dict safeObjectForKey:@"WU_FPrimaryEmail"] forKey:WU_PRIMARYEMAIL];
                    [userDefault setObject:txtPassword.text forKey:WU_PASSWORD];
                    [userDefault setObject:[dict safeObjectForKey:@"WU_ActiveStatus"] forKey:WU_ACTIVE];
                    [userDefault setObject:[dict safeObjectForKey:@"WU_FParent1_LastName"] forKey:WU_LASTNAME];
                    [userDefault setObject:[dict safeObjectForKey:@"WU_Phoneno"] forKey:WU_PHONE];
                    [userDefault setObject:[dict safeObjectForKey:@"LogCount"] forKey:LOGCOUNT];
                    
                    NSDateFormatter *dateFormatter=[NSDateFormatter new];
                    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
                    [userDefault setObject:[dateFormatter stringFromDate:[NSDate date]] forKey:TODAY];
                    [userDefault synchronize];
                    
                    [self getChildCount];
                    
                    // [SHARED_APPDELEGATE setHomeViewController];
                }
            }
            else
            {
                NSMutableArray *arrLogin = [responseObject safeObjectForKey:@"LoginDtl"];
                NSDictionary *dict = [arrLogin firstObject];
                [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
                
                [SHARED_APPDELEGATE hideLoadingView];
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

- (IBAction)onClickRememberBtn:(id)sender {
    
    if ([btnRemember isSelected]) {
        btnRemember.selected = NO;
    }else{
        btnRemember.selected = YES;
        [[NSUserDefaults standardUserDefaults]setBool:YES forKey:CHECK];
    }
}

- (IBAction)onClickForgotPassword:(id)sender {
    
    ForgotViewController *viewForgot  = [[ForgotViewController alloc]initWithNibName:@"ForgotViewController" bundle:nil];
    [viewForgot.view setFrame:CGRectMake(viewForgot.view.frame.origin.x, viewForgot.view.frame.origin.y, self.view.frame.size.width, viewForgot.view.frame.size.height)];
    viewForgot.forgotDelegate = self;
    [self presentPopupViewController:viewForgot animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickNewAccountBtn:(id)sender {
    
    LoginInformationViewController *viewLoginInfo =[[LoginInformationViewController alloc] initWithNibName:@"LoginInformationViewController" bundle:nil];
    [self.navigationController pushViewController:viewLoginInfo animated:YES];
}

#pragma mark -
#pragma mark - ForgotDelegate Method

-(void)setDismissForgotPasswordView:(NSString *)strType
{
    if ([strType isEqualToString:@"Close"]) {
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    }else{
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:strType forKey:@"Email"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"Params %@",params);
        
        [manager POST:forgot_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                NSMutableArray *arrForgot = [responseObject safeObjectForKey:@"ForgotPass"];
                
                if ([arrForgot count] > 0) {
                    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
                    NSDictionary *dict = [arrForgot firstObject];
                    [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
                }
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:@"Email address not found. Please check spelling and try again, or contact the office for assistance." delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
