//
//  LoginViewController.h
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "ForgotViewController.h"
#import "LoginInformationViewController.h"
#import "Transition.h"
#import "UIViewController+MJPopupViewController.h"

@interface LoginViewController : Transition <popUpForgotDelegate>

{
    IBOutlet UITextField *txtUserName;
    IBOutlet UITextField *txtPassword;
    IBOutlet UILabel *lblVersion;
    
    IBOutlet UIButton *btnRemember;
}
@end
