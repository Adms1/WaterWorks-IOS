//
//  TelephoneTypeViewController.h
//  WaterWorks
//
//  Created by Darshan on 15/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MJPopupViewController.h"
#import "SiteLocation.h"
#import "UniversalCell.h"
#import "AFNetworking.h"

@protocol TelepnoneTypeDelegate <NSObject>
@optional
-(void)selectNumberTypePopUp:(NSString *)strNumberType andReturnType:(NSString *)strType;
-(void)selectNumberTypePopUp:(NSString *)strNumberType siteID:(NSString *)strSiteID andReturnType:(NSString *)strType;

@end

@interface TelephoneTypeViewController : UIViewController

{
    IBOutlet UITableView *tblTypeList;
    
    IBOutlet UILabel *lblTitle;
    
    NSMutableArray *arrSelectNumberType;
}

@property (assign, nonatomic) id <TelepnoneTypeDelegate> telephoneDelegate;

@property (nonatomic , strong) NSMutableArray *arrHearAbout1;
@property (nonatomic , strong) NSMutableArray *arrHearAbout2;
@property (nonatomic , strong) NSMutableArray *arrHearAbout3;
@property (nonatomic , strong) NSMutableArray *arrNumberType;

@property (nonatomic , strong) NSString *strAboutHear;
@property (nonatomic , strong) NSString *strType;

@end
