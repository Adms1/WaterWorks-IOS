//
//  ContectsInfoViewController.h
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TelephoneTypeViewController.h"

@interface ContectsInfoViewController : UIViewController<TelepnoneTypeDelegate>

{
    IBOutlet UIScrollView *scrollV;
    
    IBOutlet UIView *zipView;
    
    IBOutlet UITextField *txtStreetAddress;
    IBOutlet UITextField *txtAPT;
    IBOutlet UITextField *txtZipCode;
    IBOutlet UITextField *txtCity;
    IBOutlet UITextField *txtState;
    IBOutlet UITextField *txtPrimaryTelephone;
    IBOutlet UITextField *txtSecondaryTelephone;
    
    IBOutlet UIButton *btnPrimaryNumberType;
    IBOutlet UIButton *btnSecondaryNumberType;
    
    IBOutlet UIToolbar *toolDone;
    
    NSString *strStreetAddress;
    NSString *strAPT;
    NSString *strZipCode;
    NSString *strPrimaryTelephone;
    NSString *strSecondaryTelephone;
    
}

@end
