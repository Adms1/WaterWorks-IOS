//
//  UniversalCell.h
//  WaterWorks
//
//  Created by Darshan on 16/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SiteLocation.h"

@interface UniversalCell : UITableViewCell

{
    
}

@property (nonatomic , strong) IBOutlet UILabel *lblTitle;

-(void)setChooseLocationDataList:(SiteLocation *)objSite;
-(void)setChooseHearAbout1DataList:(SiteLocation *)objSite;
-(void)setChooseHearAbout2DataList:(SiteLocation *)objSite;
-(void)setChooseHearAbout3DataList:(SiteLocation *)objSite;
-(void)setChooseParentTypePhoneDataList:(NSDictionary *)dict;

@end
