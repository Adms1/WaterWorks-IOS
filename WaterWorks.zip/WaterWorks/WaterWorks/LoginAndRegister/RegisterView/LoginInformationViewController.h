//
//  LoginInformationViewController.h
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginInformationViewController : UIViewController

{
    IBOutlet UIScrollView *scrollV;
    
    IBOutlet UIView *secondaryView;
    
    IBOutlet UIButton *btnSingleParent;
    
    IBOutlet NSLayoutConstraint *constHeightSecondary;
    
    IBOutlet UITextField *txtEmailID;
    IBOutlet UITextField *txtConfirmEmailID;
    IBOutlet UITextField *txtPassword;
    IBOutlet UITextField *txtConfirmPassword;
    
    IBOutlet UITextField *txtPrimaryFirstName;
    IBOutlet UITextField *txtPrimaryLastName;
    
    IBOutlet UITextField *txtSecondaryFirstName;
    IBOutlet UITextField *txtSecondaryLastName;
}

@end
