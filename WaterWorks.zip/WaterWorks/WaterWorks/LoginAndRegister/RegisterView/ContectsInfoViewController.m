//
//  ContectsInfoViewController.m
//  WaterWorks
//
//  Created by Darshan on 19/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ContectsInfoViewController.h"
#import "FacilityViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ContectsInfoViewController ()
{
    UITextField *activeField;
}
@end

@implementation ContectsInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.titleView = [SHARED_APPDELEGATE getNavigationWithTitle:NavigationRegisterAccount fontSize:16];
    
    UIImage *backButtonImage = [UIImage imageNamed:@"Back"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [backButton setImage:backButtonImage
                forState:UIControlStateNormal];
    
    backButton.frame = CGRectMake(0, 0, backButtonImage.size.width, backButtonImage.size.height);
    
    [backButton addTarget:self
                   action:@selector(popViewController)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
    
    txtStreetAddress.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtStreetAddress.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtStreetAddress.leftViewMode = UITextFieldViewModeAlways;
    txtStreetAddress.rightViewMode = UITextFieldViewModeAlways;
    txtStreetAddress.layer.borderWidth = 1.0f;
    txtStreetAddress.layer.borderColor = RegisterTextColor.CGColor;
    
    txtAPT.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtAPT.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtAPT.leftViewMode = UITextFieldViewModeAlways;
    txtAPT.rightViewMode = UITextFieldViewModeAlways;
    txtAPT.layer.borderWidth = 1.0f;
    txtAPT.layer.borderColor = RegisterTextColor.CGColor;
    
    txtZipCode.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtZipCode.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtZipCode.leftViewMode = UITextFieldViewModeAlways;
    txtZipCode.rightViewMode = UITextFieldViewModeAlways;
    txtZipCode.layer.borderWidth = 1.0f;
    txtZipCode.inputAccessoryView = toolDone;
    txtZipCode.layer.borderColor = RegisterTextColor.CGColor;
    
    txtCity.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtCity.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtCity.leftViewMode = UITextFieldViewModeAlways;
    txtCity.rightViewMode = UITextFieldViewModeAlways;
    txtCity.layer.borderWidth = 1.0f;
    txtCity.layer.borderColor = RegisterTextColor.CGColor;
    
    txtState.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtState.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtState.leftViewMode = UITextFieldViewModeAlways;
    txtState.rightViewMode = UITextFieldViewModeAlways;
    txtState.layer.borderWidth = 1.0f;
    txtState.layer.borderColor = RegisterTextColor.CGColor;
    
    txtPrimaryTelephone.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryTelephone.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryTelephone.inputAccessoryView = toolDone;
    txtPrimaryTelephone.leftViewMode = UITextFieldViewModeAlways;
    txtPrimaryTelephone.rightViewMode = UITextFieldViewModeAlways;
    txtPrimaryTelephone.layer.borderWidth = 1.0f;
    txtPrimaryTelephone.layer.borderColor = RegisterTextColor.CGColor;
    
    txtSecondaryTelephone.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryTelephone.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryTelephone.leftViewMode = UITextFieldViewModeAlways;
    txtSecondaryTelephone.rightViewMode = UITextFieldViewModeAlways;
    txtSecondaryTelephone.layer.borderWidth = 1.0f;
    txtSecondaryTelephone.layer.borderColor = RegisterTextColor.CGColor;
    txtSecondaryTelephone.inputAccessoryView = toolDone;
    
    toolDone.translucent = NO;
    toolDone.barTintColor = Top_Color;
    
    [btnPrimaryNumberType setTitle:@"Home" forState:UIControlStateNormal];
    [btnSecondaryNumberType setTitle:@"Home" forState:UIControlStateNormal];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [userDefault setObject:@"1" forKey:PRIMARYTELETYPE];
    [userDefault setObject:@"1" forKey:SECONDARYTELETYPE];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Textfield Delegate

-(void)addToolBar:(UITextField *)txtfld
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    txtfld.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = activeField.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [activeField.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [activeField.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [activeField resignFirstResponder];
        [scrollV setContentInset:UIEdgeInsetsZero];
        [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [scrollV setContentInset:UIEdgeInsetsZero];
    [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
    [scrollV endEditing:YES];
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [scrollV setContentInset:contentInsets];
    [scrollV setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [scrollV scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [scrollV setContentInset:UIEdgeInsetsZero];
    [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [scrollV setContentInset:UIEdgeInsetsZero];
        [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
        return YES;
    }
    return NO;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    if (activeField.keyboardType == UIKeyboardTypeNumberPad) {
        [self addToolBar:activeField];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSLog(@"string>>>>>%@",string);
    NSLog(@"txtZipCode>>>>> %@",txtZipCode.text);
    
    if (textField == txtZipCode && range.location <= 4 && [string isEqualToString:@""])
    {
        [txtState setText:@""];
        [txtCity setText:@""];
        [zipView setHidden:YES];
        
        return YES;
    }
    
    if (textField == txtZipCode && range.location == 4)
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        NSString *strZip = [NSString stringWithFormat:@"%@%@",txtZipCode.text,string];
        
        [params setObject:strZip forKey:@"zipcode"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"Params %@",params);
        
        [manager POST:zipCode_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            NSMutableArray *arrZipCheck;
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                arrZipCheck = [responseObject safeObjectForKey:@"LocationDtl"];
                
                if ([arrZipCheck count] > 0)
                {
                    textField.userInteractionEnabled = YES;
                    NSDictionary *dict = [arrZipCheck firstObject];
                    zipView.hidden = NO;
                    txtCity.text = [dict safeObjectForKey:@"City"];
                    txtState.text = [dict safeObjectForKey:@"State"];
                    
                    [txtPrimaryTelephone becomeFirstResponder];
                }
            }
            else
            {
                txtZipCode.userInteractionEnabled = YES;
                zipView.hidden = YES;
                txtZipCode.text = @"";
                txtState.text = @"";
                txtCity.text = @"";
                [txtZipCode becomeFirstResponder];
                arrZipCheck = [responseObject safeObjectForKey:@"LocationDtl"];
                
                NSDictionary *dict = [arrZipCheck firstObject];
                [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
    
    if (textField == txtZipCode && range.location >= 5) {
        
        return NO;
    }
    else if (textField == txtPrimaryTelephone || textField == txtSecondaryTelephone)
    {
        return [CommonClass Textfield:textField :range];
    }
    
    return YES;
}

#pragma mark -
#pragma mark - Validation Method

-(BOOL)CreateAccountValidate
{
    [scrollV setContentOffset:CGPointZero animated:YES];
    strStreetAddress  = [CommonClass trimString:txtStreetAddress.text];
    strAPT = [CommonClass trimString:txtAPT.text];
    strZipCode  = [CommonClass trimString:txtZipCode.text];
    strPrimaryTelephone  = [CommonClass trimString:txtPrimaryTelephone.text];
    strSecondaryTelephone  = [CommonClass trimString:txtSecondaryTelephone.text];
    
    if ([strStreetAddress length] == 0) {
        [txtStreetAddress becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideStreetAddress delegate:self];
        return NO;
    }
    //    if ([strAPT length] == 0) {
    //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideAPT delegate:self];
    //        return NO;
    //    }
    if ([strZipCode length] == 0) {
        [txtZipCode becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideZipCode delegate:self];
        return NO;
    }
    if ([strPrimaryTelephone length] == 0) {
        [txtPrimaryTelephone becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePrimaryTelephone delegate:self];
        return NO;
    }
    if ([strPrimaryTelephone length] < 14) {
        [txtPrimaryTelephone becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideInvalidTelephone delegate:self];
        return NO;
    }
    //    if ([strSecondaryTelephone length] >= 1) {
    //        [txtSecondaryTelephone becomeFirstResponder];
    //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideSecondaryTelephone delegate:self];
    
    if ([strSecondaryTelephone length] < 14 && [strSecondaryTelephone length] > 1) {
        [txtSecondaryTelephone becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideInvalidTelephone delegate:self];
        return NO;
    }
    //        return NO;
    //    }
    return  YES;
}

#pragma mark -
#pragma mark - Button Method

- (IBAction)onClickPrimaryNumberTypeBtn:(id)sender {
    
    TelephoneTypeViewController *viewTelephone;
    if (isIpad) {
        viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewControllerIpad" bundle:nil];
    }else{
        viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    }
    
    viewTelephone.telephoneDelegate = self;
    viewTelephone.strType = @"Primary";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickSecondaryNumberTypeBtn:(id)sender {
    
    TelephoneTypeViewController *viewTelephone;
    if (isIpad) {
        viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewControllerIpad" bundle:nil];
    }else{
        viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    }
    
    viewTelephone.telephoneDelegate = self;
    viewTelephone.strType = @"Secondary";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickNextBtn:(id)sender {
    
    [scrollV setContentInset:UIEdgeInsetsZero];
    [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
    if ([self CreateAccountValidate]) {
        
        FacilityViewController *viewFacility = [[FacilityViewController alloc] initWithNibName:@"FacilityViewController" bundle:nil];
        [self.navigationController pushViewController:viewFacility animated:YES];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        [userDefault setObject:strStreetAddress forKey:STREETADDRESS];
        [userDefault setObject:strAPT forKey:API];
        [userDefault setObject:strZipCode forKey:ZIPCODE];
        [userDefault setObject:txtCity.text forKey:CITY];
        [userDefault setObject:txtState.text forKey:STATE];
        [userDefault setObject:strPrimaryTelephone forKey:PRIMARYTELEPHONE];
        [userDefault setObject:strSecondaryTelephone forKey:SECONDARYTELEPHONE];
    }
}

#pragma mark -
#pragma mark - Delegate Method

#pragma mark -
#pragma mark - Delegate Method

-(void)selectNumberTypePopUp:(NSString *)strNumberType siteID:(NSString *)strSiteID andReturnType:(NSString *)strType{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if ([strType isEqualToString:@"Primary"]) {
        [userDefault setObject:strSiteID forKey:PRIMARYTELETYPE];
        [btnPrimaryNumberType setTitle:strNumberType forState:UIControlStateNormal];
    }else{
        [userDefault setObject:strSiteID forKey:SECONDARYTELETYPE];
        [btnSecondaryNumberType setTitle:strNumberType forState:UIControlStateNormal];
    }
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}
-(void)selectNumberTypePopUp:(NSString *)strNumberType andReturnType:(NSString *)strType
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
