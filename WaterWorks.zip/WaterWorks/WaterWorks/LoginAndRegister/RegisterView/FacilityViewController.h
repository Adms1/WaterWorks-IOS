//
//  FacilityViewController.h
//  WaterWorks
//
//  Created by Darshan on 15/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TelephoneTypeViewController.h"
#import "SiteLocation.h"

@interface FacilityViewController : UIViewController<TelepnoneTypeDelegate>

{
    IBOutlet NSLayoutConstraint *constHeightFirstView;
    IBOutlet NSLayoutConstraint *constHeightSecondView;
    IBOutlet NSLayoutConstraint *constHeightThirdView;
    IBOutlet NSLayoutConstraint *constHeightFourthView;
    
    IBOutlet UIButton *btnChooseLocation;
    IBOutlet UIButton *btnHearAbout1;
    IBOutlet UIButton *btnHearAbout2;
    IBOutlet UIButton *btnHearAbout3;
    
    IBOutlet UITextField *txtOther;
    
    NSMutableArray *arrLocationList;
    NSMutableArray *arrAboutHear1;
    NSMutableArray *arrAboutHear2;
    NSMutableArray *arrAboutHear3;
    
    NSString *strHearAbout;
}

@end
