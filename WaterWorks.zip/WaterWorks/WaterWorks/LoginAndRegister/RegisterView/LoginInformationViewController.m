//
//  LoginInformationViewController.m
//  WaterWorks
//
//  Created by Darshan on 14/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LoginInformationViewController.h"
#import "ContectsInfoViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface LoginInformationViewController ()
{
    UITextField *activeField;
}
@end

@implementation LoginInformationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    self.navigationItem.titleView = [SHARED_APPDELEGATE getNavigationWithTitle:NavigationRegisterAccount fontSize:18];
    
    UIImage *backButtonImage = [UIImage imageNamed:@"Back"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [backButton setImage:backButtonImage
                forState:UIControlStateNormal];
    
    backButton.frame = CGRectMake(0, 0, backButtonImage.size.width, backButtonImage.size.height);
    
    [backButton addTarget:self
                   action:@selector(popViewController)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
    
    //Login Information TextField
    txtEmailID.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtEmailID.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtEmailID.leftViewMode = UITextFieldViewModeAlways;
    txtEmailID.rightViewMode = UITextFieldViewModeAlways;
    txtEmailID.layer.borderWidth = 1.0f;
    txtEmailID.layer.borderColor = RegisterTextColor.CGColor;
    
    txtConfirmEmailID.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtConfirmEmailID.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtConfirmEmailID.leftViewMode = UITextFieldViewModeAlways;
    txtConfirmEmailID.rightViewMode = UITextFieldViewModeAlways;
    txtConfirmEmailID.layer.borderWidth = 1.0f;
    txtConfirmEmailID.layer.borderColor = RegisterTextColor.CGColor;
    
    txtPassword.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPassword.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPassword.leftViewMode = UITextFieldViewModeAlways;
    txtPassword.rightViewMode = UITextFieldViewModeAlways;
    txtPassword.layer.borderWidth = 1.0f;
    txtPassword.layer.borderColor = RegisterTextColor.CGColor;
    
    txtConfirmPassword.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtConfirmPassword.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtConfirmPassword.leftViewMode = UITextFieldViewModeAlways;
    txtConfirmPassword.rightViewMode = UITextFieldViewModeAlways;
    txtConfirmPassword.layer.borderWidth = 1.0f;
    txtConfirmPassword.layer.borderColor = RegisterTextColor.CGColor;
    
    //Primary Parent/Gaurdian TextField
    txtPrimaryFirstName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryFirstName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryFirstName.leftViewMode = UITextFieldViewModeAlways;
    txtPrimaryFirstName.rightViewMode = UITextFieldViewModeAlways;
    txtPrimaryFirstName.layer.borderWidth = 1.0f;
    txtPrimaryFirstName.layer.borderColor = RegisterTextColor.CGColor;
    
    txtPrimaryLastName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryLastName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtPrimaryLastName.leftViewMode = UITextFieldViewModeAlways;
    txtPrimaryLastName.rightViewMode = UITextFieldViewModeAlways;
    txtPrimaryLastName.layer.borderWidth = 1.0f;
    txtPrimaryLastName.layer.borderColor = RegisterTextColor.CGColor;
    
    //Secondary Parent/Gaurdian TextField
    txtSecondaryFirstName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryFirstName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryFirstName.leftViewMode = UITextFieldViewModeAlways;
    txtSecondaryFirstName.rightViewMode = UITextFieldViewModeAlways;
    txtSecondaryFirstName.layer.borderWidth = 1.0f;
    txtSecondaryFirstName.layer.borderColor = RegisterTextColor.CGColor;
    
    txtSecondaryLastName.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryLastName.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSecondaryLastName.leftViewMode = UITextFieldViewModeAlways;
    txtSecondaryLastName.rightViewMode = UITextFieldViewModeAlways;
    txtSecondaryLastName.layer.borderWidth = 1.0f;
    txtSecondaryLastName.layer.borderColor = RegisterTextColor.CGColor;
    
    if (isIpad) {
        constHeightSecondary.constant = 135.0f;
    }else{
        constHeightSecondary.constant = 115.0f;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [scrollV setContentInset:contentInsets];
    [scrollV setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = activeField.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [scrollV scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [scrollV setContentInset:UIEdgeInsetsZero];
    [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [scrollV setContentInset:UIEdgeInsetsZero];
        [scrollV setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    CGPoint point;
    
    if (textField == txtEmailID) {
        point = CGPointMake(0, 0);
    }else if(textField == txtConfirmEmailID){
        point = CGPointMake(0, 0);
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
    }else if(textField == txtPassword){
        point = CGPointMake(0, 0);
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
    }else if(textField == txtConfirmPassword){
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
        point = CGPointMake(0, 0);
        
    }else if(textField == txtPrimaryFirstName){
        point = CGPointMake(0, textField.frame.origin.y - 210);
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
        else if (![txtPassword.text isEqualToString:txtConfirmPassword.text]) {
            [txtConfirmPassword becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothPassowrd delegate:self];
        }
    }else if(textField == txtPrimaryLastName){
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
        else if (![txtPassword.text isEqualToString:txtConfirmPassword.text]) {
            [txtConfirmPassword becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothPassowrd delegate:self];
        }
        
        point = CGPointMake(0, textField.frame.origin.y - 150);
    }else if(textField == txtSecondaryFirstName){
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
        else if (![txtPassword.text isEqualToString:txtConfirmPassword.text]) {
            [txtConfirmPassword becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothPassowrd delegate:self];
        }
        
        point = CGPointMake(0, secondaryView.frame.origin.y - 170);
    }else if(textField == txtSecondaryLastName){
        
        if ([txtEmailID.text length] == 0) {
            [txtEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        }
        
        else if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:txtEmailID.text]])
        {
            [txtConfirmEmailID becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        }
        
        else if (![txtConfirmEmailID.text isEqualToString:txtEmailID.text]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideNotConfrimEmail delegate:self];
        }
        
        else if (![txtPassword.text isEqualToString:txtConfirmPassword.text]) {
            [txtConfirmPassword becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothPassowrd delegate:self];
        }
        
        point = CGPointMake(0, secondaryView.frame.origin.y - 170);
    }
    //[scrollV setContentOffset:point animated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
    if (textField == txtEmailID) {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [params setObject:txtEmailID.text forKey:@"EmailID"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"Params %@",params);
        
        [manager POST:checkEmail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            NSMutableArray *arrEmailCheck;
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                arrEmailCheck = [responseObject safeObjectForKey:@"CheckEmail"];
                
                if ([arrEmailCheck count] > 0) {
                    txtEmailID.text = @"";
                    [txtEmailID becomeFirstResponder];
                    arrEmailCheck = [responseObject safeObjectForKey:@"CheckEmail"];
                    
                    NSDictionary *dict = [arrEmailCheck firstObject];
                    [CommonClass showAlertWithTitle:provideAlert andMessage:@"Email address already used." delegate:self];
                }
            }else{
                
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

#pragma mark -
#pragma mark - Validation Method

-(BOOL)CreateAccountValidate
{
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
    
    NSString *strCreateAccountEmail  = [CommonClass trimString:txtEmailID.text];
    NSString *strCreateAccountConfirmEmail = [CommonClass trimString:txtConfirmEmailID.text];
    NSString *strCreateAccountPassword  = [CommonClass trimString:txtPassword.text];
    NSString *strCreateAccountConfirmPassword  = [CommonClass trimString:txtConfirmPassword.text];
    
    NSString *strCreatePrimaryFirstName  = [CommonClass trimString:txtPrimaryFirstName.text];
    NSString *strCreatePrimaryLastName  = [CommonClass trimString:txtPrimaryLastName.text];
    
    NSString *strCreateSecondaryFirstName  = [CommonClass trimString:txtSecondaryFirstName.text];
    NSString *strCreateSecondaryLastName  = [CommonClass trimString:txtSecondaryLastName.text];
    
    if ([strCreateAccountEmail length] == 0) {
        [txtEmailID becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideUserName delegate:self];
        return NO;
    }
    if(![CommonClass textIsValidEmailFormat:[CommonClass trimString:strCreateAccountEmail]]){
        [txtConfirmEmailID becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideValidEmail delegate:self];
        return NO;
    }
    if ([strCreateAccountConfirmEmail length] == 0) {
        [txtConfirmEmailID becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideConfrimEmail delegate:self];
        return NO;
    }
    
    if (![strCreateAccountEmail isEqualToString:strCreateAccountConfirmEmail]) {
        [txtConfirmEmailID becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothEmailCheck delegate:self];
        return NO;
    }
    if ([strCreateAccountPassword length] == 0) {
        [txtPassword becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePassword delegate:self];
        return NO;
    }
    if ([strCreateAccountConfirmPassword length] == 0) {
        [txtConfirmPassword becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideConfirmPassword delegate:self];
        return NO;
    }
    if (![strCreateAccountPassword isEqualToString:strCreateAccountConfirmPassword]) {
        [txtConfirmPassword becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideBothPassowrd delegate:self];
        return NO;
    }
    
    if ([strCreatePrimaryFirstName length] == 0) {
        [txtPrimaryFirstName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePrimaryFirstName delegate:self];
        return NO;
    }
    if ([strCreatePrimaryLastName length] == 0) {
        [txtPrimaryLastName becomeFirstResponder];
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePrimaryLastName delegate:self];
        return NO;
    }
    
    if ([btnSingleParent isSelected] == NO) {
        if ([strCreateSecondaryFirstName length] == 0) {
            [txtSecondaryFirstName becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideSecondaryFirstName delegate:self];
            return NO;
        }
        if ([strCreateSecondaryLastName length] == 0) {
            [txtSecondaryLastName becomeFirstResponder];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideSecondaryLastName delegate:self];
            return NO;
        }
    }
    [scrollV setContentOffset:CGPointZero animated:YES];
    [scrollV scrollRectToVisible:CGRectMake(scrollV.contentSize.width - 1,scrollV.contentSize.height - 1, 1, 1) animated:YES];
    return  YES;
}

#pragma mark -
#pragma mark - Button Method

- (IBAction)onClickSingleParentBtn:(id)sender {
    
    if ([btnSingleParent isSelected]) {
        txtSecondaryFirstName.tag = 7;
        txtPrimaryLastName.returnKeyType = UIReturnKeyNext;
        secondaryView.hidden = NO;
        btnSingleParent.selected = NO;
        if (isIpad) {
            constHeightSecondary.constant = 135.0f;
        }else{
            constHeightSecondary.constant = 115.0f;
        }
    }else{
        txtSecondaryFirstName.tag = 8;
        txtPrimaryLastName.returnKeyType = UIReturnKeyDefault;
        secondaryView.hidden = YES;
        btnSingleParent.selected = YES;
        constHeightSecondary.constant = 0.0f;
    }
}

- (IBAction)onClickNextBtn:(id)sender {
    
    if ([self CreateAccountValidate]) {
        
        ContectsInfoViewController *viewContectInfo = [[ContectsInfoViewController alloc] initWithNibName:@"ContectsInfoViewController" bundle:nil];
        [self.navigationController pushViewController:viewContectInfo animated:YES];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        [userDefault setObject:txtEmailID.text forKey:EMAILID];
        [userDefault setObject:txtPassword.text forKey:PASSWORD];
        [userDefault setObject:txtPrimaryFirstName.text forKey:PRIMARYFIRSTNAME];
        [userDefault setObject:txtPrimaryLastName.text forKey:PRIMARYLASTNAME];
        [userDefault setObject:txtSecondaryFirstName.text forKey:SECONDARYFIRSTNAME];
        [userDefault setObject:txtSecondaryLastName.text forKey:SECONDARYLASTNAME];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
