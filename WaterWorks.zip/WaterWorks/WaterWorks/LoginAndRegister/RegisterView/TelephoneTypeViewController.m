//
//  TelephoneTypeViewController.m
//  WaterWorks
//
//  Created by Darshan on 15/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TelephoneTypeViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface TelephoneTypeViewController ()

@end

@implementation TelephoneTypeViewController

@synthesize strType;
@synthesize arrNumberType;
@synthesize strAboutHear;
@synthesize arrHearAbout1;
@synthesize arrHearAbout2;
@synthesize arrHearAbout3;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.layer.borderWidth = 1.0f;
    self.view.layer.borderColor = [UIColor darkGrayColor].CGColor;
    
    arrSelectNumberType = [[NSMutableArray alloc] init];
    
    if ([strType isEqualToString:@"Primary"]) {
        lblTitle.text = @"Primary Telophone";
        arrNumberType = [[NSMutableArray alloc] init];
        
        [arrNumberType addObject:[self getDictfromTitle:@"Home" andTitleID:@"1"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Mom Cell" andTitleID:@"2"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Dad Cell" andTitleID:@"3"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Mom Work" andTitleID:@"4"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Dad Work" andTitleID:@"5"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Grand Parent" andTitleID:@"6"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Baby Sitter" andTitleID:@"7"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Relative" andTitleID:@"8"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Fax" andTitleID:@"9"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Other" andTitleID:@"10"]];
    }else if ([strType isEqualToString:@"Secondary"]){
        lblTitle.text = @"Secondary Telophone";
        arrNumberType = [[NSMutableArray alloc] init];
        
        [arrNumberType addObject:[self getDictfromTitle:@"Home" andTitleID:@"1"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Mom Cell" andTitleID:@"2"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Dad Cell" andTitleID:@"3"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Mom Work" andTitleID:@"4"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Dad Work" andTitleID:@"5"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Grand Parent" andTitleID:@"6"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Baby Sitter" andTitleID:@"7"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Relative" andTitleID:@"8"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Fax" andTitleID:@"9"]];
        [arrNumberType addObject:[self getDictfromTitle:@"Other" andTitleID:@"10"]];
    }else if ([strType isEqualToString:@"ChooseLocation"]){
        
        lblTitle.text = @"Choose Location";
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        arrNumberType = [[NSMutableArray alloc] init];
        
        [manager POST:chooseLocation_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            NSMutableArray *arrLocation = [[NSMutableArray alloc] init];
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                arrLocation = [responseObject safeObjectForKey:@"Sites"];
                
                if ([arrLocation count] > 0) {
                    
                    for (NSDictionary *dict in arrLocation) {
                        SiteLocation *objSiteLocation = [[SiteLocation alloc] init];
                        
                        objSiteLocation.SiteID = [dict safeObjectForKey:@"SiteID"];
                        objSiteLocation.SiteName = [dict safeObjectForKey:@"SiteName"];
                        
                        [arrNumberType addObject:objSiteLocation];
                    }
                    [tblTypeList reloadData];
                }
                
            }else{
                NSDictionary *dict = [arrLocation firstObject];
                [CommonClass showAlertWithTitle:provideAlert andMessage:[dict safeObjectForKey:@"Msg"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }else if ([strType isEqualToString:@"hearabout1"]){
        lblTitle.text = @"Hear About";
        arrNumberType = [[NSMutableArray alloc] init];
        [arrNumberType addObjectsFromArray:arrHearAbout1];
    }else if ([strType isEqualToString:@"hearabout2"]){
        lblTitle.text = @"Hear About";
        arrNumberType = [[NSMutableArray alloc] init];
        [arrNumberType addObjectsFromArray:arrHearAbout2];
    }else if ([strType isEqualToString:@"hearabout3"]){
        lblTitle.text = @"Hear About";
        arrNumberType = [[NSMutableArray alloc] init];
        [arrNumberType addObjectsFromArray:arrHearAbout3];
    }
    
}

#pragma mark -
#pragma mark - SideMenu Icon And Title Dict Method

-(NSMutableDictionary *)getDictfromTitle:(NSString *)title andTitleID:(NSString *)strID
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:title forKey:@"title"];
    [dict setObject:strID forKey:@"phonetype"];
    return dict;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrNumberType count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdenti = @"ChatImageCell";
    
    UniversalCell *cell = (UniversalCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"UniversalCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    if([arrSelectNumberType containsObject:[arrNumberType objectAtIndex:indexPath.row]]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if ([arrNumberType count] > 0) {
        if ([strType isEqualToString:@"ChooseLocation"]) {
            SiteLocation *objSiteLocation = [arrNumberType objectAtIndex:indexPath.row];
            [cell setChooseLocationDataList:objSiteLocation];
        }else if ([strType isEqualToString:@"hearabout1"]){
            SiteLocation *objSiteLocation = [arrNumberType objectAtIndex:indexPath.row];
            [cell setChooseHearAbout1DataList:objSiteLocation];
        }else if ([strType isEqualToString:@"hearabout2"]){
            SiteLocation *objSiteLocation = [arrNumberType objectAtIndex:indexPath.row];
            [cell setChooseHearAbout2DataList:objSiteLocation];
        }else if ([strType isEqualToString:@"hearabout3"]){
            SiteLocation *objSiteLocation = [arrNumberType objectAtIndex:indexPath.row];
            [cell setChooseHearAbout3DataList:objSiteLocation];
        }else{
            NSDictionary *dictParam = [arrNumberType objectAtIndex:indexPath.row];
            [cell setChooseParentTypePhoneDataList:dictParam];
        }
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if ([strType isEqualToString:@"ChooseLocation"]) {
        
        SiteLocation *objSite = [arrNumberType objectAtIndex:indexPath.row];
        
        //   NSString *strSelect  = [arrBusCategory objectAtIndex:indexPath.row];
        
        [tblTypeList deselectRowAtIndexPath:indexPath animated:YES];
        
        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [arrSelectNumberType addObject:objSite.SiteName];
        }else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            [arrSelectNumberType removeObject:objSite.SiteName];
        }
        
        if (self.telephoneDelegate && [self.telephoneDelegate respondsToSelector:@selector(selectNumberTypePopUp:siteID:andReturnType:)]) {
            [self.telephoneDelegate selectNumberTypePopUp:objSite.SiteName siteID:objSite.SiteID andReturnType:strType];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
    }else if ([strType isEqualToString:@"hearabout1"]){
        SiteLocation *objSite = [arrNumberType objectAtIndex:indexPath.row];
        
        //   NSString *strSelect  = [arrBusCategory objectAtIndex:indexPath.row];
        
        [tblTypeList deselectRowAtIndexPath:indexPath animated:YES];
        
        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [arrSelectNumberType addObject:objSite.hearaboutlabel];
        }else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            [arrSelectNumberType removeObject:objSite.hearaboutlabel];
        }
        
        if (self.telephoneDelegate && [self.telephoneDelegate respondsToSelector:@selector(selectNumberTypePopUp:siteID:andReturnType:)]) {
            [self.telephoneDelegate selectNumberTypePopUp:objSite.hearaboutlabel siteID:objSite.master andReturnType:strType];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];

    }else if ([strType isEqualToString:@"hearabout2"]){
        SiteLocation *objSite = [arrNumberType objectAtIndex:indexPath.row];
        
        //   NSString *strSelect  = [arrBusCategory objectAtIndex:indexPath.row];
        
        [tblTypeList deselectRowAtIndexPath:indexPath animated:YES];
        
        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [arrSelectNumberType addObject:objSite.hearaboutlabel1];
        }else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            [arrSelectNumberType removeObject:objSite.hearaboutlabel1];
        }
        
        if (self.telephoneDelegate && [self.telephoneDelegate respondsToSelector:@selector(selectNumberTypePopUp:siteID:andReturnType:)]) {
            [self.telephoneDelegate selectNumberTypePopUp:objSite.hearaboutlabel1 siteID:objSite.secondary andReturnType:strType];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
    }else if ([strType isEqualToString:@"hearabout3"]){
        SiteLocation *objSite = [arrNumberType objectAtIndex:indexPath.row];
        
        //   NSString *strSelect  = [arrBusCategory objectAtIndex:indexPath.row];
        
        [tblTypeList deselectRowAtIndexPath:indexPath animated:YES];
        
        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [arrSelectNumberType addObject:objSite.hearaboutlabel2];
        }else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            [arrSelectNumberType removeObject:objSite.hearaboutlabel2];
        }
        
        if (self.telephoneDelegate && [self.telephoneDelegate respondsToSelector:@selector(selectNumberTypePopUp:siteID:andReturnType:)]) {
            [self.telephoneDelegate selectNumberTypePopUp:objSite.hearaboutlabel2 siteID:objSite.child andReturnType:strType];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
    }else{
        NSDictionary *dict = [arrNumberType objectAtIndex:indexPath.row];
        
        //   NSString *strSelect  = [arrBusCategory objectAtIndex:indexPath.row];
        
        [tblTypeList deselectRowAtIndexPath:indexPath animated:YES];
        
        if (cell.accessoryType == UITableViewCellAccessoryNone) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            [arrSelectNumberType addObject:[dict objectForKey:@"title"]];
        }else {
            cell.accessoryType = UITableViewCellAccessoryNone;
            [arrSelectNumberType removeObject:[dict objectForKey:@"title"]];
        }
        
        if (self.telephoneDelegate && [self.telephoneDelegate respondsToSelector:@selector(selectNumberTypePopUp:andReturnType:)]) {
            [self.telephoneDelegate selectNumberTypePopUp:[dict valueForKey:@"title"] siteID:[dict valueForKey:@"phonetype"] andReturnType:strType];
//            [self.telephoneDelegate selectNumberTypePopUp:strSelect andReturnType:strType];
        }
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}
- (void) deselect
{
    [tblTypeList deselectRowAtIndexPath:[tblTypeList indexPathForSelectedRow] animated:YES];
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
