//
//  UniversalCell.m
//  WaterWorks
//
//  Created by Darshan on 16/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UniversalCell.h"

@implementation UniversalCell

@synthesize lblTitle;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setChooseLocationDataList:(SiteLocation *)objSite{
    
    lblTitle.text = objSite.SiteName;
}

-(void)setChooseHearAbout1DataList:(SiteLocation *)objSite{
    lblTitle.text = objSite.hearaboutlabel;
}

-(void)setChooseHearAbout2DataList:(SiteLocation *)objSite{
    lblTitle.text = objSite.hearaboutlabel1;
}

-(void)setChooseHearAbout3DataList:(SiteLocation *)objSite{
    lblTitle.text = objSite.hearaboutlabel2;
}

-(void)setChooseParentTypePhoneDataList:(NSDictionary *)dict{
    lblTitle.text = [dict objectForKey:@"title"];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
