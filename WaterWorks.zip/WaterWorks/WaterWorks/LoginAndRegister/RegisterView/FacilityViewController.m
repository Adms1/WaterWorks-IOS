//
//  FacilityViewController.m
//  WaterWorks
//
//  Created by Darshan on 15/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "FacilityViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface FacilityViewController ()

@end

@implementation FacilityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.titleView = [SHARED_APPDELEGATE getNavigationWithTitle:NavigationRegisterAccount fontSize:16];
    
    UIImage *backButtonImage = [UIImage imageNamed:@"Back"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [backButton setImage:backButtonImage
                forState:UIControlStateNormal];
    
    backButton.frame = CGRectMake(0, 0, backButtonImage.size.width, backButtonImage.size.height);
    
    [backButton addTarget:self
                   action:@selector(popViewController)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
    
    constHeightFirstView.constant = 0.0f;
    constHeightSecondView.constant = 0.0f;
    constHeightThirdView.constant = 0.0f;
    constHeightFourthView.constant = 0.0f;
    
    txtOther.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtOther.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtOther.leftViewMode = UITextFieldViewModeAlways;
    txtOther.rightViewMode = UITextFieldViewModeAlways;
    
    txtOther.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    txtOther.layer.borderWidth = 0.5f;
}

#pragma mark -
#pragma mark - Pop To View Mothod

-(void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - TextField Return Keyboard Method

-(void)hideallKeyBoard
{
    if([txtOther isFirstResponder]){
        [txtOther resignFirstResponder];
    }
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        return YES;
    }
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint point;
    
    if (textField == txtOther) {
        point = CGPointMake(0, 0);
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

-(BOOL)LocationValidate
{
    NSString *strLoginUserName  = [CommonClass trimString:txtOther.text];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:txtOther.text forKey:OTHER];
    
    if ([btnChooseLocation.titleLabel.text isEqualToString:@"Choose a location"]) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideLocation delegate:self];
        return NO;
    }
    if (constHeightFirstView.constant == 40.0f) {
        if ([btnHearAbout1.titleLabel.text isEqualToString:@"Select"]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideHearAbout delegate:self];
            return NO;
        }
    }
    if (constHeightSecondView.constant == 40.0f) {
        if ([btnHearAbout2.titleLabel.text isEqualToString:@"Select"]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideHearAbout delegate:self];
            return NO;
        }
    }
    if (constHeightThirdView.constant == 40.0f) {
        if ([btnHearAbout3.titleLabel.text isEqualToString:@"Select"]) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideHearAbout delegate:self];
            return NO;
        }
    }
    if (constHeightFourthView.constant == 40.0f) {
        if ([strLoginUserName length] == 0) {
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideOther delegate:self];
            return NO;
        }
    }
    return  YES;
}

- (IBAction)onClickSubmitBtn:(id)sender {
    
    if ([self LocationValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        NSString *strEmailID = [[NSUserDefaults standardUserDefaults]objectForKey:EMAILID];
        NSString *strPassword = [[NSUserDefaults standardUserDefaults]objectForKey:PASSWORD];
        NSString *strPrimaryFirstName = [[NSUserDefaults standardUserDefaults]objectForKey:PRIMARYFIRSTNAME];
        NSString *strPrimaryLastName = [[NSUserDefaults standardUserDefaults]objectForKey:PRIMARYLASTNAME];
        NSString *strSecondaryFirstName = [[NSUserDefaults standardUserDefaults]objectForKey:SECONDARYFIRSTNAME];
        NSString *strSecondaryLastName = [[NSUserDefaults standardUserDefaults]objectForKey:SECONDARYLASTNAME];
        NSString *strAddress = [[NSUserDefaults standardUserDefaults]objectForKey:STREETADDRESS];
        NSString *strAPT = [[NSUserDefaults standardUserDefaults]objectForKey:API];
        NSString *strZipCode = [[NSUserDefaults standardUserDefaults]objectForKey:ZIPCODE];
        NSString *strCity = [[NSUserDefaults standardUserDefaults]objectForKey:CITY];
        NSString *strState = [[NSUserDefaults standardUserDefaults]objectForKey:STATE];
        NSString *strPrimaryTelophone = [[NSUserDefaults standardUserDefaults]objectForKey:PRIMARYTELEPHONE];
        NSString *strSecondaryTelophone = [[NSUserDefaults standardUserDefaults]objectForKey:SECONDARYTELEPHONE];
        NSString *strSiteID = [[NSUserDefaults standardUserDefaults]objectForKey:SITEID];
        NSString *strCildID = [[NSUserDefaults standardUserDefaults]objectForKey:CHILDID];
        NSString *strMasterID = [[NSUserDefaults standardUserDefaults]objectForKey:MASTERID];
        NSString *strSecondaryID = [[NSUserDefaults standardUserDefaults]objectForKey:SECONDARYID];
        NSString *strOtherText = [[NSUserDefaults standardUserDefaults]objectForKey:OTHER];
        NSString *strPrimaryType = [[NSUserDefaults standardUserDefaults]objectForKey:PRIMARYTELETYPE];
        NSString *strScondaryType = [[NSUserDefaults standardUserDefaults]objectForKey:SECONDARYTELETYPE];
        
        [params setObject:strEmailID forKey:@"EmailAdd"];
        [params setObject:strEmailID forKey:@"ConfirmEmail"];
        [params setObject:strPassword forKey:@"Password"];
        [params setObject:strPassword forKey:@"ConfrmPassword"];
        [params setObject:strPrimaryFirstName forKey:@"PFirstName"];
        [params setObject:strPrimaryLastName forKey:@"PLastName"];
        
        if ([strSecondaryFirstName isEqualToString:@""] || [strSecondaryFirstName isEqual:[NSNull class]] || strSecondaryFirstName == nil) {
            [params setObject:@"" forKey:@"SFirstName"];
        }else{
            [params setObject:strSecondaryFirstName forKey:@"SFirstName"];
        }
        
        if ([strSecondaryLastName isEqualToString:@""] || [strSecondaryLastName isEqual:[NSNull class]] || strSecondaryLastName == nil) {
            [params setObject:@"" forKey:@"SLastName"];
        }else{
            [params setObject:strSecondaryLastName forKey:@"SLastName"];
        }
        
        [params setObject:strAddress forKey:@"Address"];
        [params setObject:strAPT forKey:@"Apt"];
        [params setObject:strZipCode forKey:@"Zipcode"];
        [params setObject:strState forKey:@"State"];
        [params setObject:strCity forKey:@"City"];
        
        [params setObject:strSiteID forKey:@"SiteID"];
        
        if ([strMasterID isEqualToString:@""] || [strMasterID isEqual:[NSNull class]] || strMasterID == nil) {
            [params setObject:@"0" forKey:@"strMaster"];
        }else{
            [params setObject:strMasterID forKey:@"strMaster"];
        }
        
        if ([strSecondaryID isEqualToString:@""] || [strSecondaryID isEqual:[NSNull class]] || strSecondaryID == nil) {
            [params setObject:@"0" forKey:@"strSecondary"];
        }else{
            [params setObject:strSecondaryID forKey:@"strSecondary"];
        }
        
        if ([strCildID isEqualToString:@""] || [strCildID isEqual:[NSNull class]] || strCildID == nil) {
            [params setObject:@"0" forKey:@"strChild"];
        }else{
            [params setObject:strCildID forKey:@"strChild"];
        }
        
        if ([strOtherText isEqualToString:@""] || [strOtherText isEqual:[NSNull class]] || strOtherText == nil) {
            [params setObject:@"" forKey:@"strOther"];
        }else{
            [params setObject:strOtherText forKey:@"strOther"];
        }
        
        [params setObject:@"0" forKey:@"status"];
        
        [params setObject:@"" forKey:@"PLeavePrivate"];
        [params setObject:@"" forKey:@"SLeavePrivate"];
        [params setObject:strPrimaryTelophone forKey:@"Phone1"];
        [params setObject:strSecondaryTelophone forKey:@"Phone2"];
        [params setObject:strPrimaryType forKey:@"PhoneType1"];
        [params setObject:strScondaryType forKey:@"PhoneType2"];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSLog(@"Params %@",params);
        
        [manager POST:register_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                NSMutableArray *arrForgot = [responseObject safeObjectForKey:@"CreateAccount"];
                
                if ([arrForgot count] > 0) {
                    UIAlertController * alert=   [UIAlertController
                                                  alertControllerWithTitle:@"Registration - Success"
                                                  message:@"Dear Customer,\nThank you for registering with Waterworks Aquatics.You will be receiving an activation email shortly."
                                                  preferredStyle:UIAlertControllerStyleAlert];
                    
                    UIAlertAction* ok = [UIAlertAction
                                         actionWithTitle:provideOk
                                         style:UIAlertActionStyleDefault
                                         handler:^(UIAlertAction * action)
                                         {
                                             [self setLoginView];
                                             [alert dismissViewControllerAnimated:YES completion:nil];
                                         }];
                    [alert addAction:ok];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(void)setLoginView
{
    [SHARED_APPDELEGATE setLoginViewController];
}
- (IBAction)onClickChooseLocationBtn:(id)sender {
    
    [btnHearAbout1 setTitle:@"Select" forState:0];
    [btnHearAbout2 setTitle:@"Select" forState:0];
    [btnHearAbout3 setTitle:@"Select" forState:0];
    
    TelephoneTypeViewController *viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    viewTelephone.telephoneDelegate = self;
    viewTelephone.strType = @"ChooseLocation";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickHearAbout1Btn:(id)sender {
    
    TelephoneTypeViewController *viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    viewTelephone.telephoneDelegate = self;
    viewTelephone.arrHearAbout1 = arrLocationList;
    viewTelephone.strType = @"hearabout1";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickHearAbout2Btn:(id)sender {
    TelephoneTypeViewController *viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    viewTelephone.telephoneDelegate = self;
    viewTelephone.arrHearAbout2 = arrAboutHear1;
    viewTelephone.strType = @"hearabout2";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

- (IBAction)onClickHearAbout3Btn:(id)sender {
    
    TelephoneTypeViewController *viewTelephone = [[TelephoneTypeViewController alloc] initWithNibName:@"TelephoneTypeViewController" bundle:nil];
    viewTelephone.telephoneDelegate = self;
    viewTelephone.arrHearAbout3 = arrAboutHear2;
    viewTelephone.strType = @"hearabout3";
    [self presentPopupViewController:viewTelephone animationType:MJPopupViewAnimationFade];
}

#pragma mark -
#pragma mark - Delegate Method

-(void)selectNumberTypePopUp:(NSString *)strNumberType siteID:(NSString *)strSiteID andReturnType:(NSString *)strType{
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    if ([strType isEqualToString:@"ChooseLocation"]) {
        
        [btnChooseLocation setTitle:strNumberType forState:UIControlStateNormal];
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [userDefault setObject:strSiteID forKey:SITEID];
        
        [params setObject:strSiteID forKey:@"Siteid"];
        
        arrLocationList = [[NSMutableArray alloc] init];
        
        [manager POST:masterData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            NSMutableArray *arrLocation = [[NSMutableArray alloc] init];
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                arrLocation = [responseObject safeObjectForKey:@"MasterList"];
                
                if ([arrLocation count] > 0) {
                    
                    constHeightFirstView.constant = 40.0f;
                    
                    for (NSDictionary *dict in arrLocation) {
                        SiteLocation *objSiteLocation = [[SiteLocation alloc] init];
                        
                        objSiteLocation.master = [dict safeObjectForKey:@"master"];
                        objSiteLocation.hearaboutlabel = [dict safeObjectForKey:@"hearaboutlabel"];
                        
                        [arrLocationList addObject:objSiteLocation];
                    }
                }else{
                    constHeightFirstView.constant = 0.0f;
                    constHeightSecondView.constant = 0.0f;
                    constHeightThirdView.constant = 0.0f;
                    constHeightFourthView.constant = 0.0f;
                    
                    [btnHearAbout1 setTitle:@"Select" forState:UIControlStateNormal];
                    [btnHearAbout2 setTitle:@"Select" forState:UIControlStateNormal];
                    [btnHearAbout3 setTitle:@"Select" forState:UIControlStateNormal];
                    
                    txtOther.text = @"";
                }
            }else{
                constHeightFirstView.constant = 0.0f;
                constHeightSecondView.constant = 0.0f;
                constHeightThirdView.constant = 0.0f;
                constHeightFourthView.constant = 0.0f;
                
                [btnHearAbout1 setTitle:@"Select" forState:UIControlStateNormal];
                [btnHearAbout2 setTitle:@"Select" forState:UIControlStateNormal];
                [btnHearAbout3 setTitle:@"Select" forState:UIControlStateNormal];
                
                txtOther.text = @"";
                
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:CHILDID];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:MASTERID];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:SECONDARYID];
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:OTHER];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }else if ([strType isEqualToString:@"hearabout1"]){
        
        NSString *strLastValue = [[strSiteID componentsSeparatedByString:@"/"] lastObject];
        
        [btnHearAbout1 setTitle:strNumberType forState:UIControlStateNormal];
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
        
        [userDefault setObject:strSiteID forKey:MASTERID];
        
        if ([strLastValue isEqualToString:@"0"]) {
            
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
            
            [SHARED_APPDELEGATE showLoadingView];
            
            [params setObject:strSiteID forKey:@"strChild"];
            
            arrAboutHear1 = [[NSMutableArray alloc] init];
            
            [manager POST:secondaryData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
                
                [SHARED_APPDELEGATE hideLoadingView];
                
                NSLog(@"ResponceLogin %@",responseObject);
                
                NSMutableArray *arrLocation = [[NSMutableArray alloc] init];
                
                if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                    
                    arrLocation = [responseObject safeObjectForKey:@"MasterList"];
                    
                    [btnHearAbout2 setTitle:@"Select" forState:UIControlStateNormal];
                    
                    if ([arrLocation count] > 0) {
                        
                        constHeightSecondView.constant = 40.0f;
                        constHeightFourthView.constant = 0.0f;
                        
                        for (NSDictionary *dict in arrLocation) {
                            SiteLocation *objSiteLocation = [[SiteLocation alloc] init];
                            
                            objSiteLocation.secondary = [dict safeObjectForKey:@"secondary"];
                            objSiteLocation.hearaboutlabel1 = [dict safeObjectForKey:@"hearaboutlabel"];
                            
                            [arrAboutHear1 addObject:objSiteLocation];
                        }
                    }else{
                        constHeightSecondView.constant = 0.0f;
                        constHeightThirdView.constant = 0.0f;
                    }
                }else{
                    constHeightSecondView.constant = 0.0f;
                    constHeightThirdView.constant = 0.0f;
                    
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:CHILDID];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:SECONDARYID];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:OTHER];
                }
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                
                [SHARED_APPDELEGATE hideLoadingView];
                NSLog(@"Error: %@", error);
            }];
        }else{
            constHeightSecondView.constant = 0.0f;
            constHeightThirdView.constant = 0.0f;
            constHeightFourthView.constant = 40.0f;
            
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:CHILDID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:SECONDARYID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:OTHER];
        }
    }else if ([strType isEqualToString:@"hearabout2"]){
        
        NSString *strLastValue = [[strSiteID componentsSeparatedByString:@"/"] lastObject];
        
        [btnHearAbout2 setTitle:strNumberType forState:UIControlStateNormal];
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
        
        [userDefault setObject:strSiteID forKey:SECONDARYID];
        
        if ([strLastValue isEqualToString:@"0"]) {
            
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
            
            [SHARED_APPDELEGATE showLoadingView];
            
            [params setObject:strSiteID forKey:@"strMaster"];
            
            arrAboutHear2 = [[NSMutableArray alloc] init];
            
            [manager POST:childData_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
                
                [SHARED_APPDELEGATE hideLoadingView];
                
                NSLog(@"ResponceLogin %@",responseObject);
                
                NSMutableArray *arrLocation = [[NSMutableArray alloc] init];
                
                if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                    
                    [btnHearAbout3 setTitle:@"Select" forState:UIControlStateNormal];
                    
                    arrLocation = [responseObject safeObjectForKey:@"MasterList"];
                    
                    if ([arrLocation count] > 0) {
                        
                        constHeightThirdView.constant = 40.0f;
                        constHeightFourthView.constant = 0.0f;
                        
                        for (NSDictionary *dict in arrLocation) {
                            SiteLocation *objSiteLocation = [[SiteLocation alloc] init];
                            
                            objSiteLocation.child = [dict safeObjectForKey:@"child"];
                            objSiteLocation.hearaboutlabel2 = [dict safeObjectForKey:@"hearaboutlabel"];
                            
                            [arrAboutHear2 addObject:objSiteLocation];
                        }
                    }else{
                        constHeightThirdView.constant = 0.0f;
                    }
                }else{
                    constHeightThirdView.constant = 0.0f;
                }
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                
                constHeightThirdView.constant = 0.0f;
                [SHARED_APPDELEGATE hideLoadingView];
                NSLog(@"Error: %@", error);
            }];
        }else{
            constHeightThirdView.constant = 0.0f;
            constHeightFourthView.constant = 40.0f;
            
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:CHILDID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:OTHER];
        }
    }else if ([strType isEqualToString:@"hearabout3"]){
        
        [userDefault setObject:strSiteID forKey:CHILDID];
        
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:OTHER];
        
        [btnHearAbout3 setTitle:strNumberType forState:UIControlStateNormal];
        [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
