//
//  AppDelegate.h
//  WaterWorks
//
//  Created by Sweta Sheth on JANUARY - 2017
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
#import "HomeViewController.h"
#import "CustomAnimation.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIView *loadView;
    UIView *viewBack;
    UILabel *lblLoading;
    UIActivityIndicatorView *spinningWheel;
}

@property (strong, nonatomic) UIWindow *window;
@property () BOOL restrictRotation;
@property (nonatomic , strong) UINavigationController *navigation;
@property (nonatomic , strong) UINavigationController *navHome;
@property (nonatomic , strong) NSString *startDate;
@property (nonatomic , strong) NSString *endDate;
@property (nonatomic , strong) NSMutableArray *arrStudentName;
@property (nonatomic , strong) NSMutableArray *arrStudentComboName;
@property (nonatomic , strong) NSMutableDictionary *dicStudentDetails;
@property (nonatomic , strong) NSArray *items;
@property (nonatomic , strong) NSMutableDictionary *dicTemp;
@property (nonatomic , assign) BOOL isFromPrograms;
@property (nonatomic , assign) BOOL isFromSwim;
@property (nonatomic , assign) BOOL sameInstructor;
@property (nonatomic , assign) BOOL sameClass;
@property (nonatomic , assign) BOOL IsPlaceOrder;
@property (nonatomic , strong) NSMutableDictionary *selectedInstructors;
@property (nonatomic , assign) int min;
@property (nonatomic , assign) int sec;

+(AppDelegate*)sharedAppDelegate;
-(UIView*)getTextFieldLeftAndRightView;
-(void)showLoadingView;
-(void) hideLoadingView;
-(UILabel *)getNavigationWithTitle:(NSString *)title fontSize:(int)size;
-(UILabel *)getNavigationCenterWithTitle:(NSString *)title fontSize:(int)size;
-(UILabel *)getNavigationWithScheduleTitle:(NSString *)title fontSize:(int)size;
-(void)setAppProperty;
-(UIImage *)imageFromColor:(UIColor *)color;
-(void)setLoginViewController;
-(void)setHomeViewController;
-(void)setScheduleViewController;
-(void)setBuyLessonViewController;
-(void)setMyScheduleViewController;
@end

