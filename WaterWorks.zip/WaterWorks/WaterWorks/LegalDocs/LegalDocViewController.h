//
//  LegalDocViewController.h
//  WaterWorks
//
//  Created by Ankit on 28/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LegalDocViewController : UIViewController
{
    IBOutlet UILabel *lblDocName, *lblInstruction, *lblPageNo;
    IBOutlet UIWebView *webViewLegalDoc;
    IBOutlet UIView *viewSign, *viewParent, *viewDate, *viewChild, *viewEmergency, *viewDisclaimer;
    
    IBOutlet NSLayoutConstraint *webViewHeight;
    IBOutlet NSLayoutConstraint *viewSignHeight;
    IBOutlet NSLayoutConstraint *viewParentHeight;
    IBOutlet NSLayoutConstraint *viewDateHeight;
    IBOutlet NSLayoutConstraint *viewChildHeight;
    IBOutlet NSLayoutConstraint *viewEmergencyHeight;
    IBOutlet NSLayoutConstraint *viewDisclaimerHeight;
    IBOutlet NSLayoutConstraint *btnSendMailHeight;
    
    IBOutlet UIButton *btn, *btnSendMail;
}
@end
