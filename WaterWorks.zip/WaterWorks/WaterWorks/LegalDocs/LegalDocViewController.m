//
//  LegalDocViewController.m
//  WaterWorks
//
//  Created by Ankit on 28/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "LegalDocViewController.h"
#import "LogoutPopup.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface LegalDocViewController ()<LogoutPopupDelegate,UITextFieldDelegate>
{
    NSArray *arrStudentList;
    UITextField *txtfld;
    NSMutableDictionary *dicLegalDoc;
    NSArray *arr_student_family, *arr_disclimer;
    NSMutableArray *tempArray;
    NSString *strDocName;
    BOOL firstTime;
    NSInteger total_count,student_count;
}
@end

@implementation LegalDocViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //                                             selector:@selector(keyboardWillBeHidden:)
    //                                                 name:UIKeyboardWillHideNotification object:nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    for (UIView *v in self.view.subviews[1].subviews)
    {
        for (UIView *v1 in v.subviews)
        {
            if ([v1 isKindOfClass:[UITextField class]])
            {
                ((UITextField *)v1).leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v1).rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
                ((UITextField *)v1).leftViewMode = UITextFieldViewModeAlways;
                ((UITextField *)v1).rightViewMode = UITextFieldViewModeAlways;
            }
        }
    }
    
    firstTime = YES;
    [self viewReset];
    [self LegDoc_Check_Login_Load_Doc];
}

-(void)viewReset
{
    [((UIScrollView *)self.view.subviews[1]) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)self.view.subviews[1]) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)self.view.subviews[1])setContentOffset:CGPointZero animated:NO];
    
    [btnSendMail setSelected:YES];
    [btn setSelected:NO];
    [webViewLegalDoc setHidden:YES];
    [viewChild setHidden:YES];
    [viewSign setHidden:YES];
    [viewParent setHidden:YES];
    [viewDate setHidden:YES];
    [viewEmergency setHidden:YES];
    [btnSendMail setHidden:YES];
    [viewDisclaimer setHidden:YES];
    [viewChild.subviews[1] setHidden:YES];
    
    viewDateHeight.constant = viewSignHeight.constant = viewChildHeight.constant = viewParentHeight.constant = viewEmergencyHeight.constant = webViewHeight.constant = btnSendMailHeight.constant = viewDisclaimerHeight.constant = 0.0f;
    
}

#pragma mark - Legal Docs

-(void)LegDoc_Check_Login_Load_Doc
{
    total_count = 0;
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    
    NSString *Weburl;
    if (firstTime)
    {
        Weburl = LegDoc_Check_LoginDoc_Url;
        firstTime = NO;
    }
    else
    {
        Weburl = LegDoc_Check_LoadDoc_Url;
    }
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Weburl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            if (((NSArray *)[responseObject valueForKey:@"Disclaimer"]).count > 0)
            {
                strDocName = @"Disclaimer";
                [self viewReset];
                
                for (UIView *v in self.view.subviews[1].subviews) {
                    if ([v isEqual:lblDocName] || v.tag == 30 || [v isEqual:lblInstruction] || [v isEqual:btn] || [v isEqual:viewDisclaimer])
                    {
                        [v setHidden:NO];
                    }
                    else
                    {
                        [v setHidden:YES];
                    }
                }
                
                arr_disclimer = [responseObject valueForKey:@"Disclaimer"];
                
                //                if (arr_disclimer.count == 1)
                //                {
                //                    [btnSendMail setHidden:NO];
                //                    btnSendMailHeight.constant = 30.0f;
                //                }
                
                lblDocName.text = [arr_disclimer objectAtIndex:total_count][@"DisclaimerName"];
                
                tempArray = [[NSMutableArray alloc]init];
                for (int i = 0; i < ((NSArray *)[responseObject valueForKey:@"Disclaimer"]).count; i++)
                {
                    [tempArray addObject:[NSString stringWithFormat:@"%d_%@",i+1,[[[responseObject valueForKey:@"Disclaimer"] valueForKey:@"DisclaimerContent"] objectAtIndex:i]]];
                }
                
                [self DynamicAddDesclaimer:((NSArray *)[[responseObject valueForKey:@"Disclaimer"] valueForKey:@"DisclaimerContent"])];
                
                [SHARED_APPDELEGATE hideLoadingView];
            }
            else
            {
                if (((NSArray *)[responseObject valueForKey:@"FamilyDoc"]).count > 0)
                {
                    strDocName = @"FamilyDoc";
                }
                else
                {
                    strDocName = @"StudentDoc";
                    student_count = 0;
                }
                
                arr_student_family = [responseObject valueForKey:strDocName];
                [self SetDocScreen:0];
                
                if (arr_student_family.count == 1)
                {
                    [btnSendMail setHidden:NO];
                    btnSendMailHeight.constant = 50.0f;
                }
            }
        }
        else
        {
            [SHARED_APPDELEGATE setHomeViewController];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Update_StudentDocStatus
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Update_StudentDocStatus_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [self LegDoc_Bind_StudentList:[arr_student_family objectAtIndex:total_count][@"SiteID"] :[arr_student_family objectAtIndex:total_count][@"DocID"]];
            
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Update_DocProcess:(NSString *)stuID :(NSString *)docId :(NSString *)siteId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"DocID":docId,
                             @"StudentID":stuID,
                             @"SiteID":siteId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Update_DocProcess_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            [self LegDoc_Check_Login_Load_Doc];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Bind_StudentList:(NSString *)SiteId :(NSString *)DocId
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"DocID":DocId,
                             @"SiteID":SiteId,
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Bind_StudentList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            arrStudentList = [responseObject valueForKey:@"PendingStudentList"];
            student_count = arrStudentList.count;
            [self DynamicAddChildren:arrStudentList.count];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Insert_StudentDocDetails_FamilyDocDetails
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSString *strStuId;
    if ([[arr_student_family objectAtIndex:total_count][@"StudentID"] isKindOfClass:[NSNumber class]])
    {
        strStuId = [arr_student_family objectAtIndex:total_count][@"StudentID"];
    }
    else
    {
        if ([strDocName isEqualToString:@"StudentDoc"] && student_count > 0)
        {
            strStuId = [arrStudentList objectAtIndex:student_count-1][@"StudentID"];
        }
        else
        {
            strStuId = [[[arr_student_family objectAtIndex:total_count][@"StudentID"]componentsSeparatedByString:@","]lastObject];
        }
    }
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"ParentName":dicLegalDoc[@"Parents Name"] == nil ? @"" : dicLegalDoc[@"Parents Name"],
                             @"strPDFCheck":dicLegalDoc[@"3"] == nil ? @"" : dicLegalDoc[@"3"],
                             @"DocID":[arr_student_family objectAtIndex:total_count][@"DocID"],
                             @"DocGroupID":[arr_student_family objectAtIndex:total_count][@"DocGroupID"],
                             @"calstartdate":dicLegalDoc[@"Start Date"] == nil ? @"" : dicLegalDoc[@"Start Date"],
                             @"Phoneno":dicLegalDoc[@"Phone Number"] == nil ? @"" : dicLegalDoc[@"Phone Number"],
                             @"EmergencyRelation":dicLegalDoc[@"Relation"] == nil ? @"" : dicLegalDoc[@"Relation"],
                             @"RequiredDate":[arr_student_family objectAtIndex:total_count][@"RequiredDate"],
                             @"EmergencyName":dicLegalDoc[@"Name"] == nil ? @"" : dicLegalDoc[@"Name"],
                             @"ConfrmText":[arr_student_family objectAtIndex:total_count][@"ConfrmText"],
                             @"StudentID":strStuId,
                             @"PageContent":[arr_student_family objectAtIndex:total_count][@"PageContent"],
                             @"RequiredStudentRelation":[arr_student_family objectAtIndex:total_count][@"RequiredStudentRelation"],
                             @"Signaturename":dicLegalDoc[@"Signature"] == nil ? @"" : dicLegalDoc[@"Signature"],
                             @"DocumentName":[arr_student_family objectAtIndex:total_count][@"DocName"],
                             @"PageID":[arr_student_family objectAtIndex:total_count][@"PageID"],
                             @"RequiredStudent":[arr_student_family objectAtIndex:total_count][@"RequiredStudent"],
                             @"RequiredSignature":[arr_student_family objectAtIndex:total_count][@"RequiredSignature"],
                             @"RequiredEmergency":[arr_student_family objectAtIndex:total_count][@"RequiredEmergency"],
                             @"RequiredParent":[arr_student_family objectAtIndex:total_count][@"RequiredParent"],
                             @"StrRelation":@"",
                             @"SiteID":[arr_student_family objectAtIndex:total_count][@"SiteID"],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *webUrl;
    if ([strDocName isEqualToString:@"StudentDoc"])
    {
        webUrl = LegDoc_Insert_StudentDocDetails_Url;
    }
    else
    {
        webUrl = LegDoc_Insert_FamilyDocDetails_Url;
    }
    
    [manager POST:webUrl parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            if ([strDocName isEqualToString:@"StudentDoc"])
            {
                student_count--;
                if (student_count > 0)
                {
                    [self LegDoc_Insert_StudentDocDetails_FamilyDocDetails];
                }
                else
                {
                    [self LegDoc_Update_DocProcess:[arr_student_family objectAtIndex:arr_student_family.count-1][@"StudentID"] :[arr_student_family objectAtIndex:arr_student_family.count-1][@"DocID"] :[arr_student_family objectAtIndex:arr_student_family.count-1][@"SiteID"]];
                }
            }
            else
            {
                total_count++;
                if (total_count < arr_student_family.count)
                {
                    [self SetDocScreen:total_count];
                    if (total_count == arr_student_family.count-1)
                    {
                        [btnSendMail setHidden:NO];
                        btnSendMailHeight.constant = 50.0f;
                    }
                }
                else
                {
                    [self LegDoc_Update_DocProcess:[arr_student_family objectAtIndex:arr_student_family.count-1][@"StudentID"] :[arr_student_family objectAtIndex:arr_student_family.count-1][@"DocID"] :[arr_student_family objectAtIndex:arr_student_family.count-1][@"SiteID"]];
                }
            }
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)LegDoc_Insert_DisclaimerDtl
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *params = @{
                             @"Token":[userDefault objectForKey:TOKEN],
                             @"DisclaimerID":[arr_disclimer objectAtIndex:total_count][@"DisclDetailsID"],
                             @"StudentListAry":[arr_disclimer objectAtIndex:total_count][@"StudentList"],
                             @"DocID":[arr_disclimer objectAtIndex:total_count][@"DocID"],
                             @"DocGroupID":[arr_disclimer objectAtIndex:total_count][@"DocGroupID"],
                             @"DiscmrAfterBeforStatus":[arr_disclimer objectAtIndex:total_count][@"DiscmrAfterBeforStatus"],
                             @"DisclaimerListAry":[tempArray componentsJoinedByString:@" "],
                             @"DiclaimerName":[arr_disclimer objectAtIndex:total_count][@"DisclaimerName"],
                             @"SiteID":[arr_disclimer objectAtIndex:total_count][@"SiteID"],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:LegDoc_Insert_DisclaimerDtl_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"])
        {
            [self LegDoc_Update_DocProcess:[arr_disclimer objectAtIndex:total_count][@"StudentList"] :[arr_disclimer objectAtIndex:total_count][@"DocID"] :[arr_disclimer objectAtIndex:total_count][@"SiteID"]];
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -

-(void)SetDocScreen:(int)i
{
    [self viewReset];
    NSDictionary *dic = [arr_student_family objectAtIndex:i];
    lblDocName.text = dic[@"DocName"];
    lblInstruction.text = dic[@"ConfrmText"];
    [lblPageNo setHidden:NO];
    lblPageNo.text = [NSString stringWithFormat:@"Page %d of %lu",i+1,(unsigned long)arr_student_family.count];
    
    NSString *htmlString = [dic[@"PageContent"]stringByReplacingOccurrencesOfString:@"<body>" withString:@"<body style=\"text-align:justify;background-color:#99eaff\" >"];
    [webViewLegalDoc loadHTMLString:htmlString baseURL:nil];
    
    if ([dic[@"RequiredSignature"] isEqualToString:@"Y"])
    {
        viewSignHeight.constant = 53.0f;
        [viewSign setHidden:NO];
        [((UITextField *)[viewSign viewWithTag:0])setText:@""];
        
        if ([dic[@"RequiredParent"] isEqualToString:@"Y"])
        {
            ((UITextField *)[viewSign viewWithTag:0]).returnKeyType = UIReturnKeyNext;
        }
        else
        {
            ((UITextField *)[viewSign viewWithTag:0]).returnKeyType = UIReturnKeyDefault;
        }
    }
    if ([dic[@"RequiredParent"] isEqualToString:@"Y"])
    {
        viewParentHeight.constant = 53.0f;
        [viewParent setHidden:NO];
        
        [((UITextField *)[viewParent viewWithTag:0])setText:[NSString stringWithFormat:@"%@ %@",[[NSUserDefaults standardUserDefaults] valueForKey:WU_FIRSTNAME],[[NSUserDefaults standardUserDefaults] valueForKey:WU_LASTNAME]]];
    }
    if ([dic[@"RequiredDate"] isEqualToString:@"Y"])
    {
        viewDateHeight.constant = 53.0f;
        [viewDate setHidden:NO];
        
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm:ss a"];
        
        [((UITextField *)[viewDate viewWithTag:0])setText:[dateFormatter stringFromDate:[NSDate date]]];
    }
    if ([dic[@"RequiredStudent"] isEqualToString:@"Y"])
    {
        [self LegDoc_Update_StudentDocStatus];
    }
    if ([dic[@"RequiredEmergency"] isEqualToString:@"Y"])
    {
        viewEmergencyHeight.constant = 255.0f;
        [viewEmergency setHidden:NO];
        for (UIView *v in viewEmergency.subviews) {
            if ([v isKindOfClass:[UITextField class]]) {
                [((UITextField *)v)setText:@""];
            }
        }
    }
}

-(void)DynamicAddDesclaimer:(NSArray *)arr
{
    [viewDisclaimer.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    [lblInstruction  setText:[arr objectAtIndex:0]];
    CGFloat height = 0;
    height = [self getLabelHeight:[arr objectAtIndex:0]];
    
    CGFloat totalHeight = 0.0f;
    for (int i = 1; i < arr.count; i++)
    {
        UIButton *btnCheck = [[UIButton alloc]initWithFrame:CGRectMake(btn.frame.origin.x, totalHeight + 8, btn.frame.size.width, btn.frame.size.height)];
        [btnCheck setImage:[UIImage imageNamed:@"UnCheckLesson"] forState:0];
        [btnCheck setImage:[UIImage imageNamed:@"CheckLesson"] forState:UIControlStateSelected];
        [btnCheck setImageEdgeInsets:UIEdgeInsetsMake(-10, -5, 0, 0)];
        btnCheck.tag = 100;
        [btnCheck addTarget:self action:@selector(checkUncheckClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        height = [self getLabelHeight:[arr objectAtIndex:i]];
        
        UILabel *lblDes = [[UILabel alloc]initWithFrame:CGRectMake(lblInstruction.frame.origin.x, btnCheck.frame.origin.y - 2, lblInstruction.frame.size.width,height)];
        [lblDes setText:[arr objectAtIndex:i]];
        [lblDes setTextColor:[UIColor blackColor]];
        [lblDes setTextAlignment:NSTextAlignmentLeft];
        [lblDes setFont:lblInstruction.font];
        [lblDes setNumberOfLines:0];
        [lblDes setLineBreakMode:NSLineBreakByWordWrapping];
        
        totalHeight += height + 8;
        
        [viewDisclaimer addSubview:btnCheck];
        [viewDisclaimer addSubview:lblDes];
    }
    
    [viewDisclaimer setHidden:NO];
    viewDisclaimerHeight.constant = totalHeight;
}

- (CGFloat)getLabelHeight:(NSString *)str
{
    CGSize constraint = CGSizeMake(lblInstruction.frame.size.width, CGFLOAT_MAX);
    CGSize size;
    
    NSStringDrawingContext *context = [[NSStringDrawingContext alloc] init];
    CGSize boundingBox = [str boundingRectWithSize:constraint
                                           options:NSStringDrawingUsesLineFragmentOrigin
                                        attributes:@{NSFontAttributeName:lblInstruction.font}
                                           context:context].size;
    
    size = CGSizeMake(ceil(boundingBox.width), ceil(boundingBox.height));
    
    return size.height;
}

-(IBAction)checkUncheckClicked:(UIButton *)sender
{
    sender.layer.borderColor = [[UIColor clearColor]CGColor];
    sender.selected = !sender.selected;
}

-(void)DynamicAddChildren:(NSInteger)count
{
    int i = 0;
    for (UIView *v in viewChild.subviews) {
        if (i > 1) {
            [v removeFromSuperview];
        }
        i++;
    }
    [self.view layoutIfNeeded];
    [viewChild setHidden:NO];
    
    BOOL relationRequired = [[arr_student_family objectAtIndex:total_count][@"RequiredStudentRelation"] isEqualToString:@"Y"];
    
    viewChildHeight.constant = (count * (relationRequired ? 40 : 20)) + 35;
    
    for (int i = 0; i < count; i++)
    {
        UILabel *lblCname = [[UILabel alloc]initWithFrame:CGRectMake(viewChild.subviews[0].frame.origin.x, (i * (relationRequired ? 40 : 20)) + 25, viewChild.subviews[0].frame.size.width,(relationRequired ? 35 : 20))];
        [lblCname setTextColor:[UIColor blackColor]];
        [lblCname setTextAlignment:NSTextAlignmentLeft];
        [lblCname setFont:FONT_OpenSans(14)];
        [lblCname setText:[[arrStudentList valueForKey:@"Children"] objectAtIndex:i]];
        
        //        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(viewChild.subviews[1].frame.origin.x, lblCname.frame.origin.y, viewChild.subviews[1].frame.size.width,lblCname.frame.size.height)];
        //        [img setImage:[UIImage imageNamed:@"input_box"]];
        
        UITextField *txtCname = [[UITextField alloc]initWithFrame:CGRectMake(viewChild.subviews[1].frame.origin.x, lblCname.frame.origin.y, viewChild.subviews[1].frame.size.width,lblCname.frame.size.height)];
        [txtCname setBorderStyle:UITextBorderStyleNone];
        [txtCname setTextColor:[UIColor blackColor]];
        [txtCname setFont:FONT_OpenSans(14)];
        txtCname.delegate = self;
        txtCname.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
        txtCname.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
        txtCname.leftViewMode = UITextFieldViewModeAlways;
        txtCname.rightViewMode = UITextFieldViewModeAlways;
        txtCname.tag = i;
        txtCname.backgroundColor = [UIColor clearColor];
        txtCname.layer.borderColor = [[UIColor colorWithRed:(10.0/255.0) green:(6.0/255.0) blue:(106.0/255.0) alpha:1.0] CGColor];
        txtCname.layer.borderWidth = 1.0f;
        
        if (count == 1) {
            txtCname.returnKeyType = UIReturnKeyDefault;
        }else{
            if (i == count-1) {
                txtCname.returnKeyType = UIReturnKeyDefault;
            }else{
                txtCname.returnKeyType = UIReturnKeyNext;
            }
        }
        
        if (relationRequired)
        {
            [viewChild.subviews[1] setHidden:NO];
            //            [viewChild addSubview:img];
            [viewChild addSubview:txtCname];
        }
        [viewChild addSubview:lblCname];
    }
}

-(IBAction)btnChecked:(UIButton *)sender
{
    sender.layer.borderColor = [[UIColor clearColor]CGColor];
    sender.selected = !sender.selected;
    
    if (sender.tag == 30)//submit
    {
        [self doneClicked:nil];
        if ([strDocName isEqualToString:@"StudentDoc"])
        {
            if ([self CheckValidation])
            {
                [self LegDoc_Insert_StudentDocDetails_FamilyDocDetails];
            }
        }
        else if ([strDocName isEqualToString:@"Disclaimer"])
        {
            if ([self CheckValidation])
            {
                [self LegDoc_Insert_DisclaimerDtl];
            }
        }
        else
        {
            if ([self CheckValidation])
            {
                [self LegDoc_Insert_StudentDocDetails_FamilyDocDetails];
            }
        }
    }
}

-(BOOL)CheckValidation
{
    dicLegalDoc = [[NSMutableDictionary alloc]init];
    for (UIView *v in self.view.subviews[1].subviews)
    {
        if ([v isKindOfClass:[UIButton class]])
        {
            if (((UIButton *)v).selected == NO && v.tag == 1)
            {
                [((UIScrollView *)self.view.subviews[1])scrollRectToVisible:v.frame animated:YES];
                
                [self view:v :viewDisclaimer.subviews.count > 0 ? @"Please read and check all the checkboxes" : @"Please check the checkbox"];
                return NO;
            }
        }
        else
        {
            if (([v isEqual:viewEmergency] || [v isEqual: viewChild] || [v isEqual:viewDisclaimer]) && v.frame.size.height > 0)
            {
                for (UIView *v1 in v.subviews)
                {
                    if ([v1 isKindOfClass:[UITextField class]])
                    {
                        if(((UITextField *)v1).text.length == 0)
                        {
                            NSString *strMsg = (v == viewEmergency )? [NSString stringWithFormat:@"Emergency %@ detail is missing",[[((UITextField *)v1).placeholder componentsSeparatedByString:@" "] lastObject]] : @"Relation field blank." ;
                            [((UITextField *)v1) becomeFirstResponder];
                            [self view:v1 :strMsg];
                            return NO;
                        }
                        else if ([v isEqual:viewEmergency] && v1.tag == 3 && ((UITextField *)v1).text.length < 14)
                        {
                            [((UITextField *)v1) becomeFirstResponder];
                            [self view:v1 :@"Please insert valid number"];
                            return NO;
                        }
                        if ([v isEqual:viewEmergency]) {
                            [dicLegalDoc setObject:((UITextField *)v1).text forKey:((UITextField *)v1).placeholder];
                        }
                    }
                    else if ([v1 isKindOfClass:[UIButton class]])
                    {
                        if (((UIButton *)v1).selected == NO)
                        {
                            [((UIScrollView *)self.view.subviews[1])scrollRectToVisible:v1.frame animated:YES];
                            
                            [self view:v1 :@"Please read and check all the checkboxes"];
                            return NO;
                        }
                    }
                }
            }
            else if (!([v isKindOfClass:[UILabel class]] || [v isKindOfClass:[UIWebView class]]) && v.frame.size.height > 0)
            {
                if ([v.subviews[1] isKindOfClass:[UITextField class]])
                {
                    if(((UITextField *)v.subviews[1]).text.length == 0)
                    {
                        if ([v isEqual:viewSign])
                        {
                            [((UITextField *)v.subviews[1]) becomeFirstResponder];
                            [self view:v.subviews[1] :@"Please sign the Doc."];
                        }
                        else
                        {
                            [((UITextField *)v.subviews[1]) becomeFirstResponder];
                            [self view:v.subviews[1] :[NSString stringWithFormat:@"Please Enter %@",((UITextField *)v.subviews[1]).placeholder]];
                        }
                        return NO;
                    }
                    [dicLegalDoc setObject:((UITextField *)v.subviews[1]).text forKey:((UITextField *)v.subviews[1]).placeholder];
                }
            }
        }
    }
    return YES;
}

-(void)view:(UIView *)v :(NSString *)msg
{
    v.layer.borderColor = [[UIColor redColor]CGColor];
    v.layer.borderWidth = 1.0f;
    [self doneClicked:nil];
    [[[UIAlertView alloc]initWithTitle:@"" message:msg delegate:nil cancelButtonTitle:@"Close" otherButtonTitles:nil, nil]show];
}

-(IBAction)LogOut:(id)sender
{
    LogoutPopup *lp = [[LogoutPopup alloc] initWithNibName:@"LogoutPopup" bundle:nil];
    lp.ldelegate = self;
    [lp.view setFrame:CGRectMake(lp.view.frame.origin.x, lp.view.frame.origin.y, self.view.frame.size.width - 60, lp.view.frame.size.height)];
    [self presentPopupViewController:lp animationType:MJPopupViewAnimationFade];
}

-(void)Logout:(NSInteger)selectedIndex :(LogoutPopup *)lcvc;
{
    if (selectedIndex == 1)
    {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:FAMILYID];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:TOKEN];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_FIRSTNAME];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_PRIMARYEMAIL];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_ACTIVE];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_LASTNAME];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:WU_PHONE];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:LOGCOUNT];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:REMEMBERME];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:BASKETID];
        
        [SHARED_APPDELEGATE setLoginViewController];
    }
    [lcvc.view removeFromSuperview];
    [self dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    txtfld.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    UIResponder *nextResponder;
    if ([sender.title isEqualToString:@">"])
    {
        UIView *txtfldSuperview = [self.view.subviews[1] viewWithTag:txtfld.superview.tag+1];
        if (txtfld.superview == viewEmergency)
        {
            nextResponder = [txtfld.superview viewWithTag:txtfld.tag+1];
        }
        else
        {
            nextResponder = [txtfldSuperview viewWithTag:0];
        }
    }
    else
    {
        UIView *txtfldSuperview = [self.view.subviews[1] viewWithTag:txtfld.superview.tag-1];
        if (txtfld.superview == viewEmergency)
        {
            nextResponder = [txtfld.superview viewWithTag:txtfld.tag-1];
        }
        else
        {
            nextResponder = [txtfldSuperview viewWithTag:0];
        }
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self resignFirstResponder];
        [self doneClicked:nil];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [txtfld.superview.superview endEditing:YES];
    [((UIScrollView *)txtfld.superview.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)txtfld.superview.superview).contentSize.width - 1,((UIScrollView *)txtfld.superview.superview).contentSize.height - 1, 1, 1) animated:YES];
}

#pragma mark - Keyboard

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)txtfld.superview.superview) setContentInset:contentInsets];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = txtfld.superview.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = txtfld.superview.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:txtfld.superview.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [((UIScrollView *)txtfld.superview.superview) layoutIfNeeded];
    [((UIScrollView *)txtfld.superview.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)txtfld.superview.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)txtfld.superview.superview).contentSize.width - 1,((UIScrollView *)txtfld.superview.superview).contentSize.height - 1, 1, 1) animated:YES];
}

#pragma mark - Webview

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [SHARED_APPDELEGATE showLoadingView];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    //NSString *heightStr = [webView stringByEvaluatingJavaScriptFromString:@"document.body.scrollHeight;"];
    //1630
    //webViewHeight.constant = [heightStr floatValue];
    
    [SHARED_APPDELEGATE hideLoadingView];
    
    [webView setHidden:NO];
    CGRect frame = webView.frame;
    frame.size.height = 1;
    webView.frame = frame;
    CGSize fittingSize = [webView sizeThatFits:CGSizeZero];
    frame.size = fittingSize;
    webView.frame = frame;
    webViewHeight.constant = webView.frame.size.height;
}


#pragma mark - UITextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    txtfld = textField;
    [txtfld becomeFirstResponder];
    if (txtfld.keyboardType == UIKeyboardTypeNumberPad) {
        [self addToolBar];
    }
    txtfld.layer.borderColor = [[UIColor clearColor]CGColor];
    if (txtfld.superview == viewChild) {
        txtfld.layer.borderColor = [[UIColor colorWithRed:(10.0/255.0) green:(6.0/255.0) blue:(106.0/255.0) alpha:1.0] CGColor];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    txtfld = textField;
    if (txtfld.returnKeyType == UIReturnKeyDefault) {
        [textField resignFirstResponder];
        [self doneClicked:nil];
        return YES;
    }
    
    UIView *txtfldSuperview = [self.view.subviews[1] viewWithTag:textField.superview.tag+1];
    
    UIResponder *nextResponder;
    if (textField.superview == viewEmergency || textField.superview == viewChild)
    {
        nextResponder = [textField.superview viewWithTag:textField.tag+1];
    }
    else
    {
        nextResponder = [txtfldSuperview viewWithTag:0];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [textField resignFirstResponder];
        [self doneClicked:nil];
        return YES;
    }
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return (txtfld.keyboardType == UIKeyboardTypeNumberPad) ? [CommonClass Textfield:textField :range] : YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
