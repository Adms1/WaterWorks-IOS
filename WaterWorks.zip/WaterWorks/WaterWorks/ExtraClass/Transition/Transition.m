//
//  Transition.m
//  WaterWorks
//
//  Created by Ankit on 18/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "Transition.h"
#import "ARTransitionAnimator.h"

@interface Transition ()
@property (nonatomic, strong) ARTransitionAnimator *transitionAnimator;
@end

@implementation Transition

- (void)viewDidLoad {
    [super viewDidLoad];
    self.transitionAnimator = [[ARTransitionAnimator alloc] init];
    self.transitionAnimator.transitionDuration = 0.5;
    self.transitionAnimator.transitionStyle = ARTransitionStyleMaterial;
    self.navigationController.delegate = self.transitionAnimator;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
