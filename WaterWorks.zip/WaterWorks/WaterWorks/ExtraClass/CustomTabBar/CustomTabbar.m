//
//  CustomTabbar.m
//  WaterWorks
//
//  Created by Ankit on 18/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CustomTabbar.h"
#import "SLViewController.h"
#import "ScheduleMakeupViewController.h"
#import "BuyLessonsViewController.h"
#import "OtherViewController.h"
#import "UpComingMeetViewController.h"
#import "RegisterViewController.h"
#import "TrophyRoomViewController.h"

@implementation CustomTabbar

static float iphone_height = 40.0f;
//static float ipad_height   = 60.0f;

- (id)initWithRect:(CGRect)frame :(NSArray *)array :(UIViewController *)vc :(int)idx :(int)Count
{
    viewController = vc;
    
    self = [super initWithFrame:frame];
    
    UIView *tabView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, iphone_height)];
    tabView.backgroundColor = Top_Color;
    [self addSubview:tabView];
    
    CGFloat width = self.frame.size.width/array.count;
    for (int i = 0; i < array.count; i++)
    {
        UIButton *tabBtn = [[UIButton alloc]initWithFrame:CGRectMake(i*width, 0, width, tabView.frame.size.height)];
        [tabBtn setTitle:[array objectAtIndex:i] forState:0];
        [tabBtn setTitleColor:[UIColor whiteColor] forState:0];
        tabBtn.titleLabel.font = FONT_Semibold(12);
        tabBtn.tag = i;
        [tabBtn addTarget:self action:@selector(btnSelected:) forControlEvents:UIControlEventTouchUpInside];
        
        [tabView addSubview:tabBtn];
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake((i*width) + width - 28, 12, 18, 18)];
        [btn setTitle:[NSString stringWithFormat:@"%d",Count] forState:0];
        [btn setTitleColor:Top_Color forState:0];
        btn.titleLabel.font = FONT_Semibold(10);
        btn.tag = i;
        [btn setBackgroundColor:botomColor];
        btn.layer.cornerRadius = 9;
        btn.layer.masksToBounds = YES;
        if (Count > 0 && i == array.count -1) {
            [tabView addSubview:btn];
        }
    }
    
    for (int i = 0; i < array.count-1; i++)
    {
        UIView *seperatorView = [[UIView alloc]initWithFrame:CGRectMake((i+1)*width, 0, 1, tabView.frame.size.height)];
        seperatorView.backgroundColor = [UIColor whiteColor];
        [self addSubview:seperatorView];
    }
    
    stripeView = [[UIView alloc]initWithFrame:CGRectMake(idx*width, tabView.frame.size.height-3, width, 3)];
    stripeView.backgroundColor = botomColor;
    [self addSubview:stripeView];
    
    return self;
}

-(IBAction)btnSelected:(UIButton *)sender
{
    str = sender.titleLabel.text;
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    if ([str containsString:@"Schedule Lessons"])
    {
        if (![viewController isKindOfClass:[SLViewController class]] && ![viewController isKindOfClass:[ScheduleMakeupViewController class]])
        {
            [self showPopup];
        }
        else
        {
            [self changeStripePosition:sender];
            SLViewController *slvc = [[SLViewController alloc] initWithNibName:@"SLViewController" bundle:nil];
            [viewController.navigationController pushViewController:slvc animated:YES];
        }
    }
    else if ([str containsString:@"Schedule Makeup"])
    {
        if (![viewController isKindOfClass:[ScheduleMakeupViewController class]] && ![viewController isKindOfClass:[SLViewController class]])
        {
            [self showPopup];
        }
        else
        {
            [self changeStripePosition:sender];
            ScheduleMakeupViewController *smvc = [[ScheduleMakeupViewController alloc] initWithNibName:@"ScheduleMakeupViewController" bundle:nil];
            [viewController.navigationController pushViewController:smvc animated:YES];
        }
    }
    else if ([str containsString:@"Swim Lessons"] || [str containsString:@"Retail Store"])
    {
        [self changeStripePosition:sender];
        BuyLessonsViewController *buylvc = [[BuyLessonsViewController alloc] initWithNibName:@"BuyLessonsViewController" bundle:nil];
        if ([sender.titleLabel.text containsString:@"Swim Lessons"])
        {
            buylvc.strType = @"Buy";
        }
        else
        {
            buylvc.strType = @"Retail";
        }
        buylvc.FromComfirmSchedule = NO;
        [viewController.navigationController pushViewController:buylvc animated:YES];
    }
    else if ([str containsString:@"Other Programs"])
    {
        [self changeStripePosition:sender];
        OtherViewController *othervc = [[OtherViewController alloc] initWithNibName:@"OtherViewController" bundle:nil];
        [viewController.navigationController pushViewController:othervc animated:YES];
    }
    else if ([str containsString:@"Upcoming"] || [str containsString:@"Today"])
    {
        [self changeStripePosition:sender];
        UpComingMeetViewController *upvc = [[UpComingMeetViewController alloc] initWithNibName:@"UpComingMeetViewController" bundle:nil];
        [viewController.navigationController pushViewController:upvc animated:YES];
    }
    else if ([str containsString:@"Register"])
    {
        [self changeStripePosition:sender];
        RegisterViewController *rvc = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:nil];
        rvc.strSwimCopatitionProgramID = @"1";
        [viewController.navigationController pushViewController:rvc animated:YES];
    }
    else
    {
        [self changeStripePosition:sender];
        TrophyRoomViewController *trvc = [[TrophyRoomViewController alloc] initWithNibName:@"TrophyRoomViewController" bundle:nil];
        [viewController.navigationController pushViewController:trvc animated:YES];
    }
}

-(void)showPopup
{
    PopupView *pv = [[PopupView alloc] initWithNibName:@"PopupView" bundle:nil];
    pv.p_delegate = self;
    pv.check = YES;
    pv.strBtnText = @"Yes";
    pv.strMsgText = @"Do you want to discontinue the scheduling process?";
    pv.strTitleText = @"Warning";
    [pv.view setFrame:CGRectMake(pv.view.frame.origin.x, pv.view.frame.origin.y, self.superview.frame.size.width - 40, pv.view.frame.size.height)];
    [viewController presentPopupViewController:pv animationType:MJPopupViewAnimationFade];
}

-(void)Continue_GoBack:(PopupView *)popup :(UIButton *)sender :(NSInteger)tag
{
    if (sender.tag == 0) {
        [self changeStripePosition:sender];
        if ([str containsString:@"Schedule Lessons"])
        {
            SLViewController *slvc = [[SLViewController alloc] initWithNibName:@"SLViewController" bundle:nil];
            [viewController.navigationController pushViewController:slvc animated:YES];
        }
        else
        {
            ScheduleMakeupViewController *smvc = [[ScheduleMakeupViewController alloc] initWithNibName:@"ScheduleMakeupViewController" bundle:nil];
            [viewController.navigationController pushViewController:smvc animated:YES];
        }
    }
    [popup.view removeFromSuperview];
    [viewController dismissPopupViewControllerWithanimationType:MJPopupViewAnimationFade];
}

-(void)changeStripePosition:(UIButton *)btn
{
    [UIView animateWithDuration:0.3 animations:^{
        [stripeView setFrame:CGRectMake(btn.frame.origin.x, stripeView.frame.origin.y, stripeView.frame.size.width, stripeView.frame.size.height)];
    }];
}
@end
