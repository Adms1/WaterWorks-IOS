//
//  CustomTabbar.h
//  WaterWorks
//
//  Created by Ankit on 18/04/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopupView.h"

@interface CustomTabbar : UIView<PopupViewDelegate>
{
    UIView *stripeView;
    UIViewController *viewController;
    NSString *str;
}
- (id)initWithRect:(CGRect)frame :(NSArray *)array :(UIViewController *)vc :(int)idx :(int)Count;
@end
