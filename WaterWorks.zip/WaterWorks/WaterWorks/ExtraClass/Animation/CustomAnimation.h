//
//  CustomAnimation.h
//  WaterWorks
//
//  Created by ADMS on 26/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CustomAnimation : NSObject

+(void)SlideUp:(UIView *)animatedView:(float)duration;
+(void)SlideCellDown:(UIView *)animatedView;
+(void)Transform:(UIView *)animatedView;

@end
