//
//  CustomAnimation.m
//  WaterWorks
//
//  Created by ADMS on 26/06/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "CustomAnimation.h"

@implementation CustomAnimation

+(void)SlideUp:(UIView *)animatedView:(float)duration
{
    //    CGFloat height = animatedView.frame.size.height;
    //    animatedView.frame = CGRectMake(animatedView.frame.origin.x, animatedView.frame.size.height, animatedView.frame.size.width, 0);
    //    [UIView animateWithDuration:1.0
    //                          delay:0.1
    //                        options: UIViewAnimationOptionCurveLinear
    //                     animations:^{
    //                         animatedView.frame = CGRectMake(animatedView.frame.origin.x, animatedView.frame.origin.y - height + 50, animatedView.frame.size.width, height);
    //                     }completion:nil];
    
    CGFloat height = animatedView.frame.size.height;
    animatedView.frame = CGRectMake(animatedView.frame.origin.x, animatedView.frame.size.height + animatedView.frame.origin.y, animatedView.frame.size.width, 0);
    [UIView animateWithDuration:duration
                          delay:0.1
                        options: UIViewAnimationOptionCurveLinear
                     animations:^{
                         animatedView.frame = CGRectMake(animatedView.frame.origin.x, animatedView.frame.origin.y - height, animatedView.frame.size.width, height);
                     }completion:nil];
}

+(void)SlideCellDown:(UIView *)animatedView
{
    animatedView.frame = CGRectMake(animatedView.frame.origin.x, animatedView.frame.origin.y, animatedView.frame.size.width, 0);
    [UIView animateWithDuration:1.0
                          delay:1.0
                        options: UIViewAnimationOptionCurveLinear
                     animations:^{
                     }completion:nil];
}

+(void)Transform:(UIView *)animatedView
{
    animatedView.transform = CGAffineTransformMakeTranslation(0,animatedView.frame.size.height);
    
    [UIView animateWithDuration:1.0f animations:^{
        animatedView.transform = CGAffineTransformMakeTranslation(0,0);
    }completion:nil];
}
@end
