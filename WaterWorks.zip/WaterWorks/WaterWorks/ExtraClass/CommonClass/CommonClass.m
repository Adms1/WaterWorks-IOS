//
//  CommonClass.m
//  Viewfoo
//
//  Created by MitulB on 22/05/15.
//  Copyright (c) 2015 com. All rights reserved.
//

#import "CommonClass.h"
#import "AppDelegate.h"
#import "KSToastView.h"
#import "OtherViewController.h"

AppDelegate *appDelegate;
NSInteger previous;
NIDropDown *dropDown;
UIButton *btnSite;
NSArray *arrSite;
UIView *scrollToview,*vStripe;
UIScrollView *scrollHeader;

@implementation CommonClass

+(CommonClass *)shareObject
{
    appDelegate  = [AppDelegate sharedAppDelegate];
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

+(NSString *)trimString:(NSString *)string
{
    return [string stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceCharacterSet]];
}

+ (BOOL)textIsValidEmailFormat:(NSString *)text {
    
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:text];
}

+(NSString *) removeNull:(NSString *) string
{
    if (string.length == 0)
    {
        string = @"";
    }
    NSRange range = [string rangeOfString:@"null"];
    if (range.length > 0 || string == nil)
    {
        string = @"";
    }
    string = [self trimString:string];
    return string;
}

+(void)showAlertWithTitle:(NSString *)strTitle andMessage:(NSString *)strMessage delegate:(id)delegate
{
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:strTitle
                                          message:strMessage
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction *action)
                                   {
                                       NSLog(@"Cancel action");
                                       
                                   }];
    [alertController addAction:cancelAction];
    [delegate presentViewController:alertController animated:YES completion:nil];
}

+(void)showToastMsg:(NSString *)strMsg
{
    [KSToastView ks_showToast:strMsg duration:2.0];
}

+(BOOL)complareTwoString:(NSString *)str1 :(NSString *)str2
{
    if (str1 == nil) {
        return NO;
    }
    if (str2 == nil) {
        return NO;
    }
    if([str1 caseInsensitiveCompare:str2] == NSOrderedSame) {
        return YES;
    }
    return NO;
}

+ (BOOL)Textfield:(UITextField *)textField :(NSRange)range
{
    int length = (int)[self getLength:textField.text];
    
    if(length == 10)
    {
        if(range.length == 0)
            return NO;
    }
    
    if(length == 3)
    {
        NSString *num = [self formatNumber:textField.text];
        textField.text = [NSString stringWithFormat:@"(%@) ",num];
        
        if(range.length > 0)
            textField.text = [NSString stringWithFormat:@"%@",[num substringToIndex:3]];
    }
    else if(length == 6)
    {
        NSString *num = [self formatNumber:textField.text];
        textField.text = [NSString stringWithFormat:@"(%@) %@-",[num  substringToIndex:3],[num substringFromIndex:3]];
        
        if(range.length > 0)
            textField.text = [NSString stringWithFormat:@"(%@) %@",[num substringToIndex:3],[num substringFromIndex:3]];
    }
    return YES;
}

+ (NSString *)formatNumber:(NSString *)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    NSLog(@"%@", mobileNumber);
    
    int length = (int)[mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
        NSLog(@"%@", mobileNumber);
        
    }
    
    return mobileNumber;
}

+ (int)getLength:(NSString *)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = (int)[mobileNumber length];
    
    return length;
}

+ (NSString *)CalculateAge:(NSString *)birthDate
{
    NSDate* todayDate = [NSDate date];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"MMM dd,yyyy"];
    int time = [todayDate timeIntervalSinceDate:[format dateFromString:birthDate]];
    int allDays = (((time/60)/60)/24);
    int days = allDays%365;
    int years = (allDays-days)/365;
    
    float extraDays = (float)days/(float)365;
    float result = years + extraDays;
    return [NSString stringWithFormat:@"%.3f",result];
}

+ (NSString *) stringByStrippingHTML :(NSString *)str {
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+>" options:NSRegularExpressionSearch]).location != NSNotFound)
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    return str;
}

+(NSString *)clearString:(NSString *)stringToClear {
    NSMutableString *clearString = [stringToClear mutableCopy];
    NSRegularExpression *regex = [NSRegularExpression
                                  regularExpressionWithPattern:@"\\[.+?\\]"
                                  options:NSRegularExpressionCaseInsensitive
                                  error:NULL];
    [regex replaceMatchesInString:clearString
                          options:0
                            range:NSMakeRange(0, [clearString length])
                     withTemplate:@""];
    return  clearString;
}

+ (void)getSiteByFamily:(void (^)(BOOL ,NSDictionary*))handler
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults] objectForKey:TOKEN],
                             };
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:Schl_Get_SiteByFamily_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"RESPONSE  %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            handler(YES,responseObject);
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        handler(NO,responseObject);
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        handler(NO,nil);
        
        NSLog(@"Error: %@", error);
    }];
    
}

+ (void)setGetBasketID:(void (^)(BOOL ))handler
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSDictionary *params = @{
                             @"Token":[[NSUserDefaults standardUserDefaults]objectForKey:TOKEN],
                             @"SiteID":[[NSUserDefaults standardUserDefaults] valueForKey:SITEID]
                             };
    
    [manager POST:basketId_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"Response %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrBasketID = [responseObject safeObjectForKey:@"BasketDtl"];
            
            NSDictionary *dict = [arrBasketID firstObject];
            
            NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
            
            [userDefault setObject:[dict safeObjectForKey:@"Basketid"] forKey:BASKETID];
            
            [SHARED_APPDELEGATE hideLoadingView];
            handler(YES);
        }
        
        [SHARED_APPDELEGATE hideLoadingView];
        handler(NO);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        handler(NO);
        NSLog(@"Error: %@", error);
    }];
}

+ (UIView *)dynamicAddChild:(UIScrollView *)scroll_header scrollToview:(UIView *)view :(id<CommonDelegate>)delegate
{
    [[self shareObject]setCc_delegate:delegate];
    scrollToview = view;
    scrollHeader = scroll_header;
    
    vStripe = [[UIView alloc]init];
    vStripe.backgroundColor = [UIColor colorWithRed:(247.0/255.0) green:(133.0/255.0) blue:(44.0/255.0) alpha:1.0];
    vStripe.tag = -1;
    [scroll_header addSubview:vStripe];
    
    for (int x = 0; x < SHARED_APPDELEGATE.arrStudentName.count; x++)
    {
        CGFloat btnwidth = ((scroll_header.superview.frame.size.width - 10)/SHARED_APPDELEGATE.arrStudentName.count);
        if (btnwidth < 80)
        {
            btnwidth = 80.0;
        }
        
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(x * btnwidth, 0, btnwidth, 25)];
        btn.backgroundColor = [UIColor clearColor];
        
        if (x == 0)
        {
            [btn setTitleColor:botomColor forState:0];
        }
        else
        {
            [btn setTitleColor:Top_Color forState:0];
        }
        
        [btn.titleLabel setFont:FONT_Bold(13)];
        [btn setTitle:[[[SHARED_APPDELEGATE.arrStudentName objectAtIndex:x] componentsSeparatedByString:@" "] firstObject] forState:0];
        btn.tag = x;
        
        [btn addTarget:self action:@selector(Btn:) forControlEvents:UIControlEventTouchUpInside];
        
        UIView *v = [[UIView alloc]initWithFrame:CGRectMake(btn.frame.origin.x, btn.frame.origin.y, btn.frame.size.width, 30)];
        v.tag = (x+1)*100;
        [scroll_header addSubview:v];
        
        [scroll_header addSubview:btn];
        [scroll_header setContentSize:CGSizeMake((btnwidth * SHARED_APPDELEGATE.arrStudentName.count), scroll_header.frame.size.height)];
        
        CGSize stringsize = [[SHARED_APPDELEGATE.arrStudentName objectAtIndex:0] sizeWithAttributes:@{NSFontAttributeName:FONT_Bold(13)}];
        [vStripe setFrame:CGRectMake((btnwidth/2) - (stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20)/2, 27, stringsize.width + 20 > btnwidth ? btnwidth : stringsize.width + 20, 3)];
    }
    return vStripe;
}

+ (void)Btn:(UIButton *)button
{
    /*
     */
    
    if ([self shareObject].cc_delegate && [[self shareObject].cc_delegate respondsToSelector:@selector(btnSelectStudent:)])
    {
        [[self shareObject].cc_delegate btnSelectStudent:button];
    }
}


+ (void)setLocation:(NSArray *)arrLocation :(UIButton *)btnLocation :(UIButton *)sender :(id<CommonDelegate>)delegate
{
    arrSite = arrLocation;
    btnSite = btnLocation;
    [[self shareObject]setCc_delegate:delegate];
    
    if(dropDown == nil) {
        CGFloat f = 300;
        NSArray *arr = [arrLocation valueForKey:@"sitename"];
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = [self shareObject];
        dropDown.tag = 1000;
    }
    else {
        [dropDown hideDropDown:sender];
        [[self shareObject] rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

- (void)select:(UIButton *)sender :(NSInteger) idx
{
    [btnSite setTitle:[[arrSite valueForKey:@"sitename"] objectAtIndex:idx] forState:0];
    if (btnSite != sender) {
        [sender setTitle:@"" forState:0];
    }
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:[[arrSite valueForKey:@"sitename"] objectAtIndex:idx] forKey:SITENAME];
    [userDefault setObject:[[arrSite valueForKey:@"siteid"] objectAtIndex:idx] forKey:SITEID];
    //[userDefault setObject:[[arrSite valueForKey:@"Lafitness"] objectAtIndex:idx] forKey:LAFITNESS];
    
    if (self.cc_delegate && [self.cc_delegate respondsToSelector:@selector(performAction::)])
    {
        [self.cc_delegate performAction:idx :sender];
    }
}

-(void)rel{
    dropDown = nil;
}

+ (void)setNavigationTitle:(NSString *)headerTitle :(UIViewController *)vc :(UIButton *)btnHome :(UIButton *)btnCart :(BOOL)flag :(id<CommonDelegate>)delegate
{
    [[self shareObject]setCc_delegate:delegate];
    vc.navigationItem.titleView = [SHARED_APPDELEGATE getNavigationWithTitle:headerTitle fontSize:16];
    
    vc.navigationController.navigationBar.layer.shadowColor = [[UIColor clearColor] CGColor];
    vc.navigationController.navigationBar.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    vc.navigationController.navigationBar.layer.shadowRadius = 0.0f;
    vc.navigationController.navigationBar.layer.shadowOpacity = 0.0f;
    
    /*
     ----------------Back Button----------------
     */
    
    UIImage *backButtonImage = [UIImage imageNamed:@"Back"];
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:backButtonImage
                forState:UIControlStateNormal];
    backButton.frame = CGRectMake(0, 0, backButtonImage.size.width, backButtonImage.size.height);
    [backButton addTarget:self
                   action:@selector(onClickBackBtn)
         forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    if (flag) {
        vc.navigationItem.leftBarButtonItem = backBarButtonItem;
    }
    
    /*
     ----------------Home & Cart----------------
     */
    
    UIBarButtonItem *barBtnhome = [[UIBarButtonItem alloc] initWithCustomView:btnHome];
    [btnHome addTarget:self action:@selector(onClickHomeBtn) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *barBtnCart = [[UIBarButtonItem alloc] initWithCustomView:btnCart];
    
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -6;
    
    vc.navigationItem.rightBarButtonItems = @[negativeSpacer,barBtnhome, barBtnCart];
}

+ (void)onClickBackBtn
{
    if ([self shareObject].cc_delegate && [[self shareObject].cc_delegate respondsToSelector:@selector(popViewController)])
    {
        [[self shareObject].cc_delegate popViewController];
    }
}

+ (void)onClickHomeBtn
{
    SHARED_APPDELEGATE.IsPlaceOrder = NO;
    [SHARED_APPDELEGATE setHomeViewController];
}



+ (NSString *)extractYoutubeIdFromLink:(NSString *)link {
    
    NSString *regexString = @"((?<=(v|V)/)|(?<=be/)|(?<=(\\?|\\&)v=)|(?<=embed/))([\\w-]++)";
    NSRegularExpression *regExp = [NSRegularExpression regularExpressionWithPattern:regexString
                                                                            options:NSRegularExpressionCaseInsensitive
                                                                              error:nil];
    
    NSArray *array = [regExp matchesInString:link options:0 range:NSMakeRange(0,link.length)];
    if (array.count > 0) {
        NSTextCheckingResult *result = array.firstObject;
        return [link substringWithRange:result.range];
    }
    return nil;
}

+ (BOOL)validateUrl: (NSString *) candidate {
    NSString *urlRegEx =
    @"((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}

+ (NSString*)generateFileNameWithExtension:(NSString *)extensionString
{
    // Extenstion string is like @".png"
    
    NSDate *time = [NSDate date];
    NSDateFormatter* df = [NSDateFormatter new];
    [df setDateFormat:@"dd-MM-yyyy-hh-mm-ss"];
    NSString *timeString = [df stringFromDate:time];
    int r = arc4random() % 100;
    int d = arc4random() % 100;
    NSString *fileName = [NSString stringWithFormat:@"File-%@%d%d%@", timeString, r , d , extensionString ];
    
    NSLog(@"FILE NAME %@", fileName);
    
    return fileName;
}

@end
