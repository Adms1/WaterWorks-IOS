//
//  CommonClass.h
//  Viewfoo
//
//  Created by MitulB on 22/05/15.
//  Copyright (c) 2015 com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NIDropDown.h"

@protocol CommonDelegate <NSObject>

@optional
-(void)popViewController;
-(void)btnSelectStudent:(UIButton *)sender;
-(void)performAction:(NSInteger)idx :(UIButton *)btn;

@end

@interface CommonClass : NSObject <NIDropDownDelegate>

+(CommonClass *)shareObject;

+(NSString *)trimString:(NSString *)string;
+(NSString *) removeNull:(NSString *) string;
+ (BOOL)textIsValidEmailFormat:(NSString *)text;
+(void)showAlertWithTitle:(NSString *)strTitle andMessage:(NSString *)strMessage delegate:(id)delegate;
+(void)showToastMsg:(NSString *)strMsg;
+(BOOL)complareTwoString:(NSString *)str1 :(NSString *)str2;
+ (BOOL)Textfield:(UITextField *)textField :(NSRange)range;
+ (NSString *)formatNumber:(NSString *)mobileNumber;
+ (int)getLength:(NSString *)mobileNumber;
+ (NSString *)CalculateAge:(NSString *)birthDate;
+ (NSString *) stringByStrippingHTML :(NSString *)str;
+(NSString *)clearString:(NSString *)stringToClear;

//-----------------
+ (void)getSiteByFamily:(void (^)(BOOL ,NSDictionary*))handler;
+ (void)setGetBasketID:(void (^)(BOOL ))handler;
+ (UIView *)dynamicAddChild:(UIScrollView *)scroll_header scrollToview:(UIView *)view :(id<CommonDelegate>)delegate;
+ (void)setLocation:(NSArray *)arrLocation :(UIButton *)btnLocation :(UIButton *)sender :(id<CommonDelegate>)delegate;
+ (void)setNavigationTitle:(NSString *)headerTitle :(UIViewController *)vc :(UIButton *)btnHome :(UIButton *)btnCart :(BOOL)flag :(id<CommonDelegate>)delegate;

//-----------------
+ (NSString *)extractYoutubeIdFromLink:(NSString *)link;
+ (BOOL)validateUrl: (NSString *) candidate;
+ (NSString*)generateFileNameWithExtension:(NSString *)extensionString;

@property(nonatomic,retain)id<CommonDelegate>cc_delegate;

@end
