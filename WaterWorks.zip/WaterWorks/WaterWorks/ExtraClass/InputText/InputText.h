//
//  InputText.h
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

extern CGSize keyboardActualSize;
@interface InputText : UITextField <UITextFieldDelegate>
{
    UITextField* activeField;
}
@end
