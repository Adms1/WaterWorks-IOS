
//
//  InputText.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InputText.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@implementation InputText

-(void)awakeFromNib{
    
    [super awakeFromNib];
    self.delegate = self;
    self.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    self.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    self.leftViewMode = UITextFieldViewModeAlways;
    self.rightViewMode = UITextFieldViewModeAlways;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShown:)
                                                 name:UIKeyboardWillShowNotification object:nil];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillBeHidden:)
//                                                 name:UIKeyboardWillHideNotification object:nil];
    
    if ((self.keyboardType == UIKeyboardTypeNumberPad) | (self.keyboardType == UIKeyboardTypePhonePad)) {
        [self addToolBar];
    }
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    self.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = self.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [self.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [self.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self doneClicked:nil];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [self resignFirstResponder];
    [((UIScrollView *)self.superview) setContentInset:UIEdgeInsetsZero];
    [((UIScrollView *)self.superview) setScrollIndicatorInsets:UIEdgeInsetsZero];
    [((UIScrollView *)self.superview) scrollRectToVisible:CGRectMake(((UIScrollView *)self.superview).contentSize.width - 1,((UIScrollView *)self.superview).contentSize.height - 1, 1, 1) animated:YES];
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    [((UIScrollView *)self.superview) setContentInset:contentInsets];
    [((UIScrollView *)self.superview) setScrollIndicatorInsets:contentInsets];
    
    CGRect frame = self.superview.frame;
    frame.size.height -= kbSize.height;
    CGPoint fOrigin = activeField.frame.origin;
    if (!CGRectContainsPoint(frame, fOrigin) ) {
        [((UIScrollView *)self.superview) scrollRectToVisible:activeField.frame animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [self doneClicked:nil];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    activeField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    activeField.layer.borderWidth = 0.5f;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (self.keyboardType == UIKeyboardTypeNumberPad && range.location > 5)
    {
        return NO;
    }
    else if (textField.superview.tag == 100 && self.keyboardType == UIKeyboardTypePhonePad && textField.tag != 5)
    {
        return [CommonClass Textfield:textField :range];
    }
    return YES;
}


//- (void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    if ([textField.superview isKindOfClass:[UIScrollView  class]]) {
//        [((UIScrollView *)textField.superview)setContentOffset:CGPointMake(0, textField.frame.origin.y-textField.frame.size.height*2) animated:YES];
//    }
//    [textField becomeFirstResponder];
//}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self doneClicked:nil];
        return YES;
    }
    return NO;
}
@end
