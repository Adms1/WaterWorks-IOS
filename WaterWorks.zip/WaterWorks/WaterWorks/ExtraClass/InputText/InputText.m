
//
//  InputText.m
//  WaterWorks
//
//  Created by Ankit on 16/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InputText.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@implementation InputText

CGSize keyboardActualSize;
-(void)awakeFromNib{
    
    [super awakeFromNib];
    self.delegate = self;
    self.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    self.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    self.leftViewMode = UITextFieldViewModeAlways;
    self.rightViewMode = UITextFieldViewModeAlways;
    
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //                                             selector:@selector(keyboardWillShown:)
    //                                                 name:UIKeyboardWillShowNotification object:nil];
    //
    //    [[NSNotificationCenter defaultCenter] addObserver:self
    //                                             selector:@selector(keyboardWillBeHidden:)
    //                                                 name:UIKeyboardWillHideNotification object:nil];
    
    if ((self.keyboardType == UIKeyboardTypeNumberPad) | (self.keyboardType == UIKeyboardTypePhonePad)) {
        [self addToolBar];
    }
}

-(void)addToolBar
{
    UIToolbar *keyboardtoolBar = [[UIToolbar alloc] init];
    [keyboardtoolBar sizeToFit];
    keyboardtoolBar.barTintColor = Top_Color;
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneClicked:)];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@">" style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    //    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Previous"] style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    //    leftButton.tag = -1;
    //    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Arrows"] style:UIBarButtonItemStylePlain target:self action:@selector(previous_next_Clicked:)];
    //    rightButton.tag = 1;
    UIBarButtonItem *flexiblespace =                                 [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [keyboardtoolBar setItems:[NSArray arrayWithObjects:leftButton,rightButton,flexiblespace,doneButton, nil]];
    
    self.inputAccessoryView = keyboardtoolBar;
}

- (void)previous_next_Clicked:(UIBarButtonItem *)sender
{
    NSInteger nextTag = self.tag;
    UIResponder *nextResponder;
    
    if ([sender.title isEqualToString:@">"])
    {
        nextResponder = [self.superview viewWithTag:nextTag+1];
    }
    else
    {
        nextResponder = [self.superview viewWithTag:nextTag-1];
    }
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self doneClicked:nil];
    }
}

- (void)doneClicked:(id)sender
{
    NSLog(@"Done Clicked.");
    [self resignFirstResponder];
    if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview isKindOfClass:[UIScrollView classForCoder]])
    {
        UIScrollView *scrollView;
        {
            if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview;
            }
            else if([self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview.superview;
            }else {
                scrollView = (UIScrollView *)self.superview;
            }
        }
        
        [scrollView setContentOffset:CGPointZero animated:YES];
        [scrollView setContentInset:UIEdgeInsetsZero];
        [scrollView setScrollIndicatorInsets:UIEdgeInsetsZero];
        [scrollView scrollRectToVisible:CGRectMake(scrollView.contentSize.width - 1,scrollView.contentSize.height - 1, 1, 1) animated:YES];
    }
}

#pragma mark - UITextField Delegate

- (void)keyboardWillShown:(NSNotification*)aNotification
{
    //    NSDictionary* info = [aNotification userInfo];
    //    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    //    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0, 0,kbSize.height + 10, 0);
    //    [((UIScrollView *)self.superview) setContentInset:contentInsets];
    //    [((UIScrollView *)self.superview) setScrollIndicatorInsets:contentInsets];
    //
    //    CGRect frame = self.superview.frame;
    //    frame.size.height -= kbSize.height;
    //    CGPoint fOrigin = activeField.frame.origin;
    //    if (!CGRectContainsPoint(frame, fOrigin) ) {
    //        [((UIScrollView *)self.superview) scrollRectToVisible:activeField.frame animated:YES];
    //    }
    
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    if(kbSize.height > 0)
    {
        keyboardActualSize = kbSize;
    }
    
    if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview isKindOfClass:[UIScrollView classForCoder]])
    {
        UIScrollView *scrollView;
        {
            if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview;
            }
            else if([self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview.superview;
            }else {
                scrollView = (UIScrollView *)self.superview;
            }
        }
        
        CGFloat compareValue = activeField.frame.origin.y;
        if(compareValue > keyboardActualSize.height) {
            [scrollView setContentOffset:CGPointMake(0, compareValue - keyboardActualSize.height) animated:YES];
        }
        else {
            [scrollView setContentOffset:CGPointZero animated:YES];
        }
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    [self doneClicked:nil];
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    activeField = textField;
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    activeField = textField;
    activeField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    activeField.layer.borderWidth = 0.5f;
    
    if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]] || [self.superview isKindOfClass:[UIScrollView classForCoder]])
    {
        UIScrollView *scrollView;
        {
            if([self.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview;
            }
            else if([self.superview.superview.superview isKindOfClass:[UIScrollView classForCoder]]) {
                scrollView = (UIScrollView *)self.superview.superview.superview;
            }else {
                scrollView = (UIScrollView *)self.superview;
            }
        }
        
        CGFloat compareValue = activeField.frame.origin.y;
        if(compareValue > (isiPhone5 ? 200 : 250)) {
            [scrollView setContentOffset:CGPointMake(0, compareValue - (isiPhone5 ? 200 : 250)) animated:YES];
        }
        else {
            [scrollView setContentOffset:CGPointZero animated:YES];
        }
    }
    
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShown:)name:UIKeyboardWillShowNotification object:nil];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    activeField = nil;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (self.keyboardType == UIKeyboardTypeNumberPad && range.location > 5)
    {
        return NO;
    }
    else if (textField.superview.tag == 100 && self.keyboardType == UIKeyboardTypePhonePad && textField.tag != 5)
    {
        return [CommonClass Textfield:textField :range];
    }
    return YES;
}


//- (void)textFieldDidBeginEditing:(UITextField *)textField
//{
//    if ([textField.superview isKindOfClass:[UIScrollView  class]]) {
//        [((UIScrollView *)textField.superview)setContentOffset:CGPointMake(0, textField.frame.origin.y-textField.frame.size.height*2) animated:YES];
//    }
//    [textField becomeFirstResponder];
//}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag;
    UIResponder *nextResponder = [textField.superview viewWithTag:nextTag+1];
    
    if (nextResponder)
    {
        [nextResponder becomeFirstResponder];
    }
    else
    {
        [self doneClicked:nil];
        return YES;
    }
    return NO;
}
@end
