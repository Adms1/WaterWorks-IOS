//
//  PastDuePopUp.h
//  WaterWorks
//
//  Created by Ankit on 03/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PastDuePopUp;

@protocol PastDueDelegate <NSObject>
-(void)RemovePopup:(PastDuePopUp *)popup;
@end
@interface PastDuePopUp : UIViewController
{
    IBOutlet UILabel *lblMsg;
    IBOutlet UIButton *btnOk;
}
@property(nonatomic,assign)NSString *strMsg;
@property(nonatomic,retain)id<PastDueDelegate>pd_delegate;
@end
