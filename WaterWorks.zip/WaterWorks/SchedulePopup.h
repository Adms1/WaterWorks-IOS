//
//  SchedulePopup.h
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SchedulePopup;

@protocol SchedulePopupDelegate <NSObject>
-(void)Continue:(SchedulePopup *)popup;
@end
@interface SchedulePopup : UIViewController
@property (assign, nonatomic) id <SchedulePopupDelegate> s_delegate;
@property (assign, nonatomic) NSString *title_msg;
@property (assign, nonatomic) NSString *msg;
@property (assign, nonatomic) NSString *btn_msg;
@property (assign, nonatomic)IBOutlet UILabel *lbl_msg;
@property (assign, nonatomic)IBOutlet UILabel *lbl_header;
@property (assign, nonatomic)IBOutlet UIButton *btnOK;
@end
