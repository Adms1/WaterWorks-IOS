//
//  TrophiesData.m
//  WaterWorks
//
//  Created by Ankit on 03/05/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "TrophiesData.h"

@implementation TrophiesData
@synthesize participation,timeimprovement,totalribbons;
@end
