//
//  SchedulePopup.m
//  WaterWorks
//
//  Created by Ankit on 03/03/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SchedulePopup.h"

@interface SchedulePopup ()

@end

@implementation SchedulePopup

- (void)viewDidLoad {
    [super viewDidLoad];
    _lbl_msg.text  = _msg;
    _lbl_header.text  = _title_msg == nil ? @"Warning": _title_msg;
    [_btnOK setTitle:_btn_msg == nil ? @"Continue" : _btn_msg forState:0];
}
-(IBAction)btnContinue:(UIButton *)sender
{
    if ([sender.titleLabel.text isEqualToString:_btn_msg]) {
        self.view.tag = 100;
    }
    
    if (_s_delegate && [_s_delegate respondsToSelector:@selector(Continue:)]) {
        [_s_delegate Continue:self];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
